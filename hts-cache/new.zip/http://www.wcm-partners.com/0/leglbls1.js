

function objectToField(object,name,typeName,extraInfo){return oft_populateField(object,null,name,typeName,extraInfo);}

if(!otf_objectToFieldFxByType){var otf_objectToFieldFxByType=[];}

function registerConverter(fieldTypeName,conversionFx){if(!otf_objectToFieldFxByType){otf_objectToFieldFxByType=[];}

otf_objectToFieldFxByType[fieldTypeName]=conversionFx;}

function oft_populateField(object,parentField,name,typeName,extraInfo){var objectType=typeof(object);if("function"==objectType){return ;}

var isObject=object&&(objectType=='object');if(typeName){var converterFx=otf_objectToFieldFxByType[typeName];return converterFx(object,name,extraInfo);}

if(isObject){var field=object.length?new array_ArrayType(name,"",0):new collectionfield_Collection(name,"",0);var dO=1;for(var i in object)
{var typeIndicatorName=i+"_ft";var extraInfoName=typeIndicatorName+"i";var childField=oft_populateField(object[i],field,i,object[typeIndicatorName],object[extraInfoName]);if(childField){childField.displayOrder=dO;field.addChildField(childField);dO++;}

}

return field;}

else 
{return new field_String(name,"",0,object,false);}

}

function oft_isTypeIndicator(fieldName){var nameLength=fieldName.length;if(nameLength<=3){return false;}

var suffix=fieldName.substring(nameLength-3,nameLength);return ("_ft"==suffix)
}

;var IS_MOZILLA=document.getElementById&&!document.all;var IS_IE=document.all;var IS_CHROME=navigator.userAgent.toLowerCase().indexOf('chrome')>-1;var crossbrowser_browserName;var crossbrowser_wc3MouseButtons=[];crossbrowser_wc3MouseButtons.left=1;crossbrowser_wc3MouseButtons.middle=4;crossbrowser_wc3MouseButtons.right=2;var crossbrowser_ieMouseButtons=[];crossbrowser_ieMouseButtons.left=1;crossbrowser_ieMouseButtons.middle=4;crossbrowser_ieMouseButtons.right=2;function crossbrowser_findMouseButtonStatus(event,buttonPosition){var buttonNumber=(event)?crossbrowser_wc3MouseButtons[buttonPosition]:crossbrowser_ieMouseButtons[buttonPosition];var isPressed=false;if(!event){event=window.event;}

if(event.which){isPressed=(event.which==buttonNumber);}

else if(event.button){isPressed=(event.button==buttonNumber);}

return isPressed;}
;function crossbrowser_dispatchEvent(element,eventObject){
if(IS_IE){element.fireEvent("on"+eventObject.type,eventObject);}

else if(IS_MOZILLA){element.dispatchEvent(eventObject);}

}

function crossbrowser_isInDom(element){if(!element.parentNode){return false;}

else if(element.parentNode.tagName){return true;}

else 
{return false;}

}

function crossbrowser_getBrowserName(){if(crossbrowser_browserName){return crossbrowser_browserName;}

var userAgent=navigator.userAgent;if(userAgent){if(userAgent.indexOf("MSIE")!=-1){crossbrowser_browserName="Internet Explorer";return crossbrowser_browserName;}

else if(userAgent.indexOf("Firefox")!=-1){crossbrowser_browserName="Firefox";return crossbrowser_browserName;}

else if(userAgent.toLowerCase().indexOf('chrome')>-1){crossbrowser_browserName="Chrome";return crossbrowser_browserName;}

}

var vendor=navigator.vendor;if(vendor){if(userAgent.indexOf("Apple")!=-1){crossbrowser_browserName="Safari";return crossbrowser_browserName;}

}

else if(window.opera){crossbrowser_browserName="Opera";return crossbrowser_browserName;}

crossbrowser_browserName="Unknown";return crossbrowser_browserName;}

function crossbrowser_attachEvent(object,eventName,eventFunction){if(IS_MOZILLA){eventName=eventName.substring(2,eventName.length);object.addEventListener(eventName,eventFunction,false);}

else if(IS_IE){object.attachEvent(eventName,eventFunction);}

}

function crossbrowser_stopEvent(event){if(IS_MOZILLA){event.stopPropagation();event.preventDefault();}

else if(IS_IE){if(!event){event=window.event;}

event.returnValue=false;event.cancelBubble=true;}

}

function crossbrowser_handleEvent(event){if(IS_MOZILLA){event.stopPropagation();event.preventDefault();}

else if(IS_IE){window.event.returnValue=false;window.event.cancelBubble=true;}

}

function crossbrowser_cancelBubble(event){if(IS_MOZILLA){event.stopPropagation();}

else if(IS_IE&&event){event.cancelBubble=true;}

else if(IS_IE&&window.event){window.event.cancelBubble=true;}

}

function crossbrowser_getKeyCode(event){var key;if(IS_MOZILLA){key=(null!=event?event.which:window.event.keyCode);}

else if(IS_IE){key=window.event.keyCode;}

return key;}

function crossbrowser_getAttribute(anObject,attributeName){var value=(anObject[attributeName])?anObject[attributeName]:anObject.getAttribute(attributeName);return value;}

function crossbrowser_removeEvent(element,eventType,eventFunction){if(!eventFunction){return ;}

if(IS_MOZILLA){eventType=eventType.substring(2,eventType.length);element.removeEventListener(eventType,eventFunction,false);}

else if(IS_IE){element.detachEvent(eventType,eventFunction);}

}

function crossbrowser_checkBrowser(messageHandler){var isValidBrowser=true;if(navigator.userAgent.indexOf("Firefox")!=-1){var versionindex=navigator.userAgent.indexOf("Firefox")+8
if(parseInt(navigator.userAgent.charAt(versionindex))<2){crossbrowser_buildBrowserAlert("Firefox",messageHandler);isValidBrowser=false;}

}

else if(navigator.userAgent.indexOf("MSIE")!=-1){var temp=navigator.appVersion.split("MSIE")
var version=parseFloat(temp[1])
if(version<6){crossbrowser_buildBrowserAlert("MSIE",messageHandler);isValidBrowser=false;}

}

else if(navigator.userAgent.indexOf("Safari")!=-1){if(version<3){crossbrowser_buildBrowserAlert("Safari",messageHandler);isValidBrowser=false;}

}

return isValidBrowser;}

function crossbrowser_buildBrowserAlert(browserType,messageHandler){var table=document.createElement("table");table.width="100%";table.cellPadding=0;table.cellSpacing=0;g_cache.popup.editableDiv.appendChild(table);var tbody=document.createElement("tbody");table.appendChild(tbody);var tr=document.createElement("tr");tbody.appendChild(tr);var td=document.createElement("td");td.width=(document.documentElement.clientWidth)?document.documentElement.clientWidth:document.body.clientWidth;td.height=1000;td.style.position="absolute";td.style.backgroundColor="#eeeeee";td.vAlign="middle";td.align="center";tr.appendChild(td);if(browserType=="Firefox"){var element=messageHandler("Firefox","http://www.mozilla.com/en-US/firefox/upgrade");element.style.marginTop=200;td.appendChild(element);}

else if(browserType=="MSIE"){var element=messageHandler("Internet Explorer","http://www.microsoft.com/windows/downloads/ie/getitnow.mspx");td.appendChild(element);}

else if(browserType=="Safari"){var element=messageHandler("Safari","http://www.apple.com/safari/download");td.appendChild(element);}

}

function scrambleString(aString){return aString;}

function util_isInDom(element){if(!element.parentNode){return false;}

else if(element.parentNode.tagName){return true;}

else 
{return false;}

}

function crossbrowser_getIEVersion(){if(navigator.appName=='Microsoft Internet Explorer'){var rv=-1;var ua=navigator.userAgent;var re=new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");var ver=re.exec(ua)[1];if(ver!=null){rv=ver.charAt(0);}

}

return rv;}

function ajax_ProcessCache(cache,requestHandler){var isAsync=(requestHandler!=null)?true:false;var xmlRequest=ajax_getXMLHttpRequest();var url="ProcessCache.ajax";xmlRequest.open("POST",url,isAsync);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("cache="+cache);if(!isAsync){do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_addToCache(xmlRequest.responseText);}

}

}

while(xmlRequest.readyState!=4)}

else 
{xmlRequest.onreadystatechange=function(){if(xmlRequest.readyState==4){if(xmlRequest.status==200){var success=ajax_addToCache(xmlRequest.responseText);if(success){requestHandler();}

}

}

}

}

}

function ajax_addToCache(obj){var errorOccured="error_"+"ocurred"
var sessionExpired="session_"+"expired";if(obj==sessionExpired){alert("Your session has expired and you will be re-directed to the home page.");location.reload("");return false;}

else if(obj.indexOf(errorOccured)!=-1){if(errorOccured==obj){alert("A problem has occured and we have been notified. Please try again later");}

else 
{alert(obj);}

}

else 
{var temp=eval(obj);ajax_updateCache(cache);}

return true;}

function ajax_updateCache(cache){var recordsById=cache.recordsById;for(var recordId in recordsById)
{recordsById[recordId].ownerCache=g_cache;recordsById[recordId].init();g_cache.recordsById[recordId]=recordsById[recordId];}

var recordsByName=cache.recordsByName;for(var recordName in recordsByName)
{g_cache.recordsByName[recordName]=recordsByName[recordName];}

var templates=cache.templates;for(var type in templates)
{templates[type].ownerCache=g_cache;g_cache.templates[type]=templates[type];}

var dynTables=cache.dynTables;for(var type in dynTables)
{dynTables[type].ownerCache=g_cache;dynTables[type].init();g_cache.dynTables[type]=dynTables[type];}

var listsByName=cache.listsByName;for(var name in listsByName)
{listsByName[name].ownerCache=g_cache;listsByName[name].init();g_cache.listsByName[name]=listsByName[name];}

var listsByType=cache.listsByType;for(var type in listsByType)
{listsByType[type].ownerCache=g_cache;listsByType[type].init();g_cache.listsByType[type]=listsByType[type];}

g_cache.lastUpdate=new Date().getTime();cache=null;}

function ajax_doNothing(){}


function ajax_getXMLHttpRequest(){var xmlreq=null;if(window.XMLHttpRequest){xmlreq=new XMLHttpRequest();}

else if(window.ActiveXObject){try
{xmlreq=new ActiveXObject("Msxml2.XMLHTTP");}

catch(e)
{xmlreq=new ActiveXObject("Microsoft.XMLHTTP");}

}

else 
{alert("This browser does not support this feature");}

return xmlreq;}

function ajax_getReadyStateHandler(xmlRequest,responseXmlHandler){var requestHandler=function(){if(xmlRequest.readyState==4){if(xmlRequest.status==200){responseXmlHandler(xmlRequest.responseText);}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

return requestHandler;}


var constants_CUSTOM_SCREEN_TABLE_NAME="custom_screens";var constants_JAVASCRIPT_GLOBALS_TABLE_NAME="js_globals";var constants_EDITOR_PATH="editor";var constants_JS_EDITOR_PATH="jseditor";var constants_CACHE_NODE_NAME="cache";var constants_TO_LOAD_NOAD_NAME="to_load";var constants_TO_SAVE_NODE_NAME="to_save";var constants_TO_DELETE_NODE_NAME="to_delete"
var constants_TO_ADD_NODE_NAME="to_add";var constans_TO_UPDATE_NODE_NAME="to_update";var constants_PRIMARY_TYPE_ATTRIBUTE="primary_type";var constants_PRIMARY_ID_ATTRIBUTE="id";var constants_DYNTABLES_NODE_NAME="dyntables";var constants_RECORDS_NODE_NAME="records";var constants_LISTS_NODE_NAME="lists";var constants_TABLE_NODE_NAME="table";var constants_NAME_ATTRIBUTE="name";var constants_DISPLAY_NAME_ATTRIBUTE="displayName";var constants_RECORD_NODE_NAME="records";var constans_TYPE_ATTRIBUTE="type"
var constants_ID_ATTRIBUTE="id";var contants_FIELD_NODE_NAME="f";var contants_FIELD_TYPE_ATTRIBUTE="type";var contants_NAME_ATTRIBUTE="name";var contants_DISPLAY_NAME_ATTRIBUTE="dn";var contants_DISPLAY_ORDER_ATTRIBUTE="do";var contants_IS_MULTIPLE_ATTRIBUTE="multiple";var contants_VALUE_ATTRIBUTE="value";var contants_NEXT_UNNAMED_CHILD_COUNT_ATTRIBUTE="nucc";var contants_IS_STATIC_ATTRIBUTE="is_static";var constants_LESS_THAN_CHAR="!#"+"lessthanForXml!";var constants_GREATER_THAN_CHAR="!#"+"greaterthanForXml!";var constants_PERCENTAGE_SIGN="!#"+"percentagesing!";var constants_AND_SIGN="!#"+"andsign!";var constants_PLUS_SIGN="!#"+"plussign!";var constants_SPECIFIC_CAT_DEF="specific_category_definition";
function util_isInDom(element){if(!element.parentNode){return false;}

else if(element.parentNode.tagName){return true;}

else 
{return false;}

}

function util_getLength(aList){var counter=0;for(var i in aList)
{counter++;}

return counter;}

function util_replaceAllString(aString,stringValue,replaceString){var re=eval("/"+stringValue+"/g");return aString.replace(re,replaceString);}

function util_addUnderlineEvent(element){element.onmouseover=function(){element.style.textDecoration="underline"}
;element.onmouseout=function(){element.style.textDecoration=""}
;}

var g_processedHtmlForXml=null;function util_formatForXml(value){alert("this function should be used. Please notify Evan");var strForXml=g_processedHtmlForXml;var htmlString=value;htmlString=util_replaceAll(htmlString,"%",constants_PERCENTAGE_SIGN);htmlString=util_replaceAll(htmlString,"&",constants_AND_SIGN);htmlString=util_replaceAll(htmlString,"+",constants_PLUS_SIGN);ajax_getStringForXml(htmlString);var maxTimeTrying=2000;var startTime=new Date();while(null==strForXml&&((new Date()-startTime)<maxTimeTrying))
{strForXml=g_processedHtmlForXml;}

g_processedHtmlForXml=null;return strForXml;}

var util_mswordchars=[]
util_mswordchars[String.fromCharCode(8220)]='"';util_mswordchars[String.fromCharCode(8221)]='"';util_mswordchars[String.fromCharCode(8216)]="'";util_mswordchars[String.fromCharCode(8217)]="'";util_mswordchars[String.fromCharCode(8211)]="-";util_mswordchars[String.fromCharCode(8212)]="--";util_mswordchars[String.fromCharCode(189)]="1/2";util_mswordchars[String.fromCharCode(188)]="1/4";util_mswordchars[String.fromCharCode(190)]="3/4";util_mswordchars[String.fromCharCode(169)]="(C)";util_mswordchars[String.fromCharCode(174)]="(R)";util_mswordchars[String.fromCharCode(8230)]="...";function util_removeMsCharacters(value){for(var msChar in util_mswordchars)
{value=util_replaceAll(value,msChar,util_mswordchars[msChar])
}

return value;}

function util_removeEmbededScripts(html){var scriptStart=html.indexOf("<SCRIPT");var scriptEnd=html.indexOf("<"+"/SCRIPT>");while(scriptStart!=-1&&scriptEnd!=-1)
{var scriptString=html.substring(scriptStart,(scriptEnd+9));html=html.replace(scriptString,"");scriptStart=html.indexOf("<SCRIPT");scriptEnd=html.indexOf("<"+"/SCRIPT>");}

var scriptStart=html.indexOf("<script");var scriptEnd=html.indexOf("<"+"/script>");while(scriptStart!=-1&&scriptEnd!=-1)
{var scriptString=html.substring(scriptStart,(scriptEnd+9));html=html.replace(scriptString,"");scriptStart=html.indexOf("<script");scriptEnd=html.indexOf("<"+"/script>");}

return html;}

function util_addHiddenInput(name,value,container){var input=document.createElement("input")
input.type="hidden";input.value=value;input.name=name;container.appendChild(input);}

function util_clearElement(element){for(var i=element.childNodes.length-1;i>=0;i--)
{element.removeChild(element.childNodes[i]);}

}

function util_openFieldXmlTag(field){var xml=constants_LESS_THAN_CHAR+"f ";xml+="name='"+field.name+"' ";xml+=" dn='"+util_formatForXmlValue(field.displayName);xml+="' type='"+field.TYPE;xml+="' do='"+field.displayOrder+"'";var valueStr=(field.value==null)?">":" value='"+util_formatForXmlValue(field.value)+"'>";xml+=valueStr;return xml;}

function util_closeFieldXmlTag(){return constants_LESS_THAN_CHAR+"/f>";}

var util_reservedXmlChars=new Array();util_reservedXmlChars["'"]='!#'+'singlequote!';util_reservedXmlChars['<']='!#'+'lessthan!';util_reservedXmlChars['>']='!#'+'greaterthan!';util_reservedXmlChars['"']='!#'+'doublequote!';util_reservedXmlChars['&']='!#'+'andsign!';util_reservedXmlChars['%']='!#'+'percentagesing!';util_reservedXmlChars['+']='!#'+'plussign!';util_reservedXmlChars['&nbsp;']=' ';function util_formatValueForHtml(value){if(value==true||value==false){return value;}

else if(value==undefined||value==null||value==""){return "";}

for(var i in util_reservedXmlChars)
{if(i=='&nbsp;'){continue;}

value=util_replaceAll(value,util_reservedXmlChars[i],i);}

return value;}

function util_formatForXmlValue(value){if(value==true||value==false){return value;}

else if(value==undefined||value==null||value==""){return "";}

value=util_newReplaceAll(value,"'","!#"+"singlequote!");value=util_newReplaceAll(value,"<","!#"+"lessthan!");value=util_newReplaceAll(value,">","!#"+"greaterthan!");value=util_newReplaceAll(value,"\"","!#"+"doublequote!");value=util_newReplaceAll(value,"&","!#"+"andsign!");value=util_newReplaceAll(value,"%","!#"+"percentagesing!");value=util_newReplaceAll(value,"\n","!#"+"breakline!");value=util_newReplaceAll(value,"\\+","!#"+"plussign!");value=util_newReplaceAll(value,"&nbsp;"," ");
return value;}

function util_newReplaceAll(aString,replaceStr,replaceValue){if("string"!=typeof(aString)){return aString;}

var rE=new RegExp(replaceStr,"g");return aString.replace(rE,replaceValue);}


function util_replaceAll(aString,replaceStr,replaceValue){try
{var index=aString.indexOf(replaceStr);}

catch(e)
{return aString;}

while(index>-1)
{aString=aString.replace(replaceStr,replaceValue);index=aString.indexOf(replaceStr,index+replaceValue.length);}

return aString;}

;;;;var g_types;var g_cache;if(window["globals_webappPath"]==undefined){var globals_webappPath="";}

if(!g_currentDateTime){var g_currentDateTime=new cache_CurrentDateTime();}

function core_Cache(primaryType,primaryId,screenType,userHandle,userId,year,month,date,time){if(year){g_currentDateTime.month=month;g_currentDateTime.year=year;g_currentDateTime.date=date;g_currentDateTime.time=time;}

this.lastUpdate=new Date().getTime();this.isUpdated=false;this.primaryType=primaryType;this.primaryId=primaryId;this.screenType=screenType;this.userHandle=userHandle;this.userId=userId;this.isUpdated=false;this.typeList=null;this.fieldTypes=null;this.mainDynTable=null;this.mainRecord=null;this.mainList=null;this.recordsById=new Array();this.recordsByName=new Array();this.recordsByKey=new Array();this.dynTables=new Array();this.listsByType=new Array();this.listsByName=new Array();this.templates=new Array();this.dyntablesToDelete=new Array();this.dyntablesToLoad=new Array();this.dyntablesToSave=new Array();this.listsToLoad=new Array();this.recordsByType=new Array();this.recordsToSave=new Array();if(window.pop_Popup){this.popup=(g_cache==null)?new pop_Popup():g_cache.popup;}

this.init=function(){cache_init(this);}
;this.toXml=function(){return cache_toXml(this);}
;this.loadList=function(type){cache_loadList(type)}
;this.rebuildScreen=function(){cache_rebuildScreen(this)}
;this.addListToLoad=function(nameOrType,list){this.listsToLoad[nameOrType]=list;}
;this.getListByName=function(name){return this.listsByName[name.toLowerCase()];}
;this.getListByType=function(type){return this.listsByType[type];}
;this.getRecordToSave=function(type,id){return this.recordsToSave[type+id]}
;this.getRecordsToSaveOfAType=function(typeName){return cache_getRecordsToSaveOfAType(typeName,this)}
;this.getChildRecord=function(fieldName,parentRecord){return cache_getChildRecord(fieldName,parentRecord)}
;this.getRecordById=function(id){var record=(this.recordsById[id]==undefined)?null:this.recordsById[id];return record;}

this.getRecordByUniqueId=function(type,id){var record=(this.recordsById[type+id]==undefined)?null:this.recordsById[type+id];return record;}

this.getRecordByName=function(name){var recordId=this.recordsByName[name.toLowerCase()];return (recordId!=undefined)?this.getRecordById(recordId):this.getRecordById(name);}

this.addRecord=function(record){cache_addRecord(record,this);}
;this.addRecordToLoad=function(type,id,name){cache_addRecordToLoad(type,id,name,this);}
;this.addRecordToDelete=function(type,id){cache_addRecordToDelete(type,id,this);}
;this.addDynTableToDelete=function(type){this.dyntablesToDelete.push(type);}
;this.addDynTableToSave=function(table){this.dyntablesToSave.push(table);}
;this.addDynTableToLoad=function(type,loadFull,loadTemplate){if((this.dyntablesToLoad[type]==null||this.dyntablesToLoad[type]==undefined)&&type!=""){this.dyntablesToLoad[type]=new cache_DynTableRequest(type,loadFull,loadTemplate)
}

}

this.getRecordByKey=function(type,fieldName,keyword,name){return cache_getRecordByKey(type,fieldName,keyword,name,this)}
;this.getTemplate=function(type){return cache_getTemplate(type,this);}
;this.getRecord=function(type,recordId){return cache_getRecord(type,recordId,this)}
;this.getList=function(type){return cache_getList(type,this)}
;this.process=function(requestHandler){cache_process(this,requestHandler)}
;this.submitCache=function(path,isToSave){cache_submit(path,this)}
;this.submitCacheNoRefresh=function(){return cache_submitNoRefresh(this)}
;this.createList=function(type,name,doSave){return cache_createList(this,type,name,doSave)}

this.createRecord=function(type){return cache_createRecord(this,type)}
;this.createMessageSenderRecord=function(){return cache_createMessageSenderRecord(this)}
;this.clearRecord=function(recordName){cache_clearRecord(recordName)}
;this.createRecordToProcess=function(recordName){return cache_createRecordToProcess(this,recordName)}
;this.enableTransaction=function(){cache_EnableTransaction(this);return this;}
;g_types=this.typeList;return this;}

function cache_createRecordToProcess(cache,recordName){var record=new core_Record(recordName,0);record.addName(recordName);record.doProcess=true;cache.addRecord(record);return record;}

function cache_clearRecord(recordName){var uniqueId=g_cache.recordsByName[recordName];delete(g_cache.recordsById[uniqueId]);delete(g_cache.recordsByName[recordName]);}

var cache_nextMessageId=0;function cache_createMessageSenderRecord(thisObj){cache_nextMessageId--;var record=new core_Record("messageSender",cache_nextMessageId);record.fields.messageSender=new messagesender_MessageSender();record.fields.messageSender.buildChildFields();record.doProcess=true;record.ownerCache=thisObj;record.init();thisObj.addRecord(record);return record;}

function cache_getRecordsToSaveOfAType(typeName,thisObj){var recordsToSave=new Array();var recordsOfAType=thisObj.recordsByType[typeName];if(recordsOfAType!=null){for(var recordId in recordsOfAType)
{var aRecord=recordsOfAType[recordId];if(aRecord.toSave){recordsToSave.push(aRecord);}

}

}

return recordsToSave;}

function cache_getChildRecord(fieldName,parentRecord){var type=parentRecord.getFieldByName(fieldName).selectedType;var id=parentRecord.getFieldByName(fieldName).selectedId;return g_cache.getRecord(type,id);}

function cache_loadPresentationRecord(type,id){var path=(type==constants_CUSTOM_SCREEN_TABLE_NAME)?constants_EDITOR_PATH:constants_JS_EDITOR_PATH;var cache=new core_Cache(type,id,path);cache.addRecordToLoad(type,id)
cache.primaryId=id;cache.primaryType=path;cache.submitCache(path);}

function cache_submitNoRefresh(thisCache){var theForm=document.getElementById("upload_form");theForm.action=globals_webappPath+"/go";util_addHiddenInput("cache",thisCache.toXml(),theForm);try
{theForm.submit();return true;}

catch(e)
{alert("Some files you are trying to submit are not valid. Please select a valid file");return false;}

}

function cache_submit(path,thisCache){var theForm=document.forms[0];if(null==theForm){theForm=document.createElement("form");theForm.enctype="multipart/form-data";theForm.method="post";}

if(window["globals_webappPath"]){theForm.action=globals_webappPath+"/"+path;}

else 
{theForm.action="/"+path;}

util_addHiddenInput("cache",thisCache.toXml(),theForm);theForm.submit();thisCache=null;}

function cache_init(thisCache){for(var recordId in thisCache.recordsById)
{var record=thisCache.recordsById[recordId];record.ownerCache=thisCache;record.init();}

for(var type in thisCache.templates)
{thisCache.templates[type].ownerCache=thisCache;}

for(var type in thisCache.dynTables)
{thisCache.dynTables[type].ownerCache=thisCache;thisCache.dynTables[type].init();}

for(var name in thisCache.listsByName)
{thisCache.listsByName[name].ownerCache=thisCache;thisCache.listsByName[name].init();}

for(var name in thisCache.lists)
{thisCache.lists[name].ownerCache=thisCache;thisCache.lists[name].init();}

thisCache.mainDynTable=thisCache.dynTables[thisCache.primaryType];thisCache.mainRecord=thisCache.getRecordById(thisCache.primaryType+thisCache.primaryId);thisCache.mainList=thisCache.listsByType[thisCache.primaryType];}

function cache_addRecordToDelete(type,id,thisCache){var record=new core_Record(type,id);record.toDelete=true;cache_addRecord(record,thisCache);}

function cache_addRecord(record,thisCache){var records;if(thisCache.recordsByType[record.type]==undefined){records=new Array();thisCache.recordsByType[record.type]=records;}

else 
{records=thisCache.recordsByType[record.type];}

var existingRecord=records[record.type+record.id];if(existingRecord==null){records[record.type+record.id]=record;}

else 
{existingRecord.addNames(record.names);}

}

function cache_addRecordToLoad(type,id,name,thisCache){var record=new core_Record(type,id);record.toLoad=true;record.addName(name);var isAdded=false;if(thisCache.recordsByType[type]){isAdded=cache_isRecordOnList(record,thisCache.recordsByType[type])
}

if(!isAdded){cache_addRecord(record,thisCache);}

}

function cache_isRecordOnList(record,addedRecords){var isAdded=false;if(addedRecords[record.type+record.id]){var names=addedRecords[record.type+record.id].names;names=names.concat(record.names);addedRecords[record.type+record.id].toLoad=true;isAdded=true;}

return isAdded
}

function cache_toXml(thisCache){var xml=constants_LESS_THAN_CHAR+"cache primary_type='"+thisCache.primaryType+"' id='"+thisCache.primaryId+"' screen_type='"+thisCache.screenType+"'>";xml+=cache_dynTablesToXml(thisCache);xml+=cache_recordsToToXml(thisCache);xml+=cache_listsToXlm(thisCache);xml+=constants_LESS_THAN_CHAR+"/cache>";return xml;}

function cache_dynTablesToXml(thisCache){var xml=constants_LESS_THAN_CHAR+"dyntables>";xml+=constants_LESS_THAN_CHAR+"to_save>";xml+=cache_dyntableToSaveToXml(thisCache);xml+=constants_LESS_THAN_CHAR+"/to_save>";xml+=constants_LESS_THAN_CHAR+"to_load>";xml+=cache_dyntableToLoadToXml(thisCache);xml+=constants_LESS_THAN_CHAR+"/to_load>";xml+=constants_LESS_THAN_CHAR+"to_delete>";xml+=cache_dyntableToDeleteToXml(thisCache);xml+=constants_LESS_THAN_CHAR+"/to_delete>";xml+=constants_LESS_THAN_CHAR+"/dyntables>";return xml;}

function cache_dyntableToSaveToXml(thisCache){var xml="";for(tableName in thisCache.dyntablesToSave)
{xml+=thisCache.dyntablesToSave[tableName].toXml();}

return xml;}

function cache_dyntableToLoadToXml(thisCache){var xml="";for(i in thisCache.dyntablesToLoad)
{var table=thisCache.dyntablesToLoad[i]
xml+=constants_LESS_THAN_CHAR
xml+="table name='";xml+=table.name;xml+="' load_full='";xml+=table.loadFull
xml+="' load_template='"
xml+=table.loadTemplate
xml+="'/>";}

return xml;}

function cache_dyntableToDeleteToXml(thisCache){var xml="";for(var i=0;i<thisCache.dyntablesToDelete.length;i++)
{xml+=constants_LESS_THAN_CHAR+"table name='"+thisCache.dyntablesToDelete[i]+"'/>";}

return xml;}

function cache_recordsToToXml(thisCache){var xml=constants_LESS_THAN_CHAR+"records>";for(var type in thisCache.recordsByType)
{var records=thisCache.recordsByType[type];if(null==records){continue
}

for(var recordId in records)
{xml+=records[recordId].toXml();}

}

xml+=constants_LESS_THAN_CHAR+"/records>";thisCache.recordsByType=new Array();return xml;}

function cache_listsToXlm(thisCache){var xml=constants_LESS_THAN_CHAR+"lists>";xml+=constants_LESS_THAN_CHAR+"to_load>";for(var nameOrType in thisCache.listsToLoad)
{xml+=thisCache.listsToLoad[nameOrType].toXml();}

xml+=constants_LESS_THAN_CHAR+"/to_load>";xml+=constants_LESS_THAN_CHAR+"/lists>";return xml;}

function cache_process(thisCache,requestHandler){if(null!=g_cache){thisCache.primaryType=g_cache.primaryType;thisCache.primaryId=g_cache.primaryId;thisCache.screenType=g_cache.screenType;}

var cacheXml=thisCache.toXml();ajax_ProcessCache(cacheXml,requestHandler);thisCache=null;}

function cache_createList(thisCache,type,name,doSave){var list=new core_List(type,[],name);list.createRequiredChildren(doSave);thisCache.addListToLoad(name,list);return list;}

function cache_createRecord(thisCache,type){var record=thisCache.getTemplate(type).clone()
record.toSave=true;record.ownerCache=thisCache;thisCache.addRecord(record);thisCache.recordsToSave[type+record.id]=record;return record;}

function cache_getRecordByKey(type,fieldName,keyword,name,thisCache){var record=g_cache.getRecordByName(name);if(null==record){var cache=new core_Cache('',-1)
cache.addRecordToLoadByKey(fieldName,keyword,type,name);cache.process();var maxTimeTrying=2000;var startTime=new Date();while(null==record&&((new Date()-startTime)<maxTimeTrying))
{record=g_cache.getRecordByName(name);}

cache=null;}

return record;}

function cache_getTemplate(type,thisCache){var template=g_cache.templates[type];if(null==template){var cache=new core_Cache('',-1);cache.addDynTableToLoad(type,false,true);cache.process();var maxTimeTrying=2000;var startTime=new Date();while(null==template&&((new Date()-startTime)<maxTimeTrying))
{template=g_cache.templates[type];}

cache=null;}

return template;}

function cache_getRecord(type,recordId,thisCache){var record=null
if(recordId==0){record=g_cache.getTemplate(type).clone();return record;}

record=g_cache.getRecordById(type+recordId);if(null==record){var cache=new core_Cache('',-1)
cache.addRecordToLoad(type,recordId);cache.process();cache=null;record=g_cache.getRecordById(type+recordId);
cache=null;}

return record;}

function cache_getList(type,thisCache){var list=g_cache.getListByType(type);if(null==list){var cache=new core_Cache('',-1)
cache.createList(type,type,false);cache.process();var maxTimeTrying=2000;var startTime=new Date();while(null==list&&((new Date()-startTime)<maxTimeTrying))
{list=g_cache.getListByType(type);}

cache=null;}

if(null==list){alert("failed to load list with ajax");}

return list;}

function cache_DynTableRequest(name,loadFull,loadTemplate){this.name=name;this.loadFull=loadFull
this.loadTemplate=loadTemplate;}

function cache_CurrentDateTime(){this.year;this.date;this.month;this.timeInSeconds;}

function cache_EnableTransaction(thisCache){thisCache.bTransactionMode=true;}

var ButtonUtil=new ButtonUtilDef();function ButtonUtilDef(){
this.buildButton=function(parentEl,label,onClickFx){var button=this.createButtonHolder(parentEl,onClickFx);button.innerHTML=label;var styleKeys=[];this.addToStyleList(styleKeys,"default");for(var i=3;i<arguments.length;i++)
{var key=arguments[i];this.addToStyleList(styleKeys,key);}

var styleData=this.combineStyles(styleKeys);setStyles(button,styleData);if(styleData.underline){addUnderlineEvents(button);}

button.className=styleData.className;return button;}

this.focusButtonEl;this.blur=function(){document.body.onkeyup=null;}
;
this.setDefaultButtonStyle=function(styleData){this.addButtonStyle("default",styleData);}


this.addButtonStyle=function(styleKey,styleData){this.buttonStyle[styleKey]=styleData;}

this.turnIntoButton=function(element,onClickFx,underline){element.tabIndex=0;element.style.cursor="pointer";if(underline){addUnderlineEvents(element);}

var thisObj=this;var onFocusFx=function(){thisObj.blur();var onKeyDown=function(event){var keyCode=IS_IE?event.keyCode:event.which;if(13==keyCode){thisObj.blur();onClickFx();}

}
;eh_attachEvent("onkeyup",document.body,onKeyDown,null,false);}
;eh_attachEvent("onfocus",element,onFocusFx,null,true,null,true,false,false);var onclickFx=function(event){thisObj.blur();onClickFx(event);}
;eh_attachEvent("onclick",element,onclickFx,null,true,null,true,false,false);var onBlurFx=function(){thisObj.blur();document.body.onkeyup=null;}
;if(!this.isUnFocusInitialized){this.initUnFocus();this.isUnFocusInitialized=true;}

}

this.isUnFocusInitialized=false;this.initUnFocus=function(){var thisObj=this;var fx=function(){thisObj.blur();}

crossbrowser_attachEvent(document.body,"onclick",fx);}
;this.createButtonHolder=function(parentEl,onClickFx){var holder=cE("a",parentEl);holder.style.cursor="pointer";holder.style.textDecoration="none";holder.tabIndex=0;holder.href="#";var contentArea=cE("span",holder);contentArea.style.margin="1px";eh_attachEvent("onclick",contentArea,onClickFx);var onFocusFx=function(){var onKeyDown=function(event){var keyCode=IS_IE?event.keyCode:event.which;if(13==keyCode){onClickFx();}

}
;eh_attachEvent("onkeyup",document.body,onKeyDown,null,false);}
;eh_attachEvent("onfocus",holder,onFocusFx,null,true,null,true,false,false);var thisObj=this;var onBlurFx=function(){thisObj.blur();}
;eh_attachEvent("onblur",holder,onBlurFx,null,true,null,true,false,false);return contentArea;}

this.addToStyleList=function(styleKeys,key){var styleData=this.buttonStyle[key];var otherStyles=styleData.otherStyles;if(otherStyles){for(var j=0;j<otherStyles.length;j++)
{styleKeys.push(otherStyles[j]);}

}

styleKeys.push(key);}
;this.combineStyles=function(styleKeys){var underline=false;var classNames={}
;var styles={}
;for(var i=0;i<styleKeys.length;i++)
{var aStyleData=this.buttonStyle[styleKeys[i]];if(aStyleData.underline){underline=true;}

var classStr=aStyleData.className;if(classStr){var classArray=classStr.split(" ");for(var j=0;j<classArray.length;j++)
{classNames[classArray[j]]=true;}

}

var aStyle=aStyleData.style;if(aStyle){for(var j in aStyle)
{styles[j]=aStyle[j];}

}

}

var className="";for(var i in classNames)
{className+=" "+i;}

return {style:styles,underline:underline,className:className}
;}
;this.buttonStyle={}
;this.addPresetButtonStyles=function(){var styleData={style:{fontWeight:"bold"}
}
;this.addButtonStyle("bold",styleData);var styleData={style:{padding:"6px 15px",height:"30px",color:"#474645"}
,className:"mediumText"}
;this.addButtonStyle("medium",styleData);var styleData={style:{padding:"3px 15px 0 15px",height:"24px"}
,className:"smallText"}
;this.addButtonStyle("small",styleData);var styleData={style:{color:"white","backgroundColor":"#336699","backgroundRepeat":"repeat-x","backgroundImage":"url(/upload/custom_screens/blog/admin/blue_btn_bg.gif)"}
,underline:true}
;this.addButtonStyle("blue",styleData);var styleData={style:{color:"white","backgroundColor":"#E78417","backgroundRepeat":"repeat-x","backgroundImage":"url(/upload/custom_screens/blog/admin/orange_btn_bg.gif)"}
,underline:true}
;this.addButtonStyle("orange",styleData);var styleData={style:{border:"1px solid #CCCCCC","backgroundColor":"#E6E6E6","backgroundRepeat":"repeat-x","backgroundImage":"url(/upload/custom_screens/commons/light_blue_btn_bg.gif)"}
,className:"linkColor",underline:true}
;this.addButtonStyle("light-blue",styleData);var styleData={style:{color:"#1A1A68"}
,otherStyles:["light-blue","medium"]}
;this.setDefaultButtonStyle(styleData);}
;this.addPresetButtonStyles();}




function cE(tagName,parentEl,doc){if(!doc){doc=getParentDocument(parentEl);}

var element=doc.createElement(tagName);if(parentEl){parentEl.appendChild(element);}

return element;}


function gL(selectors){return document.querySelectorAll(selectors);}


function gE(selector,doc){if(!doc){doc=document;}

return doc.querySelector(selector);}


function sA(element,name,value){element.setAttribute(name,value);}


function rA(element,name){element.removeAttribute(name);}


function gA(element,name){if(element.nodeType!=1){return null;}

return element.getAttribute(name);}


function cC(tBody){var tr=cE("tr",tBody);var td=cE("td",tr);return td;}


function iE(tagName,parentEl,insertIndex){var doc=getParentDocument(parentEl);var element=doc.createElement(tagName);try
{parentEl.insertBefore(element,parentEl.childNodes[insertIndex]);}

catch(e)
{parentEl.appendChild(element);}

return element;}


function aE(parentEl,element){parentEl.appendChild(element);}


function createTable(parentEl,width,height){var doc=getParentDocument(parentEl);var table=doc.createElement("table");table.cellPadding=0;table.cellSpacing=0;if(width){table.style.width=(!isNaN(width))?width+"px":width;}

if(height){table.style.height=(!isNaN(height))?height+"px":height;}

parentEl.appendChild(table);var tBody=doc.createElement("tbody");table.appendChild(tBody);return tBody;}


function getPlainText(element){var linesArray=new Array();var fx=function(element,linesArray){var displayType=CssUtil.getStyle(element,"display");if(!(displayType=="inline"||displayType=="inline-block")&&linesArray[linesArray.length-1]!=""){linesArray.push("");}

if(element.nodeType==3){linesArray[linesArray.length-1]=linesArray[linesArray.length-1]+element.data;}

else if(element.firstChild){fx(element.firstChild,linesArray);}

if(element.nextSibling){fx(element.nextSibling,linesArray);}

}
;fx(element,linesArray);return linesArray;}
;
function getParentDocument(element){var doc=null;if(element==null||element.ownerDocument==null){doc=document;}

else 
{doc=element.ownerDocument;}

return doc;}

function cls(parentEl,label,onclickFx,eventGroupName){var s=cE("span",parentEl);s.className="text linkColor";s.innerHTML=label;addUnderlineEvents(s,"main");var clickFx=(onclickFx)?onclickFx:function(){}
;eh_attachEvent("onclick",s,clickFx,eventGroupName);return s;}

function cli(parentEl,src,onclickFx,eventGroupName){var i=cE("img",parentEl);i.src=src;i.style.cursor="pointer";eh_attachEvent("onclick",i,onclickFx,eventGroupName);return i;}

function cb(parentEl,label,onclickFx,eventGroupName){var b=cE("button",parentEl);b.className="text";b.innerHTML=label;b.setAttribute('type',"button");eh_attachEvent("onclick",b,onclickFx,eventGroupName);return b;}
;function docGetEl(id){return document.getElementById(id);}

function addUnderlineEvents(element,eventGroupName){var mouseOverFx=function(){element.style.textDecoration='underline'}
;eh_attachEvent("onmouseover",element,mouseOverFx,eventGroupName,false,null,null,null,true);var mouseOutFx=function(){element.style.textDecoration=''}
;eh_attachEvent("onmouseout",element,mouseOutFx,eventGroupName,false,null,null,null,true);element.style.cursor="pointer";}
;

var JsUtil=new JsUtilBase();function JsUtilBase(){this.isEmpty=function(object){for(var i in object)
{var notEmpty=object[i];return false;}

return true;}
;this.round=function(number,noOfDecimals){var k=Math.pow(10,noOfDecimals);return Math.round(number*k)/k;}
;}

function js_isEmpty(object){for(var i in object)
{var notEmpty=object[i];return false;}

return true;}


function isInDom(element){var parentNode=element.parentNode;if(!parentNode){return false;}

else if(!parentNode.tagName){return false;}

else if(parentNode.tagName.toLowerCase()=="body"){return true;}

else if(parentNode){return isInDom(parentNode);}

else 
{return true;}

}



;var eh_events=[];
function eh_attachEvent(eventType,element,eventFx,eventGroupName,stopEvent,ownerWindow,doReturn,returnValue,allowBubbling){element[eventType]=function(event){ownerWindow=(!ownerWindow)?window:ownerWindow;event=(!event)?ownerWindow.event:event;if(eventFx){eventFx(event);}

if(stopEvent){crossbrowser_stopEvent(event);}

else if(!allowBubbling){crossbrowser_cancelBubble(event);}

if(doReturn){return returnValue;}

}
;eh_registerEvent(element,eventType,eventGroupName);}
;function eh_attachOnMouseEnter(element,fx,ownerWindow){if(BrowserUtil.isIE()||BrowserUtil.isFF()){eh_attachEvent("onmouseenter",element,fx,null,null,ownerWindow);}

else 
{element.onmouseover=function(event){if(!event){ownerWindow=(!ownerWindow)?window:ownerWindow;event=ownerWindow.event;}

if(!isDescendent(event.fromElement,event.currentTarget)&&isDescendent(event.toElement,event.currentTarget)){fx(event);}

}
;eh_registerEvent(element,"onmouseover");}

}

function eh_attachOnMouseLeave(element,fx,ownerWindow){if(BrowserUtil.isIE()||BrowserUtil.isFF()){eh_attachEvent("onmouseleave",element,fx,null,null,ownerWindow);}

else 
{var outFx=function(){if(!isInDom(element)){document.body.removeEventListener("mouseout",outFx,false);}

if(isDescendent(event.srcElement,element)&&!isDescendent(event.toElement,element)){fx(event);}

}

eh_addEvent("onmouseout",document.body,outFx);}

}


function eh_removeEventHandler(element,eventType,eventFx){if(!eventFx){return ;}

if(element.removeEventListener){var evType=eventType.substring(2,eventType.length);element.removeEventListener(evType,eventFx,false);}

else if(element.detachEvent){element.detachEvent(eventType,eventFx);}

}
;
function eh_attachBeforeUnload(onBeforeUnloadFx){var isAlreadyRun=false;var fx=function(){if(!isAlreadyRun){isAlreadyRun=true;onBeforeUnloadFx();}

}

eh_addEvent("onbeforeunload",window,fx);}

function eh_addEvent(eventName,object,eventFunction){if(document.getElementById&&!document.all){eventName=eventName.substring(2,eventName.length);object.addEventListener(eventName,eventFunction,false);}

else if(document.all){object.attachEvent(eventName,eventFunction);}

}

function eh_getSource(event){return event.target||event.srcElement;}


function eh_attachEventNoRegister(eventType,element,eventFx,eventGroupName,stopEvent,ownerWindow,doReturn,returnValue,allowBubbling){element[eventType]=function(event){ownerWindow=(!ownerWindow)?window:ownerWindow;event=(!event)?ownerWindow.event:event;if(eventFx){eventFx(event);}

if(stopEvent){crossbrowser_stopEvent(event);}

else if(!allowBubbling){crossbrowser_cancelBubble(event);}

if(doReturn){return returnValue;}

}
;}

function eh_registerEvent(element,eventType,eventGroupName){if(!IS_IE){return ;}

if(!eventGroupName){eventGroupName="default";}

var eventGroup=eh_events[eventGroupName];if(!eventGroup){eventGroup=[];eh_events[eventGroupName]=eventGroup;}

var eventsByType=eventGroup[eventType];if(!eventsByType){eventsByType=[];eventGroup[eventType]=eventsByType;}

eventsByType.push(element);}


function eh_clearEventGroup(eventGroupName,omitGC){eh_clearEventsNotInDom();}

function eh_clearEventsNotInDom(){for(var groupName in eh_events)
{eh_clearUnusedEvents(eh_events[groupName]);}

if(IS_IE){CollectGarbage();}

}

function eh_clearUnusedEvents(eventGroup){for(var eventType in eventGroup)
{var eventsByType=eventGroup[eventType];var count=eventsByType.length;for(var i=0;i<count;i++)
{try
{if(!isInDom(eventsByType[i])){eventsByType[i][eventType]=null;}

}

catch(e)
{}

}

}

}


function eh_clearAllEvents(){for(var groupName in eh_events)
{eh_clearEventGroup(groupName,true);}

document.body.onunload=null;if(IS_IE){CollectGarbage();}

}

function eh_initalizeGC(){document.body.onunload=eh_clearAllEvents;}


function clone(myObj){if(typeof(myObj)!='object'){return myObj;}

if(myObj==null){return myObj;}

var myNewObj=[];if(myObj.length&&myObj[0]!=undefined&&!myObj["0_ft"]){for(var i=0;i<myObj.length;i++)
{myNewObj.push(clone(myObj[i]));}

}

else 
{for(var i in myObj)
{myNewObj[i]=clone(myObj[i]);}

}

return myNewObj;}



if(!mc_fieldTypeExtenders){var mc_fieldTypeExtenders={}
;}


mc_fieldTypeExtenders["RIL2"]=function(dynField){dynField.superGetChildField=dynField.getChildField;extendField(dynField,ril_recordIdListBase);}

var ril_recordIdListBase=new RecordIdListBase();function RecordIdListBase(){this.getIds=function(){if(!this.data.idArray){var idsField=this.getChildField("ids");var idList=idsField.getValue();this.data.idArray=(""==idList)?[]:idList.split("|");for(var i=0;i<this.data.idArray.length;i++)
{var id=this.data.idArray[i];if(id==""){this.data.idArray.splice(i,1);}

}

idsField.setValue("refer to id array",true);}

return this.data.idArray;}
;this.getChildField=function(fieldName){if(fieldName=="ids"){var ids=this.superGetChildField(fieldName);ids.setValue=function(value,isDontSetSave){var liveField=this.getLiveField();this.setFieldValue(this,value,isDontSetSave);if(liveField){this.setFieldValue(liveField,value,isDontSetSave);}

return this;}
;return ids;}

else 
{return this.superGetChildField(fieldName);}

}
;this.clearIds=function(){var liveField=this.getLiveField();this.getChildField("ids").setValue("refer to id array",true);var idArray=[];this.data.idArray=idArray;if(liveField){liveField.data.idArray=idArray;}

this.setDoSave();}
;this.addId=function(id){if(this.contains(id)){return this;}

this.setDoSave();var idsList=this.getIds();idsList.push(id);return this;}
;this.contains=function(id){var ids=this.getIds();for(var i=0;i<ids.length;i++)
{if(ids[i]==id){return true;}

}

return false;}
;this.removeId=function(id){this.setDoSave();var idsList=this.getIds();for(var i=0;i<idsList.length;i++)
{if(idsList[i]==id){idsList.splice(i,1);break;}

}

return this;}
;}



var ADateUtil=new ADateUtilBase();function ADateUtilBase(){
this.MONTH_ABBR="m_abbr";
this.MONTH_STR="m_full";
this.DAY_ABBR="d_abbr";
this.DAY_STR="d_full";
this.DAY_LETTER="day_letter";
this.DATE_ABBR="dt_abbr";
this.DATE="date";
this.MONTH="month";
this.YEAR="year";
this.adjustMonth=function(dateObj,interval){var month=dateObj.month+interval;var year=dateObj.year;if(1>month){month+=12;year--;}

else if(12<month){month-=12;year++;}

var newMonthDayCount=this.getMonthDayCount(month,year);var date=Math.min(dateObj.date,newMonthDayCount);return new ADate(date,month,year);}
;
this.getCurrentDate=function(){var currentDate=g_sessionInformation.current_datetime;return new ADate(currentDate.date,currentDate.month,currentDate.year);}


this.stringToDate=function(dateString,dateObj){var re=new RegExp("\\D*(\\d*)\\D*(\\d*)\\D*(\\d*)\\D*");var result=re.exec(dateString);if(null==result){return null;}

var date=this.parseDatePart(result[this.DATE_POS]);var month=this.parseDatePart(result[this.MONTH_POS]);var year=this.parseDatePart(result[this.YEAR_POS])
if(year<30){year+=2000;}

else if(year>30&&year<100){year+=1900;}

if(this.isValidDate(date,month,year)){if(dateObj!=null){dateObj.date=date;dateObj.month=month;dateObj.year=year;}

else 
{dateObj=new ADate(date,month,year);}

return dateObj;}

else 
{return null;}

}


this.dbFormatToDate=function(str){var dateObj=str.split("-");return new ADate(dateObj[2],dateObj[1],dateObj[0]);}


this.getLabel=function(labelKey,index){var labels=this.getLabels(labelKey);if(null==labels){return null;}

if(labelKey==this.MONTH_ABBR||labelKey==this.MONTH_STR){index--;}

return labels[index];}
;
this.getLabels=function(labelKey){var labels=this.LABEL_KEYS[labelKey];if(null==labels){return null;}

return labels;}


this.getMonthDayCount=function(month,year){var dayCounts=[31,-1,31,30,31,30,31,31,30,31,30,31];var dayCount;if(month==2){dayCount=this.isLeapYear(year)?29:28;}

else 
{dayCount=dayCounts[month-1];}

return dayCount;}


this.getInterval=function(dateObj1,dateObj2){var interval=0;var date1DbFormat=dateObj1.toDbFormat();var date2DbFormat=dateObj2.toDbFormat();var dateA;var dateB;if(date1DbFormat<date2DbFormat){dateA=dateObj1.clone();dateB=dateObj2.clone();}

else if(date1DbFormat>date2DbFormat){dateA=dateObj2.clone();dateB=dateObj1.clone();}

else 
{return 0;}

while(!dateA.equals(dateB))
{interval++;dateA.changeDate(1);}

return interval;}
;
this.TYPE="DATE";
this.EMPTY_DATE="MM/dd/yyyy";
this.SEPARATOR="/";
this.MONTH_POS=1;
this.DATE_POS=2;
this.YEAR_POS=3;
this.NULL_DATE="0000-00-00";
this.LABEL_KEYS=[];{var mAbbr=[];mAbbr.push("Jan");mAbbr.push("Feb");mAbbr.push("Mar");mAbbr.push("Apr");mAbbr.push("May");mAbbr.push("Jun");mAbbr.push("Jul");mAbbr.push("Aug");mAbbr.push("Sep");mAbbr.push("Oct");mAbbr.push("Nov");mAbbr.push("Dec");this.LABEL_KEYS[this.MONTH_ABBR]=mAbbr;}

{var months=[];months.push("January");months.push("February");months.push("March");months.push("April");months.push("May");months.push("June");months.push("July");months.push("August");months.push("September");months.push("October");months.push("November");months.push("December");this.LABEL_KEYS[this.MONTH_STR]=months;}

{var dAbbrv=[];dAbbrv.push("Sun");dAbbrv.push("Mon");dAbbrv.push("Tue");dAbbrv.push("Wed");dAbbrv.push("Thu");dAbbrv.push("Fri");dAbbrv.push("Sat");this.LABEL_KEYS[this.DAY_ABBR]=dAbbrv;}

{var days=[];days.push("Sunday");days.push("Monday");days.push("Tuesday");days.push("Wednesday");days.push("Thursday");days.push("Friday");days.push("Saturday");this.LABEL_KEYS[this.DAY_STR]=days;}

{var days=[];days.push("S");days.push("M");days.push("T");days.push("W");days.push("T");days.push("F");days.push("S");this.LABEL_KEYS[this.DAY_LETTER]=days;}

this.selectDatePart=function(partNumber,date,month,year){if(partNumber==this.DATE_POS){return this.formatDatePart(date);}

else if(partNumber==this.MONTH_POS){return this.formatDatePart(month);}

else if(partNumber==this.YEAR_POS){return year;}

}
;this.formatDatePart=function(number){if(number<10){return "0"+number;}

return parseInt(number,10);}
;this.parseDatePart=function(datePart){var i=0;while(datePart.charAt(i)=='0')
{i++;}

var datePart=datePart.substring(i,datePart.length);return parseInt(datePart,10);}
;
this.isValidDate=function(date,month,year){if(isNaN(date)||isNaN(month)||isNaN(year)){return false;}

if(month<1||month>12){return false;}

var daysInMonth=this.getMonthDayCount(month,year);if(date>daysInMonth){return false;}

if(year<1000){return false;}

return true;}
;
this.isLeapYear=function(year){if(((year%4)==0)&&((year%100)!=0)||((year%400)==0)){return true;}

else 
{return false;}

}
;this.initDateFormat=function(){try
{var dateFormat=g_sessionInformation.settings.date_format;this.EMPTY_DATE=dateFormat.empty_date;this.SEPARATOR=dateFormat.separator;this.DATE_POS=dateFormat.date_pos;this.MONTH_POS=dateFormat.month_pos;this.YEAR_POS=dateFormat.year_pos;}

catch(e)
{}

}
;this.initDateFormat();}
;
String.prototype.trim=function(){return trim(this)}
;String.prototype.safeGetValue=function(val,defVal){return safeGetValue(val,defVal)}
;String.prototype.escapeStrForSave=function(){return escapeStrForSave(this)}
;String.prototype.unescapeStrFromLoad=function(){return unescapeStrFromLoad(this)}
;String.prototype.escapeStrForXml=function(){return escapeStrForXml(this)}
;String.prototype.unescapeStrFromXml=function(){return unescapeStrFromXml(this)}
;String.prototype.sc={"\\":"\\\\","(":"\\(","^":"\\^","$":"\\$",".":"\\.","|":"\\|","?":"\\?","*":"\\*","+":"\\+",")":"\\)"}
;String.prototype.equals=function(value){return value==this;}
;String.prototype.replaceAll=function(replaceVal,replaceWith){try
{var sc=this.sc
for(var aChar in this.sc)
{var rChar=sc[aChar];replaceVal=replaceVal.replace(aChar,rChar);}

return this.replace(new RegExp(replaceVal,"g"),replaceWith);}

catch(e)
{return this.replace(new RegExp(replaceVal,"g"),replaceWith);}

}

function trim(str){var str=str.replace(/^\s\s*/,'');var ws=/\s/;var i=str.length;while(ws.test(str.charAt(--i))){}
;return str.slice(0,i+1);}

function safeGetValue(val,defVal){if(null!=val){return val;}

return defVal;}

function escapeStrForSave(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("[+]","g"),"!@!plus!@!");strRet=strRet.replace(new RegExp("[\n]","g"),"!@!newline!@!");return strRet;}

function unescapeStrFromLoad(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("!@!plus!@!","g"),"+");strRet=strRet.replace(new RegExp("!@!newline!@!","g"),"\n");return strRet;}

function escapeStrForXml(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("[&]","g"),"&amp;");strRet=strRet.replace(new RegExp("[']","g"),"&apos;");strRet=strRet.replace(new RegExp("[\"]","g"),"&quot;");strRet=strRet.replace(new RegExp("[<]","g"),"&lt;");strRet=strRet.replace(new RegExp("[>]","g"),"&gt;");return strRet;}

function unescapeStrFromXml(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("&amp;","g"),"&");strRet=strRet.replace(new RegExp("&apos;","g"),"'");strRet=strRet.replace(new RegExp("&quot;","g"),"\"");strRet=strRet.replace(new RegExp("&lt;","g"),"<");strRet=strRet.replace(new RegExp("&gt;","g"),">");return strRet;}

;;function ADate(date,month,year){try
{this.date=parseInt(date,10);this.month=parseInt(month,10);this.year=parseInt(year,10);}

catch(e)
{this.date=date;this.month=month;this.year=year;}

}
;ADate.prototype=new ADateBase();function ADateBase(){
this.getDayIndex=function(){var aDate=new Date(this.year,this.month-1,this.date);return aDate.getDay();}
;
this.toDbFormat=function(){if(!ADateUtil.isValidDate(this.date,this.month,this.year)){return ADateUtil.NULL_DATE;}

return this.year+"-"+ADateUtil.formatDatePart(this.month)+"-"+ADateUtil.formatDatePart(this.date);}
;
this.update=function(dateStr){return ADateUtil.stringToDate(dateStr,this);}
;
this.getString=function(params){if(null==params||params.length<1){return this.toDefaultString();}

var monthStr="";var monthPos=-1;var dateStr="";var datePos=-1;var fullStr="";for(var i=0;i<params.length;i++)
{switch(params[i]){
case'm_abbr':
monthStr=ADateUtil.getLabel('m_abbr',this.month);fullStr+="!monthStr!";monthPos=i;break;case'm_full':
monthStr=ADateUtil.getLabel('m_full',this.month);fullStr+="!monthStr!";monthPos=i;break;case'd_abbr':
fullStr+=ADateUtil.getLabel('d_abbr',this.getDayIndex());break;case'd_full':
fullStr+=ADateUtil.getLabel('d_full',this.getDayIndex());break;case'dt_abbr':

alert("do we need to abbreviate dates???");break;case'date':
fullStr+="!dateStr!";dateStr=this.date;datePos=i;break;case'month':
fullStr+="!monthStr!";monthStr=this.month;monthPos=i;break;case'year':
fullStr+=this.year;break;default:
fullStr+=params[i];}

}

var usDateFormat="!monthStr!/!dateStr!/"+this.year;if(fullStr.indexOf(usDateFormat)>-1){fullStr=fullStr.replace(usDateFormat,this.toDefaultString());}

else 
{var isDefaultMonthFirst=(ADateUtil.MONTH_POS<ADateUtil.DATE_POS);var isMonthFirst=(monthPos<datePos);if(isDefaultMonthFirst!=isMonthFirst){if(fullStr.indexOf("!dateStr")>0&&fullStr.indexOf("!monthStr")>0){fullStr=fullStr.replaceAll("!dateStr!",monthStr);fullStr=fullStr.replaceAll("!monthStr!",dateStr);}

else 
{fullStr=fullStr.replaceAll("!monthStr!",monthStr);fullStr=fullStr.replaceAll("!dateStr!",dateStr);}

}

else 
{fullStr=fullStr.replaceAll("!dateStr!",dateStr);fullStr=fullStr.replaceAll("!monthStr!",monthStr);}

}

return fullStr;}
;
this.changeDate=function(numberOfDays){numberOfDays=parseInt(numberOfDays,10);if(0==numberOfDays){return this;}
;var dayOfYear=numberOfDays;var isLeapYear=ADateUtil.isLeapYear(this.year);var daysInYear=(isLeapYear)?366:365;var daysInFebruary=(isLeapYear)?29:28;var dayCounts=[0,31,daysInFebruary,31,30,31,30,31,31,30,31,30,31];for(var i=1;i<this.month+1;i++)
{if(i==this.month){dayOfYear+=this.date;break;}

dayOfYear+=dayCounts[i];}

while(dayOfYear>daysInYear)
{dayOfYear=dayOfYear-daysInYear;this.year=this.year+1;isLeapYear=ADateUtil.isLeapYear(this.year);daysInYear=(isLeapYear)?366:365;}

while(dayOfYear<=0)
{isLeapYear=ADateUtil.isLeapYear(this.year-1);daysInYear=(isLeapYear)?366:365;dayOfYear=daysInYear+dayOfYear;this.year=this.year-1;}

daysInFebruary=(isLeapYear)?29:28;dayCounts=[0,31,daysInFebruary,31,30,31,30,31,31,30,31,30,31];for(var i=1;i<dayCounts.length;i++)
{var dayCount=dayCounts[i];if(dayCount>=dayOfYear){this.month=i;this.date=dayOfYear;break;}

dayOfYear-=dayCount;}

return this;}
;
this.clone=function(){return new ADate(this.date,this.month,this.year);}
;
this.getNextDate=function(){var nextDate=this.clone();nextDate.changeDate(1);return nextDate;}
;
this.getPreviousDate=function(){var nextDate=this.clone();nextDate.changeDate(-1);return nextDate;}
;
this.equals=function(otherDate){return ((this.year==otherDate.year)&&(this.month==otherDate.month)&&(this.date==otherDate.date));}
;
this.isLessThan=function(otherDate){return ((this.year<otherDate.year)||
((this.year==otherDate.year)&&(this.month<otherDate.month))||
((this.year==otherDate.year)&&(this.month==otherDate.month)&&(this.date<otherDate.date)));}
;
this.isLessThanEqual=function(otherDate){var isLessThan=((this.year<otherDate.year)||((this.year==otherDate.year)&&(this.month<otherDate.month))||
((this.year==otherDate.year)&&(this.month==otherDate.month)&&(this.date<otherDate.date)));var isEqual=this.equals(otherDate)
return (isLessThan||isEqual);}
;
this.isBeforeOtherDate=function(otherDate){return this.isLessThan(otherDate);
}
;
this.toDefaultString=function(){if(!ADateUtil.isValidDate(this.date,this.month,this.year)){return ADateUtil.EMPTY_DATE;}

var dateString="";dateString+=ADateUtil.selectDatePart(1,this.date,this.month,this.year)+ADateUtil.SEPARATOR;dateString+=ADateUtil.selectDatePart(2,this.date,this.month,this.year)+ADateUtil.SEPARATOR;dateString+=ADateUtil.selectDatePart(3,this.date,this.month,this.year);return dateString;}
;
this.getDateString=function(){return this.toDefaultString();}
;}



var ATimeUtil=new ATimeUtilBase();function ATimeUtilBase(){this.TYPE="TIME";this.TIME_FORMAT=12;
this.getCurrentTime=function(){return new ATime(g_sessionInformation.current_datetime.minute_offset);}
;
this.timeToString=function(minuteOffset){if(this.TIME_FORMAT==24){timeStr=this.offsetTo24Hr(minuteOffset);}

else 
{timeStr=this.offsetTo12Hr(minuteOffset);}

return timeStr;}
;
this.stringToTime=function(timeStr,timeObj){var offset=this.stringToOffset(timeStr);if(offset<0){return null;}

if(null!=timeObj){timeObj.minuteOffset=offset;}

else 
{timeObj=new ATime(offset)
}

return timeObj;}
;
this.stringToOffset=function(timeString){var re=new RegExp("(\\d\\d*)(:?)(\\d*)\\s*([ap]?)","g");var result=re.exec(timeString.toLowerCase());if(null==result){return -1;}

var hour;var minute;var isPM;if(""==result[2]){if(result[1].length==3){hour=parseInt(result[1].charAt(0),10);minute=parseInt(result[1].charAt(1)+result[1].charAt(2),10);}

else if(result[1].length==4){hour=parseInt(result[1].charAt(0)+result[1].charAt(1),10);minute=parseInt(result[1].charAt(2)+result[1].charAt(3),10);}

else 
{return -1;}

}

else 
{hour=parseInt(result[1],10);var mStr=result[3];if("0"==mStr.charAt(0)){mStr=mStr.charAt(1)
}

minute=parseInt(mStr,10);}

if(minute<0||minute>59||isNaN(minute)||isNaN(hour)){return -1;}

var timeOffset;if(this.TIME_FORMAT==24){if(hour<0||hour>23){return -1;}

timeOffset=this.to24HrToOffset(hour,minute);}

else 
{if(hour<1||hour>12){return -1;}

isPM=("p"==result[4])?true:false;timeOffset=this.to12HrToOffset(hour,minute,isPM);}

return timeOffset;}
;
this.offsetTo12Hr=function(offset){if(offset>=0&&offset<60){return "12:"+this.ensureTwoDigits(offset)+"AM";}

else if(offset>=60&&offset<720){var hour=Math.floor(offset/60);var minute=offset%60;return hour+":"+this.ensureTwoDigits(minute)+"AM";}

else if(offset>=720&&offset<780){var minute=offset%60;return "12:"+this.ensureTwoDigits(minute)+"PM";}

else if(offset>=780&&offset<1440){offset-=12*60;var hour=Math.floor(offset/60);var minute=offset%60;return hour+":"+this.ensureTwoDigits(minute)+"PM";}

}


this.offsetTo24Hr=function(offset){var hour=Math.floor(offset/60);var minute=offset%60;return this.ensureTwoDigits(hour)+":"+this.ensureTwoDigits(minute);}


this.ensureTwoDigits=function(number){var numberStr=number.toString()
var dot=numberStr.indexOf(".");if(dot!=-1){number=parseInt(numberStr.substring(0,dot),10);}

if(number<10){return "0"+number;}

return number;}
;this.to12HrToOffset=function(hour,minute,isPM){var minuteOffset=hour*60+minute;if(isPM){minuteOffset+=60*12;}

if(hour==12){minuteOffset-=60*12;}

return minuteOffset;}
;this.to24HrToOffset=function(hour,minute){return hour*60+minute;}
;this.initTimeFormat=function(){try
{this.TIME_FORMAT=g_sessionInformation.settings.time_format;}

catch(e)
{}

}
;this.isValidValue=function(value){return (this.validValues[value.toLowerCase()])
}
;this.initTimeFormat();this.validValues={closed:true}
;}

;function ATime(minuteOffset){this.minuteOffset=minuteOffset;}

ATime.prototype=new ATimeBase();function ATimeBase(){
this.getString=function(){var timeStr=ATimeUtil.timeToString(this.minuteOffset);return timeStr;}
;
this.toDbString=function(){return ATimeUtil.ensureTwoDigits(this.getHour())+":"+ATimeUtil.ensureTwoDigits(this.getMinute())+":00";}
;
this.clone=function(){return new ATime(this.minuteOffset);}
;
this.getHour=function(){return Math.floor(this.minuteOffset/60);}
;
this.getMinute=function(){return this.minuteOffset%60;}
;
this.changeTime=function(noOfMinutes){this.minuteOffset+=noOfMinutes;if(this.minuteOffset>=1440){this.minuteOffset=1439;}

else if(this.minuteOffset<0){this.minuteOffset=0;}

return this;}
;
this.equals=function(time){return this.minuteOffset==time.minuteOffset;}
;
this.isLessThan=function(time){return this.minuteOffset<time.minuteOffset;}
;
this.isLessThanEqual=function(time){return this.minuteOffset<=time.minuteOffset;}
;
this.isGreaterThan=function(time){return this.minuteOffset>time.minuteOffset;}
;
this.isGreaterThanEqual=function(time){return this.minuteOffset>=time.minuteOffset;}
;
this.update=function(timeStr){return ATimeUtil.stringToTime(timeStr,this);}
;
this.timeToString=function(){var timeStr=ATimeUtil.timeToString(this.minuteOffset);return timeStr;}
;}
;

;;mc_fieldTypeExtenders["TIMESTAMP"]=function(dynField){var timeObj=dynField.getValue().date_time.time;if(null!=timeObj){for(var i in ATime.prototype)
{timeObj[i]=ATime.prototype[i];}
;}
;var dateObj=dynField.getValue().date_time.date;if(null!=dateObj){for(var i in ADate.prototype)
{dateObj[i]=ADate.prototype[i];}

}
;dynField.forceSave=true;dynField.getDate=function(){return this.getValue().date_time.date;}
;dynField.getTime=function(){return this.getValue().date_time.time;}
;}
;

mc_fieldTypeExtenders["FILE2"]=function(dynField){extendField(dynField,f2_file2Base);}

var f2_file2Base=new File2Base();function File2Base(){this.getImagePath=function(width,height,allowSizingUp,fitType){var path=this.data.full_path
var params=ImageUtil.parseQueryString(path);if(width){params["w"]=width;}

if(height){params["h"]=height;}

if(allowSizingUp){params["u"]=allowSizingUp;}

if(fitType){params["f"]=fitType;}

var cleanSrc=ImageUtil.getUrlWithNoParams(path);var newPath=cleanSrc+"?"+ImageUtil.createQueryString(params);return newPath;}


this.setImageRotation=function(rotateCount){var path=this.getOriginalPath()+"?r="+rotateCount;this.getChildField("full_path").setValue(path);}
;
this.incrementRotation=function(rotateCount){var path=this.getChildField("full_path").getValue();var index=path.indexOf("?r=");var newRotation;if(-1==index){newRotation=rotateCount;}

else 
{var current=parseInt(path.charAt(index+3));newRotation=(current+rotateCount)%4;}

this.setImageRotation(newRotation);return newRotation;}


this.getOriginalPath=function(){var fullPath=this.getChildField("full_path").getValue();var end=fullPath.indexOf("?");if(-1==end){return fullPath;}

else 
{return fullPath.substring(0,end);}

}
;}

mc_fieldTypeExtenders["DATETIME"]=function(dynField){extendField(dynField,mc_dateTimeBase);var timeObj=dynField.getValue().time;if(null!=timeObj){for(var i in ATime.prototype)
{timeObj[i]=ATime.prototype[i];}
;}

var dateObj=dynField.getValue().date;if(null!=dateObj){for(var i in ADate.prototype)
{dateObj[i]=ADate.prototype[i];}

}

}

var mc_dateTimeBase=new DateTimeBase();function DateTimeBase(){this.setDate=function(date){this.data.date=date;this.setDoSave();}
;this.setTime=function(time){this.data.time=time;this.setDoSave();}
;this.getString=function(){var dateTime=this.getValue();return dateTime.date.getString()+" "+dateTime.time.getString();}
;}


mc_fieldTypeExtenders["NAME"]=function(dynField){extendField(dynField,name_nameBase);}

var name_nameBase=new NameBase();function NameBase(){this.getFirstMiddleLast=function(){return this.data.first_name+" "+this.data.middle_name+" "+this.data.last_name;}
;this.toString=function(lastNameFirst){var nameObj=this.getValue();if(lastNameFirst){return nameObj.last_name+", "+nameObj.first_name
}

else 
{return nameObj.first_name+" "+nameObj.last_name
}

}
;}


mc_fieldTypeExtenders["MODULE"]=function(dynField){extendField(dynField,mc_moduleBase);}

var mc_moduleBase=new ModuleBase();function ModuleBase(){this.setValueFromEl=function(element,lpSaver){var ahtml=lpSaver.getAhtml(element);this.getChildField("ahtml").setValue(ahtml);}
;this.getBgImageInfo=function(){var bgImageInfo={bgType:null,path:null}
;var record=this.getOwnerRecord();var fullScreenBgImage=record.getField("properties.body_attrs.full_screen_bg_image");var cssValue=record.getField("style_sheet.style_sheet").getAttrValue("body","background-image");if(fullScreenBgImage){bgImageInfo.bgType="full";bgImageInfo.path=fullScreenBgImage.getValue();}

else if(cssValue){bgImageInfo.bgType="tile";var start=cssValue.indexOf("(")+1;var end=cssValue.indexOf(")");bgImageInfo.path=cssValue.substring(start,end);}

return bgImageInfo;}
;this.setBgImageInfo=function(bgType,path,rte){path=path.replaceAll(" ","%20");var record=this.getOwnerRecord();this.clearBgImage(rte);if("full"==bgType){var bodyAttrs=record.getField("properties.body_attrs");bodyAttrs.addChildField("full_screen_bg_image","TEXT",path);BgImageUtil.setRteFullScreenBgImage(path,rte,true);}

else 
{var value="url("+path+")";record.getField("style_sheet.style_sheet").setAttribute("body","background-image",value,rte.doc);}

}
;this.clearBgImage=function(rte){var record=this.getOwnerRecord();record.getField("style_sheet.style_sheet").removeAttribute("body","background-image",rte.doc);record.getField("properties.body_attrs").removeChildField("full_screen_bg_image");BgImageUtil.removeFullScreenBgImage(rte.doc);}
;}


mc_fieldTypeExtenders["TEXT"]=function(dynField){extendField(dynField,mc_shortTextBase);}
;mc_fieldTypeExtenders["LONG_TEXT"]=function(dynField){extendField(dynField,mc_shortTextBase);}
;var mc_shortTextBase=new ShortTextBase();function ShortTextBase(){this.setValueFromEl=function(element,lpSaver){this.setValue(element.innerText);}
;}
;

;;;;;;;mc_fieldTypeExtenders["USERSTAMP"]=function(dynField){dynField.forceSave=true;}

mc_fieldTypeExtenders["C3"]=function(dynField){dynField.setDisplayValue=function(displayValue){var optionValue=null;var options=this.getChildField("category_definition.category_definition.options").data;for(var i in options)
{if(displayValue==options[i]){optionValue=i;break;}

}

if(optionValue){this.getChildField("value").setValue(optionValue);}

}

}

mc_fieldTypeExtenders["RECORD_TYPE"]=function(dynField){dynField.getRecord=function(){var mc=this.ownerRecord.ownerCache;return mc.getRecord(this.getChildField("type").getValue(),this.getChildField("id").getValue());}

dynField.createNewRecord=function(){var mc=this.ownerRecord.ownerCache;var record=mc.createRecord(this.getChildField("type").getValue());this.getChildField("id").setValue(record.id);return record;}
;}

mc_fieldTypeExtenders["RECORD_NAME"]=function(dynField){dynField.setValue=function(value){this.getChildField("recordName").setValue(value);}
;dynField.getValue=function(){return this.getChildField("recordName").getValue();}
;}

mc_fieldTypeExtenders["ARRAY"]=function(dynField){dynField.clear=function(){var length=this.getChildFieldNames().length;for(var i=length-1;i>=0;i--)
{this.removeChildField(i);}

}

}

mc_fieldTypeExtenders["DATE"]=function(dynField){var dateObj=dynField.getValue();if(null==dateObj){return ;}

if(window["ADate"]==undefined){return 
}

for(var i in ADate.prototype)
{dateObj[i]=ADate.prototype[i];}

}
;mc_fieldTypeExtenders["TIME_TYPE_NAME"]=function(dynField){var timeObj=dynField.getValue();if(null==timeObj){return ;}

if(window["ATime"]==undefined){return 
}

for(var i in ATime.prototype)
{timeObj[i]=ATime.prototype[i];}

}
;
;;function DynField(name,data,metaData,parentField,ownerRecord){this.name=name
this.data=data;this.metaData=metaData;this.parentField=parentField;this.ownerRecord=ownerRecord;addExentsions(this);}
;DynField.prototype=new DynFieldBase();function DynFieldBase(){
this.buildField=function(parentEl,converterName,properties){var uiType=this.getUiType()||this.getFieldType();var conversionFx=mc_objectToHtmlFxByType[converterName][uiType];if(!conversionFx){var doc=(properties&&properties.doc)?properties.doc:document;var div=cE("div",parentEl,doc);div.innerHTML="no for drawing type: "+uiType+" with converter '"+converterName+"'";return ;}

return conversionFx(parentEl,this,properties);}
;this.getChildField=function(fieldName){fieldName+="";var ownerRecord=this.ownerRecord;var dotIndex=fieldName.indexOf(".");if(this.data[fieldName]||-1==dotIndex){if("RECORD_TYPE"==this.getFieldType()&&fieldName!="id"&&fieldName!="type"&&fieldName!="createRecord"&&fieldName!="deleteRecord"){if(ownerRecord.isTemplate){var template=ownerRecord.ownerCache.getTemplate(this.data.type);if(null==template){alert("The template for "+this.data.type+" is not loaded. Please add it to load");return null;}

return ownerRecord.ownerCache.getTemplate(this.data.type).getField(fieldName);}

else 
{var record=ownerRecord.ownerCache.getRecord(this.data.type,this.data.id);if(null==record){return null;}

return record.getField(fieldName);}

}

else 
{if(!this.metaData[fieldName+"_ft"]){return null;}

return new DynField(fieldName,this.data[fieldName],this.metaData[fieldName],this,ownerRecord);}

}

else 
{var field=this.getChildField(fieldName.substring(0,dotIndex));if(null==field){return null;}

return field.getChildField(fieldName.substring(dotIndex+1,fieldName.length));}

}
;
this.getChildFields=function(){var childFields=[];var fieldNames=this.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var childField=this.getChildField(fieldNames[i]);if(null!=childField){childFields.push(childField);}

}

return childFields;}
;this.addChildField=function(fieldName,fieldType,value,displayName,displayOrder){var newField=this.addChildFieldData(fieldName,fieldType,value,displayName,displayOrder);var liveField=this.getLiveField();if(liveField){newField=liveField.addChildFieldData(fieldName,fieldType,value,displayName,displayOrder);}

return newField;}
;this.addChildFieldData=function(fieldName,fieldType,value,displayName,displayOrder){var metaValue;if(!value){var defaultData=mc_typeToDefaultValue[fieldType]();value=defaultData.data;metaValue=defaultData.metaData;}

else 
{metaValue=value;}

if("ARRAY"==this.getFieldType()){fieldName=this.data.length;this.data.push(clone(value));var metaData=this.metaData;metaData[fieldName]=clone(metaValue);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName;metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;}

else 
{this.data[fieldName]=clone(value);var metaData=this.metaData;metaData[fieldName]=clone(metaValue);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;}

var childField=this.getChildField(fieldName);childField.setDoSave();return childField;}
;this.getFullFieldName=function(){var fieldName=this.name;var aField=this.parentField;while(aField)
{fieldName=aField.name+"."+fieldName;aField=aField.parentField;}

return fieldName;}

this.insertChildField=function(fieldName,fieldType,field,displayName,displayOrder){field.parentField=this;field.ownerRecord=this.ownerRecord;if("ARRAY"==this.getFieldType()){fieldName=this.data.length;this.data.push(field.data);var metaData=this.metaData;metaData[fieldName]=field.metaData;metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName;metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;metaData[fieldName+"_uit"]=""
}

else 
{field.name=fieldName;this.data[fieldName]=field.data;var metaData=this.metaData;metaData[fieldName]=field.metaData;metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;metaData[fieldName+"_uit"]=""
}

var childField=this.getChildField(fieldName);childField.setDoSave();return childField;}
;this.renameChild=function(newName,previousName){var oldField=this.getChildField(previousName);var fieldType=oldField.getFieldType();var displayName=oldField.getDisplayName();var displayOrder=oldField.getDisplayOrder();var newChild=oldField.cloneField();this.removeChildField(previousName);return this.insertChildField(newName,fieldType,newChild,displayName,displayOrder);}
;this.cloneField=function(){var data=clone(this.data);var metaData=clone(this.metaData);return new DynField(this.name,data,metaData,null,null);}

this.removeChildField=function(fieldName){this.removeChildFieldData(fieldName);var liveField=this.getLiveField();if(liveField){liveField.removeChildFieldData(fieldName);}

}
;this.removeChildFieldData=function(fieldName){if("ARRAY"==this.getFieldType()){var index=parseInt(fieldName);var originalLength=this.data.length;this.data.splice(index,1);var metaData=this.metaData;delete(metaData[index]);delete(metaData[index+"_ft"]);delete(metaData[index+"_dn"]);delete(metaData[index+"_do"]);delete(metaData[index+"_ds"]);delete(metaData[index+"_uit"]);for(var i=index;i<originalLength-1;i++)
{var oldIndex=i+1;metaData[i]=metaData[oldIndex];metaData[i+"_ft"]=metaData[oldIndex+"_ft"];metaData[i+"_dn"]=metaData[oldIndex+"_dn"];metaData[i+"_do"]=metaData[oldIndex+"_do"];metaData[i+"_ds"]=metaData[oldIndex+"_ds"];metaData[i+"_uit"]=metaData[oldIndex+"_uit"];}

delete(metaData[i]);delete(metaData[i+"_ft"]);delete(metaData[i+"_dn"]);delete(metaData[i+"_do"]);delete(metaData[i+"_ds"]);delete(metaData[i+"_uit"]);}

else 
{delete(this.data[fieldName]);var metaData=this.metaData;delete(metaData[fieldName]);delete(metaData[fieldName+"_ft"]);delete(metaData[fieldName+"_dn"]);delete(metaData[fieldName+"_do"]);delete(metaData[fieldName+"_ds"]);delete(metaData[fieldName+"_uit"]);}

this.setDoSave();}
;this.getChildFieldNames=function(){if("ARRAY"==this.getFieldType()){var indexNames=[];for(var i=0;i<this.data.length;i++)
{indexNames[i]=i;}

return indexNames;}

return mc_getFieldNames(this.metaData);}
;this.getChildFieldCount=function(){return this.getChildFieldNames().length;}
;this.getFieldType=function(){var thisMetaData=this.getThisMetaData();return thisMetaData?thisMetaData[this.name+"_ft"]:null;}
;this.getOwnerRecord=function(){var testField=this;while(!testField.ownerRecord&&testField.parentField)
{testField=testField.parentField;}

return testField.ownerRecord;}
;this.getOwnerCache=function(){return this.getOwnerRecord().ownerCache;}
;this.isSetDoSave=function(){return this.getMetaInfo("ds");}
;this.setDoSave=function(){var record=this.getOwnerRecord();if(null==record){return ;}

var metaData=this.getThisMetaData();if(metaData[this.name+"_ds"]){return ;}

metaData[this.name+"_ds"]=true;var parentField=this.parentField;if(!parentField){record.setDoSave();}

else 
{parentField.setDoSave();}

}
;this.setDontSave=function(){this.setMetaInfo(false,"ds");}
;this.resetMetaInfo=function(value,suffix){
var metaData=this.getThisMetaData();metaData[this.name+"_"+suffix]=value;var fieldNames=this.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var childField=this.getChildField(fieldNames[i]);childField.resetMetaInfo(value,suffix);}

}
;this.getThisMetaData=function(){if(this.parentField){return this.parentField.metaData;}

else if(this.ownerRecord){return this.ownerRecord.metaData;}

else 
{return null;}

}
;this.getMetaInfo=function(suffix){return this.getThisMetaData()[this.name+"_"+suffix];}
;this.setMetaInfo=function(value,suffix){var metaData=this.getThisMetaData();metaData[this.name+"_"+suffix]=value;if(!value&&suffix=="ds"){return ;}

this.setDoSave();}
;this.getDisplayOrder=function(){return this.getMetaInfo("do");}
;this.setDisplayOrder=function(displayOrder){this.setMetaInfo(displayOrder,"do");}
;this.getUiType=function(){if(null==this.getMetaInfo("uit")){return "";}

return this.getMetaInfo("uit");}
;this.setUiType=function(uiType){this.setMetaInfo(uiType,"uit");}
;this.getDisplayName=function(){return this.getMetaInfo("dn");}
;this.setDisplayName=function(displayName){this.setMetaInfo(displayName,"dn");}
;
this.getValue=function(){return this.data;}
;
this.getLiveField=function(){var fullFieldName=this.getFullFieldName();var ownerRecord=this.getOwnerRecord();if(null==ownerRecord){return null;}

var liveField=null;try
{liveField=ownerRecord.getRefreshed().getField(fullFieldName);}

catch(e)
{}

return (liveField&&liveField.data!=this.data)?liveField:null;}
;this.setValue=function(value,isDontSetSave){this.setFieldValue(this,value,isDontSetSave);var liveField=this.getLiveField();if(liveField){this.setFieldValue(liveField,value,isDontSetSave);}

return this;}
;this.setValueFromEl=function(element,lpSaver){}
;this.setFieldValue=function(dynField,value,isDontSetSave){if(null==dynField){return ;}

dynField.data=value;if(dynField.parentField){dynField.parentField.data[dynField.name]=value;}

else 
{dynField.ownerRecord.data[dynField.name]=value;}

if(!isDontSetSave){dynField.setDoSave();}

}

}

function addExentsions(dynField){var fieldType=dynField.getFieldType();var extender=mc_fieldTypeExtenders[fieldType];if(extender){extender(dynField);}

}

function extendField(dynField,objectDef){for(var i in objectDef)
{dynField[i]=objectDef[i];}

}
;

;function Record(type,id,data,metaData,ownerCache){this.type=type;this.id=id;this.ownerCache=ownerCache;delete(data.type);delete(data.id);this.data=data;this.metaData=metaData;this.recordCount=++mc_recordCounter;}

Record.prototype=new RecordBase();function RecordBase(type,id,data,metaData,ownerCache){this.getId=function(){if(0>=this.id){var ids=mc_tempToRealId[this.type];if(ids){return ids[this.id]||this.id;}

else 
{return this.id;}

}

return this.id;}

this.getField=function(fieldName){var dotIndex=fieldName.indexOf(".");if(-1==dotIndex){if( typeof (this.metaData[fieldName])!="undefined"){return new DynField(fieldName,this.data[fieldName],this.metaData[fieldName],null,this);}

else 
{return null;}

}

else 
{var field=this.getField(fieldName.substring(0,dotIndex));if(!field){return null;}

return field.getChildField(fieldName.substring(dotIndex+1,fieldName.length));}

}
;this.addField=function(fieldName,fieldType,displayName,displayOrder){var defaultData=mc_typeToDefaultValue[fieldType]();this.data[fieldName]=clone(defaultData.data);var metaData=this.metaData;metaData[fieldName]=clone(defaultData.metaData);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;return this.getField(fieldName);}
;this.cloneRecord=function(mc){var newRecord=mc.createRecord(this.type,this.getId());
var fieldNames=this.getFieldNames();for(var i=0;i<fieldNames.length;i++)
{var field=this.getField(fieldNames[i]);var newField=field.cloneField();newField=newRecord.insertField(field.name,field.getFieldType(),newField,field.getDisplayName(),field.getDisplayOrder());if(field.isSetDoSave()){newField.setDoSave();}

}

return newRecord;}
;this.addName=function(name){this.ownerCache.addRecordName(this,name);}
;this.insertField=function(fieldName,fieldType,field,displayName,displayOrder){field.ownerRecord=this;this.data[fieldName]=field.data;var metaData=this.metaData;metaData[fieldName]=field.metaData;metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;return this.getField(fieldName);}
;this.replaceField=function(fieldName,dynField){var replacedField=this.insertField(fieldName,dynField.getFieldType(),dynField,dynField.getDisplayName(),dynField.getDisplayOrder());replacedField.setDoSave();return replacedField;}

this.setDoSave=function(){if(this.metaData.doProcess){return ;}

this.metaData.doSave=true;this.setDoLoad();}
;this.isSetDoSave=function(){return this.metaData.doSave;}
;this.cancelSave=function(){this.ownerCache.cancelRecordToLoad(this.type,this.id);this.metaData.doSave=false;}
;this.setDoLoad=function(){this.ownerCache.addRecordToLoad(this.type,this.id);}
;this.getFieldNames=function(){return mc_getFieldNames(this.metaData);}
;this.getRefreshed=function(){return this.ownerCache.getRecord(this.type,this.id);}
;this.resetMetaInfo=function(value,suffix){var fieldNames=this.getFieldNames();for(var i=0;i<fieldNames.length;i++)
{var childField=this.getField(fieldNames[i]);childField.resetMetaInfo(value,suffix);}

}
;this.removeUnchangedFields=function(){var names=this.getFieldNames();for(var i=0;i<names.length;i++)
{var field=this.getField(names[i]);if(!field.isSetDoSave()){this.removeField(names[i]);}

}

}
;
this.removeField=function(fieldName){delete(this.data[fieldName]);var metaData=this.metaData;delete(metaData[fieldName]);delete(metaData[fieldName+"_ft"]);delete(metaData[fieldName+"_dn"]);delete(metaData[fieldName+"_do"]);delete(metaData[fieldName+"_ds"]);delete(metaData[fieldName+"_uit"]);}
;
}

var mc_recordCounter=0;

function DynTable(type,data,metaData,settings,ownerCache){this.type=type;this.ownerCache=ownerCache;this.data=data;this.metaData=metaData;this.settings=settings;this.getField=function(fieldName){return new DynField(fieldName,this.data[fieldName],this.metaData[fieldName],null,this);}
;this.setDoSave=function(){this.settings.doSave=true;}
;this.addField=function(fieldName,fieldType,displayName,displayOrder){this.setDoSave();var defaultData=mc_typeToDefaultValue[fieldType]();this.data[fieldName]=clone(defaultData.data);var metaData=this.metaData;metaData[fieldName]=clone(defaultData.metaData);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName;metaData[fieldName+"_do"]=displayOrder;metaData[fieldName+"_ds"]=true;metaData[fieldName+"_uit"]="";return this.getField(fieldName);}
;this.getFieldNames=function(){return mc_getFieldNames(this.metaData);}
;}

if(!mc_typeToDefaultValue){var mc_typeToDefaultValue={}
;}

function mc_insertMetaData(object,fieldName,fieldType,displayName,displayOrder,value){object[fieldName]=value;object[fieldName+"_ft"]=fieldType;object[fieldName+"_dn"]=displayName;object[fieldName+"_do"]=displayOrder;}

mc_typeToDefaultValue["COLLECTION"]=function(){return {data:{}
,metaData:{}
}
;}
;mc_typeToDefaultValue["ARRAY"]=function(){return {data:[],metaData:[]}
;}
;mc_typeToDefaultValue["INTEGER"]=function(){return {data:0,metaData:0}
;}
;mc_typeToDefaultValue["DOUBLE"]=function(){return {data:0.0,metaData:0.0}
;}
;mc_typeToDefaultValue["TIME_TYPE_NAME"]=function(){return {data:null,metaData:null}
;}
;mc_typeToDefaultValue["BOOLEAN"]=function(){return {data:false,metaData:false}
;}
;mc_typeToDefaultValue["RECORD_TYPE"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("type","TEXT");field.addChildField("id","INTEGER");field.addChildField("createRecord","BOOLEAN");field.addChildField("deleteRecord","BOOLEAN");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["RIL2"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("type","TEXT");field.addChildField("ids","LONG_TEXT");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["MODULE"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("ahtml","LONG_TEXT");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["TEXT"]=function(){return {data:"",metaData:""}
;}
;mc_typeToDefaultValue["TREE"]=function(){return {data:"",metaData:""}
;}
;mc_typeToDefaultValue["PASSWORD"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("value","TEXT");field.addChildField("doSave","BOOLEAN",true);return {data:field.data,metaData:field.metaData}
;}
;mc_typeToDefaultValue["DATE"]=function(){return {data:null,metaData:null}
;}
;mc_typeToDefaultValue["DATETIME"]=function(){var field=new DynField(null,{date:null,time:null}
,{}
,null,null);field.addChildField("isGMT","BOOLEAN");return {data:field.data,metaData:field.metaData}
;}
;mc_typeToDefaultValue["LONG_TEXT"]=function(){return {data:"",metaData:""}
;}
;mc_typeToDefaultValue["MS3"]=function(){var data={selected_options:"",category_definition:{type:"cat_def3",id:0,deleteRecord:false,createRecord:false}
}
;var metaData={}
;mc_insertMetaData(metaData,"selected_options","LONG_TEXT","",0,"");mc_insertMetaData(metaData,"category_definition","RECORD_TYPE","",0,{}
);var definitionMeta=metaData.category_definition;mc_insertMetaData(definitionMeta,"type","TEXT","",0,"cat_def3");mc_insertMetaData(definitionMeta,"id","INTEGER","",0,0);mc_insertMetaData(definitionMeta,"createRecord","BOOLEAN","",0,false);mc_insertMetaData(definitionMeta,"deleteRecord","BOOLEAN","",0,false);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["C3"]=function(){var data={default_value:"",value:"",category_definition:{type:"cat_def3",id:0,deleteRecord:false,createRecord:false}
}
;var metaData={}
;mc_insertMetaData(metaData,"default_value","TEXT","",0,"");mc_insertMetaData(metaData,"value","TEXT","",0,"");mc_insertMetaData(metaData,"category_definition","RECORD_TYPE","",0,{}
);var definitionMeta=metaData.category_definition;mc_insertMetaData(definitionMeta,"type","TEXT","",0,"cat_def3");mc_insertMetaData(definitionMeta,"id","INTEGER","",0,0);mc_insertMetaData(definitionMeta,"createRecord","BOOLEAN","",0,false);mc_insertMetaData(definitionMeta,"deleteRecord","BOOLEAN","",0,false);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["TIMESTAMP"]=function(){var data={str_format:"simple",do_update:false,date_time:{date:{date:1,month:1,year:1}
,time:{minuteOffset:0}
}
}
;var metaData={}
;mc_insertMetaData(metaData,"str_format","TEXT","",0,"simple");mc_insertMetaData(metaData,"do_update","BOOLEAN","",0,false);mc_insertMetaData(metaData,"date_time","DATETIME","",0,{}
);var dateTimeMeta=metaData.date_time;mc_insertMetaData(dateTimeMeta,"isGMT","BOOLEAN","",0,true);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["USERSTAMP"]=function(){var data={do_update:false,user_name:'',user_id:0}
;var metaData={}
;mc_insertMetaData(metaData,"user_name","TEXT","",0,"");mc_insertMetaData(metaData,"do_update","BOOLEAN","",0,false);mc_insertMetaData(metaData,"user_id","INTEGER","",0,0);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["RECORD_NAME"]=function(){var data={recordName:'',updateOnImport:true}
;var metaData={}
;mc_insertMetaData(metaData,"recordName","TEXT","",0,"");mc_insertMetaData(metaData,"updateOnImport","BOOLEAN","",0,true);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["TIME_ALLOCATION_TYPE"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("time_allocation_record","RECORD_TYPE");field.addChildField("finder","RECORD_TYPE");field.addChildField("physical_resource","RECORD_TYPE");field.addChildField("event_title","TEXT");field.addChildField("event_status","COLLECTION");field.addChildField("is_double_allowed","BOOLEAN",false);field.addChildField("start_date","DATE");field.addChildField("start_time","TIME_TYPE_NAME");field.addChildField("end_date","DATE");field.addChildField("end_time","TIME_TYPE_NAME");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["RTA2"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("time_allocation_record","RECORD_TYPE");field.addChildField("physical_resource","RECORD_TYPE");field.addChildField("event_title","TEXT");field.addChildField("is_double_allowed","BOOLEAN",false);field.addChildField("start_date","DATE");field.addChildField("start_time","TIME_TYPE_NAME");field.addChildField("end_date","DATE");field.addChildField("end_time","TIME_TYPE_NAME");var recurInfo=field.addChildField("recur_info","COLLECTION");recurInfo.addChildField("recur_type","TEXT","weekly","",1);recurInfo.addChildField("every_nth_week","INTEGER",1,"",2);recurInfo.addChildField("is_monday","BOOLEAN",true,"",3);recurInfo.addChildField("is_tuesday","BOOLEAN",true,"",4);recurInfo.addChildField("is_wednesday","BOOLEAN",true,"",5);recurInfo.addChildField("is_thursday","BOOLEAN",true,"",6);recurInfo.addChildField("is_friday","BOOLEAN",true,"",7);recurInfo.addChildField("is_saturday","BOOLEAN",true,"",8);recurInfo.addChildField("is_sunday","BOOLEAN",true,"",9);recurInfo.addChildField("every_nth_month","INTEGER",1,"",10);recurInfo.addChildField("day_or_date","TEXT","day","",11);field.addChildField("cancelled_dates","COLLECTION");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["NAME"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("prefix","TEXT");field.addChildField("first_name","TEXT");field.addChildField("middle_name","TEXT");field.addChildField("last_name","TEXT");field.addChildField("suffix","TEXT");return field;}
;mc_typeToDefaultValue["FILE2"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("file_name","TEXT");field.addChildField("folder_name","TEXT");field.addChildField("full_path","TEXT");field.addChildField("rename_on_upload","BOOLEAN");return field;}
;mc_typeToDefaultValue["PATH"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("real_path","TEXT");field.addChildField("friendly_path","TEXT");return field;}
;mc_typeToDefaultValue["URL"]=function(){var field=new DynField(null,{}
,{}
,null,null);var fUrl=field.addChildField("friendly_url","TEXT");fUrl.setUiType("FURL");field.addChildField("action_path","TEXT");field.addChildField("params","COLLECTION");field.addChildField("update_on_import","BOOLEAN");field.addChildField("url","RECORD_TYPE");field.addChildField("is_clash","BOOLEAN");field.addChildField("is_public","BOOLEAN",true);field.addChildField("clash_url","RECORD_TYPE");var fUrl=field.addChildField("forward_url","RECORD_TYPE");fUrl.getChildField("type").setValue("url");field.addChildField("screen_title","TEXT");field.addChildField("minicache_input","MCL");return field;}
;mc_typeToDefaultValue["RR"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("range_name","TEXT");field.addChildField("min","TEXT");field.addChildField("max","TEXT");return field;}
;mc_typeToDefaultValue["INPUT"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("value","TEXT");field.addChildField("validationType","TEXT","false");field.addChildField("autoComplete","BOOLEAN",false);return {data:field.data,metaData:field.metaData}
;}
;
function ajax_getStringForXml(string){var xmlRequest=ajax_getXMLHttpRequest();var url="GetHtmlForXml.ajax";xmlRequest.open("POST",url,false);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("html="+string);do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_setFormatedXmlString(xmlRequest.responseText);}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

while(xmlRequest.readyState!=4)}

function ajax_setFormatedXmlString(str){g_processedHtmlForXml=str;}

function ajax_getStringForEditor(string){var xmlRequest=ajax_getXMLHttpRequest();var handlerFunction=ajax_getReadyStateHandler(xmlRequest,ajax_setEditorString);xmlRequest.onreadystatechange=handlerFunction;var url="GetHtmlForEditor.ajax";xmlRequest.open("POST",url,false);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("html="+string);do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_setEditorString(xmlRequest.responseText)
}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

while(xmlRequest.readyState!=4)}

function ajax_setEditorString(str){editor_processedHtmlForEditor=str;}

function ajax_getStringForHtml(string){var xmlRequest=ajax_getXMLHttpRequest();var handlerFunction=ajax_getReadyStateHandler(xmlRequest,ajax_setHtmlString);xmlRequest.onreadystatechange=handlerFunction;var url="GetHtml.ajax";xmlRequest.open("POST",url,false);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("html="+string);do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_setHtmlString(xmlRequest.responseText)
}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

while(xmlRequest.readyState!=4)}

function ajax_setHtmlString(str){editor_processedHtmlForHtml=str;}


;if(!vfc_converters){var vfc_converters={}
;}

function vfc_getValue(dynField){var fieldType=dynField.getFieldType();var converter=vfc_converters[fieldType];if(!converter){return "";}

return converter(dynField);}

function vfc_registerConverter(fieldType,converterFx){vfc_converters[fieldType]=converterFx;}

vfc_converters["DATETIME"]=function(dynField){var dateTimeObj=dynField.data;var value;if(dateTimeObj&&dateTimeObj.date!=null&&dateTimeObj.time!=null){var dateObj=dateTimeObj.date;value=dateObj.toDbFormat()
value+=" "+dateTimeObj.time.toDbString();}

else 
{value="";}

return value;}

vfc_converters["RECORD_TYPE"]=function(dynField){return dynField.data.id;}

vfc_converters["RIL2"]=function(dynField){if(dynField.data.idArray){var idsStr="";var idArray=dynField.data.idArray;for(var i=0;i<idArray.length;i++)
{if(i!=0){idsStr+="|"+idArray[i];}

else 
{idsStr+=idArray[i];}

}

dynField.data.ids=idsStr;delete(dynField.data.idArray);}

return dynField.data.ids;}

function vfc_getCategory3Value(dynField){var definition=dynField.data.category_definition;var miniCache=dynField.ownerRecord.ownerCache;var c3Records=miniCache.records[definition.type];if(!c3Records){return "";}

var definitionRecord=c3Records[definition.id];if(!definitionRecord){return "";}

var value=dynField.data.value;return util_formatForXmlValue(definitionRecord.category_definition.options[value]);}

vfc_registerConverter("C3",vfc_getCategory3Value);function vfc_getRecordTypeValue(dynField){return dynField.data.id;}

vfc_registerConverter("RECORD_TYPE",vfc_getRecordTypeValue);function vfc_getLongTextValue(dynField){return util_formatForXmlValue(dynField.data);}

vfc_registerConverter("LONG_TEXT",vfc_getLongTextValue);function vfc_getDateValue(dynField){if(!dynField.data){return "";}

return dynField.data.toDbFormat();}

vfc_registerConverter("DATE",vfc_getDateValue);function vfc_getGenericValue(dynField){return dynField.getValue();}

vfc_registerConverter("BOOLEAN",vfc_getGenericValue);vfc_registerConverter("INTEGER",vfc_getGenericValue);vfc_registerConverter("DOUBLE",vfc_getGenericValue);function vfc_getTimeValue(dynField){var timeStr="";var timeObj=dynField.data;if(timeObj!=null){timeStr=timeObj.toDbString();}

return timeStr;}

vfc_registerConverter("TIME_TYPE_NAME",vfc_getTimeValue);function vfc_getRecordNameValue(dynField){return dynField.data.recordName;}

vfc_registerConverter("RECORD_NAME",vfc_getRecordNameValue);function vfc_returnNoValue(){return "";}

vfc_registerConverter("COLLECTION",vfc_returnNoValue);vfc_registerConverter("SST",vfc_returnNoValue);vfc_registerConverter("ARRAY",vfc_returnNoValue);vfc_registerConverter("TIMESTAMP",vfc_returnNoValue);vfc_registerConverter("USERSTAMP",vfc_returnNoValue);vfc_registerConverter("CD3",vfc_returnNoValue);vfc_registerConverter("DBI",vfc_returnNoValue);vfc_registerConverter("TIME_ALLOCATION_TYPE",vfc_returnNoValue);vfc_registerConverter("RTA2",vfc_returnNoValue);vfc_registerConverter("NAME",vfc_returnNoValue);vfc_registerConverter("MODULE",vfc_returnNoValue);function vfc_getShortTextValue(dynField){return util_formatForXmlValue(dynField.getValue());}

vfc_registerConverter("TEXT",vfc_getShortTextValue);vfc_registerConverter("TREE",vfc_getShortTextValue);function vfc_getInputValue(dynField){return util_formatForXmlValue(dynField.getChildField("value").getValue());}

vfc_registerConverter("INPUT",vfc_getInputValue);vfc_registerConverter("TEXT_AREA",vfc_getInputValue);vfc_registerConverter("PASSWORD",vfc_getInputValue);function vfc_getNewCategoryValue(dynField){return util_formatForXmlValue(dynField.getChildField("value").getValue());}

vfc_registerConverter("NEW_CATEGORY",vfc_getNewCategoryValue);function vfc_getMs3Value(dynField){return util_formatForXmlValue(dynField.getChildField("selected_options").getValue());}

vfc_registerConverter("MS3",vfc_getMs3Value);function vfc_getRecordNameValue(dynField){return dynField.data.recordName;}

vfc_registerConverter("RECORD_NAME",vfc_getRecordNameValue);function vfc_getUrlValue(dynField){return dynField.getChildField("friendly_url").getValue();}

vfc_registerConverter("URL",vfc_getUrlValue);function vfc_getNamelValue(dynField){try
{dynField.ownerRecord.getField(dynField.name+"_ln").setValue("");}

catch(e){}

return ""
}

vfc_registerConverter("NAME",vfc_getNamelValue);vfc_converters["PATH"]=function(dynField){return dynField.data.real_path;}

vfc_converters["FILE2"]=function(dynField){if(!dynField.data.file_name){return ;}

dynField.getOwnerCache().useFrame=true;return "";}

function photoConverter(dynField){dynField.getChildField("originalImagePath").setValue("");if(!dynField.data.originalImage.image_file.file_name){return ;}

dynField.getOwnerCache().useFrame=true;return "";}

vfc_converters["PHOTO"]=photoConverter;vfc_converters["FILE"]=vfc_returnNoValue;vfc_converters["IMAGE"]=vfc_returnNoValue;vfc_converters["VIDEO"]=vfc_returnNoValue;
;
function mcs_process(miniCache,onAfterProcess,onErrorFx){miniCache.runBeforeProcesses();miniCache.useFrame=false;var xml=mcs_createCacheXml(miniCache);mc_processCache(xml,miniCache,onAfterProcess,onErrorFx);}

function mc_processCache(xml,miniCache,onAfterProcessFx,onErrorFx){if(miniCache.useFrame){mc_processUploadCache(xml,miniCache,onAfterProcessFx);return ;}

var isAsync=(onAfterProcessFx!=null)?true:false;var xmlRequest=ajax_getXMLHttpRequest();var url="ProcessMiniCache.ajax";xmlRequest.open("POST",url,isAsync);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");var requestUrl="cache="+xml;requestUrl+="&screenId="+g_sessionInformation.screen_id;xmlRequest.send(requestUrl);if(isAsync){xmlRequest.onreadystatechange=function(){if(xmlRequest.readyState==4){if(xmlRequest.status==200){if(!mc_isResponseValid(xmlRequest.responseText)){if(onErrorFx){onErrorFx();}

return ;}

mc_setXmlResponseInto(miniCache,xmlRequest.responseText);if(onAfterProcessFx){onAfterProcessFx();}

}

}

}

}

else {do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){mc_setXmlResponseInto(miniCache,xmlRequest.responseText);}

}

}

while(xmlRequest.readyState!=4)return ;}

}

function mc_processUploadCache(xml,miniCache,onAfterProcessFx){var thisWindow=miniCache.ownerWindow||window;var doc=thisWindow.document||document;var body=doc.body;var html="<form id='uploadForm' method='post' action='IFrameCommunicator.do' enctype='multipart/form-data' target='uploadTarget'></form>";html+="<iframe style='display:none' id='uploadTarget' name='uploadTarget'></iframe>";var formHolder=cE("div",body);formHolder.id="uploadElements";formHolder.innerHTML=html;var form=doc.getElementById("uploadForm");var inputs=doc.getElementsByTagName("input");for(var i=inputs.length-1;i>=0;i--)
{var input=inputs[i];if(input.type.toLowerCase()!="file"){continue;}

var removed=input.parentNode.removeChild(input);aE(form,removed);}

var input=doc.createElement("input")
input.type="hidden";input.name="cache";input.id="mc_cache";form.appendChild(input);input.value=xml;thisWindow.mc_onAfterProcessIFrameFx=function(responseText){var uploadElements=doc.getElementById("uploadElements");uploadElements.parentNode.removeChild(uploadElements);if(!mc_isResponseValid(responseText)){return ;}

mc_setXmlResponseInto(miniCache,responseText,"from upload cache");if(onAfterProcessFx){onAfterProcessFx();}

}
;form.submit();}
;

var mc_onAfterProcessIFrameFx;function mc_setXmlResponseInto(miniCache,responseText,errorInfo){try
{eval(responseText);}

catch(e)
{if(!errorInfo){errorInfo="";}

alert("error receiving data: "+errorInfo);return ;}

mc_updateData(miniCache,miniCacheData);if(miniCache.doSyncToMaster){mc_updateData(getMasterCache(),miniCacheData);}

}

function mc_isResponseValid(obj){var errorOccured="error_"+"ocurred";var sessionExpired="session_"+"expired";if(obj==sessionExpired){alert("Your session has expired and you will be re-directed to the home page.");location.reload("");return false;}

if(obj.indexOf(errorOccured)==0){if(errorOccured==obj){alert("A problem has occured and we have been notified. Please try again later");}

else 
{alert(obj);}

return false;}

return true;}

function mc_updateData(miniCache,miniCacheData){mc_updateIds(miniCache,miniCacheData);copyData(miniCacheData.records_by_key,miniCache.records_by_key);var recordTypes=miniCacheData.records;var mcRecordTypes=miniCache.records;for(var i in recordTypes)
{if(!mcRecordTypes[i]){mcRecordTypes[i]=clone(recordTypes[i]);}

else 
{copyData(recordTypes[i],mcRecordTypes[i]);}

}

var recordTypes=miniCacheData.record_meta_data;var mcRecordTypes=miniCache.record_meta_data;for(var i in recordTypes)
{if(!mcRecordTypes[i]){mcRecordTypes[i]=clone(recordTypes[i]);}

else 
{copyData(recordTypes[i],mcRecordTypes[i]);}

}

copyData(miniCacheData.lists,miniCache.lists);copyData(miniCacheData.templates,miniCache.templates);copyData(miniCacheData.template_meta_data,miniCache.template_meta_data);copyData(miniCacheData.dyn_tables,miniCache.dyn_tables);copyData(miniCacheData.temp_to_real_id,mc_tempToRealId);copyData(miniCacheData.values,miniCache.values);}

function mc_updateIds(miniCache,miniCacheData){var records=miniCache.records;var recordMetaData=miniCache.record_meta_data;for(var i in miniCacheData.temp_to_real_id)
{if(!records[i]){continue;}

var idMap=miniCacheData.temp_to_real_id[i];for(var j in idMap)
{var recordsOfType=records[i];var recordMetaDataOfType=recordMetaData[i];if(recordsOfType[j]){var newId=idMap[j];recordsOfType[newId]=recordsOfType[j];recordMetaDataOfType[newId]=recordMetaDataOfType[j];delete(recordMetaDataOfType[j]);delete(recordsOfType[j]);}

}

}

}

function copyData(dataHolder,destinationHolder){for(var i in dataHolder)
{destinationHolder[i]=clone(dataHolder[i]);}

}

function mcs_createCacheXml(miniCache){var xml=constants_LESS_THAN_CHAR+"cache>";xml+=mcs_appendRecordsXml(miniCache);xml+=mcs_appendDynTablesXml(miniCache);xml+=constants_LESS_THAN_CHAR+"/cache>";return xml;}

function mcs_appendDynTablesXml(miniCache){var xml=constants_LESS_THAN_CHAR+"dyntables>";xml+=constants_LESS_THAN_CHAR+"to_save>";var dynTables=miniCache.dyn_tables;for(var i in dynTables)
{var dynTable=miniCache.getDynTable(i);if(dynTable.settings.doSave){xml+=mcs_appendDynTableXml(dynTable);}

}

xml+=constants_LESS_THAN_CHAR+"/to_save>";xml+=mcs_appendTablesToDeleteXml(miniCache);xml+=constants_LESS_THAN_CHAR+"/dyntables>";return xml;}

function mcs_appendTablesToDeleteXml(miniCache){var tablesToDelete=miniCache.tables_to_delete;if(tablesToDelete.length==0){return "";}

var xml=constants_LESS_THAN_CHAR+"to_delete>";for(var i=0;i<tablesToDelete.length;i++)
{xml+=constants_LESS_THAN_CHAR+"f name='"+tablesToDelete[i]+"'/>";}

xml+=constants_LESS_THAN_CHAR+"/to_delete>";return xml;}

function mcs_appendDynTableXml(dynTable){var xml=constants_LESS_THAN_CHAR+"table";xml+=" name='"+dynTable.type;xml+="' dn='"+dynTable.settings.singularName+"'>";xml+=mcs_appendTableFieldsToDelete(dynTable);xml+=mcs_appendTableFieldsToSave(dynTable);xml+=mcs_appendTableSettings(dynTable);xml+=constants_LESS_THAN_CHAR+"/table>";return xml;}

function mcs_appendTableFieldsToDelete(dynTable){var deleteXml="";var fieldsToDelete=dynTable.settings.fieldsToDelete;for(var i in fieldsToDelete)
{deleteXml+=constants_LESS_THAN_CHAR+"f name='"+fieldsToDelete[i]+"'/>";}

delete(dynTable.settings.fieldsToDelete);if(""==deleteXml){return "";}

var xml=constants_LESS_THAN_CHAR+"to_delete>";xml+=deleteXml;xml+=constants_LESS_THAN_CHAR+"/to_delete>";return xml;}

function mcs_appendTableSettings(dynTable){var xml=constants_LESS_THAN_CHAR+"settings>";xml+=constants_LESS_THAN_CHAR+"f ";xml+=" type='"+"DYNTABLE_SETTINGS"+"'>";var settings=dynTable.settings;delete(settings.doSave);for(var i in settings)
{xml+=constants_LESS_THAN_CHAR+"f ";xml+="name='"+i;xml+="' type='"+"TEXT";xml+="' value='"+util_formatForXmlValue(settings[i])+"'/>";}

xml+=constants_LESS_THAN_CHAR+"/f>";xml+=constants_LESS_THAN_CHAR+"/settings>";return xml;}

function mcs_appendTableFieldsToSave(dynTable){var xml="";var fieldNames=mc_getFieldNames(dynTable.metaData);for(var i in fieldNames)
{var field=dynTable.getField(fieldNames[i]);if(field.getMetaInfo("ds")){xml+=mcs_appendFieldXml(field);}

}

if(""==xml){return "";}

return constants_LESS_THAN_CHAR+"to_save>"+xml+constants_LESS_THAN_CHAR+"/to_save>";}

function mcs_appendRecordsXml(miniCache){var xml=constants_LESS_THAN_CHAR+"records>";var recordsMetaData=miniCache.record_meta_data;for(var type in recordsMetaData)
{var records=recordsMetaData[type];for(var id in records)
{var record=miniCache.getRecord(type,id);xml+=mcs_appendRecordXml(record);}

}

xml+=constants_LESS_THAN_CHAR+"/records>";return xml;}

function mcs_appendRecordXml(record){var xml="";if(!record.metaData.doSave&&!record.metaData.doProcess){return xml;}

xml+=constants_LESS_THAN_CHAR+"record type='"+record.type+"'";if(record.metaData.doSave){xml+=" do_save='true' ";}

if(record.metaData.doProcess){xml+=" do_process='true' ";}

xml+="id='"+record.id+"'>";var fieldNames=record.getFieldNames();var fieldXml="";for(var i=0;i<fieldNames.length;i++)
{var dynField=record.getField(fieldNames[i]);if(record.metaData.doSave&&!dynField.getMetaInfo("ds")&&!dynField.forceSave){continue;}

fieldXml+=mcs_appendFieldXml(dynField);}

if(fieldXml==""&&record.id>0){return "";}

xml+=fieldXml+constants_LESS_THAN_CHAR+"/record>"
record.metaData.doSave=false;return xml;}

function mcs_appendFieldXml(dynField){var fieldType=dynField.getFieldType();var xml=constants_LESS_THAN_CHAR+"f ";xml+="name='"+dynField.name;xml+="' dn='"+util_formatForXmlValue(dynField.getMetaInfo("dn"));xml+="' type='"+fieldType;xml+="' do='"+dynField.getMetaInfo("do");xml+="' uit='"+dynField.getUiType();xml+="' value='"+vfc_getValue(dynField)+"'";var childFieldNames=mc_getFieldNames(dynField.metaData);var chidFieldCount=childFieldNames.length;if(0==chidFieldCount){xml+="/>";return xml;}

else 
{xml+=">";for(var i=0;i<chidFieldCount;i++)
{var childFieldName=childFieldNames[i];xml+=mcs_appendFieldXml(dynField.getChildField(childFieldName));}

xml+=constants_LESS_THAN_CHAR+"/f>";return xml;}

}


function createListInput(type,name,startRecord,max,sortField,sortDirection){startRecord=startRecord||0;max=max||-1;sortDirection=sortDirection||"asc";name=name||"temp";var listInput=new DynField(null,{}
,{}
,null,null);listInput.addChildField("record_type","TEXT",type);listInput.addChildField("name","TEXT",name);listInput.addChildField("start_record","INTEGER",startRecord);listInput.addChildField("max_record_count","INTEGER",max);listInput.addChildField("fields_to_load","TEXT","");listInput.addChildField("sort_field","TEXT",sortField);listInput.addChildField("sort_direction","TEXT",sortDirection);listInput.addChildField("search_criteria","ARRAY");extendField(listInput,g_listInputBase);return listInput;}

function turnIntoListInput(field){extendField(field,g_listInputBase);return field;}

var g_listInputBase=new ListInputBase();function ListInputBase(){this.addField=function(fieldName){var fieldsToLoad=this.getChildField("fields_to_load");fieldsToLoad.setValue(fieldsToLoad.getValue()+fieldName+",");return this;}
;this.setMax=function(max){this.getChildField("max_record_count").setValue(max);}
;this.setSortField=function(sortField){this.getChildField("sort_field").setValue(sortField);}
;this.setStartRecord=function(startRecord){this.getChildField("start_record").setValue(startRecord);}
;this.setSortDirection=function(sortDirection){this.getChildField("sort_direction").setValue(sortDirection);}
;this.addSearchTerm=function(fieldName,value,searchType,groupName){var searchCriteria=this.getChildField("search_criteria");var criteria=searchCriteria.addChildField(null,"COLLECTION");criteria.addChildField("criteria_type","TEXT","search_term");criteria.addChildField("field_name","TEXT",fieldName);criteria.addChildField("value","TEXT",value);criteria.addChildField("search_type","INTEGER",searchType);var position=this.getChildField("search_criteria").getChildFieldNames().length;criteria.addChildField("position","INTEGER",position);if(null==groupName){groupName="";}

criteria.addChildField("group","TEXT",groupName);return criteria;}
;this.addOrSearchTerm=function(fieldName,value,searchType,groupName){var criteria=this.addSearchTerm(fieldName,value,searchType);if(null==groupName){groupName="";}

criteria.addChildField("group","TEXT",groupName);var position=this.getChildField("search_criteria").getChildFieldNames().length;criteria.addChildField("position","INTEGER",position);criteria.addChildField("is_or","BOOLEAN",true);}
;this.addConditional=function(fieldName,value,conditionalType){var searchCriteria=this.getChildField("search_criteria");var criteria=searchCriteria.addChildField(null,"COLLECTION");criteria.addChildField("criteria_type","TEXT","conditional");criteria.addChildField("field_name","TEXT",fieldName);criteria.addChildField("value","TEXT",value);criteria.addChildField("conditional_type","INTEGER",conditionalType);}
;this.addDateConditional=function(fieldName,value,conditionalType){alert("need to implement");}
;this.cloneField=function(){var newListInput=createListInput();newListInput.data=clone(this.data);newListInput.metaData=clone(this.metaData);return newListInput;}
;this.getSortFieldName=function(){return this.getChildField("sort_field").getValue();}
;this.getSearchCriteria=function(fieldName){var criteria=[];var searchCriteria=this.getChildField("search_criteria");var childNames=searchCriteria.getChildFieldNames();for(var i=0;i<childNames.length;i++)
{var aCriteria=searchCriteria.getChildField(childNames[i]);if(fieldName==aCriteria.getChildField("field_name").getValue()){criteria.push(aCriteria);}

}

return criteria;}
;this.removeSearchCriteria=function(fieldName){var searchCriteria=this.getChildField("search_criteria");var childNames=searchCriteria.getChildFieldNames();for(var i=0;i<childNames.length;i++)
{var aCriteria=searchCriteria.getChildField(childNames[i]);if(fieldName==aCriteria.getChildField("field_name").getValue()){searchCriteria.removeChildField(childNames[i]);break;}

}

}
;this.getConditionals=function(){var conditionals=[];var criteria=this.getChildField("search_criteria");var fieldNames=criteria.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var field=criteria.getChildField(fieldNames[i]);if("conditional"==field.getChildField("criteria_type").getValue()){conditionals.push(field);}

}

return conditionals;}
;}

var CONDITIONAL_EQUALS=0;var CONDITIONAL_GREATER_THAN=1;var CONDITIONAL_GREATER_THAN_EQUAL=2;var CONDITIONAL_LESS_THAN=3;var CONDITIONAL_LESS_THAN_EQUAL=4;var CONDITIONAL_NOT_EQUAL=5;var SEARCHTERM_CONTAINS=0;var SEARCHTERM_EXACT_MATCH=1;var SEARCHTERM_BEGINS_WITH=2;var SEARCHTERM_ENDS_WITH=3;var SEARCHTERM_NOT_CONTAINS=4;
function li_getSearchCriteria(listInput,fieldName){var criteria=[];var searchCriteria=listInput.getChildField("search_criteria");var childNames=searchCriteria.getChildFieldNames();for(var i in childNames)
{var aCriteria=searchCriteria.getChildField(childNames[i]);if(fieldName==aCriteria.getChildField("field_name").getValue()){criteria.push(aCriteria);}

}

return criteria;}

function li_setFieldsToLoad(listInput,fieldsToLoad){listInput.getChildField("fields_to_load").setValue(fieldsToLoad);}

function li_addSearchTerm(listInput,fieldName,value,searchType,isOr){var searchCriteria=listInput.getChildField("search_criteria");var criteria=searchCriteria.addChildField(null,"COLLECTION");criteria.addChildField("criteria_type","TEXT","search_term");criteria.addChildField("field_name","TEXT",fieldName);criteria.addChildField("value","TEXT",value);criteria.addChildField("search_type","INTEGER",searchType);if(null==isOr){isOr=false;}

criteria.addChildField("is_or","BOOLEAN",isOr);}

function li_removeCriteria(listInput,fieldName){var criteria=listInput.getChildField("search_criteria");var childNames=criteria.getChildFieldNames();for(var i in childNames)
{if(criteria.getChildField(childNames[i]).getChildField("field_name").getValue()==fieldName){criteria.removeChildField(i);break;}

}

}


function createRecordInput(type,id){var recordInput=new DynField(null,{}
,{}
,null,null);recordInput.usedAddField=false;recordInput.addChildField("type","TEXT",type);recordInput.addChildField("id","INTEGER",id);recordInput.addChildField("fields_to_load","TEXT","*");recordInput.addChildField("record_names","TEXT","");
extendField(recordInput,g_recordInputBase);return recordInput;}

function turnIntoRecordInput(field){if(!field){return null;}

extendField(field,g_recordInputBase);return field;}

var g_recordInputBase=new RecordInputBase();function RecordInputBase(){this.clearFieldsToLoad=function(){this.getChildField("fields_to_load").setValue("");}
;this.addField=function(fieldName){var fieldsToLoad=this.getChildField("fields_to_load");var value=fieldsToLoad.getValue();if(!this.usedAddField){this.usedAddField=true;value=fieldName;}

else 
{value+=","+fieldName;}

fieldsToLoad.setValue(value);return this;}
;this.addName=function(recordName){var recordNames=this.getChildField("record_names");var value=recordNames.getValue();if(value){value+=","+recordName;}

else 
{value=recordName;}

recordNames.setValue(value);return this;}
;}


mc_typeToDefaultValue["MCL"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("name","TEXT");field.addChildField("records_to_load","COLLECTION");field.addChildField("records_by_key","COLLECTION");field.addChildField("record_names","COLLECTION");field.addChildField("fields_to_process","COLLECTION");field.addChildField("fields_to_process_first","COLLECTION");field.addChildField("fields_to_process_last","COLLECTION");field.addChildField("lists","ARRAY");field.addChildField("templates","COLLECTION");field.addChildField("dyn_tables","COLLECTION");field.addChildField("values","COLLECTION");return {data:field.data,metaData:field.metaData}
;}

vfc_registerConverter("MCL",vfc_returnNoValue);

function extendList(aList){aList.copyToListInput=function(){if(aList.listInput){return aList.listInput;}

var listInput=createListInput(this.record_type,this.name,this.start_record,this.max_record_count,this.sort_field,this.sort_direction);aList.listInput=listInput;var fields=aList.fields_to_load;for(var i in fields)
{listInput.addField(fields[i]);}

var searchCriteria=aList.search_criteria;for(var i in searchCriteria)
{var criteria=searchCriteria[i];if("search_term"==criteria.criteria_type){if(criteria.is_or){listInput.addOrSearchTerm(criteria.field_name,criteria.value,criteria.search_type,criteria.group);}

else 
{listInput.addSearchTerm(criteria.field_name,criteria.value,criteria.search_type);}

}

else if("conditional"==criteria.criteria_type){listInput.addConditional(criteria.field_name,criteria.value,criteria.conditional_type);}

}

return listInput;}
;aList.getFirstRecord=function(){return this.ownerCache.getRecord(this.record_type,this.ids[0]);}
;return aList;}

function createGeneralExecuter(name,miniCache,instruction,basePackage){var gE=miniCache.createAction(name,"GXT");prepareGE(gE,instruction,basePackage);return gE;}

function createGEToRunFirst(name,miniCache,instruction,basePackage){var gE=miniCache.createFirstAction(name,"GXT");prepareGE(gE,instruction,basePackage);return gE;}

function createGEToRunLast(name,miniCache,instruction,basePackage){var gE=miniCache.createLastAction(name,"GXT");prepareGE(gE,instruction,basePackage);return gE;}

function prepareGE(gE,instruction,basePackage){var instructions=gE.getChildField("instructions");instructions.addChildField(instruction,"TEXT",instruction);gE.getChildField("base_package").setValue(basePackage);}

mc_typeToDefaultValue["GXT"]=function(){var gE=new DynField(null,{}
,{}
,null,null);gE.addChildField("instructions","COLLECTION");gE.addChildField("base_package","TEXT");gE.addChildField("exec_params","COLLECTION");return gE;}

vfc_registerConverter("GXT",vfc_returnNoValue);
mc_fieldTypeExtenders["GXT"]=function(dynField){dynField.getResults=function(){return this.getChildField("exec_res");}

dynField.getResultByName=function(resName){return this.getChildField("exec_res").getChildField(resName)
}

dynField.addExecParamDynField=function(fieldType,dynField,name){if(null==name){name=dynField.name;}

return this.getChildField("exec_params").insertChildField(name,fieldType,dynField);}

dynField.addExecParamObj=function(name,fieldType,value){return this.getChildField("exec_params").addChildField(name,fieldType,value);}

dynField.getExecParam=function(paramName){return this.getChildField("exec_params").getChildField(paramName);}

}

;var rd_counter=0;function createRecordDeleter(miniCache){rd_counter++;var name="deleter"+rd_counter;var deleter=createGeneralExecuter(name,miniCache,"RecordDeleter");addRecordDeleterExtensions(deleter);return deleter;}

function createRecordDeleterToRunFirst(miniCache){rd_counter++;var name="deleter"+rd_counter;var deleter=createGEToRunFirst(name,miniCache,"RecordDeleter");addRecordDeleterExtensions(deleter);return deleter;}

function addRecordDeleterExtensions(deleter){var params=deleter.getChildField("exec_params");params.addChildField("type","TEXT");params.addChildField("ids","TEXT");params.addChildField("is_delete_tas","BOOLEAN",false);deleter.setType=function(type){this.getChildField("exec_params").getChildField("type").setValue(type);}
;deleter.addId=function(id){var ids=this.getChildField("exec_params").getChildField("ids");var value=ids.getValue();value+=id+",";ids.setValue(value);}
;deleter.setIsDeleteTas=function(isDeleteTas){this.getChildField("exec_params").getChildField("is_delete_tas").setValue(isDeleteTas);}
;}


function sorter_sortAscending(sortProperty,arrayToSort){sorter_sortProperty=sortProperty;arrayToSort.sort(sorter_generalCompare);sorter_sortProperty=null;}
;function sorter_sortDescending(sortProperty,arrayToSort){sorter_sortProperty=sortProperty;arrayToSort.sort(sorter_reverseCompare);sorter_sortProperty=null;}
;var sorter_sortProperty;function sorter_generalCompare(arg1,arg2){if(!sorter_sortProperty){alert("You must set the sort property");}

eval("var value1 = arg1."+sorter_sortProperty);eval("var value2 = arg2."+sorter_sortProperty);if(value1>value2){return 1;}

else if(value1<value2){return -1;}

else 
{return 0;}

}
;function sorter_reverseCompare(arg1,arg2){return sorter_generalCompare(arg2,arg1);}

;function ValidationHandler(){this.valTypes={}
;this.valObjects={}
;this.errors=[];this.errorDisplayFx;this.types={}
;this.valObjectsByType={}

this.errorList={}
;this.errorHandlerByType={}
;}

ValidationHandler.prototype=new ValidationBase();function ValidationBase(){
this.addVal=function(type,valFx){this.valTypes[type]=valFx;}
;
this.addObjectToVal=function(type,object){var objsByType=this.valObjectsByType[type];if(null==objsByType){objsByType=[];this.valObjectsByType[type]=objsByType;}

objsByType.push(object);}
;this.addValidationObject=function(type,valObject){this.valObjects[type]=valObject;}

this.getValObject=function(type){return this.valObjects[type];}


this.setErroDisplayFx=function(errorDisplayFx){this.errorDisplayFx=errorDisplayFx;}


this.validate=function(){this.resetErrors();var objsByType=this.valObjectsByType;for(var type in objsByType)
{var valFx=this.types[type]
if(null==valFx){valFx=this.valTypes[type];}

if(valFx==null){alert("There is not  a validation function registered for the type "+type);return ;}

var objList=objsByType[type];for(var i=0;i<objList.length;i++)
{var element=objList[i];if(null==element){continue;}

if(!isInDom(element)&&element.tagName!=undefined){objList[i]=null;continue;}

var result=valFx(objList[i]);var objectType=typeof(result);if(objectType=="object"){for(var j=0;j<result.length;j++)
{var error=result[j];this.errors.push(error);this.hasErrors=true;}

break}

else if(objectType=="boolean"){if(!result){this.addToErrorList(type,element);}

}

}

}

if(this.hasErrors){this.showErrors();return false;}

return true;}
;this.registerTypeValFx=function(type,valFx){this.types[type]=valFx;}
;this.registerErrorMsgFx=function(type,errorFx){this.errorHandlerByType[type]=errorFx;}
;this.registerValidation=function(type,valFx,error){this.types[type]=valFx;this.errorHandlerByType[type]=error;}
;this.showErrors=function(){var errMsg="";var errorsByType=this.errorList;for(var type in errorsByType)
{var errorFx=this.errorHandlerByType[type]
if(null==errorFx){alert("There is no error handling function registered for the type "+type);return ;}

var errorElList=errorsByType[type];for(var i=0;i<errorElList.length;i++)
{if(typeof(errorFx)=="string"){errMsg+=errorFx+"\n";}

else 
{var aMsg=errorFx(errorElList[i]);if(aMsg.trim()!=""){errMsg+=aMsg+"\n";}

}

}

}

var errors=this.errors;for(var i=0;i<errors.length;i++)
{errMsg+=errors[i]+"\n";}

if(null!=this.errorDisplayFx){this.errorDisplayFx(errMsg.replaceAll("\n","<br>"));}

else if(window.showMessage){showMessage(errMsg.replaceAll("\n","<br>"));}

else 
{alert(errMsg);}

}
;this.resetErrors=function(){this.hasErrors=false;this.errorList={}
;this.errors=[];}
;this.addToErrorList=function(type,element){this.hasErrors=true;var errorListByType=this.errorList[type];if(null==errorListByType){errorListByType=[];this.errorList[type]=errorListByType;}

errorListByType.push(element);}
;}
;if(null==ValidationUtil){var ValidationUtil=new ValidationHandler();}


var KeyCodeUtil=new KeyCodeUtilBase();function KeyCodeUtilBase(){this.getTranslation=function(keyCode){var trans=this.KEY_CODE_TRANSLATOR[keyCode];return trans;}
;this.cancelPressKey=function(event){if(null!=event.stopPropagation){event.stopPropagation();event.preventDefault();}

else 
{window.event.returnValue=false;window.event.cancelBubble=true;}

return null;}
;this.isNumeric=function(event){var keyCode=this.getKeyCode(event);if(keyCode>=48&&keyCode<=57){return true;}

return false;}
;this.isAlphabetic=function(event){var keyCode=this.getKeyCode(event);if((keyCode>=65&&keyCode<=90)||(keyCode>=97&&keyCode<=122)){return true;}

return false;}
;this.getKeyCode=function(event){var key;if(null!=event&&null!=event.which){key=event.which;}

else if(null!=window.event){key=window.event.keyCode;}

return key;}
;this.isNumber=function(keyCode){return ((keyCode>=48&&keyCode<=57)||(keyCode>=96&&keyCode<=105));}
;this.isCharacter=function(event,keyCode){var keyCodePressed=this.getKeyCode(event);if(keyCodePressed==keyCode){return true;}

return false;}

this.isValidCharForNumber=function(event){if(this.isNumeric(event)){return true;}

var isValidCharacter=(this.isCharacter(event,46)||
this.isCharacter(event,44)||
this.isCharacter(event,45)||
this.isCharacter(event,8)||
this.isCharacter(event,0));return isValidCharacter;}

var kc=[];kc[48]="0";kc[49]="1";kc[50]="2";kc[51]="3";kc[52]="4";kc[53]="5";kc[54]="6";kc[55]="7";kc[56]="8";kc[57]="9";kc[65]="A";kc[66]="B";kc[67]="C";kc[68]="D";kc[69]="E";kc[70]="F";kc[71]="G";kc[72]="H";kc[73]="I";kc[74]="J";kc[75]="K";kc[76]="L";kc[77]="M";kc[78]="N";kc[79]="O";kc[80]="P";kc[81]="Q";kc[82]="R";kc[83]="S";kc[84]="T";kc[85]="U";kc[86]="V";kc[87]="W";kc[88]="X";kc[89]="Y";kc[90]="Z";kc[96]="0";kc[97]="1";kc[98]="2";kc[99]="3";kc[100]="4";kc[101]="5";kc[102]="6";kc[103]="7";kc[104]="8";kc[105]="9";this.KEY_CODE_TRANSLATOR=kc;}
;

function getProperty(properties,name,defaultValue){if(properties==null||properties[name]==null){return defaultValue;}

return properties[name];}
;

function RequiredValidation(validationHandler){this.reqElCount=0;this.validationHandler=validationHandler;validationHandler.addValidationObject(this.TYPE,this);validationHandler.registerValidation(this.TYPE,this.validateFx,this.errorFx);}

RequiredValidation.prototype=new RequiredValidationBase();function RequiredValidationBase(){this.TYPE="REQUIRED";var eV={}
;eV[g_sessionInformation.settings.date_format.empty_date]=true;this.emptyValues=eV;this.attachValidation=function(element){if(element.name.trim()==""){element.name="Unnamed element "+this.reqElCount;}

this.validationHandler.addObjectToVal(this.TYPE,element);this.reqElCount++;}
;this.validateFx=function(element){var value=element.value.trim();if(value==""||RequiredUtil.emptyValues[value]){return false;}

return true;}

this.errorFx=function(element){return element.name+" "+"is required.";}
;this.registerEmptyValue=function(val){this.emptyValues[val]=true;}
;}

var RequiredUtil=new RequiredValidation(ValidationUtil);
;;;;
;;;;;;;;;;;;;;;
function MiniCache(){
this.ownerWindow;
this.records_by_key={}
;
this.records={}
;
this.lists={}
;
this.values={}
;
this.record_meta_data={}
;
this.templates={}
;
this.template_meta_data={}
;
this.dyn_tables={}
;
this.tables_to_delete=[];
this.record_names={}
;
this.validationHandler=new ValidationHandler();
this.onBeforeProcessFxs={}
;
this.addBeforeProcessFx=function(fx,name){var count=++mc_processFxCounter;if(!name){name="fx"+count;}

this.onBeforeProcessFxs[name]=fx;}
;
this.removeBeforeProcessFx=function(name){delete(this.onBeforeProcessFxs[name]);}
;
this.runBeforeProcesses=function(){for(var i in this.onBeforeProcessFxs)
{var fx=this.onBeforeProcessFxs[i];fx();}

}
;
this.addRecordName=function(record,name){this.record_names[name]={type:record.type,id:record.getId()}
;}
;
this.getRecordByName=function(name){var info=this.record_names[name];if(!info){return null;}

return this.getRecord(info.type,info.id);}
;this.getValue=function(name){return this.values[name];}
;
this.getDynTable=function(type){var data=this.templates[type];var metaData=this.template_meta_data[type];var settings=this.dyn_tables[type];return new DynTable(type,data,metaData,settings,this);}
;
this.getRecord=function(type,id){id=parseInt(id);if(0>id&&mc_tempToRealId[type]&&mc_tempToRealId[type][id]){id=mc_tempToRealId[type][id];}

var recordsOfType=this.records[type];if(!recordsOfType){if(mc_masterCache&&mc_masterCache.records[type]){this.records[type]=clone(mc_masterCache.records[type]);this.record_meta_data[type]=clone(mc_masterCache.record_meta_data[type]);recordsOfType=this.records[type];}

else 
{return null;}

}

var data=recordsOfType[id];if(!data){if(mc_masterCache&&mc_masterCache.records[type]&&mc_masterCache.records[type][id]){this.records[type][id]=clone(mc_masterCache.records[type][id]);this.record_meta_data[type][id]=clone(mc_masterCache.record_meta_data[type][id]);data=recordsOfType[id];}

else 
{return null;}

}

var metaData=this.record_meta_data[type][id];return new Record(type,id,data,metaData,this);}
;
this.getListByName=function(name){var aList=this.lists[name];if(!aList){if(!mc_masterCache){return null;}

var masterList=mc_masterCache.lists[name];if(null==masterList){return null;}

var masterCache=masterList.ownerCache;masterList.ownerCache=null;aList=clone(masterList);masterList.ownerCache=masterCache;}

if(!aList){return null;}

aList.ownerCache=this;return extendList(aList);}
;
this.getRecordByKey=function(type,fieldName,key){if(mc_masterCache&&mc_masterCache.records_by_key[type+"|"+fieldName+"|"+key]){var recordInfo=clone(mc_masterCache.records_by_key[type+"|"+fieldName+"|"+key]);}

else 
{var recordInfo=this.records_by_key[type+"|"+fieldName+"|"+key];}

var record=null;if(null!=recordInfo){record=this.getRecord(recordInfo.type,recordInfo.id);}

return record;}
;
this.deleteRecord=function(type,id){var deleter=createRecordDeleter(this);deleter.setType(type);deleter.addId(id);this.clearRecord(type,id);}
;
this.clearRecord=function(type,id){var mData=this.record_meta_data[type];if(!mData){return ;}

delete(mData[id]);var recordData=this.records[type];delete(recordData[id]);var isEmpty=true;for(var rId in recordData)
{isEmpty=false;break;}

if(isEmpty){delete(this.record_meta_data[type]);delete(this.records[type]);}

this.cancelRecordToLoad(type,id);}
;
this.clearAllRecords=function(){this.records_by_key={}
;this.records={}
;this.lists={}
;this.record_meta_data={}
;}
;
this.getTemplate=function(type){if(!this.templates[type]&&mc_masterCache.templates[type]){this.templates[type]=clone(mc_masterCache.templates[type]);this.template_meta_data[type]=clone(mc_masterCache.template_meta_data[type]);}

if(this.templates[type]){var template=new Record(type,0,this.templates[type],this.template_meta_data[type],this);template.isTemplate=true;return template;}

return null;}
;
this.createRecord=function(type,id){if(!id){mc_newIdCounter--;id=mc_newIdCounter;}

var templateData=this.getTemplate(type);var record=clone(templateData.data);record.type=type;record.id=id;var recordsOfType=this.records[type];if(!recordsOfType){this.records[type]={}
;recordsOfType=this.records[type];}

recordsOfType[id]=record;var recordMetaData=clone(templateData.metaData);recordMetaData.type=type;recordMetaData.id=id;var metaDataForType=this.record_meta_data[type];if(!metaDataForType){this.record_meta_data[type]={}
;metaDataForType=this.record_meta_data[type];}

metaDataForType[id]=recordMetaData;var record=this.getRecord(type,id);record.setDoSave();return record;}
;this.createTable=function(name,displayName,pluralName,packageName){this.dyn_tables[name]={singularName:displayName,pluralName:pluralName,packageName:packageName,cachingSetting:"",doSave:true}
;this.templates[name]={}
;this.template_meta_data[name]={}
;}
;this.initializeProcessor=function(){this.records["processor"]={}
;this.records["processor"][0]={}
;this.record_meta_data["processor"]={}
;this.record_meta_data["processor"][0]={}
;this.record_meta_data["processor"][0].doProcess=true;var recordToProcess=this.getRecord("processor",0);return recordToProcess.addField("processor","MCL","",0);}
;this.processor=this.initializeProcessor();this.process=function(onAfterProcessFx,onErrorFx){this.syncToMaster();var thisCache=this;var finishFx=function(){thisCache.processor=thisCache.initializeProcessor();if(onAfterProcessFx){onAfterProcessFx();}

}

mcs_process(thisCache,finishFx,onErrorFx);}
;
this.syncProcess=function(){this.syncToMaster();var thisCache=this;mcs_process(thisCache);thisCache.processor=thisCache.initializeProcessor();}
;this.createAction=function(name,fieldType){return this.processor.getChildField("fields_to_process").addChildField(name,fieldType);}
;this.createFirstAction=function(name,fieldType){return this.processor.getChildField("fields_to_process_first").addChildField(name,fieldType);}
;this.createLastAction=function(name,fieldType){return this.processor.getChildField("fields_to_process_last").addChildField(name,fieldType);}
;this.removeActionField=function(name){this.processor.getChildField("fields_to_process_last").removeChildField(name);this.processor.getChildField("fields_to_process_first").removeChildField(name);this.processor.getChildField("fields_to_process").removeChildField(name);}
;this.getActionField=function(name){return this.getRecord(name,0).getField(name);}

this.addKeyedRecordToLoad=function(type,fieldName,key,fieldsToLoad){if(!fieldsToLoad){fieldsToLoad="*";}

var recordsByKey=this.processor.getChildField("records_by_key");var requestId=type+fieldName+key;var recordToLoad=recordsByKey.addChildField(requestId,"COLLECTION",null,null,null);recordToLoad.addChildField("type","TEXT",type,null,null);recordToLoad.addChildField("field_name","TEXT",fieldName,null,null);recordToLoad.addChildField("key","TEXT",key,null,null);recordToLoad.addChildField("fields_to_load","TEXT",fieldsToLoad,null,null);return recordToLoad;}
;this.addRecordToLoad=function(type,id){var recordInput=createRecordInput(type,id);this.addRecordInput(recordInput);return recordInput;}
;this.addRecordInput=function(recordInput){var requestId=recordInput.data.type+recordInput.data.id;this.processor.getChildField("records_to_load").insertChildField(requestId,"COLLECTION",recordInput);}
;this.cancelRecordToLoad=function(type,id){var requestId=type+id;this.processor.getChildField("records_to_load").removeChildField(requestId);}

this.addListToLoad=function(type,name,startRecord,max,sortField,sortDirection){var listInput=createListInput(type,name,startRecord,max,sortField,sortDirection);this.addListInput(listInput);return listInput;}
;this.addListInput=function(listInput){this.processor.getChildField("lists").insertChildField(null,"COLLECTION",listInput);}
;this.addTableToLoad=function(tableName){var tablesToLoad=this.processor.getChildField("dyn_tables");tablesToLoad.addChildField(tableName,"TEXT",tableName);}
;this.addTemplateToLoad=function(tableName){var templates=this.processor.getChildField("templates");templates.addChildField(tableName,"TEXT",tableName);}
;this.syncToMaster=function(){if(this.isMaster||!mc_masterCache){return ;}

var recordsToSave=this.getRecordsToSave();for(var i in recordsToSave)
{var newRecord=recordsToSave[i];var masterRecord=mc_masterCache.getRecord(newRecord.type,newRecord.id);if(!masterRecord){continue;}

mc_cloneContent(newRecord.data,masterRecord.data);mc_cloneContent(newRecord.metaData,masterRecord.metaData);masterRecord.resetMetaInfo(null,"bs");}

}
;this.getRecordsToSave=function(){var recordsToSave=[];var recordsMetaData=this.record_meta_data;for(var type in recordsMetaData)
{var records=recordsMetaData[type];for(var id in records)
{var record=this.getRecord(type,id);if(record.metaData.doSave){recordsToSave.push(record);}

}

}

return recordsToSave;}
;this.getRecordsToSaveOfAType=function(type){var recordsToSave=[];var records=this.record_meta_data[type];for(var id in records)
{var record=this.getRecord(type,id);if(record.metaData.doSave){recordsToSave.push(record);}

}

return recordsToSave;}
;this.getRecordsByType=function(type,sortField,sortDirection){var recordsByType=[];var records=this.record_meta_data[type];for(var id in records)
{var record=this.getRecord(type,id);recordsByType.push(record);}

if(sortField){if(sortDirection=="asc"||!sortDirection){sorter_sortAscending("data."+sortField,recordsByType);}

else 
{sorter_sortDescending("data."+sortField,recordsByType);}

}

return recordsByType;}
;this.syncToMasterOnProcess=function(){this.doSyncToMaster=true;}

this.clearRecordsOfAType=function(type){var records=this.record_meta_data[type];for(var id in records)
{this.clearRecord(type,id);}

}

this.copyTemplate=function(recordType,fromMiniCache){var data=fromMiniCache.templates[recordType];var metaData=fromMiniCache.template_meta_data[recordType]
if(data&&metaData){this.templates[recordType]=clone(data);this.template_meta_data[recordType]=clone(metaData);}

}
;
this.addValType=function(valType,valFx){this.validationHandler.addVal(valType,valFx);return this;}
;
this.addValToObj=function(valType,valObj){this.validationHandler.addObjectToVal(valType,valObj);return this;}
;
this.validate=function(){return this.validationHandler.validate();}
;
this.id=++mc_newCacheIdCounter;
this.setOwnerWindow=function(ownerWindow){this.ownerWindow=ownerWindow;}
;
this.isDataToLoad=function(){var p=this.processor.data;return (this.isEmpty(p.records_by_key)||this.isEmpty(p.records_to_load)||this.isEmpty(p.lists));}
;this.isEmpty=function(object){for(var i in object)
{var notEmpty=object[i];return false;}

return true;}
;}
;function getMasterCache(){if(null==mc_masterCache){mc_masterCache=new MiniCache();mc_masterCache.isMaster=true;mc_masterCache.id="master";}

return mc_masterCache;}

var mc_newIdCounter=0;var mc_newCacheIdCounter=0;var mc_processFxCounter=0;var mc_tempToRealId={}
;if(!mc_masterCache){var mc_masterCache=null;}

if(!mc_objectToHtmlFxByType){var mc_objectToHtmlFxByType={}
;}

function mc_getFieldNames(metaData){var fieldNames=[];for(var i in metaData)
{var nameLength=i.length;if(nameLength<=3){continue;}

var suffix=i.substring(nameLength-3,nameLength);if("_do"==suffix){var fieldName=i.substring(0,nameLength-3);fieldNames.push({name:fieldName,order:metaData[i]}
);}

}

sorter_sortAscending("order",fieldNames);for(var i in fieldNames)
{fieldNames[i]=fieldNames[i].name;}

return fieldNames;}

function mc_clearObject(anObject){for(var i in anObject)
{delete(anObject[i]);}

}


function mc_cloneContent(source,destination){mc_clearObject(destination);for(var i in source)
{destination[i]=clone(source[i]);}

return destination;}


var HtmlDtd=new HtmlDtdDef();function HtmlDtdDef(){this.isATag=function(tagName){return atags[tagName.toUpperCase()]?true:false;}
;this.isEmptyTag=function(tagName){return emptyTags[tagName.toLowerCase()]?true:false;}

this.isNotEmptyTag=function(tagName){return !this.isEmptyTag(tagName)&&this.isValidTag(tagName);}

this.isValidTag=function(tagName){if(!tagName){}

return tags[tagName.toUpperCase()]?true:false;}

this.getAttributes=function(tagName){return clone(tags[tagName]);}

var emptyTags={area:1,base:1,br:1,col:1,hr:1,img:1,input:1,link:1,meta:1,param:1}
;var atags={}
;this.atags=atags;atags["A_COMPONENT"]=[];atags["A_CYCLE"]=[];atags["A_CRITERIA"]=[];atags["A_FIELD"]=[];atags["A_LIST"]=[];atags["A_MODULE"]=[];atags["A_NAV"]=[];var tags={}
;this.tags=tags;
tags["A"]=["href","tabIndex"];tags["ABBR"]=[];tags["ACRONYM"]=[];tags["ADDRESS"]=[];tags["APPLET"]=[];tags["AREA"]=[];tags["B"]=[];tags["BASE"]=[];tags["BASEFONT"]=[];tags["BDO"]=[];tags["BIG"]=[];tags["BLOCKQUOTE"]=[];tags["BODY"]=["topMargin","rightMargin","bottomMargin","leftMargin"];tags["BR"]=[];tags["BUTTON"]=["tabIndex"];tags["CAPTION"]=[];tags["CENTER"]=[];tags["CITE"]=[];tags["CODE"]=[];tags["COL"]=["align","vAlign"];tags["COLGROUP"]=[];tags["DD"]=[];tags["DEL"]=[];tags["DFN"]=[];tags["DIR"]=[];tags["DIV"]=["align"];tags["DL"]=[];tags["DT"]=[];tags["EM"]=[];tags["FIELDSET"]=[];tags["FONT"]=[];tags["FORM"]=[];tags["FRAME"]=[];tags["FRAMESET"]=[];tags["H1"]=[];tags["H2"]=[];tags["H3"]=[];tags["H4"]=[];tags["H5"]=[];tags["H6"]=[];tags["HEAD"]=[];tags["HR"]=[];tags["HTML"]=[];tags["I"]=[];tags["IFRAME"]=[];tags["IMG"]=["src","alt"];tags["INPUT"]=[];tags["INS"]=[];tags["ISINDEX"]=[];tags["KBD"]=[];tags["LABEL"]=[];tags["LEGEND"]=[];tags["LI"]=[];tags["LINK"]=[];tags["MAP"]=[];tags["MENU"]=[];tags["META"]=[];tags["NOFRAMES"]=[];tags["NOSCRIPT"]=[];tags["OBJECT"]=[];tags["OL"]=[];tags["OPTGROUP"]=[];tags["OPTION"]=[];tags["P"]=["align"];tags["PARAM"]=[];tags["PRE"]=[];tags["Q"]=[];tags["S"]=[];tags["SAMP"]=[];tags["SCRIPT"]=[];tags["SELECT"]=[];tags["SMALL"]=[];tags["SPAN"]=[];tags["STRIKE"]=[];tags["STRONG"]=[];tags["STYLE"]=[];tags["SUB"]=[];tags["SUP"]=[];tags["TABLE"]=["cellSpacing","cellPadding","border","summary"];tags["TBODY"]=[];tags["TD"]=["align","vAlign","colSpan","rowSpan"];tags["TEXTAREA"]=[];tags["TFOOT"]=[];tags["TH"]=[];tags["THEAD"]=[];tags["TITLE"]=[];tags["TR"]=[];tags["TT"]=[];tags["U"]=[];tags["UL"]=[];tags["VAR"]=[];tags["ARTICLE"]=[];tags["ASIDE"]=[];tags["BDI"]=[];tags["COMMAND"]=[];tags["DETAILS"]=[];tags["DIALOG"]=[];tags["SUMMARY"]=[];tags["FIGURE"]=[];tags["FIGCAPTION"]=[];tags["FOOTER"]=[];tags["HEADER"]=[];tags["HGROUP"]=[];tags["MARK"]=[];tags["METER"]=[];tags["NAV"]=[];tags["PROGRESS"]=[];tags["RUBY"]=[];tags["RT"]=[];tags["RP"]=[];tags["SECTION"]=[];tags["TIME"]=[];tags["WBR"]=[];}

function CssClass(selector,media){this.media=media;this.selector=selector;this.properties=[];}
;CssClass.prototype=new CssClassBase();function CssClassBase(){this.sheetsByMedia={}
;this.add=function(property,value){this.properties.push({property:property,value:value}
);}
;
this.init=function(doc){var styleSheet=this.getStyleSheet(doc);var rules=styleSheet.rules;var index=(rules!=null)?rules.length:0;var styleStr="";for(var i=0;i<this.properties.length;i++)
{styleStr+=this.properties[i].property+":"+this.properties[i].value+";"
}

var selectors=this.selector.split(",");for(var i=0;i<selectors.length;i++)
{var aSelector=selectors[i];try
{if(!styleSheet.insertRule){if(!this.media){styleSheet.addRule(aSelector,styleStr,index);}

}

else 
{var classStr="";if(this.media){classStr+="@media "+this.media+" {";}

classStr+=aSelector+"{"+styleStr+"}";if(this.media){classStr+="}";}

styleSheet.insertRule(classStr,index);}

index++;}

catch(e)
{debugger;}

}

}
;
this.getStyleSheet=function(doc){doc=doc||document;if(false&&this.media){if(this.sheetsByMedia[this.media]){return CssClass.prototype.sheetsByMedia[this.media];}

var properties={media:this.media}
;return StyleSheetUtil.createStyleSheet(doc);}

else 
{return StyleSheetUtil.getStyleSheet(doc);}

}
;}
;

if(!window["StyleSheetUtil"]){var StyleSheetUtil=new StyleSheetUtilBase();}

function StyleSheetUtilBase(){this.rootStyleSheet;this.idToPath={}
;this.clearIdToPath=function(){this.idToPath={}
;}
;this.getPath=function(styleSheetId){var path=this.idToPath[styleSheetId];if(path){return path;}

var current=new Date();var path="/0/"+styleSheetId+".css?"+current.getTime();this.idToPath[styleSheetId]=path;return path;}
;this.getStyleSheet=function(doc){if(!doc||document==doc){if(!this.rootStyleSheet){this.rootStyleSheet=this.createStyleSheet(doc);}

return this.rootStyleSheet;}

return this.createStyleSheet(doc);}
;this.createStyleSheet=function(doc,properties){doc=doc||document;var index=doc.styleSheets.length;var el=cE("style");el.rel="stylesheet";if(properties){for(var i in properties)
{el[i]=properties[i];}

}

var heads=doc.getElementsByTagName("head");aE(heads[0],el);var sS=doc.styleSheets[index];return sS;}
;this.enableSheetById=function(styleSheetId,afterFx){var linkEl=this.findSheetElById(styleSheetId);if(linkEl){linkEl.removeAttribute("disabled");if(afterFx){afterFx();}

}

else 
{this.appendSheetById(styleSheetId,afterFx);}

}
;this.disableSheetById=function(styleSheetId){var linkEl=this.findSheetElById(styleSheetId);if(linkEl){linkEl.disabled=true;}

}
;this.appendSheetById=function(styleSheetId,afterFx){var path=this.getPath(styleSheetId);this.appendStyleSheet(path,afterFx);}
;this.appendStyleSheet=function(path,afterFx){var headEl=document.getElementsByTagName('head')[0];var cssEl=document.createElement("link");cssEl.rel="stylesheet"
cssEl.href=path;cssEl.type="text/css";aE(headEl,cssEl);var fx=function(){var div=cE("div",document.body);document.body.removeChild(div);if(afterFx){afterFx();}

}
;E.add(cssEl,"load",fx);}
;this.removeSheetById=function(styleSheetId){var headEl=document.getElementsByTagName('head')[0];var links=headEl.getElementsByTagName("link");for(var i=links.length-1;i>=0;i--)
{var aLink=links[i];var href=aLink.href;if(!href){continue;}

var url=UrlUtil.getUrlWithNoParams(href);url=UrlUtil.removeOrigin(url);if(this.getRelativePath(styleSheetId)==url){aLink.parentElement.removeChild(aLink);break;}

}

}
;this.removeStyleSheet=function(path){var headEl=document.getElementsByTagName('head')[0];var links=headEl.getElementsByTagName("link");for(var i=links.length-1;i>=0;i--)
{var aLink=links[i];var href=aLink.href;if(!href){continue;}

var rPath=href.substring(window.location.origin.length);if(rPath.substring(0,path.length)==path){aLink.parentElement.removeChild(aLink);break;}

}

}
;this.findSheetElById=function(styleSheetId){var headEl=document.getElementsByTagName('head')[0];var links=headEl.getElementsByTagName("link");for(var i=links.length-1;i>=0;i--)
{var aLink=links[i];var href=aLink.href;if(!href){continue;}

var url=UrlUtil.getUrlWithNoParams(href);url=UrlUtil.removeOrigin(url);if(this.getRelativePath(styleSheetId)==url){return aLink;}

}

}
;this.getRelativePath=function(styleSheetId){return "/0/"+styleSheetId+".css";}
;}

;;;;if(!window["CssUtil"]){var CssUtil=new CssUtilBase();}

function CssUtilBase(){this.rootStyleSheet;this.isInit=false;this.getHighestZIndex=function(){return this.findHighestZIndex(document.body)+1;}
;this.findHighestZIndex=function(node){if(node.nodeType!=1){return 0;}

var count=node.childNodes.length;var zIndex=parseInt(CssUtil.getStyle(node,"z-index"));var value=isNaN(zIndex)?0:zIndex;for(var i=0;i<count;i++)
{value=Math.max(value,this.findHighestZIndex(node.childNodes[i]));}
;return value;}
;this.getZIndex=function(element){var z=parseInt(CssUtil.getStyle(element,"z-index"));return isNaN(z)?0:z;}
;this.makeNotSelectable=function(element){if(!this.isInit){this.initCss();this.isInit=true;}

this.addClassToEl(element,"notSelectable");}
;this.makeSelectable=function(element){this.removeClassFromEl(element,"notSelectable");}
;this.getNumberUnit=function(value){var index=value.length-1;var unit="";while(index>=0&&isNaN(parseInt(value.charAt(index))))
{unit=value.charAt(index)+unit;index--;}

return unit;}
;this.getNumberVal=function(value){if(!value){return 0;}

var unit=this.getNumberUnit(value);var number=parseFloat(value.substring(0,value.length-unit.length));return number||0;}
;this.getElementsByClassName=function(className,doc){if(null==doc){doc=document;}

var results=[];if(doc.body.getElementsByClassName){return doc.body.getElementsByClassName(className);}

else {var elements=document.all;for(var i=0;i<elements.length;i++)
{if(this.elHasClass(elements[i],className)){results.push(elements[i]);}

}

}

return results;}


this.getStyle=function(element,property){if(!element||element.nodeType==3||element.nodeType==8){return null;}

if(element.currentStyle){return element.currentStyle[property];}

else if(window&&window.getComputedStyle){var style=document.defaultView.getComputedStyle(element);if(!style){return null;}

return style.getPropertyValue(property);}

return "";}
;this.findStyle=function(node,property){if(node.nodeType==3){node=node.parentElement;}

return this.getStyle(node,property);}
;this.setFloat=function(element,value){var prop=BrowserUtil.isIE()?"styleFloat":"cssFloat";element.style[prop]=value;}
;this.getHtmlPropName=function(jsPropName){var parts=[];var partStart=0;for(var i=0;i<jsPropName.length;i++)
{var aChar=jsPropName.charAt(i);if(aChar>='A'&&aChar<='Z'){parts.push(jsPropName.substring(partStart,i));partStart=i;}

}

parts.push(jsPropName.substring(partStart));var propName=parts[0];for(var i=1;i<parts.length;i++)
{propName+="-"+parts[i];}

return propName.toLowerCase();}
;this.pixelToInt=function(str){var strSize=str.length;if(!strSize||(strSize<2)||str.charAt(strSize-2)!="p"||str.charAt(strSize-1)!="x"){return (str=="")?0:str;}

var value=parseInt(str.substring(0,str.length-2));if(!value){return 0;}

return value;}
;this.intToPixel=function(value){return (typeof(value)=="number")?value+"px":value;}
;this.getClasses=function(element,startingWith){var classStr=element.className;var classes=classStr.split(" ");if(!startingWith){if(classes[0]==""){classes.splice(0,1);}

return classes;}

var filtered=[];for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(!aClass){continue;}

if(startingWith==aClass.substring(0,startingWith.length)){filtered.push(aClass);}

}

return filtered;}
;this.elHasClass=function(element,className){var classStr=element.className;if(!classStr){return false;}

var classes=classStr.split(" ");for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(aClass&&aClass==className){return true;}

}

return false;}
;this.addClassToEl=function(element,classToAdd){var className=element.className;var classes=className.split(" ");for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(aClass&&aClass==classToAdd){return ;}

}

var newClassName=element.className+" "+classToAdd;newClassName=newClassName.trim();try
{element.className=newClassName;}

catch(e){}

}
;this.removeClassesStartingWith=function(element,startString){var rE=new RegExp("^"+startString);var className=element.className;var classes=className.split(" ");var newClassName="";for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(!aClass){continue;}

if(!rE.test(aClass)){newClassName+=aClass+" ";}



}

newClassName=newClassName.trim();try
{element.className=newClassName;}

catch(e){}

}
;this.removeClassFromEl=function(element,classToRemove){var className=element.className;var classes=className.split(" ");var newClassName="";for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(aClass&&aClass!=classToRemove){newClassName+=aClass+" ";}

}

newClassName=newClassName.trim();try
{element.className=newClassName;}

catch(e){}

}
;this.initCss=function(){var cls=new CssClass("notSelectable");cls.add("-moz-user-select","none");cls.add("-khtml-user-select","none");cls.add("-webkit-user-select","none");cls.add("user-select","none");cls.init();}
;}



;;function css_StyleSheet(aDocument){this.aDocument=!aDocument?document:aDocument;this.classes=[];this.addClass=function(ccsClassObj){this.classes[ccsClassObj.name]=ccsClassObj.styles;}

this.init=function(){css_buildStyleSheet(this)}
;}

function css_CssClass(name){this.name=name;this.styles=[];this.addStyle=function(name,value){this.styles[name]=value;}

}

function css_addRule(doc,className,styleStr,index){var styleSheet=StyleSheetUtil.getStyleSheet(doc);var selector=(HtmlDtd.isValidTag(className)||className.charAt(0)=='.'||className.charAt(0)=='#')?className:"."+className;var selectors=selector.split(",");for(var i=0;i<selectors.length;i++)
{var aSelector=selectors[i];try
{if(IS_IE){styleSheet.addRule(aSelector,styleStr,index);}

else 
{styleSheet.insertRule(aSelector+"{"+styleStr+"}",index);}

}

catch(e)
{}

}

}

function css_changeStyle(doc,className,property,value){var isUpdated=false;var rules=IS_IE?doc.styleSheets[0].rules:doc.styleSheets[0].cssRules;for(var i=0;i<rules.length;i++)
{if(rules[i].selectorText.toUpperCase()==className.toUpperCase()){try
{property=css_getJsProperty(property);rules[i].style[property]=value;isUpdated=true;}

catch(e)
{return false;}

}

}

if(!isUpdated){var styleSheet=new css_StyleSheet(doc);var cssClass=new css_CssClass(className);styleSheet.addClass(cssClass);cssClass.addStyle(property,value);styleSheet.init();}

return true;}

function css_pixelToInt(str){if(!str){return 0;}

var value=parseInt(str.substring(0,str.length-2));if(!value){return 0;}

return value;}

function css_getJsProperty(property){var index=property.indexOf("-");while(-1!=index)
{property=property.substring(0,index)+property.charAt(index+1).toUpperCase()+property.substring(index+2);index=property.indexOf("-");}

return property;}

function css_buildStyleSheet(thisObj){var classCounter=0
var classes=thisObj.classes;for(var className in classes)
{var styleStr=css_buildClass(classes[className]);css_addRule(thisObj.aDocument,className,styleStr,classCounter);classCounter++;}

}

function css_buildClass(styles){var styleStr="";for(var style in styles)
{styleStr+=style+":"+styles[style]+";"
}

return styleStr;}

function css_addClassToEl(element,classToAdd){var className=element.className;var classes=className.split(" ");for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(aClass&&aClass==classToAdd){return ;}

}

var newClassName=element.className+" "+classToAdd;newClassName=newClassName.trim();try
{element.className=newClassName;}

catch(e){}

}

function css_removeClassFromEl(element,classToRemove){var className=element.className;var classes=className.split(" ");var newClassName="";for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(aClass&&aClass!=classToRemove){newClassName+=aClass+"  ";}

}

newClassName=newClassName.trim();try
{element.className=newClassName;}

catch(e){}

}


var B=BrowserUtil=new BrowserUtilBase();function BrowserUtilBase(){this.name;this.version;this.OS;this.isFF=function(){return ("Firefox"==this.name);}
;this.isIE=function(){return ("Explorer"==this.name);}
;this.isChrome=function(){return ("Chrome"==this.name);}
;this.isSafari=function(){return ("Safari"==this.name);}
;this.isOpera=function(){return ("Opera"==this.name);}
;this.getName=function(){return this.name;}
;this.getVersion=function(){return this.version;}
;this.isIOS=function(){return (this.OS=="IOS");}
;this.isAndroid=function(){var ua=navigator.userAgent.toLowerCase();return ua.indexOf("android")>-1;}
;this.getOS=function(){return this.OS;}
;this.init=function(){this.name=this.searchString(this.dataBrowser)||"An unknown browser";this.version=this.searchVersion(navigator.userAgent)||this.searchVersion(navigator.appVersion)||"an unknown version";this.OS=this.searchString(this.dataOS)||"an unknown OS";}
;this.searchString=function(data){for(var i=0;i<data.length;i++)
{var dataString=data[i].string;var dataProp=data[i].prop;this.versionSearchString=data[i].versionSearch||data[i].identity;if(dataString){if(dataString.indexOf(data[i].subString)!=-1){return data[i].identity;}

else if(dataProp){return data[i].identity;}

}

}

}
;this.searchVersion=function(dataString){var index=dataString.indexOf(this.versionSearchString);if(index==-1){return ;}

return parseFloat(dataString.substring(index+this.versionSearchString.length+1));}
;this.dataBrowser=[];var obj={string:navigator.userAgent,subString:"Chrome",identity:"Chrome"}
;this.dataBrowser.push(obj)
var obj={string:navigator.userAgent,subString:"OmniWeb",versionSearch:"OmniWeb/",identity:"OmniWeb"}
;this.dataBrowser.push(obj)
var obj={string:navigator.vendor,subString:"Apple",identity:"Safari",versionSearch:"Version"}
;this.dataBrowser.push(obj)
var obj={prop:window.opera,identity:"Opera"}
;this.dataBrowser.push(obj)
var obj={string:navigator.vendor,subString:"iCab",identity:"iCab"}
;this.dataBrowser.push(obj);var obj={string:navigator.vendor,subString:"KDE",identity:"Konqueror"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Firefox",identity:"Firefox"}
;this.dataBrowser.push(obj);var obj={string:navigator.vendor,subString:"Camino",identity:"Camino"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Netscape",identity:"Netscape"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"MSIE",identity:"Explorer",versionSearch:"MSIE"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Gecko",identity:"Mozilla",versionSearch:"rv"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Mozilla",identity:"Netscape",versionSearch:"Mozilla"}

this.dataBrowser.push(obj);this.dataOS=[];var obj={string:navigator.platform,subString:"Win",identity:"Windows"}

this.dataOS.push(obj);var obj={string:navigator.platform,subString:"Mac",identity:"Mac"}
;this.dataOS.push(obj);var obj={string:navigator.platform,subString:"iPad",identity:"IOS"}
;this.dataOS.push(obj);var obj={string:navigator.userAgent,subString:"iPhone",identity:"IOS"}
;this.dataOS.push(obj);var obj={string:navigator.platform,subString:"Linux",identity:"Linux"}
;this.dataOS.push(obj);this.init();}
;
;
function findElAt(x,y,doc){if(!doc){doc=document;}

return doc.elementFromPoint(x,y);}

function getPosTop(element){if(IS_IE){return element.style.posTop;}

else 
{var topString=element.style.top;return parseInt(topString.substring(0,topString.length-2));}

}

function getEventCoord(event,doc){if(!doc){doc=document;}

if(!event){event=window.event;}

if(event.pageX){return {x:event.pageX,y:event.pageY}
;}

else 
{var x=event.clientX+doc.body.scrollLeft+doc.documentElement.scrollLeft;var y=event.clientY+doc.body.scrollTop+doc.documentElement.scrollTop;return {x:x,y:y}
;}

}

function findElCoord(element,accountForScroll){var curLeft=0;var curTop=0;var mainEl=element;if(element.offsetParent){do
{if("BODY"==element.tagName||element==mainEl){curLeft+=accountForScroll?element.offsetLeft-element.scrollLeft:element.offsetLeft;}

else 
{curLeft+=(element.offsetLeft-element.scrollLeft);}

var bLW=CssUtil.getStyle(element,"border-left-width")
if(element!=mainEl&&bLW){curLeft+=css_pixelToInt(bLW);}

curTop+=(accountForScroll&&"BODY"==element.tagName)?element.offsetTop-element.scrollTop:element.offsetTop;var bTW=CssUtil.getStyle(element,"border-left-width")
if(element!=mainEl&&bTW){curTop+=css_pixelToInt(bTW);}

element=element.offsetParent;}

while(element);}

return {x:curLeft,y:curTop}
;}





var ShadowUtil=new ShadowUtilBase();function ShadowUtilBase(){this.buildShadow=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);var image=cE("img",td);image.src="/upload/js_globals/background_images/ulc.png";var td=cE("td",tr);td.style.backgroundImage="url(/upload/js_globals/background_images/t.png)";var td=cE("td",tr);var image=cE("img",td);image.src="/upload/js_globals/background_images/urc.png";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.backgroundImage="url(/upload/js_globals/background_images/l.png)";td.style.fontSize=0;td.innerHTML="&nbsp;";var td=cE("td",tr);td.style.border="1px solid #C4C4C4";var contentArea=td;var td=cE("td",tr);td.style.backgroundImage="url(/upload/js_globals/background_images/r.png)";td.style.fontSize=0;td.innerHTML="&nbsp;";var tr=cE("tr",tBody);var td=cE("td",tr);var image=cE("img",td);image.src="/upload/js_globals/background_images/llc.png";var td=cE("td",tr);td.style.backgroundImage="url(/upload/js_globals/background_images/b.png)";var td=cE("td",tr);var image=cE("img",td);image.src="/upload/js_globals/background_images/lrc.png";return contentArea;}
;this.build3SideShadow=function(parentEl){var tBody=createTable(parentEl);tBody.parentNode.style.height="100%";var tr=cE("tr",tBody);var td=cE("td",tr);td.vAlign="top";td.style.height="100%";var iBody=createTable(td);iBody.parentNode.style.height="100%";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);var image=cE("img",iTd);image.src="/upload/js_globals/background_images/ulc.png";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);iTd.style.height="100%";iTd.style.fontSize=0;iTd.style.backgroundImage="url(/upload/js_globals/background_images/l.png)";iTd.innerHTML="&nbsp;";var td=cE("td",tr);td.style.border="1px solid #C4C4C4";var contentArea=td;var td=cE("td",tr);td.vAlign="top";td.style.height="100%";var iBody=createTable(td);iBody.parentNode.style.height="100%";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);var image=cE("img",iTd);image.src="/upload/js_globals/background_images/urc.png";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);iTd.style.height="100%";iTd.style.fontSize=0;iTd.style.backgroundImage="url(/upload/js_globals/background_images/r.png)";iTd.innerHTML="&nbsp;";var tr=cE("tr",tBody);var td=cE("td",tr);var image=cE("img",td);image.src="/upload/js_globals/background_images/llc.png";var td=cE("td",tr);td.style.backgroundImage="url(/upload/js_globals/background_images/b.png)";var td=cE("td",tr);var image=cE("img",td);image.src="/upload/js_globals/background_images/lrc.png";return contentArea;}
;}

;;;
function Popup(){this.doc=document;this.addInstance(this);}

Popup.prototype=new PopupBase();
var popup_counter=0;var popup_isInit=false;
function PopupBase(){
this.instances={}
;
this.addInstance=function(popup){popup.id=++popup_counter;this.instances[popup.id]=popup;}
;
this.removeInstance=function(popup){delete(this.instances[popup.id]);}
;
this.closeAllPopups=function(){var popups=[];for(var i in this.instances)
{popups.push(this.instances[i]);}

for(var i in popups)
{popups[i].close();}

}

this.initialize=function(){if(popup_isInit){return ;}

this.attachEscEvent();popup_isInit=true;}
;this.attachEscEvent=function(){var thisObj=this;var fx=function(event){thisObj.runEsc(event);}
;eh_addEvent("onkeydown",this.doc.body,fx);}
;this.runEsc=function(event){var key=crossbrowser_getKeyCode(event);if(27!=key){return ;}

for(var i in this.instances)
{var popup=this.instances[i];if(popup.onEsc){popup.onEsc();}

else if(!popup.disableEsc){popup.close();}

}

}
;
this.positionEl;
this.offsetLeft=0;
this.offsetTop=0;
this.closeFx;
this.isMaximize;
this.disableBg;
this.fadeBg=true;
this.onMouseOver;
this.onMouseOut;
this.onEsc;
this.position="absolute";
this.clickBgToClose=false;
this.useFrame=false;this.width;this.height;this.pctWidth;this.pctHeight;this.minWidth;this.opacity;this.hideTopBar=false;this.showX=true;this.addDragBar=true;this.titleBarBg="/upload/js_globals/background_images/b9o_gradient_title_bar.gif";this.closeImg="/upload/js_globals/generic_images/popup_close.gif";this.titleDragBarClass;this.title;this.titleClass;this.disableEsc;this.shadow="full";this.border;this.closeEvent;this.closeEvents=[];this.alignment;this.container;this.contentArea;this.anchor;this.centerEl;this.zIndex;this.isDrawHidden;
this.ensureOnTop=true;this.cancelClose=false;this.build=function(){this.initialize();var thisObj=this;if(this.ensureOnTop){this.zIndex=CssUtil.getHighestZIndex();}

if(this.disableBg){var container=cE("div",this.doc.body);container.className="a_popupContainer";container.style.width="100%";container.style.height=this.doc.body.scrollHeight+"px";container.style.position="absolute";container.style.top=0;container.style.left=0;if(this.zIndex){container.style.zIndex=this.zIndex;}

this.container=container;if(this.fadeBg){var opacity=this.fadeBg?50:0;container.style.backgroundColor="black";}

var opacity=this.fadeBg?50:0;container.style.backgroundColor="black";if(this.clickBgToClose){var thisObj=this;var closeFx=function(){thisObj.close();}

eh_attachEvent("onclick",container,closeFx);}

fade_setOpacity(container,opacity);if(this.closeEvent){var closeThisFx=function(){thisObj.close();}
;eh_attachEvent(this.closeEvent,container,closeThisFx);}

if(this.closeEvents){var closeThisFx=function(){thisObj.close();}
;for(var i=0;i<this.closeEvents.length;i++)
{eh_attachEvent(this.closeEvents[i],container,closeThisFx);}

}

}

var offsetLeft=this.offsetLeft;var offsetTop=this.offsetTop;if(this.positionEl){var position=findElCoord(this.positionEl,false);offsetLeft+=position.x;offsetTop+=position.y;}

var anchor=cE("div",this.doc.body);if(this.isDrawHidden){anchor.style.display="none";}

anchor.className="a_popupAnchor";anchor.style.position=this.position;anchor.style.left=offsetLeft+"px";anchor.style.top=offsetTop+"px";if(this.zIndex){anchor.style.zIndex=this.zIndex;}

this.anchor=anchor;if(this.closeEvent){var fx=function(){}
;eh_attachEvent(this.closeEvent,anchor,fx,null,true);this.anchor=anchor;}

var mainArea=this.buildMainArea(anchor);if(this.onMouseOver){var overFx=function(event){if(event.srcElement==thisObj.mainArea){thisObj.cancelClose=true;}

var testEl=event.srcElement.parentNode;while(testEl&&testEl.tagName!="BODY")
{if(testEl==thisObj.mainArea){thisObj.cancelClose=true;break;}

testEl=testEl.parentNode;}

thisObj.onMouseOver();}
;eh_attachEvent("onmouseover",this.mainArea,overFx);}

if(this.onMouseOut){var outFx=function(event){thisObj.cancelClose=false;var delayFx=function(){if(!thisObj.cancelClose){thisObj.onMouseOut();}

}
;window.setTimeout(delayFx,50);}
;eh_attachEvent("onmouseout",this.mainArea,outFx);}

if(this.isMaximize){this.maximize();}

if(this.pctWidth){this.setPctWidth();}

else if(this.width){this.setWidth();}

else if(this.minWidth){this.setMinWidth();}

if(this.pctHeight){this.setPctHeight();}

else if(this.height){this.setHeight();}

var contentArea=this.createContentArea(mainArea);this.contentArea=contentArea;return contentArea;}
;
this.getPosition=function(){return findElCoord(this.anchor);}
;this.putOnTop=function(){var zIndex=CssUtil.getHighestZIndex();if(this.container){this.container.style.zIndex=zIndex;}

this.anchor.style.zIndex=zIndex;}
;this.setAsAnchor=function(positionEl,alignment,offsetLeft,offsetTop){this.positionEl=positionEl;this.alignment=alignment;this.shadow="";this.showX=false;this.closeEvent="onclick";this.disableBg=true;this.fadeBg=false;this.hideTopBar=true;this.offsetLeft=offsetLeft||0;this.offsetTop=offsetTop||0;}
;this.setAtCoord=function(offsetLeft,offsetTop){this.positionEl=this.doc.body;this.showX=false;this.closeEvent="onclick";this.disableBg=true;this.fadeBg=false;this.hideTopBar=true;this.offsetLeft=offsetLeft||0;this.offsetTop=offsetTop||0;this.aligment="coordinate";}
;this.getContentArea=function(parentEl){if(this.useFrame){var div=cE("div",parentEl);div.innerHTML="<iframe frameborder='0' style='width:100%'></iframe>";var frame=div.firstChild;frame.style.padding=0;frame.style.margin=0;frame.style.width=this.contentWidth;frame.style.height=this.contentHeight;this.frame=frame;this.window=frame.contentWindow;var doc=frame.contentWindow.document;doc.open();doc.write("<!DOCTYPE HTML>");doc.write("<html><head><style type=\"text/css\"></style>");doc.write("</head><body style='margin:0px; padding:0px'>");doc.write("</body></html>");doc.close();var holder=cE("div",doc.body);this.innerDoc=doc;return holder;}

return parentEl;}
;this.createContentArea=function(parentEl){if(this.hideTopBar&&this.showX&&this.addDragBar){var tBody=createTable(parentEl,"100%");var tr=cE("tr",tBody);var td=cE("td",tr);td.style.minHeight="30px";td.align="right";this.makeDraggable(td);var img=cE("img",td);img.style.margin="14px 14px 0px 0px";img.src=this.closeImg;img.style.cursor="pointer";var thisObj=this;var closeFx=function(){thisObj.close();}
;eh_attachEvent("onmousedown",img,closeFx);var tr=cE("tr",tBody);var td=cE("td",tr);return this.getContentArea(td);}

else if(this.hideTopBar&&this.showX){parentEl.style.position="relative";var img=cE("img",parentEl);img.style.position="absolute";img.style.right="5px";img.style.top="5px";img.src=this.closeImg;img.style.cursor="pointer";var thisObj=this;var closeFx=function(){thisObj.close();}
;eh_attachEvent("onmousedown",img,closeFx);if(this.addDragBar){this.makeDraggable(parentEl);}
;var div=cE("div",parentEl);return this.getContentArea(div);}

if(this.hideTopBar||(!this.showX&&!this.addDragBar)){return this.getContentArea(parentEl);}

var tBody=createTable(parentEl,"100%","100%");var td=cC(tBody);if(this.title){td.style.height=28+"px";td.style.backgroundRepeat="repeat-x";if(this.titleDragBarClass){td.className=this.titleDragBarClass;}

else if(this.titleBarBg){td.style.backgroundImage="url("+this.titleBarBg+")";}

td.style.borderBottom="1px solid  #B6B6B6";}

this.makeDraggable(td);this.buildTopBar(td);var td=cC(tBody);td.vAlign="top";td.align="left";return this.getContentArea(td);}
;this.buildTopBar=function(parentEl){var tBody=createTable(parentEl,"100%");var tr=cE("tr",tBody);if(this.title){var td=cE("td",tr);td.style.paddingLeft="10px";td.className="mediumText";td.style.fontWeight="bold";td.innerHTML=this.title;if(this.titleClassName){td.className=this.titleClassName;}

}

if(this.showX){var td=cE("td",tr);td.align="right";td.style.padding="4px";td.style.paddingRight="12px";this.drawCloseX(td);}

}
;this.buildMainArea=function(anchor){var mainArea;if(this.border){mainArea=cE("div",anchor);mainArea.style.border=this.border;this.centerEl=mainArea;}

else if(this.shadow){mainArea=cE("div",anchor);mainArea.style.boxShadow="4px 4px 4px #bbbbbb";mainArea.style.border="1px solid #cccccc";this.centerEl=anchor.childNodes[0];}

else 
{mainArea=cE("div",anchor);this.centerEl=mainArea;}

if(this.closeEvent){var fx=function(){}
;eh_attachEvent(this.closeEvent,mainArea,fx,null,true);}

if(this.opacity){mainArea.style.opacity=this.opacity;}

else 
{mainArea.style.backgroundColor="white";}

this.mainArea=mainArea;return mainArea;}
;this.show=function(){this.anchor.style.display="";}
;this.hide=function(){this.anchor.style.display="none";}
;this.drawCloseX=function(parentEl){var img=cE("img",parentEl);img.src=this.closeImg;img.style.cursor="pointer";var thisObj=this;var closeFx=function(){thisObj.close();}
;eh_attachEvent("onmousedown",img,closeFx);}
;this.maximize=function(){this.mainArea.style.width=(this.container.offsetWidth-40)+"px";this.mainArea.style.height=(this.container.offsetHeight-40)+"px";this.center();}
;this.setMinWidth=function(){this.mainArea.style.minWidth=CssUtil.pixelToInt(this.minWidth)+"px";}
;this.setWidth=function(){this.mainArea.style.width=CssUtil.pixelToInt(this.width)+"px";}
;this.setHeight=function(){this.mainArea.style.height=CssUtil.pixelToInt(this.height)+"px";}
;this.setPctWidth=function(){var totalWidth=window.top.innerWidth||this.doc.body.clientWidth;this.mainArea.style.width=(totalWidth*this.pctWidth/100)+"px";}
;this.setPctHeight=function(){var totalHeight=window.top.innerHeight||this.doc.body.clientHeight;this.mainArea.style.height=(totalHeight*this.pctHeight/100)+"px";}
;
this.setFrameWidth=function(width){if(!this.useFrame){return ;}

this.frame.style.width=width+"px";}
;
this.setFrameHeight=function(height){if(!this.useFrame){return ;}

this.frame.style.height=height+"px";}
;this.center=function(){var totalHeight=window.top.innerHeight||this.doc.documentElement.offsetHeight;var totalWidth=window.top.innerWidth||this.doc.documentElement.offsetWidth;var clientHeight=this.centerEl.innerHeight||this.centerEl.clientHeight;var clientWidth=this.centerEl.innerWidth||this.centerEl.clientWidth;var height=totalHeight-clientHeight;if(height<0){this.mainArea.style.height=(totalHeight-30)+"px";this.mainArea.style.overflowY="auto";height=30;}

var width=totalWidth-clientWidth;if(width<0){this.mainArea.style.width=(totalWidth-30)+"px";this.mainArea.style.overflowX="auto";width=30;}

var topPosition=height/3;var leftPosition=width/2;var scrollTop=this.doc.documentElement.scrollTop||this.doc.body.scrollTop;var scrollLeft=this.doc.documentElement.scrollLeft||this.doc.body.scrollLeft;this.anchor.style.top=(topPosition+scrollTop)+"px";this.anchor.style.left=(leftPosition+scrollLeft)+"px";}
;this.adjustForOverflow=function(noOverlapEl){this.adjustForTooTall();this.adjustForOverlap(noOverlapEl);this.adjustForOffScreen();}
;this.adjustForOverlap=function(noOverlapEl){if(!noOverlapEl){return ;}

var c1=findElCoord(noOverlapEl);var c2=findElCoord(this.anchor);var isHoriz=this.isOverLap(c1.x,c1.x+noOverlapEl.offsetWidth,c2.x,c2.x+this.anchor.offsetWidth);var isVert=this.isOverLap(c1.y,c1.y+noOverlapEl.offsetHeight,c2.y,c2.y+this.anchor.offsetHeight);if(!(isHoriz&&isVert)){return ;}

var position=findElCoord(noOverlapEl,false);var x=position.x;var y=position.y;{y+=noOverlapEl.offsetHeight;}

this.anchor.style.left=x+"px";this.anchor.style.top=y+"px";}
;this.isOverLap=function(start1,end1,start2,end2){return ((start1<=start2&&start2<end1)||
(start2<=start1&&end2>=end1)||
(start1<end2&&end2<=end1)||
(start1<=start2&&end2<=end1));}
;this.adjustForOffScreen=function(){var popupLoc=findElCoord(this.anchor,true);var windowHeight=this.getWindowHeight();if((this.centerEl.offsetHeight+popupLoc.y)>windowHeight){var oldTop=CssUtil.pixelToInt(this.anchor.style.top);var newTop=oldTop-((this.centerEl.offsetHeight+popupLoc.y)-windowHeight)-10;this.anchor.style.top=newTop+"px";}

else if(0>popupLoc.y){this.anchor.style.top=(this.doc.documentElement.scrollTop||this.doc.body.scrollTop)+"px";}

var windowWidth=this.getWindowWidth();if((this.centerEl.offsetWidth+popupLoc.x)>windowWidth){var oldLeft=CssUtil.pixelToInt(this.anchor.style.left);var newLeft=oldLeft-((this.centerEl.offsetWidth+popupLoc.x)-windowWidth)-30;this.anchor.style.left=newLeft+"px";}

else if(0>popupLoc.x){this.anchor.style.left=(this.doc.documentElement.scrollLeft||this.doc.body.scrollLeft)+"px";}

}
;this.getWindowWidth=function(){return window.top.innerWidth||this.doc.documentElement.offsetWidth;}
;this.getWindowHeight=function(){return window.top.innerHeight||this.doc.documentElement.offsetHeight;}
;this.adjustForTooTall=function(){var totalHeight=window.top.innerHeight||this.doc.body.clientHeight;if(this.mainArea.scrollHeight>=totalHeight){this.mainArea.style.height=(totalHeight-20)+"px";this.mainArea.style.overflow="auto";}

}
;
this.align=function(alignment,noOverlapEl,accountForScroll){var alignment=alignment||this.alignment;var positionEl=this.positionEl||this.doc.body;var position=findElCoord(positionEl,accountForScroll);var x=position.x+this.offsetLeft;var y=position.y+this.offsetTop;if("belowLeft"==alignment){x+=(this.positionEl.offsetWidth-this.contentArea.offsetWidth);if(this.shadow){x-=18;}

y+=this.positionEl.offsetHeight;}

else if("belowRight"==alignment){if(this.shadow){x-=9;}

y+=this.positionEl.offsetHeight;}

else if("belowCenter"==alignment){x+=positionEl.offsetWidth-Math.ceil(this.contentArea.offsetWidth/2);if(this.shadow){x-=18;}

y+=this.positionEl.offsetHeight;}

else if("rightCenter"==alignment){x+=this.positionEl.offsetWidth;y+=(this.positionEl.offsetHeight/2)-this.anchor.offsetHeight/2;}

else if("upperRight"==alignment){x+=positionEl.offsetWidth-this.contentArea.offsetWidth;if(this.shadow){x-=18;}

}

else if("upperLeft"==alignment){x+=-this.contentArea.offsetWidth;
}

else if("outsideUpperRight"==alignment){x+=positionEl.offsetWidth;
}

else if("aboveCenter"==alignment){x+=positionEl.offsetWidth-this.contentArea.offsetWidth/2;if(this.shadow){x-=18;}

y-=(this.contentArea.offsetHeight);}

else if("aboveLeft"==alignment){y-=(this.contentArea.offsetHeight);if(this.shadow){y-=9;}

}

else if("coordinate"==alignment){x=this.offsetLeft;y=this.offsetTop;}

var yPos=this.doc.body.scrollTop;var xPos=this.doc.body.scrollLeft;this.anchor.style.left=x+"px";this.anchor.style.top=y+"px";this.adjustForOverflow(noOverlapEl);}
;this.makeDraggable=function(element,onDragStart,onDragEnd){element.style.cursor="move";CssUtil.makeNotSelectable(element)
var thisObj=this;var mouseDownFx=function(ev){var cover=cE("div",thisObj.doc.body);cover.style.width="100%";cover.style.height="100%";cover.style.position="absolute";cover.style.top="0px";cover.style.left="0px";cover.style.zIndex=thisObj.zIndex+10;cover.style.overflow="hidden";thisObj.dragCover=cover;if(onDragStart){onDragStart();}

thisObj.doc.body.style.cursor="move";var originalX=ev.clientX;var originalY=ev.clientY;var anchorX=css_pixelToInt(thisObj.anchor.style.left);var anchorY=css_pixelToInt(thisObj.anchor.style.top);var moveFx=function(moveEv){thisObj.anchor.style.left=(anchorX+(moveEv.clientX-originalX))+"px";thisObj.anchor.style.top=(anchorY+(moveEv.clientY-originalY))+"px";}
;eh_addEvent("onmousemove",thisObj.doc.body,moveFx);var mouseUpFx=function(){eh_removeEventHandler(thisObj.doc.body,"onmousemove",moveFx);document.body.style.cursor="";eh_removeEventHandler(thisObj.doc.body,"onmouseup",mouseUpFx);if(onDragEnd){onDragEnd();}

thisObj.dragCover.parentElement.removeChild(thisObj.dragCover);}
;eh_addEvent("onmouseup",thisObj.doc.body,mouseUpFx);}
;eh_attachEvent("onmousedown",element,mouseDownFx);}
;this.createDragger=function(parentEl){var dragger=cE("div",parentEl);dragger.align="center";dragger.style.height="8px";dragger.style.paddingTop="3px";dragger.style.fontSize=0;dragger.style.cursor="move";this.makeDraggable(dragger);var dotSrc="/upload/custom_screens/architect/components/dropdownmenu/grip_dot.gif";for(var i=0;i<4;i++)
{var dot=cE("img",dragger);dot.src=dotSrc;dot.style.margin="2px";}

}
;this.close=function(){this.removeInstance(this);if(this.closeFx){try
{this.closeFx();}

catch(e)
{}

this.closeFx=null;}

if(this.container){this.container.parentNode.removeChild(this.container);}

if(this.anchor&&this.anchor.parentNode){this.anchor.parentNode.removeChild(this.anchor);}

this.positionEl=null;this.container=null;this.contentArea=null;window.setTimeout(eh_clearEventsNotInDom,10);}
;}
;function fade_setOpacity(element,opacity){if(IS_IE){element.style.filter="alpha(opacity="+opacity+")";}

else 
{element.style.opacity=opacity/100;}

}

;function registerHtmlConverter(fieldTypeName,converterName,conversionFx){var converters=mc_objectToHtmlFxByType[converterName];if(!converters){var converters={}
;mc_objectToHtmlFxByType[converterName]=converters;}

converters[fieldTypeName]=conversionFx;}


function setStyles(element,properties){if(null==properties){return ;}

var stylesObj=properties.style;if(null==stylesObj){return ;}

for(var i in stylesObj)
{var value=stylesObj[i];if(!isNaN(value)){value=value+"px";}

element.style[i]=value;}

}


var TextUtil=new TextUtilBase();function TextUtilBase(){this.removeHtmlFormat=function(str){if(null==str){return "";}

str=str.replaceAll("<","&lt;");str=str.replaceAll(">","&gt;");return str;}
;this.parseForHtml=function(str){if(null==str){return "";}

str=str.replaceAll("&lt;","<");str=str.replaceAll("&gt;",">");return str;}
;this.removeMsFormating=function(str){return str;}
;this.removeBr=function(value){value=value.replaceAll("<br>","\n");return value.replaceAll("<BR>","\n");}
;this.addBr=function(value){value=value.replaceAll("\r\n","<br>");return value.replaceAll("\n","<BR>");}
;}
;

function EmailValidation(validationHandler){this.validationHandler=validationHandler;validationHandler.addValidationObject(this.TYPE,this);validationHandler.registerValidation(this.TYPE,this.validateFx,this.errorFx);}

EmailValidation.prototype=new EmailValidationBase()
function EmailValidationBase(){this.TYPE="EMAIL";this.attachValidation=function(element){this.validationHandler.addObjectToVal(this.TYPE,element);}
;this.validateFx=function(element){var value=element.value.trim();if(value==""){return true;}

var re=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;var result=value.match(re);if(result==null){return false;}

return true;}
;this.errorFx=function(element){return element.value+" "+"is not a valid email address.";}
;}
;

;;function buildTextInput(parentEl,properties){var input=cE("input",parentEl);input.type="text";enableTextInput(input,properties);return input;}

function enableTextInput(input,properties){var displayName=getProperty(properties,"displayName","");input.name=displayName;var maxLength=getProperty(properties,"maxLength",1027);input.maxLength=maxLength;var value=getProperty(properties,"value","").trim();var shadowText=getProperty(properties,"shadowText","").trim();var validationHandler=getProperty(properties,"validationHandler",null);if(shadowText!=""&&""==value){input.value=shadowText
input.style.color="#CCCCCC";}

else 
{input.value=TextUtil.parseForHtml(value);}

if(shadowText!=""){var onFocusFx=function(){if(input.value==shadowText){input.value="";input.style.color="";}

}
;eh_attachEvent("onfocus",input,onFocusFx);var onBlurFx=function(){if(input.value==""){input.value=shadowText;input.style.color="#999999";}

else 
{input.style.color="";}

}
;eh_attachEvent("onblur",input,onBlurFx);}

var isRequired=getProperty(properties,"isRequired",false);if(isRequired){var requiredVal=validationHandler.getValObject("REQUIRED")
if(null==requiredVal){requiredVal=new RequiredValidation(validationHandler);}

requiredVal.registerEmptyValue(shadowText);requiredVal.attachValidation(input);}

if("phone"==getProperty(properties,"uiType","")){input.maxLength=20;var validateKeyStroke=function(){if(KeyCodeUtil.isAlphabetic(event)){KeyCodeUtil.cancelPressKey(event)
return null;}

}
;eh_attachEvent("onkeypress",input,validateKeyStroke);}

else if("email"==getProperty(properties,"uiType",false)){var emailVal=validationHandler.getValObject("EMAIL");if(null==emailVal){emailVal=new EmailValidation(validationHandler);}

emailVal.attachValidation(input);}

var onAfterChangeFx=getProperty(properties,"onAfterChangeFx",null);var onChangeFx=function(){if(null!=onAfterChangeFx){var value=TextUtil.removeHtmlFormat(input.value);onAfterChangeFx(value);}

}
;eh_attachEvent("onchange",input,onChangeFx);var onKeyUpFx=function(event){if(!event){event=window.event;}

var keyCode=KeyCodeUtil.getKeyCode(event)
if((keyCode==86||keyCode==118)&&event.ctrlKey){if(null!=onAfterChangeFx){var value=TextUtil.removeHtmlFormat(input.value);value=TextUtil.removeMsFormating(value);onAfterChangeFx(value);}

}

}
;eh_attachEvent("onkeyup",input,onKeyUpFx);setStyles(input,properties);return input;}
;
;function str_fieldToEditHtml(parentEl,dynField,properties){if(null==properties){properties={}
;}

var onAfterValueChange=properties.onAfterChangeFx;properties.onAfterChangeFx=function(value){dynField.setValue(value);if(null!=onAfterValueChange){onAfterValueChange(dynField);}

}
;properties.value=dynField.data;properties.uiType=dynField.getUiType();properties.validationHandler=dynField.getOwnerCache().validationHandler;return buildTextInput(parentEl,properties);}
;registerHtmlConverter("TEXT","edit",str_fieldToEditHtml);registerHtmlConverter("TREE","edit",str_fieldToEditHtml);registerHtmlConverter("phone","edit",str_fieldToEditHtml);registerHtmlConverter("email","edit",str_fieldToEditHtml);
function drawCounter(parentEl,string,maxChar){parentEl.innerHTML="";var numberHolder=cE("span",parentEl);numberHolder.style.fontWeight="bold";numberHolder.style.marginRight=4;numberHolder.innerHTML=getRemainingCharacters(string,maxChar);var span=cE("span",parentEl);span.style.fontWeight="normal";span.innerHTML="characters remaining";}
;function getFilteredString(string,maxChar){if(string.length>=maxChar){return string.substring(0,maxChar);}

else 
{return string;}

}
;function getRemainingCharacters(string,maxChar){string=(string)?string:"";return maxChar-string.length;}
;
;function buildTextArea(parentEl,properties){var maxLength=getProperty(properties,"maxLength",null);var value=getProperty(properties,"value","");var taHolder;if(maxLength){var width=200;if(properties.style){width=properties.style.width;}

var counterHolder=cE("div",parentEl)
counterHolder.align="right";counterHolder.style.fontSize="11px";counterHolder.style.fontFamily="arial";counterHolder.style.width=width;drawCounter(counterHolder,value,maxLength);properties.counterHolder=counterHolder;taHolder=cE("div",parentEl);}

else 
{taHolder=parentEl;}

var displayName=getProperty(properties,"displayName","");var textArea=cE("textArea",taHolder);textArea.style.width=200;textArea.style.height=100;textArea.style.fontFamily="arial";textArea.name=displayName;return enableTextArea(textArea,properties);}

function enableTextArea(textArea,properties){var maxLength=getProperty(properties,"maxLength",null);var value=getProperty(properties,"value","");var shadowText=getProperty(properties,"shadowText","").trim();textArea.name=properties.displayName||"";if(shadowText!=""&&""==value){textArea.value=shadowText
textArea.style.color="#999999";}

else 
{textArea.value=TextUtil.removeBr(value);}

if(shadowText!=""){var onFocusFx=function(){if(textArea.value==shadowText){textArea.value="";textArea.style.color="";}

}
;eh_attachEvent("onfocus",textArea,onFocusFx);var onBlurFx=function(){if(textArea.value==""){textArea.value=shadowText;textArea.style.color="#999999";}

else 
{textArea.style.color="";}

}
;eh_attachEvent("onblur",textArea,onBlurFx);}

if(null!=maxLength){var validateLength=function(event){if(!event){event=window.event;}

var value=textArea.value;var counterHolder=properties.counterHolder;if(maxLength!=null&&counterHolder){var curLength=value.length;if(curLength>maxLength){textArea.value=value.substring(0,maxLength);}

drawCounter(counterHolder,textArea.value,maxLength);}

}
;eh_attachEvent("onkeydown",textArea,validateLength);}

var onAfterChangeFx=getProperty(properties,"onAfterChangeFx",null);var afterSetVal=getProperty(properties,"afterSetVal",null);var onChangeFx=function(event){var value=TextUtil.removeHtmlFormat(textArea.value);value=TextUtil.removeMsFormating(value);value=TextUtil.addBr(value);if(onAfterChangeFx){onAfterChangeFx(value);}

if(afterSetVal){afterSetVal(value);}

}
;eh_attachEvent("onchange",textArea,onChangeFx)
var validatePastedTxt=function(){var keyCode=crossbrowser_getKeyCode(event)
if((keyCode==86||keyCode==118)&&event.ctrlKey){var value=TextUtil.removeHtmlFormat(textArea.value);value=TextUtil.removeMsFormating(value);value=TextUtil.addBr(value);if(onAfterChangeFx){onAfterChangeFx(value);}

if(afterSetVal){afterSetVal(value);}

}

}
;eh_attachEvent("onkeyup",textArea,validatePastedTxt);var validationHandler=getProperty(properties,"validationHandler",null);var isRequired=getProperty(properties,"isRequired",false);if(isRequired){var requiredVal=validationHandler.getValObject("REQUIRED")
if(null==requiredVal){requiredVal=new RequiredValidation(validationHandler);}

requiredVal.attachValidation(textArea);}

setStyles(textArea,properties);return textArea;}
;
;function long_fieldToHtml(parentEl,dynField,properties){if(null==properties){properties={}
;}

properties.onAfterChangeFx=function(value){dynField.setValue(value);}
;properties.value=dynField.data;properties.validationHandler=dynField.getOwnerCache().validationHandler;if(null==properties.style){properties.style={width:450,height:250}
;}

return buildTextArea(parentEl,properties);}

registerHtmlConverter("LONG_TEXT","edit",long_fieldToHtml);

function cat_fieldToHtml(parentEl,dynField,properties){var definitionId=dynField.data.category_definition.id;var miniCache=dynField.ownerRecord.ownerCache;var definitionRecord=miniCache.getRecord("cat_def3",definitionId);var cSelect=cE("select",parentEl);cSelect.style.width=(properties&&properties.style&&properties.style.width)?properties.style.width+"px":"248px";if(properties&&properties.noSelect!=null){var option=cE("option",cSelect);option.innerHTML=properties.noSelect;option.value="";}

var initValue=dynField.data.default_value;var options=definitionRecord.getField("category_definition").getChildField("options");var fNames=options.getChildFieldNames();for(var i=0;i<fNames.length;i++)
{var valueKey=fNames[i];var display=options.getChildField(valueKey).getValue();var display=(display=="")?"-------------":display;var option=cE("option",cSelect);option.innerHTML=display;option.value=valueKey;if(valueKey==dynField.data.value){option.selected=true;}

else if(valueKey==initValue&&dynField.data.value==""){option.selected=true;dynField.getChildField("value").setValue(initValue)
}

}

var onChange=function(){var value=cSelect.options[cSelect.selectedIndex].value
dynField.getChildField("value").setValue(value);if(properties&&properties.onChangeFx){properties.onChangeFx();}

}
;eh_attachEvent("onchange",cSelect,onChange);
}

registerHtmlConverter("C3","edit",cat_fieldToHtml);

mc_fieldTypeExtenders["MS3"]=function(dynField){dynField.isOptionSelected=function(codeName){this.initSelection();if(this.selectedOptions[codeName]){return true;}

return false;}

dynField.initSelection=function(){if(this.selectedOptions){return ;}

var selectedOptions=this.data.selected_options.split("|");this.selectedOptions={}
;for(var i=0;i<selectedOptions.length;i++)
{var optionName=selectedOptions[i];if(optionName==""){continue;}

this.selectedOptions[optionName]=optionName;}

}

dynField.buildOptionBox=function(parentEl,optionName){var curDynField=this;if(!curDynField.checkboxes){curDynField.checkboxes={}
;}

var input=document.createElement("input");input.type="checkbox";input.optionName=optionName;input.defaultChecked=curDynField.isOptionSelected(optionName);parentEl.appendChild(input);if(!curDynField.checkboxes[optionName]){curDynField.checkboxes[optionName]=input;}

var onOptionSelectFx=function(){var valueStr="|";var checkBoxes=curDynField.checkboxes;for(var optionName in checkBoxes)
{var checkbox=checkBoxes[optionName];if(checkbox.checked){valueStr+=optionName+"|";}

}

curDynField.getChildField("selected_options").setValue(valueStr);}

eh_attachEvent("onclick",input,onOptionSelectFx);}

}


;function nms_ms3EditHtml(parentEl,dynField,properties){var definitionId=dynField.data.category_definition.id;var miniCache=dynField.ownerRecord.ownerCache;var definitionRecord=miniCache.getRecord("cat_def3",definitionId);if(!definitionRecord){parentEl.innerHTML="";return ;}

var optionField=definitionRecord.getField("category_definition").getChildField("options")
var optionLength=optionField.getChildFieldNames().length;var cells=[];var tbody=createTable(parentEl);var colCount=(properties&&properties.colCount)?properties.colCount:2;var rowCount=Math.ceil(optionLength/colCount);for(var i=0;i<rowCount;i++)
{var tr=cE("tr",tbody);for(var j=0;j<colCount;j++)
{cells.push(cE("td",tr));}

}

var cellCount=0;var options=optionField.data;var props=(properties!=null)?properties:{}
;for(var optionName in options)
{var cell=cells[cellCount];if(props&&null==props.optionStyle){cell.style.padding="3 8 0 0";}

else if(props.optionStyle){cell.style.padding=(props.optionStyle.padding)?props.optionStyle.padding:"3 8 0 0";}

var oTbody=createTable(cell);var tr=cE("tr",oTbody);var td=cE("td",tr);dynField.buildOptionBox(td,optionName);var td=cE("td",tr);td.className="text";td.innerHTML=options[optionName];cellCount++;}

}

registerHtmlConverter("MS3","edit",nms_ms3EditHtml);

var ANumberUtil=new ANumberUtilBase()
function ANumberUtilBase(){this.DS=".";this.TS=",";this.formatForDisplay=function(x,decimalPlaces){var decimals=this.occurence(x,this.DS);if(typeof(x)!='number'){var nonNumMatch=new RegExp("[^0-9-.,]","g");var illegalChars=x.match(nonNumMatch);if((null!=illegalChars)||(decimals>1)){return ""
}

}

if(decimalPlaces!=undefined){var decimalPlaces=parseInt(decimalPlaces,10);if(!isNaN(decimalPlaces)){x=this.ensureDecimalPlaces(x,decimalPlaces);}

else 
{x=Math.floor(x);}

}

return this.reformat(x);}
;this.reformat=function(x){if(x==0){return x
}

if(null==x||""==x){return "";}

var re=/(\-?)([^\.]*)\.?(\d*)/;var result=re.exec(x);var sign=result[1];var numberPart=result[2];var decimalPart=result[3];var newNumberPart="";var digitPlace=0;for(var i=numberPart.length-1;i>=0;i--)
{if(isNaN(parseInt(numberPart.charAt(i)))){continue;}

newNumberPart=numberPart.charAt(i)+newNumberPart;digitPlace++;if(digitPlace==3&&i!=0){newNumberPart=this.TS+newNumberPart;digitPlace=0;}

}

decimal=(decimalPart=="")?"":this.DS;return sign+newNumberPart+decimal+decimalPart;}
;this.occurence=function(aString,c){var total=0;for(var i=0;i<aString.length;i++)
{if(c==aString.charAt(i)){total++;}

}

return total;}

this.formatForStorage=function(numStr,isDecimal){numStr=numStr.replaceAll(this.DS,".");numStr=numStr.replaceAll(this.TS,"");var number;if(isDecimal){number=parseFloat(numStr,10);}

else 
{number=parseInt(numStr,10);}

return (isNaN(number))?"":number;}
;this.ensureDecimalPlaces=function(numberString,noOfDecimals){if(null==numberString||""==numberString){return ;}

var re=/(\-?)([^\.]*)\.?(\d*)/;var result=re.exec(numberString);var negativeSign=result[1];var numberPart=result[2];var decimalPart=result[3];var pureNumber=0;var digitPlace=0;for(var i=0;i<numberPart.length;i++)
{var thisNumber=parseInt(numberPart.charAt(i));if(!isNaN(thisNumber)){pureNumber=(10*pureNumber)+thisNumber;}

}

if(noOfDecimals==0){var number=parseFloat(pureNumber+"."+decimalPart);return Math.round(number);}

var orginalNoOfDecimals=decimalPart.length;var decimalNumber=parseInt(decimalPart,10);decimalNumber=(isNaN(decimalNumber))?0:decimalNumber;var allDigits=pureNumber*Math.pow(10,orginalNoOfDecimals)+decimalNumber;if(0==allDigits){var str="0"+this.DS;return this.addZeros(str,noOfDecimals);}

if(negativeSign!=null&&negativeSign!=""){allDigits*=-1;}

var numToRound=allDigits/(Math.pow(10,(orginalNoOfDecimals-noOfDecimals)));var rounded=Math.round(numToRound);var finalNumber=rounded/(Math.pow(10,noOfDecimals));var numberStr=""+finalNumber;var shouldBeLength=(""+rounded).length+1;var retVal;if(numberStr.length==(shouldBeLength-1-noOfDecimals)){retVal=numberStr+this.DS;retVal=this.addZeros(retVal,noOfDecimals);}

else if(shouldBeLength==numberStr.length){retVal=numberStr;}

else 
{var zerosToAdd=shouldBeLength-numberStr.length;retVal=this.addZeros(numberStr,zerosToAdd);}

return retVal;}
;this.addZeros=function(str,noOfZeros){for(var i=0;i<noOfZeros;i++)
{str+="0";}

return str;}
;}
;

;function buildNumberInput(parentEl,properties){var isNoComma=getProperty(properties,"isNoComma",false);var maxLength=getProperty(properties,"maxLength",100);var decimalPlaces=getProperty(properties,"decimalPlaces",null);;var isDecimal=(null!=decimalPlaces)?true:false;var displayName=getProperty(properties,"displayName","");var input=cE("input",parentEl);input.maxLength=maxLength;input.name=displayName;input.type="text";var value=getProperty(properties,"value","");if(value==0&&!getProperty(properties,"defaultToZero",false)){value="";}

input.value=(isNoComma)?value:ANumberUtil.formatForDisplay(value,decimalPlaces);var onAfterChangeFx=getProperty(properties,"onAfterChangeFx",null);var onChangeFx=function(){var value=input.value.trim();if(""!=value&&!isNoComma){input.value=ANumberUtil.formatForDisplay(input.value,decimalPlaces);}

value=ANumberUtil.formatForStorage(value,isDecimal);if(null!=onAfterChangeFx){onAfterChangeFx(value);}

}
;eh_attachEvent("onchange",input,onChangeFx);var validateKeyStroke=function(event){var isValidCharacter=KeyCodeUtil.isValidCharForNumber(event);if(!isValidCharacter){KeyCodeUtil.cancelPressKey(event);return null;}

}
;eh_attachEvent("onkeypress",input,validateKeyStroke);var validationHandler=getProperty(properties,"validationHandler",null);var isRequired=getProperty(properties,"isRequired",false);if(isRequired){var requiredVal=validationHandler.getValObject("REQUIRED")
if(null==requiredVal){requiredVal=new RequiredValidation(validationHandler);}

requiredVal.attachValidation(input);}

setStyles(input,properties);return input;}
;
;function int_fieldToHtml(parentEl,dynField,properties){if(null==properties){properties={}
;}

properties.onAfterChangeFx=function(value){dynField.setValue(value);if(properties.onChange){properties.onChange(dynField);}

}
;properties.value=dynField.getValue();properties.validationHandler=dynField.getOwnerCache().validationHandler;return buildNumberInput(parentEl,properties);}
;registerHtmlConverter("INTEGER","edit",int_fieldToHtml);
;var tip_hourToAorPDefault={1:"P",2:"P",3:"P",4:"P",5:"P",6:"P",7:"A",8:"A",9:"A",10:"A",11:"A",12:"P"}
;function buildTimeInput(parentEl,properties){var input=cE("input",parentEl);input.style.width="65px";input.name=getProperty(properties,"displayName","");input.type="text";var timeObj=getProperty(properties,"timeObj",null);var updateInput=function(input,timeObj){if(null!=timeObj){input.value=timeObj.timeToString();}

}
;var validationHandler=getProperty(properties,"validationHandler",null);var attachValidation=function(){var onFocusFx=function(){input.select();}
;eh_attachEvent("onfocus",input,onFocusFx);var keyPressValFx=function(event){if(ATimeUtil.TIME_FORMAT!=12){return ;}

var keyCode=KeyCodeUtil.getKeyCode(event);if(keyCode==8||keyCode==46){input.value="";KeyCodeUtil.cancelPressKey(event);return ;}

if(keyCode==37||keyCode==39||keyCode==9){return ;}

crossbrowser_stopEvent(event);var isAOrP=((keyCode==65)||(keyCode==80));if(!(KeyCodeUtil.isNumber(keyCode)||isAOrP)){return ;}

if(IS_IE){var inputRange=document.selection.createRange();if(inputRange.text==input.value){input.value="";}

var actualMove=inputRange.moveStart("character",-10);var cursorPos=Math.abs(actualMove);}

else 
{var cursorPos=input.selectionStart;}

if((cursorPos<4)&&isAOrP){return ;}

var timeString=input.value;var firstPart=timeString.substring(0,cursorPos);var enteredKey=KeyCodeUtil.getTranslation(keyCode);var lastPart=(cursorPos==timeString.length)?"":timeString.substring(cursorPos,timeString.length);timeString=firstPart+enteredKey+lastPart;var re=new RegExp("(1?)(\\d):?(\\d?)(\\d?)(\\d?)[^aApP]*([aApP]?)","g");var result=re.exec(timeString);if(!result){input.value="";return ;}

var firstNumber=result[1];var secondNumber=result[2];var thirdNumber=result[3];var fourthNumber=result[4];var fifthNumber=result[5];var aOrP=result[6];var leftPos;if(secondNumber&&!firstNumber&&!thirdNumber&&!fourthNumber&&!aOrP){if(secondNumber==0){input.value="";return ;}

timeString=secondNumber+":00"+tip_hourToAorPDefault[secondNumber]+"M";leftPos=cursorPos+2;}

else if((fifthNumber)&&(4==cursorPos)&&!firstNumber&&(secondNumber==1)&&(thirdNumber<=2)){var end=(2==thirdNumber)?"PM":"AM";timeString=secondNumber+""+thirdNumber+":"+fourthNumber+""+fifthNumber+end;leftPos=5;}

else 
{timeString=firstNumber+""+secondNumber+":"+thirdNumber+""+fourthNumber+aOrP.toUpperCase()+"M";leftPos=cursorPos+1;}

input.value=timeString;if(IS_IE){inputRange=input.createTextRange();inputRange.collapse();inputRange.moveStart("character",leftPos);inputRange.select();}

else 
{input.setSelectionRange(leftPos,leftPos);}

if(isAOrP){if(IS_IE){inputRange=input.createTextRange();inputRange.collapse();inputRange.moveStart("character",10);inputRange.select();}

else 
{input.setSelectionRange(10,10);}

}

}

eh_attachEvent("onkeydown",input,keyPressValFx);validationHandler.addObjectToVal(ATimeUtil.TYPE,input);updateInput(input,timeObj);}

var isRequired=getProperty(properties,"isRequired",false);if(isRequired){var requiredVal=validationHandler.getValObject("REQUIRED")
if(null==requiredVal){requiredVal=new RequiredValidation(validationHandler);}

requiredVal.attachValidation(input);}

var onAfterChangeFx=getProperty(properties,"onAfterChangeFx",null);var onChangeFx=function(){if(null==timeObj){timeObj=ATimeUtil.stringToTime(input.value);}

else 
{timeObj=timeObj.update(input.value);}

updateInput(input,timeObj);if(null!=onAfterChangeFx){onAfterChangeFx(timeObj);}

}

eh_attachEvent("onblur",input,onChangeFx);attachValidation(input);setStyles(input,properties);var validateTimeFx=function(input){var value=input.value;if(input.value.trim()==""||ATimeUtil.isValidValue(value)){return true;}

var timeObj=ATimeUtil.stringToTime(value);return (null==timeObj)?false:true;}
;var timeErrorMsgFx=function(element){return element.value+"  "+"is not a valid time.";}
;validationHandler.registerValidation(ATimeUtil.TYPE,validateTimeFx,timeErrorMsgFx);return input;}

;function time_fieldToHtml(parentEl,dynField,properties){if(null==properties){properties={}
;}

var onBeforeChange=properties.onBeforeChange;properties.onAfterChangeFx=function(timeObj){if(onBeforeChange){timeObj=onBeforeChange(timeObj);}

dynField.setValue(timeObj);}
;properties.timeObj=dynField.getValue();properties.validationHandler=dynField.getOwnerCache().validationHandler;return buildTimeInput(parentEl,properties);}

registerHtmlConverter("TIME_TYPE_NAME","edit",time_fieldToHtml);

;function double_fieldToHtml(parentEl,dynField,properties){if(null==properties){properties={}
;}

properties.onAfterChangeFx=function(value){dynField.setValue(value);if(properties.onChange){properties.onChange(dynField);}

}

properties.value=dynField.getValue();if(null==properties.decimalPlaces){properties.decimalPlaces=2;}

properties.validationHandler=dynField.getOwnerCache().validationHandler;buildNumberInput(parentEl,properties);}

registerHtmlConverter("DOUBLE","edit",double_fieldToHtml);
function ASmallCalendar(parentEl){this.parentEl=parentEl;this.cellPadding=3;this.startDate;this.noOfMonths=1;this.width=170;this.disablePastDates=false;this.monthNavOn=true;this.yearNavOn=true;this.noOfRows=0;this.noOfColumns=0;this.nextNavHolder;this.prevNavHolder;this.onDateSelectFx;this.onMonthChangeFx;this.disableCurrentDayHighlight=false;this.cellsByDate={}
;}
;ASmallCalendar.prototype=new ASmallCalendarbase();function ASmallCalendarbase(){this.disablePastNavigation=function(){this.disableNavByMonth().disableNavByYear().disablePreviousDates(true);return this;}
;this.enableNavByMonth=function(){this.monthNavOn=true;return this;}
;this.enableNavByYear=function(){this.yearNavOn=true;return this;}
;this.disableNavByMonth=function(){this.monthNavOn=false;return this;}
;this.disableNavByYear=function(){this.yearNavOn=false;return this;}
;this.setOnDateSelectFx=function(fx){this.onDateSelectFx=fx;return this;}
;this.setCalendarDisplay=function(rowCount,colCount){this.noOfRows=rowCount;this.noOfColumns=colCount;return this;}

this.setWidth=function(width){this.width=width;return this;}

this.disablePreviousDates=function(disable){this.disablePastDates=disable;return this;}
;this.setStartDate=function(dateObj){this.startDate=dateObj;return this;}
;this.build=function(){this.parentEl.id="sc_calendarHolder";calObj=this;if(null==this.startDate){this.startDate=ADateUtil.getCurrentDate();}

var dateObj=this.startDate.clone();this.buildCalendars(dateObj);}
;this.buildCalendars=function(dateObj){var aDate=new ADate(1,dateObj.month,dateObj.year);this.firstDate=aDate;var parentEl=this.parentEl
parentEl.innerHTML="";if(this.noOfRows<1||this.noOfColumns<1){var holder=cE("div",parentEl);holder.className="sc_calendarBorder";holder.style.width=(!isNaN(this.width))?this.width+"px":this.width;holder.style.background="white";this.buildCalendar(holder,aDate);}

else 
{this.noOfMonths=this.noOfRows*this.noOfColumns;var tbody=createTable(parentEl);tbody.style.background="white";tbody.border=0;var calendarCount=0;for(var i=0;i<this.noOfRows;i++)
{var tr=cE("tr",tbody);for(var j=0;j<this.noOfColumns;j++)
{var td=cE("td",tr);td.className="sc_calendarBorder";td.vAlign="top";if(calendarCount==this.noOfCalendars){break;}

this.buildCalendar(td,aDate,i,(j+1));aDate=ADateUtil.adjustMonth(aDate,1);calendarCount++;if((j+1)!=this.noOfColumns){td.style.borderRight="0px solid white";}

}

}

}

this.attachMonthNavigation();}
;this.buildCalendar=function(parentEl,dateObj,rowCount,colCount){var tbody=createTable(parentEl,this.width);var table=tbody.parentNode;var tr=cE("tr",tbody);var td=cE("td",tr);td.style.padding="3px 0px 3px 0px";this.buildTitle(td,dateObj,rowCount,colCount);var tr=cE("tr",tbody);this.buildDateDisplay(cE("td",tr),dateObj);}
;this.buildDateDisplay=function(parentEl,dateObj){var tbody=createTable(parentEl,"100%");this.buildDayLabelDisplay(tbody);var dateCells=this.buildDateCells(tbody);this.populateDateCells(dateCells,dateObj);}
;this.buildDayLabelDisplay=function(tbody){var tr=cE("tr",tbody);var labels=ADateUtil.getLabels(ADateUtil.DAY_LETTER);for(var i=0;i<labels.length;i++)
{var td=cE("td",tr)
td.align="center";td.className="sc_dayLableHolder sc_text";td.innerHTML=labels[i];}

}
;this.buildDateCells=function(tbody){var dateCells=[];for(var i=0;i<6;i++)
{var tr=cE("tr",tbody);for(var j=0;j<7;j++)
{var td=cE("td",tr);td.align="center";td.style.padding=(!isNaN(this.cellPadding))?this.cellPadding+"px":this.cellPadding;dateCells.push(td);}

}

return dateCells;}
;this.buildTitle=function(parentEl,dateObj,rowCount,colCount){var tbody=createTable(parentEl,"100%")
var tr=cE("tr",tbody);var td=cE("td",tr);td.align="center";td.style.width="20px";if((rowCount==0&&colCount==1)||this.noOfMonths==1){this.prevNavHolder=td;}

var td=cE("td",tr);td.align="center";var monthLabel=dateObj.getString([ADateUtil.MONTH_STR," ",ADateUtil.YEAR]);if(this.monthNavOn){var mL=cE("a",td);mL.innerHTML=monthLabel;mL.href="#";mL.className="sc_navEnabled sc_labelText";var calObj=this;var onClickFx=function(event){calObj.buildNavByMonth();crossbrowser_stopEvent(event);}

eh_attachEvent("onclick",mL,onClickFx);}

else 
{td.innerHTML=monthLabel;td.className="sc_navDisabled sc_labelText";}

var td=cE("td",tr);td.align="center";td.style.width="20px";if((rowCount==0&&colCount==this.noOfColumns)||this.noOfMonths==1){this.nextNavHolder=td;}

}
;this.attachMonthNavigation=function(){var curDate=ADateUtil.getCurrentDate();if((curDate.month!=this.firstDate.month)||
(curDate.year!=this.firstDate.year)||!this.disablePastDates){var prevNavEl=this.prevNavHolder;prevNavEl.style.cursor="pointer";prevNavEl.className="sc_prevImg";var calendarObj=this;var previousFx=function(){var interval=1;if(calendarObj.noOfRows>1){interval=calendarObj.noOfMonths;}

var previousMonthDate=ADateUtil.adjustMonth(calendarObj.firstDate,(-1*interval));calendarObj.buildCalendars(previousMonthDate);if(calendarObj.onMonthChangeFx){calendarObj.onMonthChangeFx(calendarObj);}
;}

eh_attachEvent("onclick",prevNavEl,previousFx);}

{var nextNavEl=this.nextNavHolder;nextNavEl.style.cursor="pointer";nextNavEl.className="sc_nextImg";var calendarObj=this;var nextFx=function(){var interval=1;if(calendarObj.noOfRows>1){interval=calendarObj.noOfMonths;}

var nextMonthDate=ADateUtil.adjustMonth(calendarObj.firstDate,interval);calendarObj.buildCalendars(nextMonthDate);if(calendarObj.onMonthChangeFx){calendarObj.onMonthChangeFx(calendarObj);}
;}

eh_attachEvent("onclick",nextNavEl,nextFx);}

}
;this.populateDateCells=function(dateCells,dateObj){var dayIndices=this.populateCurrentMonth(dateCells,dateObj);if(this.noOfMonths==1){var prevMthCells=dateCells.slice(0,dayIndices.first);var nextMthCells=dateCells.slice(dayIndices.last,dateCells.length);this.populatePastMonth(prevMthCells,dateObj);this.populateNextMonth(nextMthCells,dateObj);}

}
;this.populatePastMonth=function(cells,dateObj){var previousMonthDate=ADateUtil.adjustMonth(dateObj,-1);var prevMnthDayCount=ADateUtil.getMonthDayCount(previousMonthDate.month,previousMonthDate.year);var x=cells.length;for(var i=x;i>0;i--)
{var cell=cells[i-1];this.attachDateInfo(cell,prevMnthDayCount,previousMonthDate.month,previousMonthDate.year,false);prevMnthDayCount--;}

}
;this.populateNextMonth=function(cells,dateObj){var nextMonthDate=ADateUtil.adjustMonth(dateObj,1);for(var i=0;i<cells.length;i++)
{var date=i+1;var cell=cells[i];this.attachDateInfo(cell,date,nextMonthDate.month,nextMonthDate.year,false);}

}
;this.populateCurrentMonth=function(dateCells,dateObj){var curDate=ADateUtil.getCurrentDate();var month=dateObj.month;var year=dateObj.year;var daysInMonth=ADateUtil.getMonthDayCount(month,year);var dayIndex=dateObj.getDayIndex();var nextDayIndex=dayIndex;for(var i=1;i<=daysInMonth;i++)
{var cell=dateCells[nextDayIndex];var aDate=this.attachDateInfo(cell,i,month,year,true);this.cellsByDate[aDate.toDbFormat()]=cell;if(null!=aDate&&aDate.equals(curDate)){cell.style.border="1px solid #666666";}

nextDayIndex++;}

return {first:dayIndex,last:nextDayIndex}
;}
;this.attachDateInfo=function(cell,date,month,year,isCurrent){var dL=cE("a",cell);dL.innerHTML=date;dL.className="sc_nonCurMonthDates sc_text";var calendarObj=this;var dateObj=new ADate(date,month,year);var isBeforeStartDate=dateObj.isBeforeOtherDate(ADateUtil.getCurrentDate());if(isBeforeStartDate&&this.disablePastDates){return dateObj;}

dL.style.cursor="pointer";dL.className=(isCurrent)?"sc_curMonthDates":"sc_nonCurMonthDates";dL.className+=" sc_text";var calObj=this;var selectFx=function(){if(calObj.selectedDateCell){var selectedCell=calObj.selectedDateCell;if(!calObj.disableCurrentDayHighlight){selectedCell.style.background="white";}
;}
;if(!calObj.disableCurrentDayHighlight){cell.style.background="#f6f69b";}
;calObj.selectedDateCell=cell;var onDateSelectFx=calendarObj.onDateSelectFx;if(null!=onDateSelectFx){onDateSelectFx(dateObj);}
;}
;eh_attachEvent("onclick",dL,selectFx);if(dateObj.equals(this.startDate)){if(!this.disableCurrentDayHighlight){cell.style.background="#f6f69b";}
;this.selectedDateCell=cell;}
;return dateObj
}
;this.buildNavByMonth=function(){var parentEl=this.parentEl;parentEl.innerHTML="";var grid=buildMYGrid(parentEl,this.width);var labelCell=grid.labelCell
if(this.yearNavOn){var mL=cE("a",labelCell);mL.innerHTML=this.firstDate.year;mL.className="sc_navEnabled sc_labelText";mL.href="#";var calObj=this;var onClickFx=function(event){calObj.buildNavByYear();crossbrowser_stopEvent(event);}

eh_attachEvent("onclick",mL,onClickFx);}

else 
{labelCell.innerHTML=this.firstDate.year;labelCell.className="sc_navDisabled sc_labelText";}

var cells=grid.cells;var labels=ADateUtil.getLabels(ADateUtil.MONTH_ABBR);for(var i=0;i<labels.length;i++)
{var cell=cells[i];attachMonthClick(cell,(i+1),this,labels[i]);}

}
;this.buildNavByYear=function(year){var parentEl=this.parentEl;parentEl.innerHTML="";var grid=buildMYGrid(parentEl,this.width);var cell=grid.labelCell;if(null==year){year=this.firstDate.year;}

{var tbody=createTable(cell,"100%");var tr=cE("tr",tbody);var td=cE("td",tr);td.className="sc_prevImg";td.style.cursor="pointer";td.style.width="10px";td.style.height="20px";var calObj=this;var prevFx=function(){year=year-24;calObj.buildNavByYear(year);}

eh_attachEvent("onclick",td,prevFx);var spacerTd=cE("td",tr);spacerTd.style.width="80%";var td=cE("td",tr);td.className="sc_nextImg";td.style.cursor="pointer";td.style.width="10px";td.style.height="20px";var nextFx=function(){calObj.buildNavByYear(year);}

eh_attachEvent("onclick",td,nextFx);}

var cells=grid.cells;for(var i=0;i<cells.length;i++)
{var cell=cells[i];attachYearClick(cell,year,this);year++;}

}
;var buildMYGrid=function(parentEl,width){parentEl.innerHTML="";var tbody=createTable(parentEl,width)
tbody.parentNode.className="sc_calendarBorder";var table=tbody.parentNode;table.cellPadding=2;table.cellSpacing=2;var tr=cE("tr",tbody);var labeCell=cE("td",tr)
labeCell.colSpan=3;labeCell.align="center";var cells=[];var count=0;for(var i=0;i<4;i++)
{var tr=cE("tr",tbody);for(var j=0;j<3;j++)
{var td=cE("td",tr);td.align="center";cells.push(td);count++;}

}

return {cells:cells,labelCell:labeCell}

}
;var attachMonthClick=function(el,index,calObj,monthStr){var monthEl=cE("a",el)
monthEl.href="#";monthEl.className="sc_navEnabled sc_labelText";monthEl.innerHTML=monthStr;var onClickFx=function(event){calObj.buildCalendars(new ADate(1,index,calObj.firstDate.year));crossbrowser_stopEvent(event);}

eh_attachEvent("onclick",monthEl,onClickFx);}
;var attachYearClick=function(el,year,calObj){var yearEl=cE("a",el)
yearEl.href="#";yearEl.className="sc_navEnabled sc_labelText";yearEl.innerHTML=year;var onClickFx=function(event){calObj.firstDate=new ADate(1,calObj.firstDate.month,year);calObj.buildNavByMonth();crossbrowser_stopEvent(event);}

eh_attachEvent("onclick",yearEl,onClickFx);}
;}

;;;function buildDateInput(parentEl,properties){var disablePreviousDates=getProperty(properties,"disablePreviousDates",false);var hideCalendar=getProperty(properties,"hideCalendar",false);var onAfterChangeFx=getProperty(properties,"onAfterChangeFx",null);var navMonths=getProperty(properties,"navMonths",true);var navYears=getProperty(properties,"navYears",true);var dateObj=getProperty(properties,"dateObj",null);var displayName=getProperty(properties,"displayName","");var validationHandler=getProperty(properties,"validationHandler",ValidationUtil);var input=cE("input",parentEl);input.type="text";input.style.width="80px";input.maxLength=10;input.name=displayName;var attachValidation=function(dateObj){var validateKeyStroke=function(event){var isAlphabetic=KeyCodeUtil.isAlphabetic(event)
if(isAlphabetic){KeyCodeUtil.cancelPressKey(event);return null;}

}

eh_attachEvent("onkeypress",input,validateKeyStroke);var onFocusFx=function(){if(input.value==ADateUtil.EMPTY_DATE){input.value="";input.style.color="";}

if(!hideCalendar){var date=ADateUtil.stringToDate(input.value);if(null!=date){dateObj=date;}

var coords=findElCoord(input,true);coords.y=coords.y+input.offsetHeight;var popup=new Popup();popup.shadow="";popup.setAtCoord(coords.x,coords.y);popup.disableBg=true;popup.ensureOnTop=true;var contentArea=popup.build();var cal=new ASmallCalendar(contentArea);cal.setCalendarDisplay(1,2).disablePreviousDates(disablePreviousDates);cal.setStartDate(dateObj);if(!navYears){cal.disableNavByYear();}

if(!navMonths){cal.disableNavByMonth();}

var dateChangeFx=function(dateObj){updateInput(input,dateObj);if(null!=onAfterChangeFx){onAfterChangeFx(dateObj);}

popup.close();}

cal.setOnDateSelectFx(dateChangeFx);cal.build();popup.align();popup.putOnTop();}

}
;eh_attachEvent("onfocus",input,onFocusFx);updateInput(input,dateObj)
if(input.value==""){input.value=ADateUtil.EMPTY_DATE;input.style.color="#999999";}

validationHandler.addObjectToVal(ADateUtil.TYPE,input);}
;var updateInput=function(input,dateObj){if(null!=dateObj){input.value=dateObj.toDefaultString();}

else 
{input.value=ADateUtil.EMPTY_DATE;input.style.color="#999999";}

}
;var onChangeFx=function(){if(null==dateObj){dateObj=ADateUtil.stringToDate(input.value);}

else 
{dateObj=dateObj.update(input.value);}

updateInput(input,dateObj);if(null!=onAfterChangeFx){onAfterChangeFx(dateObj);}

}
;eh_attachEvent("onchange",input,onChangeFx);attachValidation(dateObj);var isRequired=getProperty(properties,"isRequired",false);if(isRequired){var requiredVal=validationHandler.getValObject("REQUIRED")
if(null==requiredVal){requiredVal=new RequiredValidation(validationHandler);}

requiredVal.attachValidation(input);}

setStyles(input,properties);var validateDateFx=function(input){if(input.value==ADateUtil.EMPTY_DATE){return true;}

if(""==input.value.trim()){return true;}

var dateObj=ADateUtil.stringToDate(input.value);return (null==dateObj)?false:true;}
;var dateErrorMsgFx=function(element){return element.value+"  "+"is not a valid date.";}
;validationHandler.registerValidation(ADateUtil.TYPE,validateDateFx,dateErrorMsgFx);return input;}
;

;function dateFieldToEditHtml(parentEl,dynField,properties){if(null==properties){properties={}
;}

properties.validationHandler=dynField.getOwnerCache().validationHandler;properties.dateObj=dynField.getValue();properties.onAfterChangeFx=function(value){dynField.setValue(value);}
;return buildDateInput(parentEl,properties);}

registerHtmlConverter("DATE","edit",dateFieldToEditHtml);

;;;function dateTimeEditHtml(parentEl,dynField,properties){var tBody=createTable(parentEl);tBody.className="text";var tr=cE("tr",tBody);var td=cE("td",tr);var validationHandler=dynField.getOwnerCache().validationHandler;var dateProps=(null!=properties)?clone(properties):{}
;dateProps.validationHandler=validationHandler;dateProps.onAfterChangeFx=function(dateObj){dynField.setDate(dateObj);}
;dateProps.dateObj=dynField.getValue().date;buildDateInput(td,dateProps);var td=cE("td",tr);td.style.paddingLeft=6;var timeProps=(null!=properties)?clone(properties):{}
;timeProps.onAfterChangeFx=function(timeObj){dynField.setTime(timeObj);}
;timeProps.timeObj=dynField.getValue().time;timeProps.validationHandler=validationHandler;buildTimeInput(td,timeProps);}

registerHtmlConverter("DATETIME","edit",dateTimeEditHtml);

function radiobutton_RadioButtonComponent(){this.options=[];this.onclickFx;this.selectedButton;this.fontSize=12;this.padding=15;this.fontFamily="arial";this.isVertical=true;this.selectedOption=null;this.addDynamicOption=function(value,isSelected,onLabelBuildFx){var radioButton=new radiobutton_RadioButton(null,value,isSelected);radioButton.parentObj=this;radioButton.onLabelBuildFx=onLabelBuildFx;this.options.push(radioButton);}

this.addOption=function(label,value,isSelected){var radioButton=new radiobutton_RadioButton(label,value,isSelected);radioButton.parentObj=this;this.options.push(radioButton);}

this.build=function(parentEl){radiobutton_build(this,parentEl)}
;}

function radiobutton_RadioButton(label,value,isSelected){this.label=label;this.value=value;this.isSelected=isSelected;this.radioButton;this.parentObj;this.selectOption=function(){radiobutton_runOnclickFx(this)}
;this.check=function(){radiobutton_toggleRadioButton(this)}
;}

function radiobutton_setValue(thisObj,value){var optionToSelect;var options=thisObj.options;for(var i in options)
{if(options[i].value==value){optionToSelect=options[i];break;}

}

if(null==optionToSelect){thisObj.selectedOption=optionToSelect;thisObj.selectedButton.checked=false;thisObj.selectedButton=null;return ;}

radiobutton_runOnclickFx(optionToSelect,thisObj);}

function radiobutton_build(thisObj,parentEl){var table=document.createElement("table");table.cellPadding=0;table.cellSpacing=0;table.style.fontSize=thisObj.fontSize;table.style.fontFamily=thisObj.fontFamily;table.className="tableBoolean";parentEl.appendChild(table);var tbody=document.createElement("tbody");table.appendChild(tbody);var parentEl=tbody;if(!thisObj.isVertical){parentEl=document.createElement("tr");tbody.appendChild(parentEl);}

for(var i=0;i<thisObj.options.length;i++)
{radiobutton_buildButton(thisObj,parentEl,thisObj.options[i],i,thisObj);}

}

function radiobutton_buildButton(thisObj,parentEl,option,i,thisObj){var tr=parentEl;if(parentEl.tagName=="TBODY"){tr=document.createElement("tr");parentEl.appendChild(tr);}

var td=document.createElement("td");td.vAlign="top";tr.appendChild(td);if(i!=0&&!thisObj.isVertical){td.style.paddingLeft=thisObj.padding;}

var radioButton=document.createElement("input");radioButton.type="radio";radioButton.value=option.value;option.radioButton=radioButton;td.appendChild(radioButton);var onMouseUpFx=function(event){if(option.isSelected){return ;}

option.isSelected=true;radiobutton_runOnclickFx(option,thisObj);crossbrowser_stopEvent(event);}
;eh_attachEvent("onmouseup",radioButton,onMouseUpFx);var onKeyDownFx=function(event){var keyCode=crossbrowser_getKeyCode(event);if(keyCode==32){onMouseUpFx(event);}

}
;eh_attachEvent("onkeydown",radioButton,onKeyDownFx);if(option.isSelected){thisObj.selectedOption=option;radioButton.checked=true;option.parentObj.selectedButton=radioButton;}

var td=document.createElement("td");td.style.paddingLeft=2;td.style.paddingTop=2;tr.appendChild(td);if(option.onLabelBuildFx){td.innerHTML="";option.onLabelBuildFx(td,option);}

else 
{td.innerHTML=option.label;}

}

function radiobutton_runOnclickFx(option,thisObj){if(thisObj.selectedOption){thisObj.selectedOption.isSelected=false;}

thisObj.selectedOption=option;var parentObj=option.parentObj;if(parentObj.onclickFx){parentObj.onclickFx(option.value,parentObj);}

var selectedButton=parentObj.selectedButton;if(selectedButton){parentObj.selectedButton.checked=false;}

var radioButton=option.radioButton;radioButton.checked=true;parentObj.selectedButton=option.radioButton;}

function radiobutton_toggleRadioButton(option){var parentObj=option.parentObj;var selectedButton=parentObj.selectedButton;if(selectedButton){parentObj.selectedButton.checked=false;}

var radioButton=option.radioButton;radioButton.checked=true;parentObj.selectedButton=option.radioButton;}


function RadioButton(){this.options=[];
this.layout="vertical";this.cellVAlign="middle";this.labelClass;this.buttonCellClass;this.onChange;this.selectedOption;}

RadioButton.prototype=new RadioButtonBase();function RadioButtonBase(){this.build=function(parentEl,selectedValue){if("custom"==this.layout){this.buildCustomLayout();}

else 
{this.buildLayout(parentEl);}

this.selectValue(selectedValue);}
;
this.addOption=function(label,value,parentEl,onclickFx){this.options.push({label:label,value:value,parentEl:parentEl,onclickFx:onclickFx}
);}
;
this.addDynamicOption=function(value,labelBuilderFx,parentEl,getExtraInfoFx){this.options.push({value:value,labelBuilderFx:labelBuilderFx,parentEl:parentEl,getExtraInfoFx:getExtraInfoFx}
);}
;
this.getOptionByValue=function(value){for(var i=0;i<this.options.length;i++)
{if(value==this.options[i].value){return this.options[i];}

}

return null;}
;this.selectValue=function(value){var option=this.getOptionByValue(value);if(option){this.selectOption(option,true);}

}
;this.getValue=function(){if(!this.selectedOption){return null;}

return this.selectedOption.value;}
;this.buildCustomLayout=function(){for(var i=0;i<this.options.length;i++)
{var option=this.options[i];if(option.parentEl){this.buildOption(option.parentEl,option);}

}

}
;this.buildLayout=function(parentEl){var tBody=createTable(parentEl);if("horizontal"==this.layout){var tr=cE("tr",tBody);}

for(var i=0;i<this.options.length;i++)
{var option=this.options[i];if("vertical"==this.layout){var tr=cE("tr",tBody);}

var td=cE("td",tr);this.buildOption(td,option);}

}
;this.selectOption=function(option,omitOnChange){if(this.selectedOption){this.deselectOption(this.selectedOption);}

this.selectedOption=option;option.radioEl.checked=true;if(this.onChange&&!omitOnChange){this.onChange(this.getValue());}

}

this.deselectOption=function(option){option.radioEl.checked=false;}
;this.buildOption=function(parentEl,option){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.vAlign=this.cellVAlign;td.style.paddingBottom=3;if(this.buttonCellClass){td.className=this.buttonCellClass;}

var rb=cE("input")
rb.type="radio";rb.value=option.value;option.radioEl=rb;aE(td,rb);var thisObj=this;var onclickFx=function(){if(option.onclickFx){option.onclickFx();}
;thisObj.selectOption(option);}
;eh_attachEvent("onclick",rb,onclickFx);var td=cE("td",tr);td.vAlign=this.cellVAlign
td.style.paddingLeft=2;if(this.labelClass){td.className=this.labelClass;}

else 
{td.style.fontSize="12px";td.style.fontFamily="arial";}

if(option.labelBuilderFx){option.labelBuilderFx(td);}

else if(option.label){td.innerHTML=option.label;}

}
;}
;
;;function bool_fieldToHtml(parentEl,dynField,properties){var buildRadioButton=(properties&&properties.buildRadioButton)?properties.buildRadioButton:false;if(buildRadioButton){var yesLabel=(properties.yesLabel)?properties.yesLabel:"Yes";var noLabel=(properties.noLabel)?properties.noLabel:"No";var layOut=(properties.isVertical)?"vertical":"horizontal";var radio=new RadioButton();radio.layout=layOut;radio.onChange=function(value){dynField.setValue(value);if(properties.onClickFx){properties.onClickFx(dynField);}

}

radio.addOption(yesLabel,true);radio.addOption(noLabel,false);radio.build(parentEl,dynField.getValue())
}

else 
{var checkbox=document.createElement("input");checkbox.type="checkbox";parentEl.appendChild(checkbox);checkbox.checked=dynField.data;var onclickFx=function(){dynField.setDoSave();dynField.setValue(!dynField.data);if(properties&&properties.onClickFx){properties.onClickFx(dynField);}

}
;eh_attachEvent("onclick",checkbox,onclickFx);return checkbox;}

}

registerHtmlConverter("BOOLEAN","edit",bool_fieldToHtml);

function mc_recordNameToEditHtml(parentEl,dynField,properties){var tbody=createTable(parentEl);var tr=cE("tr",tbody);var td=cE("td",tr);td.className="text";td.innerHTML="Record Name";if(properties){if(properties.hideLabels){td.style.display="none";}

}

var td=cE("td",tr);var recordName=dynField.getChildField("recordName");recordName.buildField(td,"edit",properties);var tr=cE("tr",tbody);var td=cE("td",tr);td.className="text";td.innerHTML="Update on import";var td=cE("td",tr);var updateOnImport=dynField.getChildField("updateOnImport");if(!properties){properties={}
;}

properties.buildRadioButton=true;updateOnImport.buildField(td,"edit",properties);if(properties){if(properties.hideLabels){tr.style.display="none";}

}

}

registerHtmlConverter("RECORD_NAME","edit",mc_recordNameToEditHtml);

;;;;;;;;;;;

if(window["sl_loadedScript"]==undefined){var sl_loadedScript=[];}
;if(window["sl_onAfterLoadFx"]==undefined){var sl_onAfterLoadFx=[];}
;function sl_loadScript(scriptPath,onAfterLoadFx){if(sl_loadedScript[scriptPath]){if(onAfterLoadFx){onAfterLoadFx();}

return ;}

sl_onAfterLoadFx[scriptPath]=onAfterLoadFx;var scriptToLoad=document.createElement("script");scriptToLoad.src=scriptPath;scriptToLoad.type="text/javascript";document.body.appendChild(scriptToLoad);sl_loadedScript[scriptPath]=true;}


;;;;;;;;;;;;;;;;;

function getAttributes(node,omitAttrs){var filteredAttrs={}
;var omitMap={"_moz_dirty":1,"contentEditable":1,"contenteditable":1,"atag":1}
;if(omitAttrs){for(var i in omitAttrs)
{omitMap[i]=1;}

}

var attributes=node.attributes;for(var i=0;i<attributes.length;i++)
{if(!attributes[i].specified){continue;}

var nodeName=attributes[i].nodeName;if(omitMap[nodeName]){continue;}

else if(IS_IE&&nodeName.toLowerCase()=="style"){if(BrowserUtil.isIE()){filteredAttrs["style"]=node.style.cssText.toLowerCase();}

else {var rE=/[^>]*style=['"]([^'"]*)/i;var result=rE.exec(node.outerHTML);if(result){filteredAttrs["style"]=result[1].toLowerCase();}

}

}

else 
{if(""!=attributes[i].value.trim()){filteredAttrs[nodeName]=attributes[i].value;}

else if(du_booleanAttrs[nodeName]){filteredAttrs[nodeName]="";}

}

}

return filteredAttrs;}
;var du_booleanAttrs={"checked":1,"selected":1,"disabled":1,"readonly":1,"multiple":1,"ismap":1,"isMap":1,"allowfullscreen":1,"allowFullScreen":1}
;function getChildByTagName(element,tagName){var nodes=getChildrenByTagName(element,tagName);return nodes[0];}

function getChildrenByTagName(element,tagName){tagName=tagName.toUpperCase();var nodes=[];for(var i=0;i<element.childNodes.length;i++)
{if(element.childNodes[i].tagName==tagName){nodes.push(element.childNodes[i]);}

}

return nodes;}


function getDescendentsWAttr(node,attributeName){var results=[];getDWAttrHelper(results,node,attributeName);return results;}

function getDWAttrHelper(results,node,attributeName){if(gA(node,attributeName)){results.push(node);}

for(var i=0;i<node.childNodes.length;i++)
{getDWAttrHelper(results,node.childNodes[i],attributeName);}

}

function getAttributeString(node,omitAttrs){var s="";var attrs=getAttributes(node,omitAttrs);for(var name in attrs)
{s+=name;if(attrs[name]){s+="=\""+attrs[name]+"\" ";}

else 
{ahtml+=" ";}

}

return s.substr(0,s.length-1);}
;
function replaceNodeTagName(tagName,originalNode,deepCopy){var parentEl=originalNode.parentElement;parentEl.removeChild(originalNode)
var newNode=cE(tagName,parentEl);var attrList=originalNode.attributes;for(var i=0;i<attrList.length;i++)
{var attr=attrList[i];sA(newNode,attr.nodeName,attr.nodeValue);}

if(deepCopy){var children=originalNode.children;for(var i=0;i<children.length;i++)
{var childNode=children[i].cloneNode(true);aE(newNode,childNode);}

}

return newNode;}


function switchNode(newNode,nodeToReplace){var parentEl=nodeToReplace.parentNode;var child=nodeToReplace.childNodes[0];while(child)
{child=nodeToReplace.removeChild(child);aE(newNode,child);child=nodeToReplace.childNodes[0];}

parentEl.replaceChild(newNode,nodeToReplace);}

function getNonTextChildNodes(element){var nodes=[];for(var i=0;i<element.childNodes.length;i++)
{if(element.childNodes[i].nodeType!=3){nodes.push(element.childNodes[i]);}

}

return nodes;}

function isDescendent(element,ancestor){if(!element||!ancestor){return false;}

while(element&&element.tagName!="BODY")
{if(element==ancestor){return true;}

element=element.parentNode;}

return false;}

function isBeforeSibling(element,sibling){if(!sibling){return false;}

var testEl=sibling.previousSibling;while(testEl)
{if(testEl==element){return true;}

testEl=testEl.previousSibling;}

return false;}

function insertParent(tagName,firstSibling,lastSibling,doc){if(!doc){doc=getParentDocument(firstSibling);}

var newEl=cE(tagName,null,doc);var parentEl=firstSibling.parentNode;parentEl.insertBefore(newEl,firstSibling);do
{var el=newEl.nextSibling.parentNode.removeChild(newEl.nextSibling);aE(newEl,el);}

while(firstSibling!=lastSibling&&newEl.nextSibling!=lastSibling);return newEl;}


function replaceNodeWithHtml(html,elToReplace){elToReplace.innerHTML=html;var isFirst=true;var firstEl=null;var parentEl=elToReplace.parentNode;while(elToReplace.childNodes.length>0)
{var element=elToReplace.removeChild(elToReplace.childNodes[0]);parentEl.insertBefore(element,elToReplace);if(isFirst){firstEl=element;isFirst=false;}

}

parentEl.removeChild(elToReplace);return firstEl;}

function insertAfter(toInsert,sibling){if(sibling.nextSibling){sibling.parentNode.insertBefore(toInsert,sibling.nextSibling);}

else 
{sibling.parentNode.appendChild(toInsert);}

}

function removeChildNodes(node,typesToRemove){for(var i=0;i<node.childNodes.length;i++)
{if(isTagType(node.childNodes[i],typesToRemove)){node.removeChild(node.childNodes[i]);}

}

}


function removeNode(node){if(!node){return ;}

node.normalize();var childs=[];for(var i=0;i<node.childNodes.length;i++)
{childs.push(node.childNodes[i]);}

for(var i=0;i<childs.length;i++)
{node.removeChild(childs[i]);}

var p=node.parentNode;for(var i=0;i<childs.length;i++)
{p.insertBefore(childs[i],node);}

p.removeChild(node);return node;}

function isTagType(node,tagNames){if(!node){return false;}

for(var i=0;i<tagNames.length;i++)
{if(tagNames[i]==node.tagName){return true;}

}

return false;}


function getNearestAncestor(node,tagName){return getAncestor(node,[tagName]);}


function getBlockAncestor(node){return getAncestor(node,du_blockTags);}

function getAncestor(node,tagNames){if(!node){return null;}

for(var i=0;i<tagNames.length;i++)
{tagNames[i]=tagNames[i].toUpperCase();}

while(node)
{for(var i=0;i<tagNames.length;i++)
{if(tagNames[i]==node.tagName){return node;}

}

node=node.parentNode;if(!node){return null;}

if("HTML"==node.tagName){return null;}

}

return null;}

function getAncestorByStyle(node,cssProp,value){if(!node){return null;}

while(node)
{if(value==CssUtil.getStyle(node,cssProp)){return node;}

node=node.parentNode;if(!node){return null;}

if("HTML"==node.tagName){return null;}

}

return null;}

function getPreviousSiblingByStyle(node,cssProp,value){return getSiblingByStyle(node,cssProp,value,true);}

function getNextSiblingByStyle(node,cssProp,value){return getSiblingByStyle(node,cssProp,value,false);}

function getSiblingByStyle(node,cssProp,value,isGoBack){if(!node){return null;}

node=isGoBack?node.previousElementSibling:node.nextElementSibling;while(node)
{if(value==CssUtil.getStyle(node,cssProp)){return node;}

node=isGoBack?node.previousElementSibling:node.nextElementSibling;if(!node){return null;}

}

return null;}

function getAncesterWClass(node,className){if(!node){return null;}

while(node)
{if("HTML"==node.tagName){return null;}

if(CssUtil.elHasClass(node,className)){return node;}

node=node.parentNode;if(!node){return null;}

}

return null;}

function getAncestorByStyles(node,cssProp,values){var valueMap={}
;for(var i in values)
{valueMap[values[i]]=1;}

if(!node){return null;}

while(node)
{if(valueMap[CssUtil.getStyle(node,cssProp)]){return node;}

node=node.parentNode;if(!node){return null;}

if("HTML"==node.tagName){return null;}

}

return null;}

function findSiblingIndex(node){var index=0;while(node.previousSibling)
{index++;node=node.previousSibling;}

return index;}

function findSibling(node,tagNames,isLookForward){while(node)
{if(isTagType(node,tagNames)){return node;}

node=isLookForward?node.nextSibling:node.previousSibling;}

return null;}

function getNextElement(node){if(node.children&&node.children.length>0){return node.children[0];}

else 
{while(!node.nextElementSibling)
{node=node.parentNode;if(!node){return null;}

}

return node.nextElementSibling;}

}

function getNextNode(node){if(node.childNodes&&node.childNodes.length>0){return node.childNodes[0];}

else 
{while(!node.nextSibling)
{node=node.parentNode;if(!node){return null;}

}

return node.nextSibling;}

}

function getPreviousNode(node){if(!node.previousElementSibling){return node.parentNode;}

return getLastDescendent(node.previousElementSibling);}

function getLastDescendent(node){if(node.childNodes.length==0){return node;}

else 
{var newNode;for(var i=node.childNodes.length-1;i>=0;i--)
{var temp=node.childNodes[i];if(temp.nodeType!=3){newNode=temp;break;}

}

if(!newNode){return node;}

return getLastDescendent(newNode)||newNode;}

}

var whiteSpaceTags=["BR"];
function doesContainContent(node){node=node.cloneNode(true);node.innerHTML=node.innerHTML.trim();if(node.innerHTML==""){return false;}

for(var i=0;i<node.childNodes.length;i++)
{if(!isTagType(node.childNodes[i],whiteSpaceTags)){return true;}

}

return false;}

function insertParentForChildren(aBlock,newParent){var children=[];var child=aBlock.firstChild;while(child)
{var nextChild=child.nextSibling;children.push(aBlock.removeChild(child));child=nextChild;}

aE(aBlock,newParent);while(0<children.length)
{aE(newParent,children[0]);children.splice(0,1);}

}


function extendClass(classToExtend,parentClass){var protoTypeObj=classToExtend.prototype;var nodeBase=parentClass.prototype;for(var i in nodeBase)
{if(!protoTypeObj[i]){protoTypeObj[i]=nodeBase[i];}

}

}


Function.prototype.extend=function(parentClass){var thisBase=this.prototype;var parentBase=parentClass;for(var i in parentBase)
{if(!thisBase[i]){thisBase[i]=parentBase[i];}

}

var parentPrototype=parentClass.prototype;for(var i in parentPrototype)
{if(!thisBase[i]){thisBase[i]=parentPrototype[i];}

}

}
;

var A=new ABase();function ABase(){var mc=new MiniCache();mc.syncToMasterOnProcess();this.mc=mc;this.moduleInfo=g_moduleInfo;this.params=g_params;this.tempIdCounter=0;
this.registryByName={}


this.getFragInfo=function(fragId){return this.moduleInfo.fragInfo[fragId];}
;
this.removeFragInfo=function(fragId){delete(LivePage.fragInfo[fragId]);}
;
this.addFragInfo=function(id,fragInfo){this.moduleInfo.fragInfo[id]=fragInfo;if(window["LivePage"]){LivePage.registerFragByType(fragInfo);}

}
;
this.addRecordToCreate=function(rTC){this.moduleInfo.rTC.push(rTC);}
;
this.createTempId=function(){this.tempIdCounter++;var id="temp"+this.tempIdCounter;while(gE("#"+id))
{id="temp"+this.tempIdCounter;}

return id;}
;
this.isEditMode=function(){return (window["LivePage"]||g_params.mode=="visual_edit");}


this.register=function(registryName,name,obj){var optionsForRegistry=this.registryByName[registryName];if(!optionsForRegistry){optionsForRegistry={}
;this.registryByName[registryName]=optionsForRegistry
}

optionsForRegistry[name]=obj;}
;
this.launchPoupForHtml=function(html){var popup=new Popup();popup.disableBg=true;popup.fadeBg=true;popup.ensureOnTop=true;popup.shadow="";popup.clickBgToClose=true;var contentArea=popup.build();contentArea.innerHTML=html;contentArea.style.padding="10px";popup.center();}
;
this.findOwnerCache=function(element){while(element.tagName!="BODY")
{var fragInfo=A.getFragInfo(element.id);if(fragInfo&&"module"==fragInfo["fragType"]){if(fragInfo.isDataIsolated){var mc=fragInfo.ownerCache;if(null!=mc){return mc;}

mc=new MiniCache();mc.syncToMasterOnProcess();fragInfo.ownerCache=mc;return mc;}

}

element=element.parentNode;}

return this.mc;}
;
this.loadUrl=function(urlStr,callback){var slashIndex=urlStr.indexOf("/");if(slashIndex==0){urlStr=urlStr.substring(1);}

var req=new XMLHttpRequest();req.onreadystatechange=function(){if(req.readyState!=4){return ;}

if(req.status!=200){return ;}

eval(req.responseText);callback(pageData);}
;req.open("GET","GetPageHtml.ajax?url="+urlStr,true);req.send();}
;
this.addOnProcessEvent=function(fx,eventId){alert("probably to deprecate");AProcessor.addOnProcessEvent(fx,eventId);}
;this.removeOnProcessEvent=function(eventId){alert("probably to deprecate");AProcessor.removeOnProcessEvent(eventId);}
;this.popupModule=function(modulePath,popupProps){alert("probably to deprecate");return APopupModule.popupModule(modulePath,popupProps);}
;this.getAttrValue=function(element,attributeName){alert("probably to deprecate");return this.getFragInfo(element.id+"_"+attributeName).attributeValue;}
;}
;

;


if(!window["EventUtil"]){var E=EventUtil=new EventUtilBase();}

function EventUtilBase(){this.on=function(element,eventType,fx,eventSettings){eventSettings=eventSettings||this.defaultEventSettings;if(!(B.isIE()||B.isFF())){if(eventType=="mouseenter"){this.mouseenter(element,fx,eventSettings);return ;}

else if(eventType=="mouseleave"){this.mouseleave(element,fx,eventSettings);return ;}

}

if(eventType=="rightclick"){eventType="contextmenu";}

var thisObj=this;element["on"+eventType]=function(event){thisObj.run(event,fx,eventSettings);}
;eh_registerEvent(element,"on"+eventType);}
;this.run=function(event,fx,eventSettings){eventSettings=eventSettings||this.defaultEventSettings;event=event||window.event;if(fx){fx(event);}

if(eventSettings&&eventSettings.stop){this.stop(event);}

}
;this.off=function(element,eventType){if(!(B.isIE()||B.isFF())){if("mouseleave"==eventType){var fxId=gA(element,"a_metaMouseleavefxid");var fx=this.mouseLeaveData[fxId];this.remove(document.body,"mouseout",fx);delete(this.mouseLeaveData[fxId]);element.removeAttribute("a_metaMouseleavefxid");}

else if("mouseenter"==eventType){element.onmouseover=null;return ;}

}

element["on"+eventType]=null;}
;this.add=function(element,eventType,fx){if(eventType=="rightclick"){eventType="contextmenu";}

if(!B.isIE()){element.addEventListener(eventType,fx,false);}

else 
{eventType="on"+eventType;element.attachEvent(eventType,fx);}

}
;this.remove=function(element,eventType,fx){if(!(B.isIE()||B.isFF())){if("mouseleave"==eventType){fx=gA("mouseleavefx",element);element=document.body;eventType="mouseout";}

}

element.removeEventListener(eventType,fx,false);}
;
this.stop=function(event){try
{event.stopPropagation();event.preventDefault();}

catch(excep)
{if(B.isIE()){if(!event){event=window.event;}

event.returnValue=false;event.cancelBubble=true;}

}

}
;this.blur=function(element,fx,eventSettings){this.on(element,"blur",fx,eventSettings);}
;this.change=function(element,fx,eventSettings){this.on(element,"change",fx,eventSettings);}
;this.click=function(element,fx,eventSettings){this.on(element,"click",fx,eventSettings);}
;this.dblclick=function(element,fx,eventSettings){this.on(element,"dblclick",fx,eventSettings);}
;this.error=function(element,fx,eventSettings){this.on(element,"error",fx,eventSettings);}
;this.focus=function(element,fx,eventSettings){this.on(element,"focus",fx,eventSettings);}
;this.keydown=function(element,fx,eventSettings){this.on(element,"keydown",fx,eventSettings);}
;this.keypress=function(element,fx,eventSettings){this.on(element,"keypress",fx,eventSettings);}
;this.keyup=function(element,fx,eventSettings){this.on(element,"keyup",fx,eventSettings);}
;this.makeDraggable=function(element,props){DragHandler.makeDraggable(element,props);}
;this.mousedown=function(element,fx,eventSettings){this.on(element,"mousedown",fx,eventSettings);}
;this.mouseenter=function(element,fx,eventSettings){if(B.isIE()||B.isFF()){this.on(element,"mouseenter",fx,eventSettings);}

else 
{var thisObj=this;element.onmouseover=function(event){if(!event){event=window.event;}

if(!isDescendent(event.fromElement,event.currentTarget)&&isDescendent(event.toElement,event.currentTarget)){thisObj.run(event,fx,eventSettings);}

}
;eh_registerEvent(element,"onmouseover");}

}
;this.mouseleave=function(element,fx,eventSettings){if(B.isIE()||B.isFF()){this.on(element,"mouseleave",fx,eventSettings);}

else 
{var outFx=function(event){if(!isInDom(element)){element.ownerDocument.body.removeEventListener("mouseout",outFx,false);}

if(isDescendent(event.srcElement,element)&&!isDescendent(event.toElement,element)){fx(event);}

}
;this.add(element.ownerDocument.body,"mouseout",outFx);var id=this.getNextId();this.mouseLeaveData[id]=outFx;sA(element,"a_metaMouseleavefxid",id);}

}
;this.mousemove=function(element,fx,eventSettings){this.on(element,"mousemove",fx,eventSettings);}
;this.mouseout=function(element,fx,eventSettings){this.on(element,"mouseout",fx,eventSettings);}
;this.mouseover=function(element,fx,eventSettings){this.on(element,"mouseover",fx,eventSettings);}
;this.mouseup=function(element,fx,eventSettings){this.on(element,"mouseup",fx,eventSettings);}
;this.paste=function(element,fx,eventSettings){this.on(element,"paste",fx,eventSettings);}
;this.resize=function(fx,eventSettings){this.add(window,"resize",fx);}
;this.rightclick=function(element,fx,eventSettings){this.on(element,"contextmenu",fx,eventSettings);}
;this.defaultEventSettings={stop:true}
;this.mouseLeaveData={}
;this.counter=0;this.getNextId=function(){this.counter++;return "a_e"+this.counter;}

}


var BodyOnloader=new BodyOnloaderBase();function BodyOnloaderBase(){this.fxsForBeforeLoad=[];this.fxsForAfterLoad=[];this.addFxForBeforeLoad=function(fx){this.fxsForBeforeLoad.push(fx);}
;this.addFxForAfterLoad=function(fx){this.fxsForAfterLoad.push(fx);}
;this.addFx=function(fx){this.fxsForBeforeLoad.push(fx);}
;this.runAfterLoad=function(){for(var i=0;i<this.fxsForAfterLoad.length;i++)
{var fx=this.fxsForAfterLoad[i];fx();}

}
;this.run=function(afterFx){for(var i=0;i<this.fxsForBeforeLoad.length;i++)
{var fx=this.fxsForBeforeLoad[i];fx();}

var thisObj=this;var finishFx=function(){thisObj.runAfterLoad();if(afterFx){afterFx();}

}
;var mc=getMasterCache();if(mc.isDataToLoad()){mc.process(finishFx);}

else 
{finishFx();}

}
;}

var DataInitializer=new DataInitializerBase();function DataInitializerBase(){this.createNewRecords=function(mc,rTC){for(var i=0;i<rTC.length;i++)
{var data=rTC[i];var record=mc.createRecord(data.type);var names=data.record_names.split(",");for(var j=0;j<names.length;j++)
{var name=names[j].trim();if(name){record.addName(name);}

}

}

}
;this.init=function(){if(!window["mc_i"]){return ;}

var mc=getMasterCache();mc_updateData(mc,mc_i);delete(mc_i);if(window.mc_js){mc_updateData(mc,mc_js);delete(mc_js);}

}
;{var thisObj=this;var fx=function(){thisObj.init();}
;}

}

var g_progressPopup;function showProgressIcon(title,enableBg,zIndex){hideProgressIcon();var popup=new Popup();g_progressPopup=popup;popup.shadow="full";popup.showX=false;popup.disableBg=!enableBg;popup.width=130;popup.height=130;if(zIndex){popup.zIndex=zIndex;}
;var contentArea=popup.build();contentArea.align="center";contentArea.style.width="130px";contentArea.style.height="130px";var imgContainer=cE("div",contentArea);imgContainer.style.padding="30px 30px 8px 30px";var img=cE("img",imgContainer);img.src="/upload/custom_screens/architect/moduleeditor/progress_icon.gif";var div2=cE("div",contentArea);div2.style.padding="10px";title=(title!=undefined)?title:"loading";popup.title=title;var innerDiv=cE("span",div2);innerDiv.className="mediumText";innerDiv.innerHTML=title;popup.center();return popup;}

function showProgressIconFixedInterval(str,millisec,enableBg,zIndex){var popup=showProgressIcon(str,enableBg,zIndex);g_progressPopup=null;var fx=function(){g_progressPopup=popup;hideProgressIcon();}
;window.setTimeout(fx,millisec);}
;function hideProgressIcon(){if(g_progressPopup){g_progressPopup.close();g_progressPopup=null;}

}


var ModuleUtil=new ModuleUtilBase();function ModuleUtilBase(){this.drawModule=function(path,targetEl){var mc=new MiniCache();createModuleHtmlGetter("draw",mc,path);var thisObj=this;var fx=function(){var results=mc.getActionField("draw").getChildField("exec_res");targetEl.innerHTML=results.getChildField("html").getValue();}
;mc.process(fx);}
;}


function str_fieldToHtmlList(parentEl,dynField,properties){parentEl.innerHTML=dynField.data||"&nbsp;";}

registerHtmlConverter("TEXT","list",str_fieldToHtmlList);registerHtmlConverter("phone","list",str_fieldToHtmlList);registerHtmlConverter("email","list",str_fieldToHtmlList);registerHtmlConverter("TEXT","read",str_fieldToHtmlList);registerHtmlConverter("phone","read",str_fieldToHtmlList);registerHtmlConverter("email","read",str_fieldToHtmlList);

function int_integerToHtmlList(parentEl,dynField,properties){parentEl.innerHTML=dynField.getValue();}

registerHtmlConverter("INTEGER","read",int_integerToHtmlList);registerHtmlConverter("INTEGER","list",int_integerToHtmlList);

function mc_longTextToList(parentEl,dynField,properties){parentEl.innerHTML=dynField.data||"&nbsp;";}

registerHtmlConverter("LONG_TEXT","list",mc_longTextToList);registerHtmlConverter("LONG_TEXT","read",mc_longTextToList);

function mc_category3ToList(parentEl,dynField,properties){var definitionId=dynField.data.category_definition.id;var miniCache=dynField.ownerRecord.ownerCache;var definitionRecord=miniCache.getRecord("cat_def3",definitionId);if(!definitionRecord){parentEl.innerHTML="--";return ;}

var options=definitionRecord.getField("category_definition").data.options;var value=dynField.data.value;var display=options[value];parentEl.innerHTML=display?display:"";setStyles(parentEl,properties);}

registerHtmlConverter("C3","list",mc_category3ToList);registerHtmlConverter("C3","read",mc_category3ToList);

;function timeToReadHtml(parentEl,dynField,properties){parentEl.innerHTML=(dynField.data==null)?"":dynField.data.timeToString();}

registerHtmlConverter("TIME_TYPE_NAME","read",timeToReadHtml);registerHtmlConverter("TIME_TYPE_NAME","list",timeToReadHtml);
;function dateFieldToListHtml(parentEl,dynField,properties){var dateObj=dynField.getValue();var dateFormat=(properties&&properties.dateFormat)?properties.dateFormat:null;if(null==dateFormat||dateFormat.length<=0){dateFormat=["month","/","date","/","year"];}

var display=""
if(null!=dateObj){display=dateObj.getString(dateFormat);}

parentEl.innerHTML=display;}

registerHtmlConverter("DATE","read",dateFieldToListHtml);registerHtmlConverter("DATE","list",dateFieldToListHtml);

function bool_booleanToReadHtml(parentEl,dynField,properties){parentEl.innerHTML=dynField.getValue()?"yes":"no";}

registerHtmlConverter("BOOLEAN","read",bool_booleanToReadHtml);
function dbl_doubleToReadHtml(parentEl,dynField,properties){parentEl.innerHTML=dynField.getValue();}

registerHtmlConverter("DOUBLE","read",dbl_doubleToReadHtml);registerHtmlConverter("DOUBLE","list",dbl_doubleToReadHtml);

function rn_nameToReadHtml(parentEl,dynField,properties){parentEl.innerHTML=dynField.getChildField("recordName").getValue();}

registerHtmlConverter("RECORD_NAME","read",rn_nameToReadHtml);

function nms_newMultiselectHtmlRead(parentEl,dynField,properties){var definitionId=dynField.data.category_definition.id;var miniCache=dynField.ownerRecord.ownerCache;var definitionRecord=miniCache.getRecord("cat_def3",definitionId);if(!definitionRecord){parentEl.innerHTML="";return ;}

var options=definitionRecord.getField("category_definition").data.options;dynField.initSelection();var display="";for(var name in options)
{var option=options[name];if(dynField.selectedOptions[name]){display+=option+", ";}

}

display=display.replace(/^\s+|\s+$/g,'');var commaIndex=display.lastIndexOf(",");if(commaIndex==(display.length-1)){display=display.substring(0,(display.length-1))
}

parentEl.innerHTML=display;}

registerHtmlConverter("MS3","list",nms_newMultiselectHtmlRead);registerHtmlConverter("MS3","read",nms_newMultiselectHtmlRead);

function mc_timeStampToHtml(parentEl,fieldName,dataObject,metaData,recordMetaData){parentEl.innerHTML="--";}

registerHtmlConverter("TIMESTAMP","edit",mc_timeStampToHtml);
;;;;;;;;;;;

function createWorkSession(name,miniCache,runName,runKey){var wS=miniCache.createAction(name,"WST");wS.getChildField("run_name").setValue(runName);wS.getChildField("run_key").setValue(runKey);wS.addInstruction=function(instruction){var instructions=this.getChildField("instructions");instructions.addChildField(instruction,"TEXT",instruction);return this;}

wS.addWorkParam=function(paramName,paramStrVal){var workParams=this.getChildField("work_params");workParams.addChildField(paramName,"TEXT",paramStrVal);return this;}

wS.addWorkParamObj=function(paramName,paramVal,dynFieldType){var workParams=this.getChildField("work_params");workParams.addChildField(paramName,dynFieldType,paramVal);return this;}

wS.addWorkParamDynField=function(name,dynField,fieldType){var workParams=this.getChildField("work_params");workParams.insertChildField(name,fieldType,dynField);return this;}

wS.setIsPersistent=function(isPersistent){var valToSet=isPersistent;if(null==valToSet){valToSet=true;}

this.getChildField("is_persistent").setValue(valToSet);return this;}
;wS.setIsPersistentWithReinit=function(reinitFromPersistInstrName){this.setIsPerstent();this.getChildField("instruction_on_reinit_from_persistence").setValue(reinitFromPersistInstrName);return this;}
;wS.setStartDateTime=function(dateTimeObj){this.getChildField("start_date").setValue(dateTimeObj);return this;}
;wS.setStartDelay=function(delaySec){this.getChildField("start_delay").setValue(delaySec);return this;}
;wS.setFrequency=function(freqSec){this.getChildField("frequency").setValue(freqSec);this.getChildField("is_fixed_frequency").setValue(false);return this;}

wS.setWorkTimeout=function(timeoutSec){this.getChildField("work_timeout").setValue(timeoutSec);return this;}

wS.setRetryAttemptsOnFailure=function(maxAttempts){this.getChildField("retry_attempts_on_failure").setValue(maxAttempts);return this;}

wS.setDelayBetweenRetryAttempts=function(delaySec){this.getChildField("delay_between_retry_attempts").setValue(delaySec);}

wS.setRunLockObjName=function(lockObjName){this.getChildField("run_lockObj_name").setValue(lockObjName);}

wS.setReinitFromFailureInstruction=function(reinitInstrName){this.getChildField("instruction_on_reinit_from_failure").setValue(reinitInstrName);return this;}

wS.setBasePackage=function(basePackage){this.addChildField("base_package",TEXT,basePackage);return this;}
;wS.setCancelWork=function(){this.addChildField("cancel_work","BOOLEAN").setValue(true);return this;}
;return wS;}

mc_typeToDefaultValue["WST"]=function(){var wS=new DynField(null,{}
,{}
,null,null);wS.addChildField("instructions","COLLECTION");wS.addChildField("work_params","COLLECTION");wS.addChildField("run_name","TEXT");wS.addChildField("run_key","TEXT");wS.addChildField("is_persistent","BOOLEAN");wS.addChildField("start_date","DATETIME");wS.addChildField("start_delay","DOUBLE");wS.addChildField("frequency","DOUBLE");wS.addChildField("is_fixed_frecuency","BOOLEAN");wS.addChildField("work_timeout","DOUBLE");wS.addChildField("retry_attempts_on_failure","INTEGER");wS.addChildField("delay_between_retry_attempts","DOUBLE");wS.addChildField("run_lockObj_name","TEXT");wS.addChildField("instruction_on_reinit_from_failure","TEXT");wS.addChildField("instruction_on_reinit_from_persistence","TEXT");wS.addChildField("base_package","TEXT");return {data:wS.data,metaData:wS.metaData}
;}

vfc_registerConverter("WST",vfc_returnNoValue);
;function md_MessageDispatcher(){this.onAfterSendFx=null;this.listCount=0;this.setSendDateTime=function(dateTimeObj){this.properties.getChildField("send_datetime").setValue(dateTimeObj);}
;this.setSenderId=function(id){this.properties.getChildField("sender_id").setValue(id);}
;this.setEmailSenderInformation=function(name,email){var senderInfo=this.properties.getChildField("email_sender_info");senderInfo.getChildField("sender_email").setValue(email);senderInfo.getChildField("sender_name").setValue(name);}

this.addRecipientListToLoad=function(listToLoad){this.properties.getChildField("recipient_lists_to_load").insertChildField(this.listCount,"COLLECTION",listToLoad);this.listCount++;}

this.addRecipientId=function(id){var field=this.properties.getChildField("hardcoded_user_ids");this.addValueToStr(field,id);}
;this.addGroupId=function(id){var field=this.properties.getChildField("hardcoded_group_ids");this.addValueToStr(field,id);}
;this.addEmailRecipient=function(emailAddress){var field=this.properties.getChildField("recipient_emails");this.addValueToStr(field,emailAddress);}

this.setPersistentGroups=function(type,id,fieldName){var field=this.properties.getChildField("persistent_group_ids");this.setPersistentValues(field,type,id,fieldName);}
;this.setPersistentRecipients=function(type,id,fieldName){var field=this.properties.getChildField("persistent_recipient_ids");this.setPersistentValues(field,type,id,fieldName);}

this.setPersistentSubject=function(type,id,fieldName){this.properties.getChildField("is_subject_persistent").setValue(true);var field=this.properties.getChildField("persistent_subject_info");this.setPersistentValues(field,type,id,fieldName);}

this.setPersistentContent=function(type,id,fieldName){this.properties.getChildField("is_content_persistent").setValue(true);var field=this.properties.getChildField("persistent_content_info");this.setPersistentValues(field,type,id,fieldName);}

this.setHardcodedSubject=function(subject){this.properties.getChildField("is_subject_persistent").setValue(false);this.properties.getChildField("subject").setValue(subject);}

this.setHardcodedContent=function(content){this.properties.getChildField("is_content_persistent").setValue(false);this.properties.getChildField("content").setValue(content);}

this.sendMessage=function(){var mc=new MiniCache();var workSession=createWorkSession("MessageDispatcher",mc,"MessageDispatcher");workSession.addInstruction("MessageDispatcher")
workSession.addWorkParamDynField("properties",this.properties,"COLLECTION");workSession.setIsPersistent(true);var dateTime=this.properties.getChildField("send_datetime").getValue();if(null==dateTime||null==dateTime.date||dateTime.time==null){workSession.setIsPersistent(false);}

else 
{workSession.setIsPersistent(true);workSession.setStartDateTime(dateTime);}

mc.process(this.onAfterSendFx);}

this.addValueToStr=function(field,value){var valueStr=field.getValue();valueStr+=value+",";field.setValue(valueStr);}

this.setPersistentValues=function(field,type,id,fieldName){field.getChildField("type").setValue(type);field.getChildField("id").setValue(id);field.getChildField("field_name").setValue(fieldName);}

this.addPersistentChildFields=function(field){field.addChildField("type","TEXT");field.addChildField("id","INTEGER",0);field.addChildField("field_name","TEXT");}

this.init=function(){var properties=new DynField("properties",{}
,{}
,null,null);properties.addChildField("send_datetime","DATETIME");properties.addChildField("sender_id","INTEGER",0);properties.addChildField("recipient_lists_to_load","COLLECTION");
{var emailSenderInfo=properties.addChildField("email_sender_info","COLLECTION");emailSenderInfo.addChildField("sender_email","TEXT");emailSenderInfo.addChildField("sender_name","TEXT");}


{properties.addChildField("subject","TEXT");properties.addChildField("is_subject_persistent","BOOLEAN",false);var field=properties.addChildField("persistent_subject_info","COLLECTION");this.addPersistentChildFields(field);}


{properties.addChildField("content","TEXT");properties.addChildField("is_content_persistent","BOOLEAN",false);var field=properties.addChildField("persistent_content_info","COLLECTION");this.addPersistentChildFields(field);}


{properties.addChildField("hardcoded_group_ids","TEXT");properties.addChildField("hardcoded_user_ids","TEXT");properties.addChildField("recipient_emails","TEXT");var field=properties.addChildField("persistent_recipient_ids","COLLECTION");this.addPersistentChildFields(field);var field=properties.addChildField("persistent_group_ids","COLLECTION");this.addPersistentChildFields(field);}

this.properties=properties;}

this.init();}


;;;;
var AProcessor=new AProcessorBase();function AProcessorBase(){this.onProcessFxs={}
;this.processFxCount=0;this.addOnProcessEvent=function(fx,eventId){this.processFxCount++;if(!eventId){eventId="event"+this.processFxCount;}

this.onProcessFxs[eventId]=fx;}
;this.removeOnProcessEvent=function(eventId){delete(this.onProcessFxs[eventId]);}
;
this.elementInitializers={}
;this.attachEvents=function(containerEl){for(var i in this.elementInitializers)
{var elements=containerEl.getElementsByTagName(i);var initializersForType=this.elementInitializers[i];for(var j=0;j<initializersForType.length;j++)
{var attachFx=initializersForType[j];for(var k=0;k<elements.length;k++)
{attachFx(elements[k]);}

}

}

this.registerProcessors();}
;this.runProcessFxs=function(){for(var i in this.onProcessFxs)
{var fx=this.onProcessFxs[i];fx();}

}
;this.registerProcessors=function(){var thisObj=this;var buttons=CssUtil.getElementsByClassName("a_processor");for(var i=0;i<buttons.length;i++)
{var button=buttons[i];this.attachOnClick(button);}

}
;this.attachOnClick=function(element){var thisObj=this;var processFx=function(){var params=A.getFragInfo(element.id).params;showProgressIcon("processing...");var mc=FieldHandler.findOwnerCache(element);var afterFx=function(){var emails=params.emails;var subject=params.subject;if(null!=emails){thisObj.sendEmail(mc,emails,subject);}

var contentElId=params.a_after_el;var contentEl=document.getElementById(contentElId);if(contentEl){var afterModuleName=params.a_after_module;ModuleUtil.drawModule(afterModuleName,contentEl);}

hideProgressIcon();thisObj.runProcessFxs();}
;var customErrorFx=gA(element,"errorFx");if(null!=customErrorFx){mc.validationHandler.errorDisplayFx=eval(customErrorFx);}

if(mc.validate()){mc.process(afterFx);}

hideProgressIcon();}
;eh_attachEvent("onclick",element,processFx);}
;this.sendEmail=function(mc,emails,subject){var record=this.findRecordForEmail(mc);if(!record){return ;}

var div=cE("div");var tbody=createTable(div);tbody.parentNode.border=1;tbody.parentNode.borderColor="black";var fieldNames=record.getFieldNames();for(var i=0;i<fieldNames.length;i++)
{var field=record.getField(fieldNames[i]);var tr=cE("tr",tbody);var td=cE("td",tr);td.style.width="150px";td.style.paddingRight="8px";td.innerHTML=field.getDisplayName();var td=cE("td",tr);field.buildField(td,"read");}

if(null==subject){subject="Form submission";}

var md=new md_MessageDispatcher();md.setHardcodedSubject(subject);md.setHardcodedContent(div.innerHTML);var emailList=emails.split(",");for(var i=0;i<emailList.length;i++)
{var email=emailList[i].trim();if(""==email){continue;}

md.addEmailRecipient(email);}

md.sendMessage();}
;this.findRecordForEmail=function(mc){var recordNames={}
;var elInfo=g_moduleInfo.fragInfo;for(var elName in elInfo)
{var frag=elInfo[elName];if("field"!=frag.fragType){continue;}

recordNames[frag.params.record]=true;}

for(var i in recordNames)
{var record=mc.getRecordByName(i);if(null!=record){return record;}

}

return null;}
;this.registerInitializer=function(elType,attachFx){var initializersForType=this.elementInitializers[elType];if(!initializersForType){initializersForType=this.elementInitializers[elType]=[];}

initializersForType.push(attachFx);}
;this.init=function(){var thisObj=this;var fx=function(){thisObj.attachEvents(document.body);}
;BodyOnloader.addFxForBeforeLoad(fx);}
;this.init();}
;
var FieldHandler=new FieldHandlerBase();
function FieldHandlerBase(){this.converters={}
;this.init=function(data){var params=this.getParams(data.params);var fieldHolder=gE("#"+data.elId);if(null==fieldHolder){return ;}

var mc=A.findOwnerCache(fieldHolder);var record=mc.getRecordByName(params.record);if(parseInt(data.dbId)>0){record=mc.getRecord(data.recordType,data.dbId);}

else if(g_moduleInfo.rTC&&record==null){var rTC=g_moduleInfo.rTC;record=this.getNewRecord(mc,rTC,params);}

if(!record){return ;}

if(null==mc.getRecordByName(params.record)){mc.addRecordName(record,params.record)
}

var field=record.getField(params.name);var converter=this.getConverter(field,params.converter);if(null!=converter){converter.init(data,field);}

}
;

this.getConverter=function(dynField,converterName){var converters=this.converters[converterName];if(!converters){return null;}

var converter;var uiType=dynField.getUiType();if(""!=uiType){converter=converters[uiType];}

if(null==converter){converter=converters[dynField.getFieldType()];}

return converter||null;}
;this.registerConverter=function(fieldTypeName,converterName,converter){var converters=this.converters[converterName];if(!converters){var converters={}
;this.converters[converterName]=converters;}

converters[fieldTypeName]=converter;}
;
this.getNewRecord=function(mc,rTC,data){var processedNames={}
;for(var i=0;i<rTC.length;i++)
{var rTCData=rTC[i];if(processedNames[name+rTCData.type]){continue;}

if(!data.record.equals(rTCData.record_names)){continue;}

var record=mc.createRecord(rTCData.type);var names=rTCData.record_names.split(",");for(var j=0;j<names.length;j++)
{var name=names[j].trim();if(name){record.addName(name);processedNames[name+rTCData.type]=true;}

}

}

return record;}
;
this.getParams=function(params){for(var paramName in params)
{var paramValue=params[paramName];if(!isNaN(paramValue)){paramValue=parseFloat(paramValue);}

else if(paramValue=="true"||paramValue=="false"){paramValue=(paramValue=="true");}

params[paramName]=paramValue;}

return params;}
;}
;
function AAction(params,fragInfo){this.params=params;this.fragInfo=fragInfo;}
;AAction.prototype=new AActionBase();function AActionBase(){this.setParam=function(name,value){this.params[name]=value;}
;this.removeParam=function(name){delete(this.params[name]);}
;this.setDoSave=function(){var el=gE("#"+this.fragInfo.elId);LivePage.setElementToSave(el);}
;this.toJson=function(){return serializeToJson(this.params);}
;this.remove=function(){ActionHandler.removeAction(this);}
;}
;
;var ActionHandler=new ActionHandlerBase();
function ActionHandlerBase(){this.actionHandlers={}
;this.init=function(fragInfo){var params=this.getParams(fragInfo.params);var fieldHolder=document.getElementById(fragInfo.elId);if(null==fieldHolder){return ;}

var actions=fragInfo.actions;for(var i=0;i<actions.length;i++)
{this.initAction(actions[i],fragInfo);}

}
;
this.initAction=function(actionData,fragInfo){var actionHandler=this.getActionHandler(actionData.command);if(null!=actionHandler){actionHandler.init(actionData,fragInfo);}

var aAction=new AAction(actionData,fragInfo);this.mapActionToFrag(aAction);return aAction;}
;
this.mapActionToFrag=function(aAction){var data=aAction.fragInfo;var command=aAction.params.command;var actionsByType=data.actionsByType;if(!actionsByType){actionsByType={}
;data.actionsByType=actionsByType;}

var actionsOfAType=actionsByType[command];if(!actionsOfAType){actionsOfAType=[];actionsByType[command]=actionsOfAType;}

actionsOfAType.push(aAction);}
;
this.getActionHandler=function(actionType){var action=this.actionHandlers[actionType];return action;}
;
this.registerAction=function(actionType,actionHandler){this.actionHandlers[actionType]=actionHandler;}
;
this.getParams=function(params){for(var paramName in params)
{var paramValue=params[paramName];if(!isNaN(paramValue)){paramValue=parseFloat(paramValue);}

else if(paramValue=="true"||paramValue=="false"){paramValue=(paramValue=="true");}

params[paramName]=paramValue;}

return params;}
;
this.createActionString=function(fragInfo){var actionsByType=fragInfo.actionsByType;if(null==actionsByType){return "";}

var actionStr="";for(var actionType in actionsByType)
{var actions=actionsByType[actionType];for(var i=0;i<actions.length;i++)
{actionStr+=actions[i].toJson();actionStr+=",";}

}

if(actionStr===""){return "";}

var lastComaIndex=actionStr.lastIndexOf(",");actionStr=actionStr.substring(0,lastComaIndex);return "a_action=["+actionStr+"]";}
;
this.addAction=function(element,params){var id=element.id;if(""==id){id=A.createTempId();element.id=id;}

var fragInfo=A.getFragInfo(id);if(null==fragInfo){fragInfo={params:{}
,elId:id,fragType:"standardTag",actionsByType:{}
,actions:[]}
;A.addFragInfo(id,fragInfo);}

fragInfo.actions.push(params);var aAction=this.initAction(params,fragInfo);aAction.setDoSave();return aAction;}
;
this.removeActions=function(fragInfo,actionType){if(null==fragInfo){return ;}

if(undefined===fragInfo["actionsByType"]){return ;}

delete(fragInfo.actionsByType[actionType]);var elToSave=gE("#"+fragInfo.elId);LivePage.setElementToSave(elToSave);}
;
this.removeAction=function(aAction){if(null==aAction){return ;}

var fragInfo=aAction.fragInfo;aAction.setDoSave();var actions=fragInfo.actionsByType[aAction.params.command];for(var i=0;i<actions.length;i++)
{var thisAction=actions[i];if(thisAction==aAction){actions.splice(i,1);break;}

}

aAction=null;}
;
}
;

var PageLoader=new PageLoaderBase();function PageLoaderBase(){this.init=function(actionData,data){if(A.isEditMode()){return ;}

var el=gE("#"+data.elId);var thisObj=this;var onClick=function(){if(null==el.pathname&&el.tagName.toLowerCase()!="a"){alert("PageLoader action can only be implemented in a tags");return ;}

var url=el.pathname;var callBack=function(pageData){var beforeLoad=actionData.beforeLoadFx;if(beforeLoad!=""&&beforeLoad!=undefined){var fx=eval(beforeLoad);fx(actionData.extras);}

var extras=actionData.extras||{}
;extras.prevUrl=window.location.pathname;extras.prevTitle=document.title;var curStateObj={html:pageData.html,extras:extras}
;thisObj.appendHtml(curStateObj,actionData);thisObj.initPageData(pageData)
document.title=pageData.title;if(history.pushState){history.pushState(null,pageData.pageTitle,url);}

}
;A.loadUrl(url,callBack);}
;E.click(el,onClick);var onInit=actionData.onInit;if(onInit!=undefined&&onInit!=""){var fx=eval(onInit);fx(actionData.extras);}

this.preloadDefaultTransition(actionData);}
;
this.preloadDefaultTransition=function(){try
{eval(actionData.afterLoadFx);}

catch(e){var afterLoad=function(){}
;sl_loadScript('/0/le8778_0.js',afterLoad);afterLoad;}

}
;
this.initPageData=function(pageData){var miniCacheData=pageData.mcData;var mc=getMasterCache();mc_updateData(mc,miniCacheData);eval("var moduleInfo="+pageData.json);this.appendHeadContents(pageData.head,moduleInfo);}
;
this.appendHeadContents=function(headContents,moduleInfo){var appender=cE("div",document.body);appender.innerHTML=headContents;appender.id="a_headAppender";var inlineScripts=[];var scriptSources=[];var scriptInfo={inline:inlineScripts,sources:scriptSources}
;var scripts=appender.getElementsByTagName("script");for(var i=0;i<scripts.length;i++)
{var curScript=scripts[i];var src=curScript.src;if(""!=src){scriptSources.push(curScript);}

else 
{var scriptStr=curScript.innerHTML;if(""!=scriptStr){inlineScripts.push(scriptStr)
}

}

}

if(scriptSources.length==0){this.initPageJs(moduleInfo,inlineScripts);}

else 
{this.initSecuentialJsLoad(scriptInfo,moduleInfo,0);}

}

this.initSecuentialJsLoad=function(scriptInfo,moduleInfo,index){var scripts=scriptInfo.sources;var appender=gE("#a_headAppender");var srcEl=scripts[index];var scriptEl=cE("script");scriptEl.src=srcEl.src;scriptEl.type="text/javascript";var thisObj=this;var onLoad=function(){if(index==[scripts.length-1]){thisObj.initPageJs(moduleInfo,scriptInfo.inline);}

else 
{thisObj.initSecuentialJsLoad(scriptInfo,moduleInfo,index+1);}

}
;aE(appender,scriptEl);removeNode(srcEl);E.add(scriptEl,"load",onLoad);}
;
this.initPageJs=function(moduleInfo,inlineScripts){var lFragInfo=moduleInfo.fragInfo;var gFragInfo=g_moduleInfo.fragInfo;for(var elId in lFragInfo)
{A.addFragInfo(elId,lFragInfo[elId]);}

var rTC=moduleInfo.rTC;for(var i=0;i<rTC.length;i++)
{A.addRecordToCreate(rTC[i]);}

ATagInitializer.initFromJsData(lFragInfo);for(var i=0;i<inlineScripts.length;i++)
{var scriptStr=inlineScripts[i];eval(scriptStr);}

}
;
this.appendHtml=function(curStateObj,actionData){try
{var fx=eval(actionData.afterLoadFx);fx(curStateObj);}

catch(e){this.launchDefaultTranstion(curStateObj);}

}
;this.launchDefaultTranstion=function(data){var contentEl=gE("#tr-default-dynamic-content-holder");if(null==contentEl){contentEl=cE("div",document.body);contentEl.id="tr-default-dynamic-content-holder"
}

contentEl.innerHTML="";contentEl.className="tr-default-parent-el active-layover";contentEl.style.zIndex=CssUtil.getHighestZIndex();var tr=new DefaultTransition();tr.contentClassName="tr-default-content-el";tr.gatesClassName="tr-default-gates";tr.closeButtonClassName="tr-default-close-el";var thisObj=this;tr.onClose=function(){var prevUrl=data.extras.parentUrl||data.extras.prevUrl;var prevPageTitle=data.extras.prevTitle;document.title=prevPageTitle;if(history.replaceState){history.replaceState(null,prevPageTitle,prevUrl);}

var onTrEn=function(){contentEl.className="inactive-layover";contentEl.style.zIndex=-10000;clearTimeout(thisObj.tto);thisObj.transition=null;}

thisObj.tto=setTimeout(onTrEn,2500);}
;tr.init(contentEl,data.html);}
;}
;ActionHandler.registerAction("pageLoader",PageLoader);

var ShortTextEdit=new ShortTextEditBase();function ShortTextEditBase(){this.init=function(data,dynField){var input=document.getElementById(data.elId);var properties=data.params||{}
;properties.onAfterChangeFx=function(value){dynField.setValue(value);}
;properties.value=dynField.data;properties.uiType=dynField.getUiType();properties.validationHandler=dynField.getOwnerCache().validationHandler;enableTextInput(input,properties);}
;}

FieldHandler.registerConverter("TEXT","edit",ShortTextEdit);

var LongTextEdit=new LongTextEditBase();function LongTextEditBase(){this.init=function(data,dynField){var input=document.getElementById(data.elId);var properties=data.params;properties.onAfterChangeFx=function(value){dynField.setValue(value);}
;properties.value=dynField.data;properties.uiType=dynField.getUiType();properties.validationHandler=dynField.getOwnerCache().validationHandler;enableTextArea(input,data.params);}
;}

FieldHandler.registerConverter("LONG_TEXT","edit",LongTextEdit);

var MultiSelect3Edit=new MultiSelect3EditBase();function MultiSelect3EditBase(){this.init=function(data,dynField){var elId=data.elId
var checkHolder=document.getElementById(elId);var onCheck=function(ev){var checkbox=ev.target||ev.srcElement;if(checkbox.tagName!="INPUT"){return ;}

var newValue="";var allBoxes=document.getElementById(elId).getElementsByTagName("input");for(var i=0;i<allBoxes.length;i++)
{var box=allBoxes[i];if(box.checked){newValue+="|"+box.value;}

}

if(newValue.length>0){newValue+="|";}

dynField.getChildField("selected_options").setValue(newValue);}
;eh_attachEvent("onclick",checkHolder,onCheck);}
;}

FieldHandler.registerConverter("MS3","edit",MultiSelect3Edit);

var Category3Edit=new Category3EditBase();function Category3EditBase(){this.init=function(data,dynField){var selectEl=document.getElementById(data.elId);var fx=function(ev){dynField.getChildField("value").setValue(selectEl.value);}
;eh_attachEvent("onchange",selectEl,fx);}
;}

FieldHandler.registerConverter("C3","edit",Category3Edit);

function file2ToEditHtml(parentEl,dynField,properties){properties=properties||{}
;var fileName=dynField.getChildField("file_name").getValue();if(fileName){var fileLink=cE("a",parentEl);var path=dynField.getChildField("full_path").getValue();fileLink.href=path;fileLink.target="_blank";fileLink.innerHTML=path;setStyles(fileLink,properties);}

else 
{if(properties.showFolder){var div=cE("div",parentEl);div.style.marginBottom=5;div.className="text";var span=cE("span",div);span.style.marginRight=5;span.innerHTML="Destination Folder";var props={style:{width:200}
}
;dynField.getChildField("folder_name").buildField(div,"edit",props);}

var div=cE("div",parentEl);var input=document.createElement("input");input.type="file";div.appendChild(input);var fx=function(){var value=input.value;var nameStart=value.lastIndexOf("\\")+1;if(-1==nameStart){return ;}

var fileName=value.substr(nameStart);input.name=fileName;dynField.getChildField("file_name").setValue(fileName);dynField.setDoSave();if(properties.onChooseFileFx){properties.onChooseFileFx(input);}

}
;eh_attachEvent("onchange",input,fx);setStyles(input,properties);return input;}

}

registerHtmlConverter("FILE2","edit",file2ToEditHtml);
;
function ImageRotator(imagePath){this.imagePath=imagePath;this.clockwiseCnt=1;this.myName="ImageRotatorRec";this.setName=function(myName){this.myName=myName;return this;}
;this.setRotationCount=function(clockwiseCnt){this.clockwiseCnt=clockwiseCnt;return this;}
;this.rotate=function(afterProcessFx){return imageRotator_rotate(imagePath,this.clockwiseCnt,this.myName,afterProcessFx);}
;this.prepare=function(miniCache){return imageRotator_prepare(miniCache,imagePath,this.clockwiseCnt,this.myName);}
;this.extractResult=function(miniCache){return imageRotator_extractResult(miniCache,this.myName);}
;}

function imageRotator_rotate(imagePath,clockwiseCnt,actionName,afterProcessFx){var miniCache=new MiniCache();imageRotator_prepare(miniCache,imagePath,clockwiseCnt,actionName);if(null==afterProcessFx){miniCache.process();var resPath=imageRotator_extractResult(miniCache,actionName);return resPath;}

var afterFx=function(){var resPath=imageRotator_extractResult(miniCache,actionName);afterProcessFx(resPath);}
;miniCache.process(afterFx);}

function imageRotator_prepare(miniCache,imagePath,clockwiseCnt,actionName){var imgRotateGE=createGeneralExecuter(actionName,miniCache,"ImageRotator");var params=imgRotateGE.getChildField("exec_params");params.addChildField("image_path","TEXT").setValue(imagePath);if(null!=clockwiseCnt){params.addChildField("rotate_clockwise","INTEGER").setValue(clockwiseCnt);}

return imgRotateGE;}

function imageRotator_extractResult(miniCache,actionName){var imgRotateAction=miniCache.getActionField(actionName);if(null==imgRotateAction){return null;}

var result=imgRotateAction.data.exec_res;if(null==result){return null;}

return result.success;}


;var ImageUtil=new ImageUtilBase();function ImageUtilBase(){
this.getImagePath=function(imageEl,params){var cleanSrc=this.getUrlWithNoParams(imageEl.src);return cleanSrc+"?"+ImageUtil.createQueryString(params);}
;this.optmize=function(imageEl){var params={f:"cover",u:true}
;var cssWidth=imageEl.style.width;if(cssWidth){params["w"]=CssUtil.pixelToInt(cssWidth);}

var cssHeight=imageEl.style.height;if(cssHeight){params["h"]=CssUtil.pixelToInt(cssHeight);}

var path=this.getImagePath(imageEl,params);imageEl.src=path;imageEl.style.width="";imageEl.style.height="";}
;this.changeImageEl=function(imageEl,paramsToUpate,paramsToRemove){var originalSrc=imageEl.src;var params=this.parseQueryString(originalSrc);for(var i in paramsToUpate)
{params[i]=paramsToUpate[i];}

for(var i in paramsToRemove)
{delete(params[paramsToRemove[i]]);}

var cleanSrc=this.getUrlWithNoParams(originalSrc);var newSrc=cleanSrc+"?"+this.createQueryString(params);if(originalSrc!=newSrc){imageEl.src=newSrc;}

}
;this.changeImagePath=function(imagePath,paramsToUpate,paramsToRemove){var params=this.parseQueryString(imagePath);for(var i in paramsToUpate)
{params[i]=paramsToUpate[i];}

for(var i in paramsToRemove)
{delete(params[paramsToRemove[i]]);}

var cleanSrc=this.getUrlWithNoParams(imagePath);var newSrc=cleanSrc+"?"+this.createQueryString(params);return newSrc;}
;this.getExtension=function(url){var cleanUrl=this.getUrlWithNoParams(url);var start=cleanUrl.lastIndexOf(".");var ext=cleanUrl.substring(start+1);return ext.toLowerCase();}
;
this.getUrlWithNoParams=function(url){var end=url.indexOf("?");if(-1==end){return url;}

else 
{return url.substring(0,end);}

}

this.parseQueryString=function(url){var params={}
;var start=url.indexOf("?");if(-1==start){return params;}

var qS=url.substring(start+1);var keyValues=qS.split("&");for(var i=0;i<keyValues.length;i++)
{var kV=keyValues[i];if(""==kV){continue;}

var data=kV.split("=");params[data[0]]=data[1];}

return params;}
;this.createQueryString=function(params){var str="";for(var i in params)
{str+=i+"="+params[i]+"&";}

return str;}
;this.loadByPath=function(path,mc,afterFx){path=this.getRelativePath(path);var listInput=createListInput("image_library","image_finder",0,1);listInput.addSearchTerm("file",path,SEARCHTERM_BEGINS_WITH);mc.addListInput(listInput);var thisObj=this;var fx=function(){var list=mc.getListByName("image_finder");var record=list.getFirstRecord();afterFx(record);}
;mc.process(fx);}
;this.getRelativePath=function(path){var start=path.indexOf("/upload/");if(start==-1){return null;}

var end=path.indexOf("?");if(end==-1){end=null;}

return path.substring(start,end);}
;
}


;;function ImageEditView(imageId,mc){this.imageId=imageId;this.mc=mc;this.imageWidth=350;this.imageHeight=350;this.showDelete=true;this.cancelFx;this.deleteFx;this.imageEl;this.docs=[document.body];this.onRotateFx;this.build=function(parentEl){var holder=cE("div",parentEl);holder.style.padding="15px";var record=this.mc.getRecord("image_library",this.imageId);var div=cE("div",holder);var image=cE("img",div);image.src=record.getField("file").getImagePath(this.imageWidth,this.imageHeight,true,"cover");this.imageEl=image;var div=cE("div",holder);div.style.marginTop="15px";this.buildFields(div,record);var div=cE("div",holder);div.style.marginTop="30px";this.buildButtons(div,record);}
;this.buildButtons=function(parentEl,record){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingLeft="100px";var thisObj=this;var fx=function(){thisObj.cancelFx();showProgressIcon();var finishFx=function(){hideProgressIcon();}
;thisObj.mc.process(finishFx);}
;var button=ButtonUtil.buildButton(td,"Save",fx,"medium");if(this.cancelFx){var thisObj=this;var fx=function(){thisObj.cancelFx();}
;var button=ButtonUtil.buildButton(td,"Cancel",fx,"medium");button.style.marginLeft="6px";}

var td=cE("td",tr);td.align="right";td.style.paddingLeft="50px";if(this.showDelete){this.buildDelete(td,record);}

}
;this.buildDelete=function(parentEl,record){var tBody=createTable(parentEl);var thisObj=this;var onclickFx=function(){showProgressIcon("deleting...");thisObj.mc.deleteRecord("image_library",record.getId());var afterFx=function(){thisObj.deleteFx();hideProgressIcon();}
;thisObj.mc.process(afterFx);}
;eh_attachEvent("onclick",tBody.parentNode,onclickFx);var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";var image=cE("img",td);image.src="/upload/custom_screens/architect/imagelibrary/x_icon.gif";image.style.cursor="pointer";image.style.marginRight="5px";var td=cE("td",tr);td.align="right";td.style.paddingRight="15px";var span=cE("nobr",td);span.style.color="#006699";span.className="il_text";span.innerHTML="Delete";addUnderlineEvents(span,"main");}
;this.buildFields=function(parentEl,record){var tBody=createTable(parentEl);tBody.className="il_text";var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";td.style.paddingRight="10px";td.className="il_boldText";td.innerHTML="Title";var td=cE("td",tr);var props={style:{width:"250px"}
,shadowText:"Enter Title"}
;record.getField("name").buildField(td,"edit",props);var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";td.style.padding="10px 10px 0 0";td.className="il_boldText";td.innerHTML="Date Uploaded";var dateObj=record.getField("created_on.date_time").getValue().date;var td=cE("td",tr);td.style.paddingTop="10px";td.innerHTML=dateObj.getString([ADateUtil.DAY_STR,", ",ADateUtil.MONTH_STR,", ",ADateUtil.DATE,", ",ADateUtil.YEAR]);var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";td.style.padding="10px 10px 0 0";td.className="il_boldText";td.innerHTML="Uploaded By";var td=cE("td",tr);td.style.paddingTop="10px";td.innerHTML=record.getField("created_by.user_name").getValue();var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";td.style.padding="10px 10px 0 0";td.className="il_boldText";td.innerHTML="Rotate";var td=cE("td",tr);td.className="il_linkColor il_text";td.style.paddingTop="10px";var thisObj=this;var div=cE("div",td);div.style.marginBottom="3px";var span=cE("span",div);span.innerHTML="Counter-Clockwise";var fx=function(){thisObj.rotateImage(3);}
;ButtonUtil.turnIntoButton(span,fx,true);var div=cE("div",td);div.style.marginBottom="3px";var span=cE("span",div);span.innerHTML="Flip Upside-down";var fx=function(){thisObj.rotateImage(2);}
;ButtonUtil.turnIntoButton(span,fx,true);var div=cE("div",td);div.style.marginBottom="3px";var span=cE("span",div);span.innerHTML="Clockwise";var fx=function(){thisObj.rotateImage(1);}
;ButtonUtil.turnIntoButton(span,fx,true);}

this.getImageEls=function(){var els=[];var path=this.mc.getRecord("image_library",this.imageId).getField("file.full_path").getValue();path=ImageUtil.getUrlWithNoParams(path);for(var i=0;i<this.docs.length;i++)
{var aDoc=this.docs[i];var images=document.body.getElementsByTagName("IMG");for(var j=0;j<images.length;j++)
{if(images[j].src.indexOf(path)!=-1){els.push(images[j]);}

}

}

return els;}
;this.rotateImage=function(rotateCount){var fileField=this.mc.getRecord("image_library",this.imageId).getField("file");var rValue=fileField.incrementRotation(rotateCount);var images=this.getImageEls();var params={r:rValue}
;for(var i=0;i<images.length;i++)
{ImageUtil.changeImageEl(images[i],params);}

this.mc.process();}
;}

;;
var ImageEdit=new ImageEditBase();function ImageEditBase(){this.fileRecCount=0;this.validFileTypes={"jpg":1,"png":1,"gif":1}
;this.init=function(data,dynField){var placeHolder=gE("#"+data.elId);var imageId=dynField.getChildField("id").getValue();if(0>=imageId||placeHolder.tagName.toLowerCase()!="img"){this.loadTemplate(placeHolder,dynField);}

else {this.buildImageDisplayArea(placeHolder,dynField);}

}
;this.buildImageDisplayArea=function(placeHolder,dynField){var launchEditPopup=function(){thisObj.launchEditor(dynField);}

E.click(placeHolder,launchEditPopup);var pE=placeHolder.parentElement;var editLink=cE("a",pE);editLink.innerHTML="replace image";editLink.href="#";var thisObj=this;var editFx=function(){pE.removeChild(editLink);thisObj.loadTemplate(placeHolder,dynField);}

E.click(editLink,editFx);}
;
this.launchEditor=function(dynField){var imageId=dynField.getChildField("id").getValue();var mc=dynField.getOwnerCache();mc.addRecordToLoad("image_library",imageId);var onProcess=function(){var afterload=function(){var popup=new Popup();popup.hideTopBar=true;var editorHolder=popup.build();var imageEditor=new ImageEditView(imageId,dynField.getOwnerCache());imageEditor.build(editorHolder);var fx=function(){popup.close();}
;imageEditor.cancelFx=fx;popup.center();}
;sl_loadScript('/0/le6679_0.js',afterload);afterload;}
;mc.process(onProcess);}
;
this.loadTemplate=function(placeHolder,dynField){var mc=new MiniCache();mc.syncToMasterOnProcess();mc.addTemplateToLoad("image_library");var thisObj=this;var onProcess=function(){thisObj.fileRecCount++;thisObj.buildImageSelector(placeHolder,dynField);}
;mc.process(onProcess);}
;
this.buildImageSelector=function(placeHolder,dynField){debugger;var pE=replaceNodeTagName("div",placeHolder,false);var holder=cE("div",pE);holder.className="a_uploadHolder";var div=cE("div",holder);this.buildUploadInput(div,dynField);var div=cE("div",holder);div.innerHTML="or";div.style.paddingLeft="20px";var div=cE("div",holder)
this.buildGalleryLauncher(div,dynField,pE);}
;this.buildGalleryLauncher=function(pE,dynField,placeHolder){var button=cE("button",pE);button.innerHTML="Select image from library";var thisObj=this;var fx=function(){var afterLoad=function(){var imagePopup=new ImagePopup();imagePopup.selectImgFx=function(imageId){thisObj.insertImage(imageId,dynField,placeHolder);imagePopup.popup.close();}
;imagePopup.build();}
;sl_loadScript('/0/le8121_0.js',afterLoad);afterLoad;}
;E.click(button,fx);}
;this.insertImage=function(imageId,dynField,pE){this.isFromImgLibrary=true;dynField.getChildField("id").setValue(imageId);var mc=new MiniCache();var rI=mc.addRecordToLoad("image_library",imageId);var thisObj=this;var onProcess=function(){var fileField=mc.getRecord("image_library",imageId).getField("file");var data=A.getFragInfo(pE.id);var img=replaceNodeTagName("img",pE);img.id=pE.id;img.src=fileField.data.full_path;thisObj.init(data,dynField);}
;mc.process(onProcess)
}
;this.buildUploadInput=function(pE,dynField){var thisObj=this;var imageId=dynField.getChildField("id");var mc=dynField.getOwnerCache();var imgRec=mc.createRecord("image_library");imageId.setValue(imgRec.id);dynField.getChildField("type").setValue("image_library");var fileField=imgRec.getField("file");var fileInput=fileField.buildField(pE,"edit");var validateFx=function(){var path=fileInput.value;var lastDotIndex=path.lastIndexOf(".");var ext=path.substring(lastDotIndex+1).toLowerCase();if(!thisObj.validFileTypes[ext]){alert(ext+" is not a valid image file type. Please choose  a jpg, png or gif file.");fileInput.value="";}

}

E.add(fileInput,"change",validateFx);var validateFileRec=function(){if(fileInput.value==""){mc.clearRecord(imgRec.type,imgRec.id);if(!thisObj.isFromImgLibrary){dynField.getChildField("id").setValue(0);}

}

}
;mc.addBeforeProcessFx(validateFileRec,"fileRecVal"+this.fileRecCount);}
;this.initCss=function(){var cC=new CssClass(".a_uploadHolder > div");cC.add("margin-bottom","5px");cC.init();}
;this.initCss();}

FieldHandler.registerConverter("IMAGE","edit",ImageEdit);
;
function UrlValidator(urlStr,urlField){
this.urlStr=urlStr.trim();
this.urlField=urlField;
this.saveOnValidate=true;}
;UrlValidator.prototype=new UrlEditorBase();function UrlEditorBase(){
this.validate=function(successFx,failFx){if(this.urlField!=null){if(this.urlStr==this.urlField.getChildField("friendly_url").getValue()){successFx();return ;}

}
;this.successFx=successFx;this.failFx=failFx;if(""==this.urlStr){this.save();return ;}

var mc=new MiniCache();var gE=createGEToRunFirst("urlVal",mc,"UrlValidator");gE.addExecParamObj("friendlyUrl","TEXT",this.urlStr);gE.addExecParamObj("action","TEXT","validate");var thisObj=this;var onProcess=function(){var results=mc.getActionField("urlVal").getResults();var isSuccess=results.getChildField("success").getValue();var canOverwrite=results.getChildField("can_overwrite").getValue();if(!isSuccess&&canOverwrite){thisObj.source=results.getChildField("source");if(!confirm("This URL is already in use. Do you wish to overwrite it?")){thisObj.failFx();}

else 
{thisObj.deactivate();}

}

else if(!isSuccess&&!canOverwrite){alert("This URL is in use by the system and cannot be overwritten. Please select a new URL");thisObj.failFx();}

else {thisObj.save();}

}
;mc.process(onProcess);}
;
this.deactivate=function(){var mc=(this.urlField!=null)?this.urlField.getOwnerCache():new MiniCache();var gE=createGEToRunFirst("urlDeactivate",mc,"UrlValidator");gE.addExecParamDynField("RECORD_TYPE",this.source,"source");gE.addExecParamObj("action","TEXT","deactivate");var thisObj=this;var onProcess=function(){var results=mc.getActionField("urlDeactivate").getResults();var isSuccess=results.getChildField("success").getValue();if(!isSuccess){alert("url deactivation failed");thisObj.failFx();}

else 
{thisObj.save();}

}
;mc.process(onProcess);}
;
this.prepUrlForSave=function(){this.urlField.getChildField("friendly_url").setValue(this.urlStr);}
;
this.save=function(){if(!this.saveOnValidate){this.successFx();return ;}

var mc=this.urlField.getOwnerCache();this.prepUrlForSave();var thisObj=this;var onProcess=function(){thisObj.successFx();}
;mc.process(onProcess);}
;}
;
;
var FriendlyUrlEdit=new FriendlyUrlEditBase();function FriendlyUrlEditBase(){this.init=function(data,dynField){var input=document.getElementById(data.elId);var pE=input.parentElement;var properties=data.params||{}
;properties.onAfterChangeFx=function(urlStr){var urlValidator=new UrlValidator(urlStr,dynField.parentField);urlValidator.saveOnValidate=false;var successFx=function(){dynField.setValue(urlStr);}
;var failFx=function(){input.value=dynField.getValue();}
;urlValidator.validate(successFx,failFx)
}
;properties.value=dynField.data;properties.uiType=dynField.getUiType();properties.validationHandler=dynField.getOwnerCache().validationHandler;enableTextInput(input,properties);var urlStr=dynField.getValue();if(dynField.ownerRecord.id>0&&""!=urlStr){var aLink=cE("a",pE);aLink.href="/"+urlStr;aLink.innerHTML="Launch display mode";aLink.target="_blank";}

var isPublicField=dynField.parentField.getChildField("is_public");isPublicField.buildField(cE("div",pE),"edit",{buildRadioButton:true,yesLabel:"Public URL",noLabel:"Private Url (login required)"}
);}
;}

FieldHandler.registerConverter("FURL","edit",FriendlyUrlEdit);
var ComponentHandler=new ComponentHandlerBase();function ComponentHandlerBase(){this.init=function(data){if(!data.componentName){return ;}

var constructor=eval(data.componentName);if(!constructor){return ;}

var parentEl=gE("#"+data.elId);var obj=new constructor(data);obj.build(parentEl);}
;}
;
var CycleHandler=new CycleHandlerBase();function CycleHandlerBase(){this.init=function(data){var el=gE("#"+data.elId);var cycle=new Cycle(el);cycle.liveCycle=false;this.addParams(cycle,data.params);cycle.modules=[];debugger;var startCount=data.params.slideCount||1;for(var i=startCount;i<data.modules.length;i++)
{cycle.modules.push({path:data.modules[i].modulePath,status:"notLoaded"}
);}

cycle.init();data.cycleObj=cycle;}
;
this.addParams=function(cycle,p){cycle.interval=5;cycle.elType="div";cycle.delay=0;cycle.autoplay=true;cycle.fixedHeight=false;cycle.buttonControls=false;cycle.arrowControls=false;cycle.numberButtons=false;cycle.useDynamicMargin=false;for(var i in p)
{if(null==p[i]||p[i]==""){continue;}

if(i=="interval"){cycle.interval=p[i];}

else if(i=="elementType"){cycle.elType=(p[i]!="ul")?"div":"ul";}

else if(i=="delay"){cycle.delay=p[i];}

else if(i=="autoplay"){cycle.autoplay=(p[i]=="no")?false:true;}

else if(i=="isFixedHeight"){cycle.fixedHeight=(p[i]=="true")?true:false;}

else if(i=="controls"){cycle.buttonControls=(p[i].indexOf("buttons")>-1)?true:false;cycle.arrowControls=(p[i].indexOf("arrows")>-1)?true:false;cycle.numberButtons=(p[i].indexOf("numbered")>-1)?true:false;}

else if(i=="useDynamicMargin"){var val=p[i];cycle.useDynamicMargin=(val=="true"||val=="yes")?true:false;}

else 
{cycle[i]=p[i];}

}

}
;}
;

function createModuleHtmlGetter(name,miniCache,modulePath,moduleId){var getter=createGEToRunLast(name,miniCache,"ModuleHtmlGetter");if(!modulePath){modulePath="";}

if(!moduleId){moduleId=0;}

var params=getter.getChildField("exec_params");params.addChildField("module_path","TEXT",modulePath);params.addChildField("module_id","INTEGER",moduleId);return getter;}

;
function Cycle(cycleEl){this.cycleEl=cycleEl;this.interval;this.modules;this.arrowControls;this.buttonControls;this.numberButtons;this.elType;this.delay;this.autoplay;this.fixedHeight;this.useDynamicMargin;this.isFullWdith="no";this.liveCycle;Cycle.cycleCount=++Cycle.cycleCount||1;this.cycleCount=Cycle.cycleCount;}
;Cycle.prototype=new CycleBase();function CycleBase(){this.init=function(afterInit){this.slideCont=this.cycleEl.firstElementChild;this.slideCont.className="cycle-slideContainer";this.interval=this.interval*1000;var thisObj=this;var afterFx=function(){thisObj.currentSlide=0;thisObj.slideCol=thisObj.cycleEl.firstElementChild.children;if(thisObj.arrowControls){thisObj.buildArrows();}

else if(thisObj.buttonControls||thisObj.numberButtons){thisObj.buildButtons();}

if(thisObj.fixedHeight){thisObj.setCycleHeight(thisObj.cycleEl,thisObj.slideCol);var setHeight=function(){thisObj.setCycleHeight(thisObj.cycleEl,thisObj.slideCol);}
;E.add(window,"resize",setHeight);}

if(thisObj.useDynamicMargin){var totalSlides=thisObj.slideCol.length;thisObj.slideCont.style.width=totalSlides*100+"%";if(thisObj.isFullWidth=="yes"){var totalSlides=thisObj.slideCol.length;thisObj.slideCont.style.width=totalSlides*100+"%";var slideWidth=100/totalSlides+"%";for(var i=0;i<totalSlides;i++)
{thisObj.slideCol[i].style.minWidth=slideWidth;}

}

var setMargin=function(){thisObj.moveMargin(thisObj.currentSlide);}
;E.add(window,"resize",setMargin);}

thisObj.startCycle();if(afterInit){afterInit();}

}
;this.loadSlides(afterFx);}
;
this.startCycle=function(){if(this.slideCol.length==0){return ;}

this.slideCol[0].className+=" cycle-Slide0 cycle-slideOn";if(this.useDynamicMargin){this.moveMargin(0);}

var intervalFx=function(){thisObj.showSlide();}
;if(!this.autoplay&&(this.arrowControls||this.buttonControls)&&this.liveCycle){return ;}

var thisObj=this;var timeOutFx=function(){thisObj.setSlideInterval();}
;var delay=this.delay||0;setTimeout(timeOutFx,delay*1000);}
;
this.showSlide=function(index){var lastSlide=this.currentSlide;var slideOff=this.slideCol[this.currentSlide];slideOff.className=slideOff.className.replace("cycle-slideOn","cycle-slideOff");if(null!=index){this.currentSlide=index;}

else if(this.currentSlide<this.slideCol.length-1){this.currentSlide++;}

else 
{this.currentSlide=0;}

this.slideCont.className=this.slideCont.className.replace("cycle-slide"+lastSlide,"cycle-slide"+this.currentSlide);var slideOn=this.slideCol[this.currentSlide];slideOn.className=slideOn.className.replace("cycle-slideOff","cycle-slideOn");if(this.useDynamicMargin){this.moveMargin(this.currentSlide);}

this.handleFramer();this.setSlideInterval();}
;this.handleFramer=function(){if(this.liveCycle){var framer=A.getFragInfo(this.cycleEl.id).framer;if(framer){framer.destroy();var tO=function(){framer.frame();}

window.setTimeout(tO,1000);}

}

}
;
this.moveMargin=function(currentSlide){var elWidth=this.cycleEl.offsetWidth/2;for(var i=0;i<currentSlide;i++)
{elWidth-=this.slideCol[i].offsetWidth;}

elWidth-=this.slideCol[currentSlide].offsetWidth/2;this.slideCont.style.marginLeft=elWidth+"px";}
;
this.buildButtons=function(){var slideNumber=this.slideCol.length;var buttonControl=cE("ul");buttonControl.className="cycle-sliderControls";this.controlEl=buttonControl;var thisObj=this;var intervalFx=function(){thisObj.showSlide();}
;var clickFx=function(e){thisObj.showSlide(parseInt(e.target.className.replace("cycle-sliderCont",""),10));}
;for(var i=0;i<slideNumber;i++)
{var buttonItem=cE("li");buttonItem.className="cycle-sliderCont"+i;buttonItem.innerHTML=(this.numberButtons)?i+1:"";aE(buttonControl,buttonItem);E.click(buttonItem,clickFx);var doNothing=function(){}
;E.focus(buttonItem,doNothing);E.mouseup(buttonItem,doNothing);}

aE(this.cycleEl,buttonControl);}
;
this.buildArrows=function(){var arrowControl=cE("ul");arrowControl.className="cycle-sliderArrows";this.controlEl=arrowControl;var thisObj=this;for(var i=0;i<2;i++)
{var arrowItem=cE("li");var clickFx=function(e){if(thisObj.liveCycle){var framer=A.getFragInfo(thisObj.cycleEl.id).framer;if(framer){framer.destroy();}

}

if(e.target.className=="cycle-next"){thisObj.showSlide();}

else if(thisObj.currentSlide!=0){thisObj.showSlide(thisObj.currentSlide-1);}

else 
{thisObj.showSlide(thisObj.slideCol.length-1);}

thisObj.setSlideInterval();}
;if(i==0){arrowItem.className="cycle-previous";}

else 
{arrowItem.className="cycle-next";}

E.click(arrowItem,clickFx);aE(arrowControl,arrowItem);var doNothing=function(){}
;E.focus(arrowItem,doNothing);E.mouseup(arrowItem,doNothing);E.mousedown(arrowItem,doNothing);}

aE(this.cycleEl,arrowControl);}
;this.setSlideInterval=function(){if(null==this.interval||this.liveCycle||!this.autoplay){return ;}

var thisObj=this;var intervalFx=function(){thisObj.showSlide();}
;clearInterval(this.intervalId);this.intervalId=setInterval(intervalFx,this.interval);}
;this.buildSlide=function(mc,moduleData){var results=mc.getActionField(moduleData.name).getChildField("exec_res");moduleData.status="loaded";var elType=(this.elType=="ul")?"li":this.elType;var slide=cE(elType,this.cycleEl.firstElementChild);moduleData.slideEl=slide;slide.className="cycle-Slide"+moduleData.name+" cycle-slideOff";AHtmlInserter.processInsert(slide,results.data);}
;this.loadSlides=function(afterFx){var mc=new MiniCache();var modules=this.modules;for(var i=0;i<this.modules.length;i++)
{var module=modules[i];if(null==module||module.status=="error"||module.status=="loaded"){continue;}

var path=module.path;var name="m"+i;module.name=name;var moduleTag="<a_module name='"+path+"'>";var gE=createGeneralExecuter(name,mc,"AHtmlGetter");var suffix=A.createTempId();this.suffix=gE.addExecParamObj("suffix","TEXT","cycle"+this.cycleCount+name);this.aHtml=gE.addExecParamObj("ahtml","LONG_TEXT",moduleTag);this.inputs=gE.addExecParamObj("inputs","COLLECTION");}

var thisObj=this;var fx=function(){for(var i=0;i<modules.length;i++)
{var module=modules[i];if(module.slideEl){module.slideEl.className="";module.slideEl.style.minWidth=thisObj.slideWidth;aE(thisObj.cycleEl.firstElementChild,module.slideEl);}

else 
{thisObj.buildSlide(mc,module);}

}

if(afterFx){afterFx();}

}
;mc.process(fx);}
;
this.pause=function(){if(null==this.intervalId){return ;}

clearInterval(this.intervalId);}
;
this.setCycleHeight=function(cycleElement,slideCollection){var height=slideCollection[0].offsetHeight;cycleElement.style.height=height+"px";}
;}
;


var DebugPopup=new DebugPoupBase();function DebugPoupBase(){this.width=200;this.popup;this.log=function(str){if(!this.popup){this.buildDebugInfo();}

this.debugArea.innerHTML+="<nobr>"+str+"</nobr><br>";}
;this.clear=function(){if(!this.popup){this.buildDebugInfo();}

this.debugArea.innerHTML="";}
;this.totalTime=0;this.start=function(){if(this.startTime){this.stop();}

this.startTime=new Date();}
;this.stop=function(){this.totalTime+=new Date()-this.startTime;this.startTime=null;}
;this.buildDebugInfo=function(){var popup=new Popup();popup.width=this.width;popup.setAsAnchor(document.body);popup.disableBg=false;popup.position="fixed";popup.zIndex=1000000;this.popup=popup;var contentArea=popup.build();contentArea.style.backgroundColor="#DADFE7";contentArea.style.border="3px double #b0b9c7";contentArea.style.overflow="auto";var totalHeight=window.innerHeight||document.body.clientHeight;contentArea.style.maxHeight=totalHeight+"px";this.debugArea=contentArea;popup.align();}
;}
;
;var NavHandler=new NavHandlerBase();function NavHandlerBase(){this.init=function(data){var el=gE("#"+data.elId);if(data.params.js=="HorizontalNavMenu"){var fx=function(){var menu=new HorizontalNavMenu(el);menu.fragInfo=data;menu.build();}

sl_loadScript('/0/le8510_0.js',fx);fx;}

else if(data.params.isScrollable=="true"){var nav=new ScrollableNav();nav.data=data;nav.build();window["SiteNavigation"]=nav;}

else 
{var menu=new GenericNavMenu(el);menu.fragInfo=data;menu.build();}

}
;}
;function ScrollableNav(){
this.afterInit;
this.scrollIsActive=false;
this.activeEl;
this.activeSection;this.sections={}
;this.urlMap={}
;this.urlToElMap={}
;this.itemLength=0;this.processedElCount=0;
this.build=function(){var listEl=gE("#"+this.data.elId);this.headerHeight=this.data.params.headerHeight||0;var navItems=listEl.getElementsByTagName("a");this.itemLength=navItems.length;for(var i=0;i<navItems.length;i++)
{var aLink=navItems[i];var pathname=this.getUrl(aLink.pathname);this.prepareSectionForUrl(pathname,i);this.prepareUrlClick(aLink,i);}

}
;
this.prepareSectionForUrl=function(pathname,index){var params=this.data.params;var pE=gE("#"+params.contentHolder);var cHolder=iE("section",pE,index);cHolder.className="a_dynamicHolder"+index;this.sections[pathname]=cHolder;}
;
this.prepareUrlClick=function(aLink,index){var pathname=this.getUrl(aLink.pathname);this.urlToElMap[pathname]=aLink;var thisObj=this;var browseClick=function(){thisObj.scrollIsActive=true;var params=thisObj.data.params;var beforeScroll=params.beforeScroll;if(beforeScroll){var fx;try
{fx=eval(beforeScroll);}

catch(e)
{fx=function(){}
;}

fx();}

thisObj.scrollToView(aLink);}
;E.click(aLink,browseClick);var thisObj=this;var callBack=function(pageData){thisObj.insertPageContents(pageData,pathname);}
;A.loadUrl(aLink.pathname,callBack);}
;this.getUrl=function(pathName){var slashIndex=pathName.indexOf("/");if(slashIndex==0){pathName=pathName.substring(1);}

return pathName;}
;
this.insertPageContents=function(dataObj,pathname){this.processedElCount++;var cHolder=this.sections[pathname];cHolder.id=pathname;cHolder.innerHTML=dataObj.html;cHolder.setAttribute("data-page-title",dataObj.title);PageLoader.initPageData(dataObj);if(this.itemLength>this.processedElCount){return ;}

this.createSectionUrlMap();var afterInit=this.afterInit;if(afterInit){afterInit();}

this.initUrlUpdate();}
;
this.initUrlUpdate=function(){var thisObj=this;var startUrlCheck=function(){var checkElementPos=function(){if(thisObj.scrollIsActive){return ;}

var scrollTop=document.documentElement.scrollTop;for(var url in thisObj.sections)
{var section=thisObj.sections[url];if(thisObj.activeSection==section){return ;}

if(thisObj.isSectionContainedView(section)){var pageTitle=section.getAttribute("data-page-title");document.title=pageTitle;history.replaceState(null,pageTitle,url);thisObj.alterLinkState(url);thisObj.activeSection=section;break;}

}

}

var onResize=function(){var isIOS=B.isIOS();if(isIOS){return ;}

var params=thisObj.data.params;var aE=thisObj.activeElement;if(aE){aE.className=(params.inactiveClassName)?params.inactiveClassName:"";thisObj.pushUrlIntoView(aE.pathname);}
;}
;E.add(window,"resize",onResize);clearTimeout(thisObj.urlCheckTimeOut);}
;this.urlCheckTimeOut=setTimeout(startUrlCheck,4000);}
;this.isSectionContainedView=function(el){var docTop=window.pageYOffset||document.documentElement.scrollTop;var docBottom=docTop+document.documentElement.offsetHeight;var elTop=el.offsetTop;var elBottom=elTop+el.offsetHeight;var isBiggerThanViewPort=((elTop<docTop)&&(elBottom>docBottom))
var isContainerInViewPort=(elTop>=docTop)&&(elBottom<=docBottom)
var isStillInViewPort=(elTop<docTop)&&((elBottom<=docBottom)&&(elBottom>docTop))
return (isBiggerThanViewPort||isContainerInViewPort||isStillInViewPort);}
;
this.createSectionUrlMap=function(){var sections=this.sections;for(var id in sections)
{var section=sections[id];var aTags=sections[id].getElementsByTagName("a");for(var j=0;j<aTags.length;j++)
{var aTag=aTags[j];var pathname=this.getUrl(aTag.pathname);if(sections[pathname]){continue;}

var pageTitle=section.getAttribute("data-page-title");var parentState={url:id,title:pageTitle}
;this.urlMap[pathname]={aTag:aTag,parentState:parentState}
;}

}

}
;
this.scrollToView=function(aLink){this.pushUrlIntoView(aLink.pathname);}
;
this.pushUrlIntoView=function(pathname){this.scrollIsActive=true;var pathname=this.getUrl(pathname);var urlData=this.urlMap[pathname];if(null!=urlData){var parentState=urlData.parentState;document.title=parentState.pageTitle;var parentUrl=parentState.url;var parentTitle=parentState.pageTitle;if(history.pushState){history.pushState(null,parentTitle,parentUrl);}

var pushUrlState=function(){urlData.aTag.click();}
;this.showMainSection(parentUrl,pushUrlState);}

else 
{this.showMainSection(pathname);}

}
;this.showMainSection=function(pathname,afterScroll){var elToScroll=gE("#"+pathname);if(null==elToScroll){return ;}

this.activeSection=elToScroll;this.alterLinkState(pathname);var pageTitle=elToScroll.getAttribute("data-page-title");document.title=pageTitle;if(history.pushState){history.pushState(null,pageTitle,pathname);}

if(this.data.params.afterScroll&&!afterScroll){try
{afterScroll=eval(this.data.params.afterScroll);}

catch(e)
{}

}

if(null==afterScroll){afterScroll=function(){}
;}

var thisObj=this;var isScrolled=false;var onScroll=function(){if(!isScrolled){afterScroll();isScrolled=true;}

else 
{isScrolled=false;thisObj.scrollIsActive=false;}

}

$('html, body').stop(true,true).animate({scrollTop:elToScroll.offsetTop-this.headerHeight}
,800,"swing",onScroll);}
;
this.alterLinkState=function(pathname){debugger;var params=this.data.params;if(this.activeElement){this.activeElement.className=(params.inactiveClassName)?params.inactiveClassName:"";}

var activeClass=params.activeClassName;if(activeClass){var thisLink=this.urlToElMap[pathname];thisLink.className=activeClass;this.activeElement=thisLink;this.activeSection=gE("#"+pathname);}

}
;}
;
var HoverModuleHandler=new HoverModuleHandlerBase();
function HoverModuleHandlerBase(){this.init=function(data){if(A.isEditMode()){return ;}

var el=gE("#"+data.elId);var hoverData=data.aHoverData;var holder=cE("span",document.body);var hoverEl=replaceNodeWithHtml(hoverData.html,holder);data.aHoverData.hoverElId=hoverEl.id;hoverEl.parentElement.removeChild(hoverEl);hoverEl=gE("#"+data.aHoverData.hoverElId);hoverEl.style.display="none";hoverEl.className+=" a_skip";var show=function(){var coords=findElCoord(el);hoverEl.style.position="absolute";hoverEl.style.top=coords.y+"px";hoverEl.style.left=coords.x+"px";hoverEl.style.display="";}
;E.mouseenter(el,show);var hide=function(){hoverEl.style.display="none";}
;E.mouseleave(hoverEl,hide);}
;}
;
var AHtmlInserter=new AHtmlInserterBase();function AHtmlInserterBase(){this.processInsert=function(parentEl,data){eval("var miniCacheData= "+data.mcData);var mc=getMasterCache();mc_updateData(mc,miniCacheData);var html=data.html;eval("var jsData= "+data.json);var mFragInfo=jsData.fragInfo;for(var fragId in mFragInfo)
{A.addFragInfo(fragId,mFragInfo[fragId]);}

var styles=data.styles;var scripts=data.scripts;if(styles.length==0&&scripts.length==0){this.insertHtml(parentEl,html,mFragInfo);}

else 
{this.injectResources(styles,scripts,mFragInfo,parentEl,html,mFragInfo);}

}
;
this.injectResources=function(styles,scripts,fragInfo,parentEl,html){var headEl=document.getElementsByTagName('head')[0];for(var i=0;i<styles.length;i++)
{var src=styles[i];var start=src.lastIndexOf("/")+1;var end=src.lastIndexOf(".css")
var name=src.substring(start,end);var cssInclude=gE("#css"+name);if(null!=cssInclude){continue;}

var cssEl=document.createElement("link");cssEl.rel="stylesheet"
cssEl.href=src;cssEl.id="css"+name;cssEl.type="text/css";aE(headEl,cssEl);}

this.triggerScriptLoad(scripts,0,parentEl,html,fragInfo);}
;
this.triggerScriptLoad=function(scripts,index,parentEl,html,fragInfo){if(scripts.length==0){this.insertHtml(parentEl,html,fragInfo);return ;}

var scriptEl=document.createElement("script");scriptEl.src=scripts[index];scriptEl.type="text/javascript";var thisObj=this;var onLoad=function(){if(index==[scripts.length-1]){thisObj.insertHtml(parentEl,html,fragInfo);}

else 
{thisObj.triggerScriptLoad(scripts,index+1,parentEl,html,fragInfo);}

}
;aE(document.body,scriptEl);E.add(scriptEl,"load",onLoad);}
;this.insertHtml=function(parentEl,html,fragInfo){if(null==parentEl){A.launchPoupForHtml(html);}

else 
{parentEl.innerHTML=html;}

ATagInitializer.init(null,fragInfo);}
;}
;
;;
function AHtmlGetter(aHtml){var mc=new MiniCache();this.mc=mc;var gE=createGeneralExecuter("ahtml_getter",mc,"AHtmlGetter");var suffix=A.createTempId();this.suffix=gE.addExecParamObj("suffix","TEXT",suffix);this.aHtml=gE.addExecParamObj("ahtml","LONG_TEXT",aHtml);this.inputs=gE.addExecParamObj("inputs","COLLECTION");}
;AHtmlGetter.prototype=new AHtmlGetterBase();function AHtmlGetterBase(){this.count=0;
this.execute=function(afterExecute){var mc=this.mc;var onProcess=function(){var results=mc.getActionField("ahtml_getter").getResults().data;afterExecute(results);}
;mc.process(onProcess);}
;
this.addRecordInput=function(inputName,recordType,recordId){var inputData=this.createInput(inputName,"record");var recordData=inputData.addChildField("inputData","COLLECTION");recordData.addChildField("type","TEXT",recordType);recordData.addChildField("id","INTEGER",recordId);}
;
this.createInput=function(inputName,inputType){var anInput=this.inputs.addChildField(inputName,"COLLECTION");anInput.addChildField("inputType","TEXT",inputType);return anInput;}


this.addListInput=function(listName,listInput){var input=this.createInput(listName,"list");input.insertChildField("listInput","COLLECTION",listInput);}
;}
;
;
var ClickModuleHandler=new ClickModuleBase();function ClickModuleBase(){this.init=function(data){if(A.isEditMode()){return ;}

var element=gE("#"+data.elId);element.style.cursor="pointer";var thisObj=this;var clickFx=function(){thisObj.clickFx(data);}
;E.click(element,clickFx);}
;this.clickFx=function(data){var params=data.params;this.params=params;var aModuleTag=this.createATag(params);var aHtmlGetter=new AHtmlGetter(aModuleTag);var expectedInput=params.a_expectedInput;if(expectedInput){aHtmlGetter.addRecordInput(expectedInput,data.recordType,data.dbId);}

var destination=params.a_destination;var parentEl=gE("#"+destination);if(null!=parentEl){parentEl.innerHTML="";}

var thisObj=this;var afterFx=function(results){var destination=params.a_destination;var parentEl=gE("#"+destination);AHtmlInserter.processInsert(parentEl,results);}
;aHtmlGetter.execute(afterFx)
}
;this.createATag=function(params){var eI=params.a_expectedInput;return "<a_module name=\""+params.a_clickModule+"\" input=\""+eI+":"+eI+"\">";}
;}
;
var CriteriaHandler=new CriteriaHandlerBase();
function CriteriaHandlerBase(){this.converters={}
;this.listsByName={}
;this.init=function(data){var params=this.getParams(data.params);var fieldHolder=gE("#"+data.elId);if(null==fieldHolder){return ;}

var mc=A.findOwnerCache(fieldHolder);var listName=params.list;var list=mc.getListByName(listName);if(null==list){return ;}

var listInput=this.listsByName[listName];if(null==listInput){listInput=list.copyToListInput();this.listsByName[listName]=listInput;}

var converter=this.getConverter(data.fieldType);converter.init(data,listInput);}
;this.getConverter=function(fieldType){var converter=this.converters[fieldType];if(!converter){return GenericSearchTerm;}

return converter;}
;this.registerConverter=function(fieldType,converter){this.converters[fieldType]=converter;}
;this.getListByName=function(listName){return this.listsByName[listName];}
;
this.getParams=function(params){for(var paramName in params)
{var paramValue=params[paramName];if(!isNaN(paramValue)){paramValue=parseFloat(paramValue);}

else if(paramValue=="true"||paramValue=="false"){paramValue=(paramValue=="true");}

params[paramName]=paramValue;}

return params;}
;}
;
var GenericSearchTerm=new GenericSerchTermBase();function GenericSerchTermBase(){this.init=function(data,listInput){var input=document.getElementById(data.elId);var params=clone(data.params)||{}
;params.onAfterChangeFx=function(value){listInput.removeSearchCriteria(params.field);listInput.addSearchTerm(params.field,value,SEARCHTERM_CONTAINS);}
;enableTextInput(input,params);}
;}
;
var Ms3SearchTerm=new Ms3SerchTermBase();
function Ms3SerchTermBase(){this.init=function(data,listInput){var msHolder=gE("#"+data.elId);var checkBoxes=msHolder.getElementsByTagName("input");for(var i=0;i<checkBoxes.length;i++)
{this.attachOnclick(checkBoxes[i],listInput,checkBoxes,data.params.field);}
;}
;
this.attachOnclick=function(checkBox,listInput,checkBoxes,fieldName){var thisObj=this;var onClick=function(){thisObj.clearMsCriteria(checkBoxes,fieldName,listInput);var checkedCounter=0;for(var i=0;i<checkBoxes.length;i++)
{var checkBox=checkBoxes[i];if(!checkBox.checked){continue;}

if(checkedCounter==0){listInput.addSearchTerm(fieldName,"|"+checkBox.value+"|",SEARCHTERM_CONTAINS,fieldName);checkedCounter++;}

else 
{listInput.addOrSearchTerm(fieldName,"|"+checkBox.value+"|",SEARCHTERM_CONTAINS,fieldName);}

}

}

E.click(checkBox,onClick,{stop:false}
);}
;
this.clearMsCriteria=function(checkBoxes,fieldName,listInput){for(var i=0;i<checkBoxes.length;i++)
{listInput.removeSearchCriteria(fieldName);}

}
;}
;CriteriaHandler.registerConverter("MS3",Ms3SearchTerm);
;var ProcessListHandler=ProcessSearch=new ProcessSearchBase();
function ProcessSearchBase(){this.init=function(actionData,data){var el=gE("#"+data.elId);var thisObj=this;var onClick=function(){var listName=actionData.list;var listInput=CriteriaHandler.getListByName(listName);listInput.setStartRecord(0);thisObj.processList(actionData,listInput);}
;E.click(el,onClick);}
;this.processList=function(data,listInput){var aModuleTag=this.createATag(data);var aHtmlGetter=new AHtmlGetter(aModuleTag);var expectedInput=data.list;aHtmlGetter.addListInput(data.list,listInput);var parentEl=gE("#"+data.destination);if(null!=parentEl){parentEl.innerHTML="";var progressBar=cE("progress",parentEl);progressBar.style.marginLeft="50%";progressBar.style.marginRight="50%";progressBar.style.marginTop="15px";}

var afterCompile=function(results){AHtmlInserter.processInsert(parentEl,results);scrollTo(0,0);}
;aHtmlGetter.execute(afterCompile);}
;this.createATag=function(actionData){var eI=actionData.list;var moduleName=actionData.moduleName;return "<a_module name=\""+moduleName+"\" input=\""+eI+":"+eI+"\">";}
;this.changePage=function(data){var startRecord=data.startRecord;var aHtml=this.createATag(data);var listInput=CriteriaHandler.getListByName(data.list);listInput.setStartRecord(data.startRecord);this.processList(data,listInput);}
;}
;ActionHandler.registerAction("processList",ProcessSearch);ActionHandler.registerAction("processSearch",ProcessSearch);
;var ProcessCache=new ProcessCacheBase();
function ProcessCacheBase(){this.init=function(actionData,data){var el=gE("#"+data.elId);var thisObj=this;var onClick=function(){var params=actionData;var progressOnFx=showProgressIcon;var progressOffFx=hideProgressIcon;if(params.progressIconOn){progressOnFx=evan(params.progressIconOn);}

if(params.progressIconOff){progressOffFx=eval(params.progressIconOff);}

progressOnFx();var mc=A.findOwnerCache(el);var onProcess=function(){thisObj.afterProcess(mc,actionData,progressOffFx);}
;if(!mc.validate()){progressOffFx();return ;}

mc.process(onProcess);}
;E.click(el,onClick);}
;
this.afterProcess=function(mc,data,progressOffFx){var thisObj=this;var finishFx=function(){thisObj.finishProcess(data,progressOffFx,mc);}
;var emailInfo=data.emailInfo
if(null==emailInfo){finishFx();}

else 
{debugger;var record=mc.getRecordByName(emailInfo.recordName);this.sendEmail(record,emailInfo.recipients,emailInfo.subject,finishFx,emailInfo.recordName);}

}
;this.finishProcess=function(data,progressOffFx,mc){var afterModuleName=data.afterModuleName;if(null==afterModuleName||""==afterModuleName){progressOffFx();if(data.onProcess){var onProcessFx=eval(data.onProcess);onProcessFx(mc,data);}
;return ;}

var destination=data.destination;var aModuleTag="<a_module name='"+afterModuleName+"'>";var aHtmlGetter=new AHtmlGetter(aModuleTag);var parentEl=gE("#"+data.destination);if(null!=parentEl){parentEl.innerHTML="";}

var afterCompile=function(results){AHtmlInserter.processInsert(parentEl,results);progressOffFx();if(data.onProcess){var onProcessFx=eval(data.onProcess);onProcessFx();;}
;}
;aHtmlGetter.execute(afterCompile);}
;this.sendEmail=function(record,emails,subject,afterSendFx){if(!record){afterSendFx();return ;}

var div=cE("div");var tbody=createTable(div);tbody.parentNode.border=1;tbody.parentNode.borderColor="black";var fieldNames=record.getFieldNames();for(var i=0;i<fieldNames.length;i++)
{var field=record.getField(fieldNames[i]);var tr=cE("tr",tbody);var td=cE("td",tr);td.style.width="150px";td.style.paddingRight="8px";td.innerHTML=field.getDisplayName();var td=cE("td",tr);field.buildField(td,"read");}

if(null==subject){subject="Form submission";}

var md=new md_MessageDispatcher();md.setHardcodedSubject(subject);md.setHardcodedContent(div.innerHTML);md.onAfterSendFx=afterSendFx;var emailList=emails.split(",");for(var i=0;i<emailList.length;i++)
{var email=emailList[i].trim();if(""==email){continue;}

md.addEmailRecipient(email);}

md.sendMessage();}
;}
;ActionHandler.registerAction("processCache",ProcessCache);

function HtmlFragment(){}

HtmlFragment.prototype=new HtmlFragmentBase();function HtmlFragmentBase(){this.initAttributes=function(){var fragInfo=this.fragInfo;var params=fragInfo.params;var attrs=ATagInitializer.aAttributeInitializers;for(var attrName in attrs)
{if(!params[attrName]){continue;}

var aattrInitializer=attrs[attrName];if(!aattrInitializer){continue;}

aattrInitializer.init(fragInfo);}
;}
;}
;
function StandardTag(fragInfo){this.fragInfo=fragInfo;}

StandardTag.prototype=new StandardTagBase();function StandardTagBase(){this.init=function(){this.initAttributes();}
;}
;StandardTagBase.extend(HtmlFragment);
;;;

;;;
;;;;;;;;;;
;;
;;;
;;
;var ATagInitializer=new ATagInitializerBase();function ATagInitializerBase(){this.elementTypes=["div"];this.initElements=function(afterFx){var thisObj=this;var fx=function(){thisObj.init(afterFx);}
;var mode=this.getSpecialMode();if("visual_edit"==mode&&(B.isChrome()||B.isSafari())){var endMarker=cE("div",document.body);endMarker.id="sa_eof";endMarker.style.display="none";sl_loadScript('/0/le8498_0.js',fx);fx;}

else if("template_based_page"==mode){sl_loadScript('/0/le7473_0.js',fx);fx;}

else 
{fx();}

}
;this.getSpecialMode=function(){return window["g_specialMode"];}

this.init=function(afterFx,fragInfo){if(!fragInfo){fragInfo=g_moduleInfo.fragInfo;}

for(var id in fragInfo)
{var anElData=fragInfo[id];var tagHandlers=this.getTagHandlers();if(!tagHandlers){continue;}

var handler=tagHandlers[anElData.fragType];if(handler&&handler.addDataToLoad){handler.addDataToLoad(anElData);}

}

this.initFromHtml();this.initFromJsData(fragInfo);if(afterFx){afterFx();}


}
;this.initFromJsData=function(fragInfo){for(var id in fragInfo)
{var data=fragInfo[id];var Fragment=this.getFragConstructor(data.fragType);if(null!=Fragment){var fragObj=new Fragment(data);fragObj.init();data.fragObj=fragObj;}

else 
{var tagHandlers=this.getTagHandlers();if(!tagHandlers){continue;}

var handler=tagHandlers[data.fragType];if(handler){handler.init(data);}

this.initAttibutesFromJs(data);}

}

}
;this.getTagHandlers=function(){var mode=this.getSpecialMode();if(!mode||"normal"==mode){return this.tagHandlers;}

return this.specialModeHandlers[g_specialMode];}
;this.specialModeHandlers={}
;this.addSpecialModeHandler=function(mode,tagName,handler){var modeHandlers=this.specialModeHandlers[mode];if(!modeHandlers){modeHandlers={}
;this.specialModeHandlers[mode]=modeHandlers;}

modeHandlers[tagName]=handler;}
;
this.initFromHtml=function(){for(var i=0;i<this.elementTypes.length;i++)
{var elements=document.getElementsByTagName(this.elementTypes[i]);for(var j=0;j<elements.length;j++)
{var aTag=gA(elements[j],"atag");var fx=this.initializers[aTag];if(fx){fx(elements[j]);}

}

}

}
;this.initializers={}
;
this.tagHandlers={field:FieldHandler,component:ComponentHandler,cycle:CycleHandler,nav:NavHandler,criteria:CriteriaHandler}
;this.aAttributeInitializers={a_hoverModule:HoverModuleHandler,a_clickModule:ClickModuleHandler,a_action:ActionHandler}
;this.initAttibutesFromJs=function(data){var params=data.params;if(null==params){return ;}

var attrs=this.aAttributeInitializers;for(var attrName in attrs)
{if(!params[attrName]){continue;}

var aattrInitializer=attrs[attrName];if(!aattrInitializer){continue;}

aattrInitializer.init(data);}
;}
;
this.initFragments=function(){var read={}
;read.standardTag=StandardTag;var edit={}
;this.fragsConstructorByMode={edit:edit,read:read}

}
;this.getFragConstructor=function(fragType){var mode=this.getSpecialMode();mode=(mode===undefined||mode==="normal")?"read":"edit";var fragsByMode=this.fragsConstructorByMode[mode];return fragsByMode[fragType];}
;this.initFragments();}
;

var ImageHoverUtil=new ImageHoverUtilBase();function ImageHoverUtilBase(){this.attachHover=function(imageEl){var hoverImage=imageEl.getAttribute("hoverImage");if(hoverImage){ImagePreloaderUtil.addImageToPreload(hoverImage);var overFx=function(){imageEl.setAttribute("originalSrc",imageEl.src);imageEl.src=hoverImage;}
;eh_addEvent("onmouseover",imageEl,overFx);var outFx=function(){imageEl.src=imageEl.getAttribute("originalSrc");imageEl.removeAttribute("originalSrc");}
;eh_addEvent("onmouseout",imageEl,outFx);}

}
;this.init=function(){var attachFx=this.attachHover;AProcessor.registerInitializer("IMG",attachFx);}
;this.init();}


var FullScreen=new FullScreenBase();function FullScreenBase(){this.setImage=function(imagePath){var holder=cE("div",document.body);holder.style.position="fixed";if(IS_IE){holder.style.position="absolute";}

holder.style.left=0;holder.style.top=0;holder.style.zIndex=-1000;holder.style.overflow="hidden";var image=cE("img");image.src=imagePath;image.style.position="relative";this.resizeImage=image;var thisObj=this;var fx=function(){thisObj.center(image);}
;eh_attachEvent("onload",image,fx);if(IS_IE){var positionFx=function(){thisObj.adjustForScroll(holder);}
;eh_attachEvent("onscroll",document.body,positionFx);}

aE(holder,image);this.center(image);this.adjustForScroll(holder);}
;
this.adjustForScroll=function(holder){holder.style.top=document.body.scrollTop+"px";holder.style.left=document.body.scrollLeft+"px";}
;this.center=function(image){var doc=image.ownerDocument;var totalWidth=window.innerWidth||document.documentElement.offsetWidth;var totalHeight=window.innerHeight||document.documentElement.offsetHeight;var originalW=image.offsetWidth;var originalH=image.offsetHeight;if(totalWidth/totalHeight>originalW/originalH){var ratio=totalWidth/originalW;image.style.width=Math.ceil(originalW*ratio)+"px";image.style.height=Math.ceil(originalH*ratio)+"px";image.style.left=0;image.style.top=(image.offsetHeight-totalHeight)/-2+"px";}

else 
{var ratio=totalHeight/originalH;image.style.width=Math.ceil(originalW*ratio)+"px";image.style.height=Math.ceil(originalH*ratio)+"px";image.style.left=(image.offsetWidth-totalWidth)/-2+"px";image.style.top=0;}

}
;this.attachResize=function(){var thisObj=this;var fx=function(){thisObj.center(thisObj.resizeImage);}
;eh_addEvent("onresize",window,fx);}
;}


;var FullScreenImageBgHandler=new FullScreenImageBgHandlerBase();function FullScreenImageBgHandlerBase(){this.initializeBg=function(){var imagePath=document.body.getAttribute("full_screen_bg_image");if(!imagePath){return ;}

FullScreen.setImage(imagePath);FullScreen.attachResize();}
;this.init=function(){var thisObj=this;var fx=function(){thisObj.initializeBg();}
;BodyOnloader.addFxForBeforeLoad(fx);}
;this.init();}

var ImagePreloaderUtil=new ImagePreloaderUtil();function ImagePreloaderUtil(){this.numToLoadSimultaneously=2;this.addImageToPreload=function(path){this.imagesToPreload.push(path);}
;this.run=function(afterLoadFx){var thisObj=this;var fx=function(){thisObj.afterLoadFx=afterLoadFx;thisObj.setNewBatch();}
;window.setTimeout(fx,4000);}
;this.imagesToPreload=[];this.loadedCounter=0;this.afterLoadFx;this.setNewBatch=function(){this.loadedCounter=0;var paths=[];for(var i=0;i<this.numToLoadSimultaneously;i++)
{var path=this.imagesToPreload[i];if(path){paths.push(path);}

}

this.preloadImages(paths);}
;this.preloadImages=function(paths){for(var i=0;i<paths.length;i++)
{var img=new Image();img.src=paths[i];this.attachEvents(img);}
;}
;this.removeFromLoadingList=function(){this.imagesToPreload.splice(0,this.numToLoadSimultaneously);}
;this.attachEvents=function(img){var thisObj=this;var fx=function(){thisObj.finilizeLoading(img);}
;eh_attachEvent("onload",img,fx);var fx=function(){thisObj.finilizeLoading(img);}
;eh_attachEvent("onerror",img,fx);}
;this.runAfterLoad=function(){if(this.afterLoadFx){this.afterLoadFx();}
;this.afterLoadFx=null;}
;this.finilizeLoading=function(img){img=null;this.loadedCounter++;if(this.imagesToPreload.length==this.loadedCounter&&this.numToLoadSimultaneously>1){this.runAfterLoad();}

else if(this.loadedCounter==this.numToLoadSimultaneously){this.removeFromLoadingList();if(0==this.imagesToPreload.length){this.runAfterLoad();}

else 
{this.setNewBatch();}
;}
;}
;this.init=function(){if(window["BodyOnloader"]){var thisObj=this;var fx=function(){thisObj.run();}
;BodyOnloader.addFxForAfterLoad(fx);}

}
;this.init();}
;

function a_init(){var initializer=new BodyInitializer();initializer.init();}

E.add(window,"load",a_init);function BodyInitializer(){this.init=function(){if(this.isInSA()){var fx=window.parent["g_specialModeInit"];if(fx){fx(window);}

}

else if(window.g_params&&g_params.mode){g_specialMode=g_params.mode;}

if(window.g_onloadCssId){}

DataInitializer.init();var thisObj=this;var afterFx=function(){var finishFx=function(){thisObj.finish();}

BodyOnloader.run(finishFx);}

ATagInitializer.initElements(afterFx);}
;this.finish=function(){if(window["buildScreen"]){buildScreen();}

if(null!=g_pp&&(true==g_pp.myP.lp_edit||true==g_pp.lp_allow_all)){if(!window.g_specialMode||window.g_specialMode=="normal"){var afterFx=function(){var popup=new EnablePageEditPopup();popup.build();}
;sl_loadScript('/0/le8499_0.js',afterFx);afterFx;}

else if("visual_edit"==g_specialMode){this.initVisualEditMode();}

}

var isEnabled=g_sessionInformation.settings.login_panel.is_enabled;var isEditMode=(window["g_specialMode"]!=undefined&&g_specialMode=="visual_edit")
if(isEnabled&&!isEditMode){LoginPanel.build();}

}

this.isInSA=function(){return (window.parent!=window);}
;this.initVisualEditMode=function(){if(window["LivePage"]==undefined){return ;}

var thisObj=this;var fx=function(){if(!thisObj.isInSA()){var lpInit=new LivePageInitializer();lpInit.init();}

LiveCss.init();}

LivePage.loadData(fx);}
;}


;var ResponsiveUtil=new ResponsiveUtilBase();function ResponsiveUtilBase(){this.RESPONSIVE_KEY="responsive_ranges";this.DEFAULT_RANGE="default_range";this.fontSizes=[8,9,10,11,12,14,16,18,20,22,24,26,28,32,36,48,72];this.paddingSet=[5,10,15,20,25,30,40,50,75,100,150,200,250,300];this.screenSizesByName={}
;this.screenSizes=[];this.currentSizePrefix;this.tallStyles={}
;this.styleSheet;this.addTallClass=function(height){var heightValue=height+"px";var className="a-meta-r-h-"+heightValue;if(this.tallStyles[heightValue]){return className;}

var cls=new CssClass("."+className);cls.styleSheet=this.getStyleSheet();cls.add("height",heightValue);cls.init();this.tallStyles[height]=true;return className;}
;this.addSize=function(name,minWidth,maxWidth){var sizeId=this.screenSizes.length;var size={name:name,minWidth:minWidth,maxWidth:maxWidth,isInitialized:false,sizeId:sizeId}
;var media="";if(minWidth){media+="(min-width:"+minWidth+"px)";}

else 
{size.minWidth=0;}

if(minWidth&&maxWidth){media+=" and ";}

if(maxWidth){media+="(max-width:"+maxWidth+"px)";}

else 
{size.maxWidth=Infinity;}

size.media=media;this.screenSizesByName[name]=size;this.screenSizes.push(size);var cls=new CssClass(".r-test",media);cls.add("width",sizeId+1+"px");cls.init();}
;this.getCurrentSizePrefix=function(){return "r-"+this.getCurrentSize()+"-";}
;this.getCurrentSize=function(){if(!this.sizeTestEl){var div=cE("div",document.body);div.style.display="none";div.className="r-test";this.sizeTestEl=div;}

var value=CssUtil.getStyle(this.sizeTestEl,"width");var sizeId=CssUtil.pixelToInt(value)-1;var sizeName=null;if(this.screenSizes[sizeId]){sizeName=this.screenSizes[sizeId].name;}

return sizeName||null;}
;this.isLessThan=function(rangeName,otherRangeName){var sizes=this.screenSizesByName;return (sizes[rangeName].minWidth<sizes[otherRangeName].minWidth);}

this.isOverlap=function(range1StartName,range1EndName,range2StartName,range2EndName){var sizes=this.screenSizesByName;var start1=sizes[range1StartName].minWidth;var end1=sizes[range1EndName].maxWidth;var start2=sizes[range2StartName].minWidth;var end2=sizes[range2EndName].maxWidth;return ((start2>=start1&&start2<end1)||(end2>start1&&end2<=end1)||(start2<=start1&&end2>=end1));}
;this.isContained=function(containedStartName,containedEndName,containerStartName,containerEndName){var sizes=this.screenSizesByName;var containedStart=sizes[containedStartName].minWidth;var containedEnd=sizes[containedEndName].maxWidth;var containerStart=sizes[containerStartName].minWidth;var containerEnd=sizes[containerEndName].maxWidth;return ((containerStart<=containedStart)&&(containedEnd<=containerEnd));}
;this.getRangeNameInfo=function(rangeName){if(!rangeName){return null;}

var rE=/^(xxs|xs|s|m|l|xl)$/;var result=rE.exec(rangeName);if(result){var info={}
;info.startSize=result[1];info.endSize=result[1];return info;}

var rE=/^(xxs|xs|s|m|l|xl)-(xxs|xs|s|m|l|xl)?$/;var result=rE.exec(rangeName);if(result){var info={}
;info.startSize=result[1];info.endSize=result[2];return info;}

return null;}
;this.isValidRangeName=function(rangeName){return this.getRangeNameInfo(rangeName)?true:false;
}
;this.getRangeSizes=function(rangeName){
var rE=/^(xxs|xs|s|m|l|xl)$/;var result=rE.exec(rangeName);if(result){return [rangeName];}

var rE=/^(xxs|xs|s|m|l|xl)-(xxs|xs|s|m|l|xl)?$/;var result=rE.exec(rangeName);if(!result){return null;}

var res1=result[1];var res2=result[2];var begin=res1;var end=res2;var sizes=[];var isStarted=false;for(var i=0;i<this.screenSizes.length;i++)
{var name=this.screenSizes[i].name;if(name==begin){isStarted=true;}

if(isStarted){sizes.push(name);}

if(name==end){break;}

}

return sizes;}
;this.update=function(){var prevSize=this.currentSize;var currentSize=this.getCurrentSize();this.currentSize=currentSize;if(prevSize&&prevSize!=this.currentSize){this.clearSize(prevSize);}

this.enforceTall(currentSize);}
;this.clearSize=function(size){this.clearTall(size);}
;this.getStyleSheet=function(){if(!this.styleSheet){this.styleSheet=StyleSheetUtil.getStyleSheet();}

return this.styleSheet;}
;this.attachResize=function(){var thisObj=this;var resizeFx=function(){thisObj.update();}
;E.resize(resizeFx);}
;this.init=function(){var mc=new MiniCache();var rangeList=mc.addListToLoad("feature_settings","ranges",0,-1);rangeList.addSearchTerm("feature_key",this.RESPONSIVE_KEY,SEARCHTERM_EXACT_MATCH);var thisObj=this;var onProcess=function(){thisObj.defineRanges(mc);thisObj.update();thisObj.attachResize();}

mc.process(onProcess);}
;this.defineRanges=function(mc){var rangeIds=mc.getListByName("ranges").ids;if(rangeIds.length==0){this.addSize("xxs",0,480);this.addSize("xs",481,800);this.addSize("s",801,1024);this.addSize("m",1025,1366);this.addSize("l",1367,1600);this.addSize("xl",1601);return ;}

for(var i=0;i<rangeIds.length;i++)
{var rangeRec=mc.getRecord("feature_settings",rangeIds[i]);this.defineSizes(rangeRec);}

}
;this.defineSizes=function(rangeRec){var rangeKey=rangeRec.getField("name.recordName").getValue();var ranges=rangeRec.getField("config").getChildFields();for(var i=0;i<ranges.length;i++)
{var range=ranges[i];var rangeName=range.getChildField("range_name").getValue();var fullRangeName=(rangeKey==this.DEFAULT_RANGE)?rangeName:rangeKey+"-"+rangeName;var min=CssUtil.pixelToInt(range.getChildField("min").getValue());var max=CssUtil.pixelToInt(range.getChildField("max").getValue());this.addSize(fullRangeName,min,max);}

}
;this.getFontPrefix=function(){return "r-"+this.getCurrentSize()+"-f-s-";}
;this.getFontClass=function(pixel){return this.getFontPrefix()+pixel;}
;this.setup=function(){var thisObj=this;var fx=function(){thisObj.init();}
;BodyOnloader.addFxForBeforeLoad(fx);}
;
this.clearTall=function(size){var className="r-"+size+"-tall";var els=CssUtil.getElementsByClassName(className);for(var i=0;i<els.length;i++)
{CssUtil.removeClassesStartingWith(els[i],"a-meta-r-h-");}

}
;this.enforceTall=function(size){var className=this.getCurrentSizePrefix()+"tall";var els=CssUtil.getElementsByClassName(className);for(var i=0;i<els.length;i++)
{CssUtil.removeClassesStartingWith(els[i],"a-meta-r-h-");}

for(var i=0;i<els.length;i++)
{var el=els[i];var height=el.parentElement.offsetHeight;var newClassName=this.addTallClass(height);CssUtil.addClassToEl(el,newClassName);}

}
;this.setup();}
;
var SaCss=new SiteArchitectCss();function SiteArchitectCss(){this.init=function(){this.initExistingStyles();this.initNewStyles();this.initButtonStyles();}

this.initNewStyles=function(){var cls=new CssClass("*, *:before, *:after");cls.add("-webkit-box-sizing","border-box");cls.add("-moz-box-sizing","border-box");cls.add("box-sizing","border-box");cls.init();var cls=new CssClass("html, body");cls.add("padding","0px");cls.add("margin","0px");cls.add("width","100%");cls.add("height","100%");cls.add("overflow","hidden");cls.add("-webkit-box-sizing","border-box");cls.add("-moz-box-sizing","border-box");cls.add("box-sizing","border-box");cls.add("background-color","#2c3e50");cls.init();var cls=new CssClass("body");cls.add("margin","0px");cls.add("padding","0px");cls.add("overflow","hidden");cls.add("font-family","Open Sans, arial");cls.init();var cls=new CssClass("button");cls.add("font-family","Open Sans");cls.add("font-size","14px");cls.add("font-weight","600");cls.init();var cls=new CssClass("span");cls.add("display","inline");cls.init();var cls=new CssClass("#screenContainer");cls.add("height","100%");cls.add("width","100%");cls.init();var cls=new CssClass(".sa_bgColor");cls.add("background-color","#2c3e50");cls.init();var cls=new CssClass(".sa_whiteText");cls.add("color","#ffffff");cls.init();var cls=new CssClass(".sa_regularTextSize");cls.add("font-size","14px");cls.init();var cls=new CssClass(".sa_stretchBar");cls.add("background-color","#2c3e50");cls.add("width","5px");cls.init();var cls=new CssClass(".flexColGrip");cls.add("background-color","#a7b6c5");cls.add("margin-bottom","2px");cls.add("width","2px");cls.add("height","2px");cls.init();var cls=new CssClass(".sa_toolbarHeader");cls.add("background-color","#f5f5f5");cls.add("height","25px");cls.add("border-bottom","1px solid #ffffff");cls.init();var cls=new CssClass(".sa_toolbar");cls.add("font-size","12px");cls.add("color","#333333");cls.add("font-weight","bold");cls.init();var cls=new CssClass(".sa_organizeLink");cls.add("color","#3498db");cls.add("font-size","11px");cls.add("margin-right","10px");cls.add("font-weight","600");cls.add("position","relative");cls.add("top","-2px");cls.init();var cls=new CssClass(".sa_siteLinksButtonHolder");cls.add("padding","0px 8px");cls.init();var cls=new CssClass(".sa_siteLinksCenterButtonHolder");cls.add("border-right","1px solid #5f81a0");cls.add("border-left","1px solid #5f81a0");cls.add("padding","0px 10px");cls.init();var cls=new CssClass(".sa_siteLinksJsButtonHolder");cls.add("border-right","1px solid #5f81a0");cls.add("padding","0px 10px");cls.init();var cls=new CssClass(".sa_transparentIcon");cls.add("opacity","0.65");cls.add("filter","alpha(opacity=65)");cls.init();var cls=new CssClass(".sa_transparentIcon:hover");cls.add("opacity","1");cls.add("filter","alpha(opacity=100)");cls.init();var cls=new CssClass(".sa_iconHolder");cls.add("padding","0px 8px 0px 8px");cls.init();var cls=new CssClass(".sa_centerIconHolder");cls.add("border-right","1px solid #5f81a0");cls.add("border-left","1px solid #5f81a0");cls.add("padding","0px 12px 0px 12px");cls.init();var cls=new CssClass(".sa_btnHolder");cls.add("display","inline");cls.init();var cls=new CssClass(".sa_pageTitle");cls.add("font-size","24px");cls.add("margin-bottom","10px");cls.add("color","#ffffff");cls.init();var cls=new CssClass(".sa_blankPageName");cls.add("font-style","italic");cls.add("color","#c0c8d0");cls.init();var cls=new CssClass(".sa_pageUrl");cls.add("font-size","14px");cls.add("color","#c0c8d0");cls.init();var cls=new CssClass(".sa_urlInput");cls.add("font-size","14px");cls.add("color","#ffffff");cls.add("font-weight","600");cls.add("background-color","#1abc9c");cls.add("padding","2px 5px 2px 5px");cls.add("margin-left","2px");cls.add("border","0px");cls.init();var cls=new CssClass(".sa_urlEdit");cls.add("font-size","14px");cls.add("color","#000000");cls.add("background-color","#ffffff");cls.add("padding","2px 5px 2px 5px");cls.add("margin-left","2px");cls.add("border","0px");cls.init();var cls=new CssClass(".sa_nameEdit");cls.add("color","#000000");cls.add("background-color","#ffffff");cls.add("padding","2px 5px 2px 5px");cls.add("margin-left","2px");cls.add("border","0px");cls.init();var cls=new CssClass(".sa_rightLabel");cls.add("font-size","14px");cls.add("color","#c0c8d0");cls.add("background-color","#385774");cls.add("font-weight","600");cls.add("text-align","left");cls.add("padding","5px 0px 5px 12px")
cls.init();var cls=new CssClass(".sa_radioLabel");cls.add("font-size","14px");cls.add("color","#cccccc");cls.init();var cls=new CssClass(".sa_radioLabelOn");cls.add("color","#1abc9c");cls.init();var cls=new CssClass(".sa_radioCont");cls.add("padding","18px 0px 18px 0px");cls.init();var cls=new CssClass(".sa_buttonCell");cls.add("padding-left","12px");cls.init();var cls=new CssClass(".sa_pageTitleInput");cls.add("width","213px");cls.add("height","25px");cls.add("font-size","16px");cls.add("padding-left","5px");cls.add("-webkit-border-radius","6px");cls.add("-moz-border-radius","6px");cls.add("border-radius","6px");cls.init();var cls=new CssClass(".sa_regularInput");cls.add("width","250px");cls.add("height","25px");cls.add("padding-left","5px");cls.add("-webkit-border-radius","6px");cls.add("-moz-border-radius","6px");cls.add("border-radius","6px");cls.init();var cls=new CssClass(".sa_mR10");cls.add("margin-right","10px");cls.init();var cls=new CssClass(".sa_popupHeader");cls.add("background-color","#34495e");cls.add("height","30px");cls.add("line-height","30px");cls.add("width","100%");cls.add("color","#ffffff");cls.add("text-align","left");cls.init();var cls=new CssClass(".sa_popupTitle");cls.add("font-weight","bold");cls.init();var cls=new CssClass(".sa_pageName");cls.add("color","#ffffff");cls.init();var cls=new CssClass(".sa_plusMinus");cls.add("position","relative");cls.add("top","2px");cls.add("cursor","pointer");cls.init();var cls=new CssClass(".sa_treeNode");cls.add("-webkit-border-radius","6px");cls.add("-moz-border-radius","6px");cls.add("border-radius","6px");cls.add("background-color","#e5eaeb");cls.add("cursor","move");cls.init();var cls=new CssClass(".sa_relative");cls.add("position","relative");cls.init();var cls=new CssClass(".sa_italic");cls.add("font-style","italic");cls.init();var cls=new CssClass(".sa_labelText");cls.add("font-size","14px");cls.add("color","#c0c8d0");cls.init();var cls=new CssClass(".sa_addField");cls.add("font-size","14px");cls.add("font-weight","bold");cls.add("color","#3498db");cls.add("margin","0px 5px 8px");cls.add("font-style","italic");cls.add("cursor","pointer");cls.init();var cls=new CssClass(".sa_addField:hover");cls.add("text-decoration","underline");cls.init();var cls=new CssClass(".sa_openInExplorer");cls.add("font-size","14px");cls.add("font-weight","bold");cls.add("color","#3498db");cls.add("margin-left","384px");cls.add("cursor","pointer");cls.init();var cls=new CssClass(".sa_openInExplorer:hover");cls.add("text-decoration","underline");cls.init();var cls=new CssClass(".sa_tableDefaultVals");cls.add("background","-webkit-gradient(linear, left top, right top, from(#f1f1f1), to(#ffffff))");cls.add("background","-moz-linear-gradient(left, #f1f1f1, #ffffff)");cls.add("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr='#f1f1f1', endColorstr='#ffffff)");cls.init();var cls=new CssClass(".sa_activateBtn");cls.add("-webkit-transition","0.25s");cls.add("-moz-transition","0.25s");cls.add("-o-transition","0.25s");cls.add("transition","0.25s");cls.add("opacity","0.80");cls.add("filter","alpha(opacity=80)");cls.add("float","left");cls.add("margin-left","10px");cls.add("margin-top","2px");cls.add("cursor","pointer");cls.init();var cls=new CssClass(".sa_activateBtn:hover");cls.add("opacity","1");cls.add("filter","alpha(opacity=100)");cls.init();var cls=new CssClass(".sa_pushPopupText");cls.add("font-family","Open Sans");cls.add("font-size","18px");cls.init();var cls=new CssClass(".sa_pushPopupBoldText");cls.add("font-weight","bold");cls.init();var cls=new CssClass(".ok-btn");cls.add("width","154px");cls.add("height","36px");cls.add("margin-top","40px");cls.init();var cls=new CssClass(".sa_testClass");cls.add("background-color","white");cls.init();var cls=new CssClass(".sa_hoverPopup");cls.add("background-color","#333333");cls.add("color","#ffffff");cls.add("padding","3px 0px 5px 10px");cls.add("border","1px solid #ffffff");cls.add("font-size","12px");cls.add("font-family","Open Sans");cls.add("position","relative");cls.init();var cls=new CssClass(".sa_previewAdjust");cls.add("top","35px");cls.add("left","47px");cls.init();var cls=new CssClass(".sa_duplicateAdjust");cls.add("top","35px");cls.add("left","50px");cls.init();var cls=new CssClass(".sa_deleteAdjust");cls.add("top","35px");cls.add("left","40px");cls.init();var cls=new CssClass(".sa_imgLibAdjust");cls.add("top","50px");cls.add("left","10px");cls.init();var cls=new CssClass(".sa_globalCssAdjust");cls.add("top","50px");cls.add("left","25px");cls.init();var cls=new CssClass(".sa_propsAdjust");cls.add("top","50px");cls.add("left","25px");cls.init();var cls=new CssClass(".sa_tipAdjust1");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-52px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa-push-tip");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-100px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa-img-upload-tip");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-120px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa_tipAdjust2");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-68px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa_tipAdjust3");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-35px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa_tipAdjust4");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-40px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa_tipAdjust5");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-55px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa_createNewCont");cls.add("text-align","center");cls.add("padding","6px 0px 10px 0px");cls.init();var cls=new CssClass(".sa_createNewButton");cls.add("padding-left","10px !important");cls.add("padding-right","10px !important");cls.add("width","120px");cls.init();var cls=new CssClass(".sa_publishBtn");cls.add("width","92px");cls.init();
var cls=new CssClass(".sa_globalSaveBtn");cls.add("width","92px");cls.init();var cls=new CssClass(".sa_glbSptBtn1");cls.add("width","100px");cls.init();var cls=new CssClass(".sa_glbSptBtn2");cls.add("width","220px");cls.add("margin-left","10px");cls.init();var cls=new CssClass(".sa_glbSptBtn3");cls.add("width","240px");cls.add("margin-left","10px");cls.init();var cls=new CssClass(".sa_topConsoleRightArea");cls.add("width","350px");cls.add("padding-right","20px");cls.init();var cls=new CssClass(".sa_folderHolder");cls.add("background-color","#ffffff");cls.init();var cls=new CssClass(".sa_scriptViewBtns");cls.add("width","92px");cls.add("margin-left","10px");cls.init();var cls=new CssClass(".sa_expBtn");cls.add("width","166px");cls.init();var cls=new CssClass(".sa_listBtn");cls.add("width","90px");cls.init();var cls=new CssClass(".sa_recBtn");cls.add("width","112px");cls.init();var cls=new CssClass(".sa_newRecsBtn");cls.add("width","215px");cls.init();var cls=new CssClass(".sa_addValBtn");cls.add("width","103px");cls.init();
var cls=new CssClass(".sa_tabOn");cls.add("background-color","#ffffff");cls.add("font-weight","bold");cls.add("color","#666666");cls.add("font-size","14px");cls.add("padding","5px 12px");cls.init();var cls=new CssClass(".sa_tabOff");cls.add("color","#c2c4c6");cls.add("background-color","#385774");cls.add("padding","5px 12px");cls.add("font-size","14px");cls.init();var cls=new CssClass(".sa_tabOff:hover");cls.add("color","#ffffff");cls.add("text-decoration","none");cls.init();var cls=new CssClass(".sa_tabSpacing");cls.add("width","2px");cls.init();}

this.initExistingStyles=function(){var cssStyle=new css_StyleSheet();var cssClass=new css_CssClass("*");cssClass.addStyle("-webkit-box-sizing","border-box");cssClass.addStyle("-moz-box-sizing","border-box");cssClass.addStyle("box-sizing","border-box");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("leftSideTabOff");cssClass.addStyle("font-size","14px");cssClass.addStyle("font-weight","600");cssClass.addStyle("color","#666666");cssClass.addStyle("background-color","#e9e9e9");cssClass.addStyle("padding","5px 9px");cssClass.addStyle("margin-right","4px");cssClass.addStyle("width","50%");cssClass.addStyle("text-align","center");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("leftSideTabOn");cssClass.addStyle("font-weight","600");cssClass.addStyle("font-size","14px");cssClass.addStyle("background-color","#ffffff");cssClass.addStyle("color","#666666");cssClass.addStyle("padding","5px 9px");cssClass.addStyle("margin-right","4px");cssClass.addStyle("width","50%");cssClass.addStyle("text-align","center");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("iconFont");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("treeNodeFont");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("linkColor");cssClass.addStyle("color","#1A1A68");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("link:hover");cssClass.addStyle("text-decoration","underline");cssClass.addStyle("cursor","pointer");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("link td");cssClass.addStyle("cursor","pointer");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("smallText");cssClass.addStyle("font-size","12px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("smallBoldText");cssClass.addStyle("font-weight","bold");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("text");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("boldText");cssClass.addStyle("font-weight","bold");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("mediumText");cssClass.addStyle("font-size","16px");cssClass.addStyle("font-family","Open Sans, arial");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("mediumBoldText");cssClass.addStyle("font-weight","bold");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("largeText");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("hugeText");cssClass.addStyle("font-size","36px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("buttonFontOff");cssClass.addStyle("font-weight","bold");cssClass.addStyle("color","#36373A");cssClass.addStyle("padding-left","12px");cssClass.addStyle("padding-right","12px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("popupBg");cssClass.addStyle("background-color","#EDEDED");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("buttonFontOn");cssClass.addStyle("font-weight","bold");cssClass.addStyle("color","#266AE6");cssClass.addStyle("padding-left","12px");cssClass.addStyle("padding-right","12px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("body");cssClass.addStyle("overflow-y","auto");cssClass.addStyle("padding","0px");cssClass.addStyle("margin","0px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("smallHeader");cssClass.addStyle("border-top","1px solid #98A7BD");cssClass.addStyle("border-bottom","1px solid #98A7BD");cssClass.addStyle("background-image","url(/upload/custom_screens/rte/tag_editor_bar_bg.gif)");cssClass.addStyle("background-repeat","repeat-x");cssClass.addStyle("padding-left","10px");cssClass.addStyle("color","#2B3A51");cssClass.addStyle("font-weight","bold");cssClass.addStyle("background-color","#A8B6CA");cssClass.addStyle("margin-top","5px");cssClass.addStyle("margin-bottom","5px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("right_panel_header");cssClass.addStyle("background-image","url(/upload/custom_screens/moduleeditor/section_header.gif)");cssClass.addStyle("height","19px");cssClass.addStyle("font-weight","bold");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("borderColor");cssClass.addStyle("border","1px solid #CCCCCC");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("folderOn");cssClass.addStyle("font-weight","bold");cssClass.addStyle("padding","5px 35px");cssClass.addStyle("background-color","#EEEAF9");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("folderOff");cssClass.addStyle("font-weight","bold");cssClass.addStyle("padding","5px 35px");cssClass.addStyle("background-color","");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("altBg");cssClass.addStyle("background-color","");cssStyle.addClass(cssClass);cssStyle.init();}
;this.initButtonStyles=function(){var cls=new CssClass(".btn");cls.add("border","none");cls.add("cursor","pointer");cls.add("background","#bdc3c7");cls.add("color","#ffffff");cls.add("padding","4px 12px 4px");cls.add("line-height","22px");cls.add("text-decoration","none");cls.add("text-shadow","none");cls.add("-webkit-border-radius","6px");cls.add("-moz-border-radius","6px");cls.add("border-radius","6px");cls.add("-webkit-box-shadow","none");cls.add("-moz-box-shadow","none");cls.add("box-shadow","none");cls.add("-webkit-transition","0.25s");cls.add("-moz-transition","0.25s");cls.add("-o-transition","0.25s");cls.add("transition","0.25s");cls.add("-webkit-backface-visibility","hidden");cls.init();var cls=new CssClass(".btn:hover, .btn:focus .btn-group:focus .btn.dropdown-toggle");cls.add("background-color","#cacfd2");cls.add("color","#ffffff");cls.add("outline","none");cls.add("-webkit-transition","0.25s");cls.add("-moz-transition","0.25s");cls.add("-o-transition","0.25s");cls.add("transition","0.25s");cls.add("-webkit-backface-visibility","hidden");cls.init();var cls=new CssClass(".btn:active, .btn-group.open .btn.dropdown-toggle, .btn.active");cls.add("background-color","#a1a6a9");cls.add("color","rgba(255, 255, 255, 0.75)");cls.add("-webkit-box-shadow","none");cls.add("-moz-box-shadow","none");cls.add("box-shadow","none");cls.init();var cls=new CssClass(".btn.blue-btn");cls.add("background-color","#3498db");cls.add("padding","4px 28px 4px");cls.init();var cls=new CssClass(".btn.blue-btn:hover, .btn.blue-btn:focus");cls.add("background-color","#5dade2");cls.init();var cls=new CssClass(".btn.blue-btn-info:active, .btn.blue-btn:active");cls.add("background-color","#2c81ba");cls.init();var cls=new CssClass(".btn.aqua-btn");cls.add("background-color","#1abc9c");cls.add("padding","4px 0px 4px");cls.init();var cls=new CssClass(".btn.aqua-btn:hover, .btn.aqua-btn:focus");cls.add("background-color","#48c9b0");cls.init();var cls=new CssClass(".btn.aqua-btn-info:active, .btn.aqua-btn:active");cls.add("background-color","#16a085");cls.init();var cls=new CssClass(".btn.aqua-btn:disabled");cls.add("background-color","#bdc3c7");cls.add("cursor","default");cls.init();var cls=new CssClass(".btn.gray-btn");cls.add("background-color","#7f8c9a");cls.add("padding","4px 0px 4px");cls.add("width","92px");cls.init();var cls=new CssClass(".btn.gray-btn:hover, .btn.gray-btn:focus");cls.add("background-color","#bdc3c7");cls.init();var cls=new CssClass(".btn.gray-btn-info:active, .btn.gray-btn:active");cls.add("background-color","#16a085");cls.init();}
;}
;

function StandardMenuItem(itemName,onClickFx){this.itemName=itemName;this.onClickFx=onClickFx;this.children=[];this.menu;this.subMenu;
this.buildLabel=function(td){td.style.paddingRight=25;td.style.fontSize=this.menu.fontSize;td.innerHTML=this.itemName;}
;this.addSubMenu=function(subMenu){this.subMenu=subMenu;subMenu.parent=this;}
;}

;;function DropdownMenu(){this.title;this.menuItems=[];this.menuItemHolder;this.popup;this.parent;this.subMenu;this.subMenuHolder;this.highlightedMenuItem;this.popupContainer;this.useShadow=true;this.showDragger=true;this.minWidth;}

DropdownMenu.prototype=new DropdownMenuBase();function DropdownMenuBase(){this.iconCellWidth=20;this.border="1px solid #C4C4C4";this.padding="1px";this.fontFamily="arial";this.width;this.fontSize="13px";this.fontWeight;this.fontColor="black";this.backgroundColor="#FBFBFB";this.mouseOverBgColor="#5071F2";this.dividerColor="#E3E3E3";this.skipBgShadow=false;this.addMenuItem=function(menuItem){this.menuItems.push(menuItem);menuItem.menu=this;}
;this.addDivider=function(){this.menuItems.push("divider");}
;this.attachRightClick=function(element){var menu=this;var fx=function(event){menu.buildAtEvent(event);}
;eh_attachEvent("oncontextmenu",element,fx,null,true,null,true,false,false);}
;this.build=function(leftOffset,topOffset){var popup=new Popup();popup.setAtCoord(leftOffset,topOffset)
popup.shadow=(!this.skipBgShadow)?"3side":"";popup.ensureOnTop=true;popup.disableBg=true;popup.width=this.width;popup.closeEvents=["oncontextmenu"];popup.doc=this.doc||document;var contentArea=popup.build();this.contentArea=contentArea;contentArea.style.border=this.border;if(this.showDragger){this.createDragger(contentArea,popup);}

var menu=this;popup.onCloseFx=function(){menu.close();}

this.popup=popup;this.buildElements(contentArea);popup.align();}
;this.createDragger=function(parentEl,popup){var dragger=cE("div",parentEl);dragger.align="center";dragger.style.height="8px";dragger.style.paddingTop="3px";dragger.style.fontSize=0;dragger.style.cursor="move";dragger.style.backgroundColor=this.backgroundColor;popup.makeDraggable(dragger);var dotSrc="/upload/custom_screens/architect/components/dropdownmenu/grip_dot.gif";for(var i=0;i<4;i++)
{var dot=cE("img",dragger);dot.src=dotSrc;dot.style.margin="2px";}

}
;this.buildAtEvent=function(event,leftOffset,topOffset){var coordinate=getEventCoord(event);if(leftOffset){coordinate.x+=leftOffset;}

if(topOffset){coordinate.y+=topOffset;}

this.build(coordinate.x,coordinate.y);}
;this.close=function(){if(this.subMenu){this.subMenu.close();}

if(this.popup){this.popup.close();}

this.menuItemHolder=null;}
;this.buildContainer=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.vAlign="top";td.style.height="100%";var iBody=createTable(td);iBody.parentNode.style.height="100%";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);var image=cE("img",iTd);image.src="/upload/js_globals/background_images/ulc.png";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);iTd.style.height="100%";iTd.style.fontSize=0;iTd.style.backgroundImage="url(/upload/js_globals/background_images/l.png)";iTd.innerHTML="&nbsp;";var contentArea=cE("td",tr);contentArea.style.border=this.border;contentArea.style.padding=this.padding+"px";contentArea.style.fontFamily=this.fontFamily;contentArea.style.fontSize=this.fontSize+"px";contentArea.style.width=this.width||"";contentArea.style.backgroundColor=this.backgroundColor;var td=cE("td",tr);td.vAlign="top";td.style.height="100%";var iBody=createTable(td);iBody.parentNode.style.height="100%";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);var image=cE("img",iTd);image.src="/upload/js_globals/background_images/urc.png";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);iTd.style.height="100%";iTd.style.fontSize=0;iTd.style.backgroundImage="url(/upload/js_globals/background_images/r.png)";iTd.innerHTML="&nbsp;";var tr=cE("tr",tBody);var td=cE("td",tr);var image=cE("img",td);image.src="/upload/js_globals/background_images/llc.png";var td=cE("td",tr);td.style.backgroundImage="url(/upload/js_globals/background_images/b.png)";var td=cE("td",tr);var image=cE("img",td);image.src="/upload/js_globals/background_images/lrc.png";return contentArea;}
;this.buildElements=function(parentEl){var container=cE("div",parentEl);container.style.padding=this.padding;container.style.fontFamily=this.fontFamily;container.style.fontSize=this.fontSize;container.style.width=this.width||"";container.style.backgroundColor=this.backgroundColor;var table=cE("table",container);table.cellSpacing=0;table.cellPadding=0;table.style.width="100%      ";var colGroup=cE("colgroup",table);var col1=cE("col",colGroup);col1.vAlign="middle";col1.style.width=this.iconCellWidth+"px";var col2=cE("col",colGroup);col2.vAlign="middle";var col3=cE("col",colGroup);col3.vAlign="middle";col3.style.width=this.iconCellWidth+"px";var tBody=cE("tbody",table);tBody.style.cursor="default";var noOfItems=this.menuItems.length;for(var i=0;i<noOfItems;i++)
{var menuItem=this.menuItems[i];if(menuItem=="divider"){this.drawDivider(tBody);}

else 
{this.drawMenuRow(tBody,menuItem);}

}

}
;this.drawDivider=function(tBody){var tr=cE("tr",tBody);var td=cE("td",tr);td.colSpan=3;var div=cE("div",td);div.style.height="2px";div.style.marginTop="1px";div.style.marginBottom="3px";div.style.borderTop="1px solid "+this.dividerColor;}
;this.drawMenuRow=function(tBody,menuItem){var tr=cE("tr",tBody);tr.style.color=this.fontColor;tr.style.fontWeight=this.fontWeight||"bold";if(menuItem.onClickFx){var onClickFx=function(){menuItem.menu.getRootMenu().popup.close();menuItem.onClickFx();}
;eh_attachEvent("onclick",tr,onClickFx);}

var td=cE("td",tr);if(menuItem.buildIconCell){menuItem.buildIconCell(td);}

else 
{td.innerHTML="&nbsp;";}

var td=cE("td",tr);td.style.padding="3px 0";menuItem.buildLabel(td);var td=cE("td",tr);var image;if(menuItem.subMenu){image=cE("img",td);image.src="/upload/custom_screens/components/dropdownmenu/submenu_arrow.gif";}

this.attachMouseEvents(tr,menuItem,image);}
;this.getRootMenu=function(){var menu=this;while(menu.parent)
{menu=menu.parent.menu;}

return menu;}
;this.buildSubMenu=function(menuItem,tr){var lastTd=tr.childNodes[2];var coord=findElCoord(lastTd,true);coord.x+=lastTd.offsetWidth;var div=cE("div",this.getRootMenu().popupContainer);div.style.position="absolute";div.style.left=coord.x+"px";div.style.top=coord.y+"px";this.subMenuHolder=div;this.subMenu=menuItem.subMenu;menuItem.subMenu.buildElements(div);}
;this.removeSubMenu=function(){if(this.subMenu){this.subMenu.removeSubMenu();this.subMenuHolder.parentNode.removeChild(this.subMenuHolder);this.subMenu=null;}

}
;this.handleSubMenu=function(menuItem,tr){var menu=this;var fx=function(){if(menuItem!=menu.highlightedMenuItem){return ;}

menu.removeSubMenu();if(menuItem.subMenu){menu.buildSubMenu(menuItem,tr);}

}
;setTimeout(fx,300);}
;this.attachMouseEvents=function(tr,menuItem,image){var onselectstartFx=function(){return false}
;eh_attachEvent("onselectstart",tr,onselectstartFx);var menu=this;var onmouseoverFx=function(){tr.style.backgroundColor=menu.mouseOverBgColor;tr.style.color="white";menu.handleSubMenu(menuItem,tr);menu.highlightedMenuItem=menuItem;if(image){image.src="/upload/custom_screens/components/dropdownmenu/white_arrow_left.gif";}

}
;eh_attachEvent("onmouseover",tr,onmouseoverFx);var onmouseoutFx=function(){tr.style.backgroundColor="";tr.style.color=menu.fontColor;if(image){image.src="/upload/custom_screens/components/dropdownmenu/submenu_arrow.gif";}

if(menu.highlightedMenuItem==menuItem){menu.highlightedMenuItem=null;}

}
;eh_attachEvent("onmouseout",tr,onmouseoutFx);}
;}

;function PageTreeNode(pageRecord,pageTree){this.pageId=pageRecord.getId();this.pageName=pageRecord.getField("name").getValue();this.pageType=pageRecord.getField("item_type").getValue();if(this.pageType==""){this.pageType="page";}

this.tree=pageTree;this.childNodes=[];this.childrenById={}
;this.container;this.plusOrMinusIconHolder;this.plusOrMinusImage;this.isExpanded=false;}

PageTreeNode.prototype=new PageTreeNodeBase();function PageTreeNodeBase(){this.build=function(parentEl){if(UserSettingsMgr.getProperty(this.tree.userSettingsKey,this.getNodeId().replaceAll(".","_"))){this.isExpanded=true;}

var container=cE("div",parentEl);container.style.height=this.tree.lineHeight+"px";this.container=container;var anchor=cE("div",container);anchor.style.paddingLeft=this.offsetLeft+"px";var tBody=createTable(anchor);var table=tBody.parentNode;table.style.height=this.tree.lineHeight+"px";table.className="text";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.width=this.tree.indentPixels+"px";td.style.minWidth=this.tree.indentPixels+"px";td.align="center";td.vAlign="middle";this.plusOrMinusIconHolder=td;var thisObj=this;if(this.childNodes.length>0){var onClickFx=function(){thisObj.toggleNode();}
;ButtonUtil.turnIntoButton(this.plusOrMinusIconHolder,onClickFx);var img=cE("img",this.plusOrMinusIconHolder);img.src=this.isExpanded?this.tree.expandedIcon:this.tree.collapsedIcon;img.style.margin="0px 3px 0px 3px";this.plusOrMinusImage=img;}

else 
{var img=cE("img",this.plusOrMinusIconHolder);img.style.width=this.tree.indentPixels+"px";img.style.visibility="hidden";}

var td=cE("td",tr);td.align="center";td.vAlign="middle";td.style.width=this.tree.indentPixels+"px";var iconImage=cE("img",td);iconImage.style.cursor="pointer";iconImage.src=this.tree.getIcon(this.pageType);var td=cE("td",tr);td.vAlign="middle";td.style.paddingLeft="3px";var labelHolder=cE("nobr",td);labelHolder.style.cursor="pointer";labelHolder.innerHTML=this.pageName||"Untitled";if(this.tree.fontClass){labelHolder.className=this.tree.fontClass;}

this.labelHolder=labelHolder;if(this.tree.onClick){var onClickFx=function(){thisObj.tree.onClick(thisObj)
}
;eh_attachEvent("onclick",labelHolder,onClickFx,null,true);eh_attachEvent("onclick",iconImage,onClickFx,null,true);}

if(this.tree.onRightClick){var onClickFx=function(event){thisObj.tree.onRightClick(thisObj,event);crossbrowser_stopEvent(event);crossbrowser_cancelBubble(event);return false;}
;eh_addEvent("oncontextmenu",labelHolder,onClickFx);eh_addEvent("oncontextmenu",iconImage,onClickFx);}

var childCount=this.childNodes.length;if(childCount>0){var childHolder=cE("div",parentEl);this.childHolder=childHolder;if(!this.isExpanded){childHolder.style.display="none";}

else 
{for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].build(childHolder);}

}

}

}
;this.toggleNode=function(){this.isExpanded=!this.isExpanded;if(this.isExpanded){for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].build(this.childHolder);}

this.childHolder.style.display="";this.plusOrMinusImage.src=this.tree.expandedIcon;var nodeId=this.getNodeId();UserSettingsMgr.setProperty(this.tree.userSettingsKey,nodeId.replaceAll(".","_"),"true");}

else 
{this.childHolder.style.display="none";this.childHolder.innerHTML="";this.plusOrMinusImage.src=this.tree.collapsedIcon;var nodeId=this.getNodeId();UserSettingsMgr.deleteProperty(this.tree.userSettingsKey,nodeId.replaceAll(".","_"));}

}
;this.getNodeId=function(){var id=this.pageId;var temp=this;while(temp.parentNode)
{var temp=temp.parentNode;id=temp.pageId+"."+id;}

return id+"";}
;this.addChild=function(childNode){this.childrenById[childNode.pageId]=childNode;this.childNodes.push(childNode);childNode.parentNode=this;var offsetLeft=this.offsetLeft+this.tree.indentPixels;childNode.offsetLeft=offsetLeft;}
;}
;

;function PageTree(){this.childNodes=[];this.childrenById={}
;this.onClick;this.parentEl;this.rootHolder;this.userSettingsKey="page_tree";}

PageTree.prototype=new PageTreeBase();function PageTreeBase(){this.lineHeight=22;this.indentPixels=18;this.expandedIcon="upload/custom_screens/sitearchitect/arrow-down.png";this.collapsedIcon="upload/custom_screens/sitearchitect/arrow-right.png";this.pageIcon="/upload/custom_screens/rteeditor/html_icon.gif";this.build=function(parentEl){if(parentEl){this.parentEl=parentEl;}

else 
{parentEl=this.parentEl;}

var fx=function(){}
;eh_attachEvent("onselectstart",parentEl,fx,null,true,null,true,false);var div=cE("div",parentEl);this.rootHolder=div;for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].build(div);}

}
;this.addPageAndDraw=function(pageRecord){var node=this.addPage(pageRecord);node.build(this.rootHolder);}

this.addPage=function(pageRecord,ancestry){var activeNode=this;if(!ancestry){var familyTreePos=pageRecord.getField("family_tree_pos").getValue();ancestry=familyTreePos.split(".");ancestry.splice(0,1);ancestry.splice(ancestry.length-1,1);}

for(var i=0;i<ancestry.length-1;i++)
{var childNode=activeNode.childrenById[ancestry[i]];if(!childNode){break;}

activeNode=childNode;}

var node=new PageTreeNode(pageRecord,this);activeNode.addChild(node);return node;}
;this.addChild=function(childNode){this.childNodes.push(childNode);this.childrenById[childNode.pageId]=childNode;childNode.offsetLeft=0;}
;this.getIcon=function(type){var iconPath=this.icons[type];if(null==iconPath){iconPath=this.icons.default;    
            }    
                
            return iconPath;    
      };    
          
      this.initIcons = function()    
      {    
            var icons = {}    
            icons.page = "/upload/custom_screens/sitearchitect/page_sm.png";    
            icons.folder = "/upload/custom_screens/sitearchitect/folder_sm.png";    
            icons.default = icons.page;    
               
            this.icons = icons;   
      };    
          
      this.initIcons();    
}
var UserSettingsMgr=new UserSettingsManager();function UserSettingsManager(){this.mc=new MiniCache();this.settingsByName={}
;this.addSettingsToLoad=function(settingName){var mc=getMasterCache();var listInput=mc.addListToLoad("user_settings",settingName);listInput.addConditional("user",this.getUserId(),CONDITIONAL_EQUALS);listInput.addSearchTerm("setting_name",settingName,SEARCHTERM_EXACT_MATCH);}
;this.loadSettings=function(){var fx=function(){}
;getMasterCache().process(fx);}
;this.getUserId=function(){return g_sessionInformation.logged_user_info.id||g_cache.userId;}
;this.setProperty=function(setName,key,value){var settings=this.getSettings(setName);if(settings){settings.addChildField(key,"TEXT",value);}

}
;this.getProperty=function(setName,key){var settings=this.getSettings(setName);if(!settings){return ;}

var field=settings.getChildField(key);return field?field.getValue():null;}
;this.deleteProperty=function(setName,key){var settings=this.getSettings(setName);if(settings){settings.removeChildField(key);}

}
;this.getSettings=function(setName){if(!setName){return null;}

var record=this.settingsByName[setName];if(record){return record.getField("settings");}

var list=this.mc.getListByName(setName);if(!list){return null;}

record=this.mc.getRecord("user_settings",list.ids[0]);if(!record){record=this.mc.createRecord("user_settings");record.getField("user.id").setValue(g_sessionInformation.logged_user_info.id);record.getField("setting_name").setValue(setName);}

this.settingsByName[setName]=record;return record.getField("settings");}
;this.clearProperties=function(setName){}
;
this.saveNow=function(afterFx){this.mc.process(afterFx);}
;this.init=function(){var thisObj=this;var isAlreadyRun=false;var onCloseFx=function(){if(!isAlreadyRun){isAlreadyRun=true;thisObj.mc.syncProcess();}

}
;crossbrowser_attachEvent(window,"onbeforeunload",onCloseFx);}
;this.init();}
;
function position_getXYCoords(event){var coord=null;if(event){coord=new position_Coord(event.clientX,event.clientY)
}

else 
{coord=new position_Coord(window.event.clientX,window.event.clientY)
}

return coord;}

function position_findElementPosition(element){var curleft=0;var curtop=0;if(element.offsetParent){do
{curleft+=element.offsetLeft;curtop+=element.offsetTop;}

while(element=element.offsetParent);}

return [curleft,curtop];}

function position_findElementPositionWithScroll(element){var curleft=0;var curtop=0;if(IS_CHROME){if(element.parentNode){do
{curleft+=element.offsetLeft-element.scrollLeft;curtop+=("BODY"==element.tagName)?element.offsetTop:element.offsetTop-element.scrollTop;element=("DIV"==element.parentNode.tagName)?element.parentNode:element.offsetParent;}

while(element);}

}

else 
{if(element.offsetParent){do
{curleft+=element.offsetLeft-element.scrollLeft;curtop+=("BODY"==element.tagName)?element.offsetTop:element.offsetTop-element.scrollTop;}

while(element=element.offsetParent);}

}

return [curleft,curtop];}
;
function position_pixelToInt(pixelString){if(null==pixelString){return 0;}

var pixelValue=parseInt(pixelString.substring(0,pixelString.length-2));return (isNaN(pixelValue))?0:pixelValue;}

function position_Coord(x,y){this.x=x;this.y=y;}

function position_findXYCoordinates(element){var ua=navigator.userAgent.toLowerCase();var isOpera=(ua.indexOf('opera')>-1);var isSafari=(ua.indexOf('safari')>-1);var isIE=(window.ActiveXObject);var parent=null;var pos=[];var box;var coord;if(element.getBoundingClientRect){box=element.getBoundingClientRect();var doc=document;var sTop=Math.max(doc.documentElement.scrollTop,doc.body.scrollTop);var sLeft=Math.max(doc.documentElement.scrollLeft,doc.body.scrollLeft);pos[0]=box.left+sLeft;pos[1]=box.top+sTop
}

else 
{pos=[element.offsetLeft,element.offsetTop];parent=element.offsetParent;if(parent!=element){while(parent)
{pos[0]+=parent.offsetLeft;pos[1]+=parent.offsetTop;parent=parent.offsetParent;}

}

if(element.style.position=='absolute'){pos[0]-=document.body.offsetLeft;pos[1]-=document.body.offsetTop;}

}

parent=(element.parentNode)?element.parentNode:null
while(parent&&parent.tagName.toUpperCase()!='BODY'&&parent.tagName.toUpperCase()!='HTML')
{if(parent.style.display!='inline'){pos[0]-=parent.scrollLeft;pos[1]-=parent.scrollTop;}

parent=(parent.parentNode)?parent.parentNode:null;}

var coord=((pos[0]==0&&pos[1]==0)||(pos[0]==undefined&&pos[1]==undefined))?
position_getAlternateCoordinates(element):new position_Coord(pos[0],pos[1]);return coord;}
;
;;;function tree_Tree(parentEl){this.typeToIcon=[];this.indentPixels=13;this.lineHeight=22;this.childNodes=[];this.childrenByName={}
;this.parentEl=parentEl;this.expandedIcon="/upload/custom_screens/generic_images/cm_tree_minus.gif";this.collapsedIcon="/upload/custom_screens/generic_images/cm_tree_plus.gif";this.fontClass;this.addChild=function(childNode){this.childNodes.push(childNode);this.childrenByName[childNode.label]=childNode;childNode.offsetLeft=0;childNode.treeObj=this;}
;this.addDescendent=function(fullName,branchType,branchOnClickFx,branchDblClickFx,branchRightClickMenu,
leafType,leafOnClickFx,leafOnDblClickFx,leafOnRightClickFx,leafProperties){var activeNode=this;var names=fullName.split(".");for(var i=0;i<names.length-1;i++)
{var childNode=activeNode.childrenByName[names[i]];if(!childNode){childNode=new tree_Node(names[i],branchType,branchOnClickFx,branchDblClickFx,branchRightClickMenu);activeNode.addChild(childNode);}

activeNode=childNode;}

var leafNode=new tree_Node(names[names.length-1],leafType,leafOnClickFx,leafOnDblClickFx,leafOnRightClickFx,leafProperties);activeNode.addChild(leafNode);}
;this.addRootNode=function(node,parentEl){tree_buildNode(node,parentEl);}

this.removeRootNode=function(){}

this.build=function(){tree_build(this)}
;}

function tree_Node(label,type,onClickFx,ondblclickFx,onRightClickFx,properties){this.label=label;this.type=type;this.onClickFx=onClickFx;this.ondblclickFx=ondblclickFx;this.onRightClickFx=onRightClickFx;this.properties=properties;this.onclick;this.parentNode;this.offsetLeft;this.isExpanded=false;this.childrenContainer;this.plusOrMinusIconHolder;this.plusOrMinusImage;this.nodesToDelete=[];this.treeObj;this.childNodes=[];this.childrenByName={}
;}

tree_Node.prototype=new tree_NodeBase();function tree_NodeBase(){this.addChild=function addChildNode(childNode){this.childrenByName[childNode.label]=childNode;this.childNodes.push(childNode);childNode.treeObj=this.treeObj;childNode.parentNode=this;childNode.offsetLeft=this.offsetLeft+this.treeObj.indentPixels;}
;this.getFullName=function(){var node=this;var fullName=node.label;while(node.parentNode)
{var node=node.parentNode;fullName=node.label+"."+fullName;}

return fullName;}
;this.updateLabel=function(newLabel){this.label=newLabel;this.labelHolder.innerHTML=newLabel;}
;this.remove=function(){this.nodesToDelete=[];var sourceNode=this;if(!sourceNode.isExpanded){tree_removeNode(sourceNode);}

else 
{this.nodesToDelete.push(sourceNode);tree_setNodesToRemove(sourceNode,this);tree_runThroughNodesToRemove(this.nodesToDelete);}

}
;this.getDescendentList=function(list){if(!list){list=[];}

for(var i in this.childNodes)
{list.push(this.childNodes[i]);this.childNodes[i].getDescendentList(list);}

return list;}

}

function tree_setNodesToRemove(sourceNode,thisObj){for(var i=0;i<sourceNode.childNodes.length;i++)
{var node=sourceNode.childNodes[i];thisObj.nodesToDelete.push(node);if(node.isExpanded){tree_setNodesToRemove(node,thisObj);}

}

}

function tree_runThroughNodesToRemove(nodes){for(var i=nodes.length;i>0;i--)
{var node=nodes[i-1];tree_removeNode(node);}

}

function tree_removeNode(node){tree_removeChildNodes(node);if(node.parentNode){var parentNode=node.parentNode;tree_removeChildNodes(parentNode);delete(parentNode.childrenByName[node.label]);if(parentNode.childNodes.length==0&&parentNode.plusOrMinusImage){parentNode.plusOrMinusIconHolder.innerHTML="";}

}

node.container.parentNode.removeChild(node.container);}

function tree_removeChildNodes(node){for(var i=0;i<node.childNodes.length;i++)
{node.childNodes.splice(i,1);break;}

}

function tree_build(treeObj){var parentEl=treeObj.parentEl;var fx=function(){}
;eh_attachEvent("onselectstart",parentEl,fx,null,true,null,true,false);var div=cE("div",parentEl);for(var i=0;i<treeObj.childNodes.length;i++)
{tree_buildNode(treeObj.childNodes[i],div);}

}

var processed=false;function tree_buildNode(thisObj,parentEl){var lineHeight=thisObj.treeObj.lineHeight;var container=cE("div",parentEl);container.style.height=lineHeight+"px";var fx=function(){}
;eh_attachEvent("onselectstart",container,fx,null,true,null,true,false);thisObj.container=container;var tBody=createTable(container);var table=tBody.parentNode;table.style.marginLeft=thisObj.offsetLeft+"px";table.style.height=lineHeight+"px";table.className="text";var tr=cE("tr",tBody);var plusOrMinusIconHolder=cE("td",tr);plusOrMinusIconHolder.style.width=thisObj.treeObj.indentPixels;thisObj.plusOrMinusIconHolder=plusOrMinusIconHolder;var onclickFx=function(){tree_toggleNode(thisObj)}
;eh_attachEvent("onclick",plusOrMinusIconHolder,onclickFx);if(thisObj.childNodes.length>0){var img=cE("img",plusOrMinusIconHolder);img.src=thisObj.isExpanded?thisObj.treeObj.expandedIcon:thisObj.treeObj.collapsedIcon;img.style.cursor="pointer";thisObj.plusOrMinusImage=img;}

var td=cE("td",tr);td.style.width=thisObj.treeObj.indentPixels+"px";var iconImage=cE("img",td);iconImage.style.cursor="pointer";iconImage.src=(thisObj.treeObj.typeToIcon[thisObj.type])?thisObj.treeObj.typeToIcon[thisObj.type]:tree_typeToIcon[thisObj.type];var td=cE("td",tr);var labelHolder=cE("nobr",td);labelHolder.style.cursor="pointer";labelHolder.style.marginLeft="3px";labelHolder.innerHTML=thisObj.label;if(thisObj.treeObj.fontClass){labelHolder.className=thisObj.treeObj.fontClass;}

thisObj.labelHolder=labelHolder;if(thisObj.onClickFx){var onClickFx=function(){thisObj.onClickFx(thisObj)}
;eh_attachEvent("onclick",labelHolder,onClickFx,null,true);eh_attachEvent("onclick",iconImage,onClickFx,null,true);}

if(thisObj.ondblclickFx){var ondblclickFx=function(){thisObj.ondblclickFx(thisObj)}
;eh_attachEvent("ondblclick",labelHolder,ondblclickFx,null,true);eh_attachEvent("ondblclick",iconImage,ondblclickFx,null,true);}

if(thisObj.onRightClickFx){var onRightClickFx=function(event){thisObj.onRightClickFx(event)}
;eh_attachEvent("oncontextmenu",labelHolder,onRightClickFx,null,true);eh_attachEvent("oncontextmenu",iconImage,onRightClickFx,null,true);}

var childCount=thisObj.childNodes.length;if(childCount>0){var nodeContainer=cE("div",parentEl);thisObj.childrenContainer=nodeContainer;for(var i=0;i<thisObj.childNodes.length;i++)
{if(!thisObj.isExpanded){nodeContainer.style.display="none";}

tree_buildNode(thisObj.childNodes[i],nodeContainer);}

}

}

function tree_toggleNode(nodeObj){nodeObj.isExpanded=!nodeObj.isExpanded;if(nodeObj.isExpanded){nodeObj.childrenContainer.style.display="";nodeObj.plusOrMinusImage.src=nodeObj.treeObj.expandedIcon;}

else 
{nodeObj.childrenContainer.style.display="none";nodeObj.plusOrMinusImage.src=nodeObj.treeObj.collapsedIcon;}

}

function tree_toggleIsExpanded(thisObj){if(thisObj.parentNode!=null){tree_toggleIsExpanded(thisObj.parentNode);tree_toggleNode(thisObj.parentNode);}

}


function createTemplateBasedPageCreator(fieldName,miniCache,templateId,pageName,displayInNav,parentPageId,url){var getter=createGeneralExecuter(fieldName,miniCache,"CreatePageFromTemplate");var params=getter.getChildField("exec_params");params.addChildField("module_template_id","INTEGER",templateId);params.addChildField("name","TEXT",pageName);params.addChildField("display_in_nav","BOOLEAN",displayInNav);params.addChildField("parent_page_id","INTEGER",parentPageId);if(url){params.addChildField("url","TEXT",url);}

return getter;}

;;;;;function GenericNavMenu(element){this.element=element;this.register(this);}

GenericNavMenu.prototype=new GenericNavMenuBase();function GenericNavMenuBase(){this.isLive=false;this.fragInfo;this.liveNav;this.hotSpot;this.spotWidth=10;this.spotHeight=10;this.fadeMillis=400;this.isDragging=false;this.editLink;this.originalEditLinkValue;this.isSaveTree=false;this.subMenuToAdd;this.build=function(){this.initStyles();this.attachEvents();}
;this.attachEvents=function(){var lis=gL("#"+this.element.id+" li");for(var i=0;i<lis.length;i++)
{this.attachLiEvent(lis[i]);}

}
;
this.attachLiEvent=function(li){this.initLiEnter(li);var thisObj=this;var leaveFx=function(){thisObj.leaveLi(li);}
;E.mouseleave(li,leaveFx);if(this.isLive){this.attachLinkEvent(li);}

}
;this.isOpenSubOnHover=function(){var setting=this.fragInfo.params.openSubMenusOnHover;if(!setting){return true;}

if(setting=="false"||setting=="none"){return false;}

if(setting=="true"||setting=="all"){return true;}

if(ResponsiveUtil){var sizes=setting.split(" ");var current=ResponsiveUtil.getCurrentSize();for(var i=0;i<sizes.length;i++)
{if(current==sizes[i]){return true;}

}

return false;}

return false;}
;this.attachLinkEvent=function(li){var linkEl=getChildByTagName(li,"a");if(!linkEl){return ;}

var thisObj=this;var fx=function(e){thisObj.makeLinkEditable(li,linkEl);}
;E.click(linkEl,fx);}
;this.makeLinkEditable=function(li,linkEl){if(this.editLink==linkEl){return ;}

if(this.editLink){this.editLink.contentEditable="false";}

linkEl.contentEditable="true";linkEl.focus();this.editLink=linkEl;if(!linkEl.style.outline){linkEl.style.outline="0";}

this.originalEditLinkValue=linkEl.innerText;var thisObj=this;var fx=function(){if(thisObj.editLink!=linkEl){thisObj.editLink=null;return ;}

thisObj.editLink=null;if(linkEl.innerText==thisObj.originalEditLinkValue){return ;}

thisObj.setToSave();sA(li,"doSave","true");}
;E.blur(linkEl,fx);}
;this.initLiEnter=function(li){var thisObj=this;var enterFx=function(event){thisObj.enterLi(li,event);}
;var settings={stop:false}
;E.mouseenter(li,enterFx,settings);}
;this.enterLi=function(li,event){var isOpenSub=this.isOpenSubOnHover();var prevLi=this.rootLi;var rootLi=this.getRootLi(li);this.rootLi=rootLi;if(prevLi&&prevLi!=rootLi){this.hideLiSubMenu(prevLi);}

{var subUl=this.getSubUl(li);if(subUl&&isOpenSub){this.showSub(subUl);}

else if(this.isLive&&this.isDragging&&(!isDescendent(li,this.draggingEl))){this.showSubMenuToAdd(li);}

}

var isThisEventSrc=(event.currentTarget==getNearestAncestor(event.srcElement,"li"));if(this.isLive&&isThisEventSrc){this.frameLi(li);}

if(this.isDragging&&isThisEventSrc){this.enterLiOnDrag(li);}

}
;this.closeSubMenus=function(){if(this.rootLi){this.hideLiSubMenu(this.rootLi);}

}
;this.showSubMenuToAdd=function(li){subUl=this.getSubMenuToAdd(li);subUl.style.opacity=1;subUl.style.visibility="";subUl.style.display="block";subUl.style.zIndex=CssUtil.getHighestZIndex();aE(li,subUl);if(subUl.parentNode!=this.getRootLi(subUl)){subUl.style.left=(subUl.parentNode.offsetWidth)+"px";subUl.style.top="4px";}

var parentLi=subUl.parentNode;var parentUl=parentLi.parentNode;for(var i=0;i<parentUl.children.length;i++)
{var li=parentUl.children[i];if(parentLi!=li){this.hideLiSubMenu(li);}

}

var thisObj=this;var fx=function(){thisObj.putSubMenuToAdd(subUl);}
;E.mouseenter(subUl,fx);this.setSubMenuClass();}
;this.showSub=function(subUl){if(null===gA(subUl,"origDisplay")){sA(subUl,"origDisplay",subUl.style.display);}

if(null===gA(subUl,"origVisibility")){sA(subUl,"origVisibility",subUl.style.visibility);}

subUl.style.opacity=1;subUl.style.visibility="";subUl.style.display="block";subUl.style.zIndex=CssUtil.getHighestZIndex();debugger;if(!this.isParentHorizontal(subUl)){subUl.style.left=(subUl.parentNode.offsetWidth)+"px";subUl.style.top="4px";}

else 
{subUl.style.left="";subUl.style.top="";}

var parentLi=subUl.parentNode;var parentUl=parentLi.parentNode;for(var i=0;i<parentUl.children.length;i++)
{var li=parentUl.children[i];if(parentLi!=li){this.hideLiSubMenu(li);}

}

}
;this.isParentHorizontal=function(ulEl){var display=CssUtil.getStyle(ulEl.parentNode,"display");return (display.indexOf("inline")>-1)?true:false;}
;this.putSubMenuToAdd=function(subUl){this.removeHotSpot();var li=subUl.children[0];var spot=this.getHotSpot();aE(li,spot);var spotWidth=spot.offsetWidth;var spotHeight=spot.offsetHeight;spot.style.top=((li.offsetHeight-spotHeight)/2)-3+"px";spot.style.left=((li.offsetWidth-spotWidth)/2)-3+"px";thisObj=this;var fx=function(){thisObj.replaceSubMenuToAdd(subUl);}
;E.mouseenter(spot,fx);}
;this.replaceSubMenuToAdd=function(subUl){var newUl=cE("ul");newUl.className="hasSubMenu";
subUl.parentNode.replaceChild(newUl,subUl);aE(newUl,this.draggingEl);this.removeSubMenuToAdd();this.showSub(newUl);}
;this.removeSubMenuToAdd=function(){var ul=this.subMenuToAdd;if(ul&&ul.parentNode){ul.parentNode.removeChild(ul);}

}
;this.getSubMenuToAdd=function(){var ul=this.subMenuToAdd;if(!ul){ul=cE("ul");this.subMenuToAdd=ul;
var li=cE("li",ul);li.style.left=0;li.style.top=0;li.style.position="relative";this.subMenuItemToAdd=li;var aLink=cE("a",li);aLink.href="#";var span=cE("span",aLink);span.innerHTML="Add Sub-Menu"
}

this.removeSubMenuToAdd();ul.style.left="";ul.style.top="";return ul;}
;this.getRootLi=function(element){var li=getNearestAncestor(element,"li");var ul=getNearestAncestor(element,"ul");while(ul&&ul!=this.element)
{li=getNearestAncestor(ul,"li");ul=getNearestAncestor(li,"ul");}

return li;}
;this.frameLi=function(li){var framer=LiveNavHandler.navFramer;framer.frame(li);framer.top.innerHTML="";var bar=cE("div",framer.top);bar.className="lp_navBarTop";bar.style.height="20px";bar.style.backgroundColor="black";bar.style.color="white";bar.style.fontSize="12px";bar.style.position="relative";bar.style.opacity=".75";this.addDragEvents(bar,li);var div=cE("div",bar);div.className="lp_navBarTopOpen";div.innerHTML="open";var thisObj=this;var fx=function(){var params={}
;params.mode="visual_edit";var linkEl=li.getElementsByTagName("a")[0];var href=gA(linkEl,"a_href");window.location.href=UrlUtil.addParamsToUrl(href,params);}
;E.click(div,fx);var editDiv=cE("div",bar);editDiv.className="lp_navBarTopEdit";var span=cE("span",editDiv);span.innerHTML="+";var thisObj=this;var fx=function(){thisObj.showEditOptions(editDiv);}
;E.click(editDiv,fx);var div=cE("div",bar);div.style.clear="both";bar.style.top=-bar.offsetHeight+"px";}
;this.showEditOptions=function(positionEl){var coord=findElCoord(positionEl,true);var menu=new DropdownMenu();menu.minWidth="200px";var thisObj=this;var fx=function(){showProgressIcon("Loading");thisObj.loadWebsiteData();}
;var menuItem=new StandardMenuItem("Add New Page",fx);menu.addMenuItem(menuItem);menu.build(coord.x,coord.y);}
;this.loadWebsiteData=function(){var siteId=1;var mc=new MiniCache();var recordInput=mc.addRecordToLoad("website",siteId);recordInput.addField("*")
recordInput.addField("style_sheet.*");mc.addTemplateToLoad("style_sheets");mc.addTemplateToLoad("module");mc.addTemplateToLoad("screen_module");mc.addTemplateToLoad("module_template");mc.addTemplateToLoad("action_log");var thisObj=this;var fx=function(){var afterLoadFx=function(){hideProgressIcon();var popup=new CreatePopup(siteId,mc);popup.displayInNav=true;popup.initOnPageCreation=true;popup.afterCreatePageFx=function(cP,newPageId){var mc=cP.mc;var newPageRec=mc.getRecord("page",newPageId);var friendlyUrl=newPageRec.getField("screen_module.url.friendly_url").getValue();window.location=friendlyUrl;}
;popup.afterCreateFolderFx=function(cP){debugger}
;popup.afterCreateTemplateFx=function(cP){debugger}
;popup.afterCreateModuleFx=function(cP){debugger}
;popup.build();}

sl_loadScript('/0/le8650_0.js',afterLoadFx);afterLoadFx;}
;mc.process(fx);}
;this.removeHotSpot=function(){var spot=this.getHotSpot();if(spot.parentNode){spot.parentNode.removeChild(spot);}

}
;this.putHotSpot=function(li){this.removeHotSpot();var spot=this.getHotSpot();aE(li,spot);var spotWidth=spot.offsetWidth;var spotHeight=spot.offsetHeight;spot.style.top=((li.offsetHeight-spotHeight)/2)-3+"px";spot.style.left=((li.offsetWidth-spotWidth)/2)-3+"px";thisObj=this;var fx=function(){thisObj.swapLis(li);}
;E.mouseenter(spot,fx);}
;this.getHotSpot=function(){if(this.hotSpot){return this.hotSpot;}

var spot=cE("img");this.hotSpot=spot;spot.src="/upload/custom_screens/html5/livepage/nav_bullseye.png";spot.style.position="absolute";return spot;}
;this.isLiRootLevel=function(li){return (li==this.getRootLi(li));}
;this.swapLis=function(li){var draggingEl=this.draggingEl;var isBefore=isBeforeSibling(li,draggingEl);draggingEl.parentNode.removeChild(draggingEl);if(isBefore){li.parentNode.insertBefore(draggingEl,li);}

else 
{insertAfter(draggingEl,li);}

if(!this.isLiRootLevel(draggingEl)){var parentLi=getNearestAncestor(draggingEl,"li");var subUl=this.getSubUl(parentLi);if(subUl){this.showSub(subUl);}

}

this.setSubMenuClass();}
;this.enterLiOnDrag=function(li){if(!this.isDragging){return ;}

var draggingEl=this.draggingEl;if(draggingEl==li){return ;}

if(!isDescendent(li,this.draggingEl)){this.putHotSpot(li);}

}
;this.addDragEvents=function(grip,li){var thisObj=this;var framer=LiveNavHandler.navFramer;var thisObj=this;DragUtil.getYOffset=function(dragEl){return dragEl.offsetHeight/2;}
;var createDragElFx=function(){var dragEl=li.cloneNode(true);dragEl.style.border="3px dashed #d6e0f5";dragEl.style.width=li.offsetWidth+"px";dragEl.style.height=li.offsetHeight+"px";return dragEl;}
;var onDragStart=function(){thisObj.isDragging=true;framer.disable();fade_setOpacity(li,50);thisObj.draggingEl=li;}
;var onDragEnd=function(){thisObj.removeSubMenuToAdd();thisObj.removeHotSpot();thisObj.isDragging=false;fade_resetOpacity(li);framer.enable();thisObj.setTreeToSave();}
;DragUtil.makeDraggable(grip,null,onDragStart,onDragEnd,createDragElFx);}
;this.setToSave=function(){LivePage.setElementToSave(this.element.parentNode);}
;this.setTreeToSave=function(){this.isSaveTree=true;this.setToSave();}
;this.sync=function(){var level=parseInt(this.fragInfo.params.level);var navFamilyTreePos=this.fragInfo.familyTreePos;var mc=LivePage.mc;var lis=gL("#"+this.element.id+" li");for(var i=0;i<lis.length;i++)
{this.syncLi(lis[i],level,navFamilyTreePos,mc);}

}
;this.syncLi=function(li,rootLevel,navFamilyTreePos,mc){var isSaveName=(gA(li,"doSave")=="true");if(!isSaveName&&!this.isSaveTree){return ;}

var pageId=this.getLiPageId(li);var page=mc.createRecord("page",pageId);if(this.isSaveTree){this.syncLiTreePos(page,li,rootLevel,navFamilyTreePos,mc);}

if(isSaveName){var linkEl=getChildByTagName(li,"a");page.getField("name").setValue(linkEl.innerText);}

page.removeUnchangedFields();}
;this.syncLiTreePos=function(page,li,rootLevel,navFamilyTreePos,mc){var level=rootLevel;var pageId=this.getLiPageId(li);var familyTreePos="."+pageId+".";var parentLi=getNearestAncestor(li.parentNode,"li");while(parentLi&&isDescendent(parentLi,this.element))
{level++;var otherPageId=this.getLiPageId(parentLi);familyTreePos="."+otherPageId+familyTreePos;var parentLi=getNearestAncestor(parentLi.parentNode,"li");}

familyTreePos=navFamilyTreePos+familyTreePos.substr(1);var siblingPos=findSiblingIndex(li);page.getField("sibling_pos").setValue(siblingPos);page.getField("family_tree_pos").setValue(familyTreePos);page.getField("depth_in_tree").setValue(level);}
;this.getLiLevel=function(li){var level=0;var parentLi=getNearestAncestor(li.parentNode,"li");while(parentLi&&isDescendent(parentLi,this.element))
{level++;var parentLi=getNearestAncestor(parentLi.parentNode,"li");}

return level;}
;this.getLiPageId=function(li){var classes=CssUtil.getClasses(li);for(var i=0;i<classes.length;i++)
{if(classes[i].substring(0,4)=="page"){return classes[i].substr(4);}

}

}
;this.hideLiSubMenu=function(li){var subUl=this.getSubUl(li);if(!subUl){return ;}

this.hideUlSubMenu(subUl);}
;this.hideUlSubMenu=function(subUl){var display=gA(subUl,"origDisplay");var visibility=gA(subUl,"origVisibility");subUl.style.display=display||"";subUl.style.visibility=visibility;subUl.style.opacity=1;}
;this.fadeOutSubMenu=function(li){var subUl=this.getSubUl(li);if(!subUl){return ;}

subUl.style.opacity="0";var thisObj=this;var fx=function(){if(subUl.style.opacity!="0"){return ;}

thisObj.hideUlSubMenu(subUl);}
;window.setTimeout(fx,this.fadeMillis);}
;this.hideNow=function(ul){}
;this.leaveLi=function(li){
if(this.isLive&&LiveNavHandler.navFramer.isVisible()){return ;}

this.fadeOutSubMenu(li);}
;this.getSubUl=function(li){for(var i=0;i<li.children.length;i++)
{if(li.children[i].tagName=="UL"){return li.children[i];}

}

return null;}
;this.initStyles=function(){var mainUl=this.element;if(null==mainUl){return ;}

var allLis=mainUl.getElementsByTagName("li");for(var i=0;i<allLis.length;i++)
{var li=allLis[i];li.style.position="relative";li.style.left=0;li.style.top=0;}

var topLis=getChildrenByTagName(this.element,"li");for(var i=0;i<topLis.length;i++)
{var li=topLis[i];}

this.setSubMenuClass();}
;this.setSubMenuClass=function(){var oldEls=gL("#"+this.element.id+" .hasSubMenu");for(var i=0;i<oldEls.length;i++)
{CssUtil.removeClassFromEl(oldEls[i],"hasSubMenu");}

var subUls=this.element.getElementsByTagName("ul");for(var i=0;i<subUls.length;i++)
{var subUl=subUls[i];CssUtil.addClassToEl(subUl.parentNode,"hasSubMenu");CssUtil.addClassToEl(subUl,"hasSubMenu");}

}
;this.navRegistry=[];this.register=function(nav){this.navRegistry.push(nav);}
;this.closeAllSubMenus=function(){for(var i=0;i<this.navRegistry.length;i++)
{this.navRegistry[i].closeSubMenus();}

}
;this.initCss=function(){var fadeSec=this.fadeMillis/1000;var cssClass=new CssClass(".hasSubMenu");cssClass.add("-moz-transition","opacity "+fadeSec+"s linear 0");cssClass.add("-webkit-transition","opacity "+fadeSec+"s linear 0");cssClass.add("transition","opacity "+fadeSec+"s linear 0");cssClass.init();}
;this.initCss();}


function PermissionGetter(userId,areaKey){this.userId=userId;this.areaKey=areaKey;}

PermissionGetter.prototype=new PermBase()
function PermBase(){this.addToLoad=function(mc){var pg=mc.createAction("permissions","PST");pg.setAreaKey(this.areaKey);pg.setUserId(this.userId);this.mc=mc;}
;this.getPermission=function(permName){return this.getPermissions().getChildField(permName);}
;this.getPermissions=function(){var perms=this.perms
if(perms==null){perms=this.mc.getActionField("permissions").getChildField("user_permissions");this.perms=perms;}

return perms;}
;this.getItems=function(){var permField=this.mc.getActionField("permissions");return permField.getChildField("items").data;}

}

mc_typeToDefaultValue["PST"]=function(){var permissionField=new DynField(null,{}
,{}
,null,null);permissionField.addChildField("area_key","TEXT");permissionField.addChildField("app_role","INTEGER");permissionField.addChildField("items","ARRAY");permissionField.addChildField("user","INTEGER");permissionField.addChildField("user_permissions","COLLECTION");permissionField.addChildField("master_apply_item_vals","TEXT");permissionField.addChildField("master_sync_item","TEXT");permissionField.addChildField("no_load","BOOLEAN");return {data:permissionField.data,metaData:permissionField.metaData}
;}

mc_fieldTypeExtenders["PST"]=function(dynField){dynField.setAreaKey=function(areaKey){if(null==areaKey){areaKey="";}

dynField.getChildField("area_key").setValue(areaKey);}

dynField.setUserId=function(userId){dynField.getChildField("user").setValue(userId);}

dynField.getItems=function(){return dynField.getChildField("items");}
;dynField.getUserPermissions=function(){return dynField.getChildField("user_permissions");}
;dynField.getPermission=function(permissionName){return dynField.getChildField("user_permissions").getChildField(permissionName);}

}

vfc_registerConverter("PST",vfc_returnNoValue);
;var LoggedInUtil=new LoggedInUtilBase();function LoggedInUtilBase(){this.launchOptionPopup=function(){var popup=new Popup();popup.disableBg=true;popup.fadeBg=true;popup.width=340;var cA=popup.build()
cA.style.padding="0px 20px 20px 20px";var name=g_sessionInformation.logged_user_info.name;var div=cE("div",cA);div.innerHTML="Welcome, "+name.first_name+" "+name.last_name;div.style.marginBottom="20px";div.style.fontSize="14px";div.style.color="#333333";var div=cE("div",cA);LoggedInUtil.buildDestinationDropdown(div,true);popup.center();}
;this.buildDestinationDropdown=function(parentEl,isPopup){if(this.perms!=null){this.buildDestinationOptions(parentEl);return ;}

var loggedUser=g_sessionInformation.logged_user_info;var userId=loggedUser.id;var areaKey=(loggedUser.user_type.toLowerCase()=="member")?"member_side":"office_side";this.isAdmin=(areaKey=="office_side");var mc=new MiniCache();var permsObj=new PermissionGetter(userId,areaKey)
permsObj.addToLoad(mc);var thisObj=this;var onProcess=function(){thisObj.perms=permsObj;thisObj.buildDestinationOptions(parentEl,isPopup);}
;mc.process(onProcess);}
;this.buildDestinationOptions=function(parentEl,isPopup){var activeItems=[];var items=this.perms.getItems(items);for(var i=0;i<items.length;i++)
{var item=items[i];if(item.url==""||!item.is_on){continue;}

activeItems.push(item);}

var destination=g_sessionInformation.settings.login_panel.logged_in_url;if(activeItems.length==0&&isPopup){window.location=destination;return ;}

else if(activeItems.length>0){destination="";var div1=cE("div",parentEl);div1.innerHTML="Take me to";var div2=cE("div",parentEl);var selectEl=cE("select",div2);if(isPopup){div1.style.paddingRight="4px";CssUtil.setFloat(div1,"left");CssUtil.setFloat(div2,"left");var clearDiv=cE("div",parentEl);clearDiv.style.clear="both";}

this.addSiteEditingOptions(selectEl);var option=cE("option",selectEl);option.innerHTML="--- Select a destination ---";for(var i=0;i<activeItems.length;i++)
{var item=activeItems[i];var option=cE("option",selectEl);option.innerHTML=item.label;option.value=item.url;}

var setDestinationFx=function(){destination=selectEl.options[selectEl.selectedIndex].value;}
;E.add(selectEl,"change",setDestinationFx);}

var div=cE("div",parentEl);div.style.marginTop="16px";if(isPopup){div.style.marginLeft="70px";}

var redirectFx=function(){window.location="/"+destination;}
;var label=(activeItems.length==0)?"GO TO CLIENT SIDE":"GO";var button=cb(div,label,redirectFx);button.className="lp_darkButton";}
;this.addSiteEditingOptions=function(selectEl){var pageId=getMasterCache().values.mainPage;var perm=this.perms;var saUrl=null;var editInSa=perm.getPermission("sa_allow_all")||perm.getPermission("sa_page_edit_"+pageId+".sa_edit");if(null!=editInSa&&editInSa.getValue()){saUrl="site-architect?pageId="+pageId;}

var lpUrl=null;var editInLp=perm.getPermission("lp_allow_all")||perm.getPermission("sa_page_edit_"+pageId+".lp_edit");if(null!=editInSa&&editInSa.getValue()){var url=window.location.href;var params={}
;params.mode="visual_edit";params.scrollTop=document.body.scrollTop;lpUrl=g_params.fu+"?mode=visual_edit&scrollTop="+document.body.scrollTop;}
;if(null==lpUrl&&saUrl){return ;}

var option=cE("option",selectEl);option.innerHTML="--- Select an action ---";if(lpUrl!=null&&(BrowserUtil.isChrome()||BrowserUtil.isSafari())&&!g_sessionInformation.isMobileDevice){var option=cE("option",selectEl);option.innerHTML="Edit on Live Pages";option.value=lpUrl;}

if(saUrl!=null){var option=cE("option",selectEl);option.innerHTML="Edit on Site Architect";option.value=saUrl;}

}
;}
;
function createCookie(name,value,days){if(days){var date=new Date();date.setTime(date.getTime()+(days*24*60*60*1000));var expires="; expires="+date.toGMTString();}

else 
{var expires="";}

document.cookie=name+"="+value+expires+";  path=/";}

function readCookie(name){var nameEQ=name+"=";var ca=document.cookie.split(';');for(var i=0;i<ca.length;i++)
{var c=ca[i];while(c.charAt(0)==' ')
{c=c.substring(1,c.length);}

if(c.indexOf(nameEQ)==0){return c.substring(nameEQ.length,c.length);}

}

return null;}

function eraseCookie(name){createCookie(name,"",-1);}


;;function LoginAction(userName,password){var mc=new MiniCache();this.mc=mc;var gE=createGeneralExecuter("login",mc,"Login");gE.addExecParamObj("user_name","TEXT",userName);gE.addExecParamObj("password","TEXT",password);this.gE=gE;}

LoginAction.prototype=new LoginActionBase();function LoginActionBase(){this.run=function(onProcess){var mc=this.mc;mc.process(onProcess);}
;this.getResult=function(){return this.mc.getActionField("login").getResults().data;}
;}

;
function PasswordReseter(userName,oldPass,newPass){this.uN=userName
this.oP=oldPass||"";this.nP=newPass||"";this.reset=function(afterResetFx){var mc=new MiniCache();var gE=createGeneralExecuter("pr",mc,"PasswordReseter");gE.addExecParamObj("user_name","TEXT",this.uN);gE.addExecParamObj("old_password","TEXT",this.oP);gE.addExecParamObj("new_password","TEXT",this.nP);var onProcess=function(){var isReset=mc.getActionField("pr").getResults().data.success;afterResetFx(isReset);}

mc.process(onProcess);}
;}
;
;;
function CredentialHandler(){this.mc=new MiniCache();
this.encrypt=function(val1,val2,afterProcess){var thisObj=this;var onProcess=function(){var encryptedVal=thisObj.mc.getActionField("crd_handler").getResultByName("result_val").getValue();createCookie("crdhdlr",encryptedVal,30);createCookie("remember_me",true,30);afterProcess();}
;var srcVal=val1+"$"+val2;this.processGe(srcVal,"encrypt",onProcess);}
;
this.decrypt=function(afterProcess){var thisObj=this;var onProcess=function(){var decryptedVal=thisObj.mc.getActionField("crd_handler").getResultByName("result_val").getValue();var val=decryptedVal.split("$");afterProcess(val[0],val[1]);}
;var srcVal=readCookie("crdhdlr");this.processGe(srcVal,"decrypt",onProcess);}
;this.processGe=function(srcVal,action,onProcess){var mc=this.mc;var gE=createGeneralExecuter("crd_handler",mc,"EncryptionHandler");gE.addExecParamObj("source_val","TEXT",srcVal);gE.addExecParamObj("action","TEXT",action);mc.process(onProcess)
}

}

;;;;;var LoginPanel=new LoginPanelBase();
function LoginPanelBase(){
this.isExpanded=false;
this.build=function(){if(this.isInSA()){return ;}

this.initCss();var loginBoxHolder=cE("div",document.body);loginBoxHolder.className="lp_reseter lgp_loginBoxHide";loginBoxHolder.id="lgp_loginBoxMainHolder";this.loginHolder=loginBoxHolder;var tbody=createTable(loginBoxHolder);var tr=cE("tr",tbody);var td=cE("td",tr);this.buildTab(td);var td=cE("td",tr);var div=cE("div",td);div.className="lpg_contentBox";this.contentHolder=div;this.buildContentBox();var fx=null;var thisObj=this;
var repositionFx=function(){thisObj.loginHolder.style.display="none";if(fx==null){fx=function(){thisObj.reposition();clearTimeout(fx);fx=null;}

setTimeout(fx,300);}

}
;E.add(window,"resize",repositionFx);}
;this.isInSA=function(){return (window.parent!=window);}
;
this.buildTab=function(parentEl){var tabEl=cE("div",parentEl);tabEl.className="lpg_loginBoxTab";var arrowEl=cE("div",tabEl);arrowEl.className="lgp_arrow lpg_left";this.arrowEl=arrowEl;var thisObj=this;var onClick=function(){thisObj.buildContentBox();thisObj.tooglePanelVisibility();}
;E.click(tabEl,onClick);}
;
this.tooglePanelVisibility=function(){var thisObj=this;if(thisObj.isExpanded){thisObj.loginHolder.className="lgp_loginBoxHide";thisObj.arrowEl.className="lgp_arrow lpg_left";thisObj.isExpanded=false;}

else 
{thisObj.loginHolder.className="lgp_loginBoxShow";thisObj.arrowEl.className="lgp_arrow lpg_right";thisObj.isExpanded=true;}

}
;
this.buildContentBox=function(){var pE=this.contentHolder;pE.innerHTML="";if(!g_sessionInformation.isLoggedIn){this.buildLoginArea(pE);}

else {this.buildLoggedInArea(pE);}

}
;this.buildLoggedInArea=function(parentEl){var name=g_sessionInformation.logged_user_info.name;var holder=cE("div",parentEl);holder.style.width="85%";var div=cE("div",holder);div.innerHTML=name.first_name+" "+name.last_name;div.style.textAlign="right";var div=cE("div",holder);LoggedInUtil.buildDestinationDropdown(div);var div=cE("div",holder);div.style.textAlign="right";var anchor=cE("a",div);anchor.innerHTML="LOG OUT";anchor.href="/logout";}
;
this.buildLoginArea=function(parentEl){var div=cE("div",parentEl);div.innerHTML="LOGIN";div.className="lgp_title";var div=cE("div",parentEl);var failedHolder=cE("div",div);failedHolder.style.display="none";failedHolder.id="lgp_failedLoginHolder";this.failedHolder=failedHolder;var div=cE("div",failedHolder);var childDiv=cE("div",div);childDiv.style.fontWeight="bold";childDiv.innerHTML="Incorrect Email/Password combination";var childDiv=cE("div",div);childDiv.innerHTML="Passwords are case-senstive.";var div=cE("div",parentEl);this.buildInput(div,"text","userName","Email");var div=cE("div",parentEl);var pwInput=this.buildInput(div,"password","password","Password");var onEnter=function(){var keyCode=KeyCodeUtil.getKeyCode(event);if(keyCode==13){thisObj.password=pwInput.value;thisObj.login();}

}
;E.add(pwInput,"keyup",onEnter);var div=cE("div",parentEl);var rmBox=document.createElement("input");rmBox.type="checkbox";this.rememberMe=rmBox;aE(div,rmBox);var span=cE("span",div);span.innerHTML="Remember me";span.style.position="relative";span.style.top="-2px";var buttonHolder=cE("div",parentEl);buttonHolder.style.marginTop="20px";var tbody=createTable(buttonHolder);var thisObj=this;var onClick=function(){thisObj.login();}
;var tr=cE("tr",tbody);var td=cE("td",tr);var button=cb(td,"LOG IN",onClick);button.className="lp_darkButton";var td=cE("td",tr);td.style.verticalAlign="middle";td.style.paddingLeft="10px";this.buildForgotPasswordLink(td);}
;
this.buildForgotPasswordLink=function(parentEl){var anchor=cE("a",parentEl);anchor.innerHTML="Help with login";anchor.href="#";var thisObj=this;var onClick=function(){thisObj.buildPasswordRecovery();}
;E.click(anchor,onClick);}
;
this.buildPasswordRecovery=function(){var pE=this.contentHolder;pE.innerHTML="";var div=cE("div",pE);div.className="lgp_title";div.innerHTML="PASSWORD RECOVERY";var pwHolder=cE("div",pE);var label=cE("div",pwHolder);label.innerHTML="Please enter your email.";label.style.marginBottom="4px";var div=cE("div",pwHolder);var input=this.buildInput(div,"text","userName","Email");var thisObj=this;var onClick=function(){if(thisObj.userName==null||thisObj.userName==""){label.style.color="red";return ;}

showProgressIcon("Recovering password");var afterReset=function(isReset){if(!isReset){alert("User name is invalid");hideProgressIcon();return ;}

pwHolder.innerHTML="";var div=cE("div",pwHolder);div.innerHTML="Your password has been reset and it has been emailed to the email on file.";div.style.width="85%";var div=cE("div",pE);var loginFx=function(){thisObj.buildContentBox();}
;var button=cb(div,"Back to login",loginFx);button.className="lp_darkButton";hideProgressIcon();}
;var passwordReseter=new PasswordReseter(thisObj.userName,"","");passwordReseter.reset(afterReset);}
;var div=cE("div",pwHolder);div.style.marginTop="10px";var button=cb(div,"SUBMIT",onClick);button.className="lp_darkButton";var anchor=cE("a",div);anchor.innerHTML="Back to login";anchor.href="#";anchor.style.paddingLeft="5px";var thisObj=this;var onClick=function(){thisObj.buildContentBox();}
;E.click(anchor,onClick);}
;
this.login=function(){this.failedHolder.style.display="none";showProgressIcon(" ");var lA=new LoginAction(this.userName,this.password);var thisObj=this;var afterRun=function(){var loginSuccess=function(){thisObj.tooglePanelVisibility();thisObj.buildContentBox();LoggedInUtil.launchOptionPopup();}
;var result=lA.getResult();if(result.success){var rememberMe=thisObj.rememberMe;if(rememberMe&&rememberMe.checked){var cH=new CredentialHandler();cH.encrypt(thisObj.userName,thisObj.password,loginSuccess);}

else 
{loginSuccess();}

}

else 
{var errorCode=result.errorCode;thisObj.failedHolder.style.display="";}

hideProgressIcon();}
;lA.run(afterRun);}
;
this.buildInput=function(parentEl,type,name,shadowText){var input=document.createElement("input");input.type=type;input.placeholder=shadowText;var thisObj=this;var onChange=function(){thisObj[name]=input.value;}
;E.add(input,"change",onChange);aE(parentEl,input);return input;}
;
this.reposition=function(){this.initCss();this.loginHolder.style.display="";}
;
this.initCss=function(){var posEl=cE("div",document.body);posEl.style.width="100%";posEl.style.height="2px";posEl.style.position="absolute";var width=posEl.offsetWidth;document.body.removeChild(posEl);var cC=new CssClass(".lgp_title");cC.add("font-size","14px");cC.add("font-weight","bold");cC.init();var cC=new CssClass("#lgp_loginBoxMainHolder");cC.add("width","235px");cC.add("position","fixed");cC.add("top","60px");cC.add("font","12px arial");cC.add("z-index","10000");cC.init();var cC=new CssClass("#lgp_loginBoxMainHolder div");cC.add("margin-bottom","8px");cC.init();var cC=new CssClass("#lgp_loginBoxMainHolder a");cC.add("color","#99ccff");cC.add("text-decoration","none");cC.init();var cC=new CssClass("#lgp_loginBoxMainHolder a:hover");cC.add("text-decoration","underline");cC.init();var cC=new CssClass("#lgp_loginBoxMainHolder td");cC.add("vertical-align","top");cC.init();var leftEnd=width-233+"px";var cC=new CssClass(".lgp_loginBoxShow");cC.add("-webkit-transition","all 0.5s ease-in-out");cC.add("-moz-transition","all 0.5s ease-in-out");cC.add("-o-transition","all 0.5s ease-in-out");cC.add("transition","all 0.5s ease-in-out");cC.add("left",leftEnd);cC.init();var leftStart=width-18+"px";var cC=new CssClass(".lgp_loginBoxHide");cC.add("-webkit-transition","all 0.5s ease-in-out");cC.add("-moz-transition","all 0.5s ease-in-out");cC.add("-o-transition","all 0.5s ease-in-out");cC.add("transition","all 0.5s ease-in-out");cC.add("left",leftStart);cC.init();var cC=new CssClass(".lgp_arrow");cC.add("width","0px");cC.add("height","0px");cC.add("margin-top","95%");cC.init();var cC=new CssClass(".lpg_left");cC.add("border","6px solid");cC.add("border-color","#333333 #cccccc #333333 #333333");cC.add("margin-right","50%");cC.init();var cC=new CssClass(".lpg_left:hover");cC.add("border-color","#333333 white #333333 #333333");cC.init();var cC=new CssClass(".lpg_right");cC.add("margin-left","50%");cC.add("border","5px solid");cC.add("border-color","#333333 #333333 #333333 #cccccc");cC.init();var cC=new CssClass(".lpg_right:hover");cC.add("border-color","#333333 #333333 #333333 white");cC.init();var cC=new CssClass(".lpg_loginBoxTab");cC.add("border","1px solid #cccccc");cC.add("background","#333333");cC.add("border-right","0px solid transparent");cC.add("width","20px");cC.add("position","relative");cC.add("left","1px");cC.add("border-top-left-radius","8px");cC.add("border-bottom-left-radius","8px");cC.add("height","50px");cC.add("cursor","pointer");cC.init();var cC=new CssClass(".lpg_contentBox");cC.add("background","#333333");cC.add("border","1px solid #cccccc");cC.add("width","215px");cC.add("color","white");cC.add("padding","15px");cC.add("-webkit-box-shadow","3px 3px 16px rgba(0, 0, 0, 0.5)");cC.add("-moz-box-shadow","3px 3px 16px rgba(0, 0, 0, 0.5)");cC.add("box-shadow","3px 3px 16px rgba(0, 0, 0, 0.5)");cC.init();var cC=new CssClass(".lpg_contentBox input[type=text]");cC.add("width","80%");cC.add("padding","2px");cC.init();var cC=new CssClass(".lpg_contentBox input[type=password], .lpg_contentBox input[type=text], .lpg_contentBox select");cC.add("border-radius","5px");cC.add("width","95%");cC.add("border","1px solid #cccccc");cC.add("padding","5px");cC.add("margin","0px");cC.init();var cC=new CssClass(".lpg_contentBox input[type=checkbox]");cC.add("margin","0px 3px");cC.init();var cC=new CssClass("#lgp_failedLoginHolder");cC.add("width","80%");cC.add("border","1px solid red");cC.add("background","#ffebe8");cC.add("padding","5px");cC.add("font-size","11px");cC.add("color","black");cC.init();var cC=new CssClass("#lgp_failedLoginHolder div");cC.add("margin-bottom","3px");cC.init();var cC=new CssClass(".lp_darkButton");cC.add("display","inline-block");cC.add("vertical-align","baseline");cC.add("margin","0 2px");cC.add("outline","none");cC.add("cursor","pointer");cC.add("text-align","center");cC.add("text-decoration","none");cC.add("font","14px/100% Arial, Helvetica, sans-serif");cC.add("border-radius","5px");cC.add("padding","5px 10px 5px 10px");cC.add("color","white");cC.add("border","solid 1px #7a7a7a");cC.add("background","#8d8d8d");cC.add("background","-webkit-gradient(linear, left top, left bottom, from(#8d8d8d), to(#4f4f4f))");cC.add("background","-moz-linear-gradient(top, #8d8d8d, #4f4f4f)");cC.add("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr='#8d8d8d, endColorstr='#4f4f4f)");cC.init();var cC=new CssClass(".lp_darkButton:hover");cC.add("background","#4f4f4f");cC.add("background","-webkit-gradient(linear, left top, left bottom, from(#4f4f4f), to(#8d8d8d))");cC.add("background","-moz-linear-gradient(top, #4f4f4f, #8d8d8d)");cC.add("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr='#4f4f4f, endColorstr='#8d8d8d)");cC.init();var cls=new CssClass(".lp_darkButton:active");cls.add("position","relative");cls.add("top","1px");cls.init();}
;}
;

function Video(){this.highRes;this.standardRes;this.lowRes;this.loop;this.muted;this.delay;this.id;this.nextIndex;this.autoplay;this.horizontalAlign="center";this.verticalAlign="top";this.sizeValue="cover";this.poster;this.onShow;this.onEnd;this.played;this.element;this.holder;}
;Video.prototype=new VideoBase();function VideoBase(){
this.addSource=function(source,quality){if(!quality){return ;}

var video=this;video[quality]=source;}
;
this.getSource=function(quality){if(this[quality+"Res"]){return this[quality+"Res"];}

return this.standardRes||this.lowRes||this.highRes;}
;
this.setAlign=function(){if(!this.element){return ;}

var videoEl=this.element;videoEl.style.width=(videoEl.style.width&&elStyle.width.indexOf("%")>=0)?videoEl.style.width:(this.horizontalAlign=="center")?"":"auto";videoEl.style.height=(videoEl.style.height&&elStyle.height.indexOf("%")>=0)?videoEl.style.height:"";if(this.horizontalAlign=="right"){this.element.parentNode.style.textAlign="";videoEl.style.right="0";videoEl.style.left="auto";this.element.style.position="";}

else if(this.horizontalAlign=="left"){this.element.parentNode.style.textAlign="";videoEl.style.right="";videoEl.style.left="0";this.element.style.position="";}

else if(this.sizeValue!="cover"){this.setSize();}

if(this.verticalAlign!=="top"){videoEl.style.top="auto";videoEl.style.bottom="0";}

}
;
this.fixSize=function(){if(!this.element){return ;}

if(this.sizeValue.indexOf("%")<0){this.setSize();return ;}

var sizeValues=this.sizeValue.split(" ");this.element.style.width=sizeValues[0];this.element.style.height=sizeValues[1]||sizeValues[0];}
;
this.setSize=function(){var videoEl=this.element;if(!videoEl){return ;}

var totalWidth=videoEl.parentNode.clientWidth||window.innerWidth||document.documentElement.offsetWidth;var totalHeight=videoEl.parentNode.clientHeight||window.innerHeight||document.documentElement.offsetHeight;var vW=videoEl.videoWidth||16;var vH=videoEl.videoHeight||9;var isCover=(this.sizeValue==="cover");if(totalWidth/totalHeight>vW/vH){videoEl.style.width=(!isCover)?"auto":(B.isSafari())?"100%":"";videoEl.style.height=(isCover)?"auto":(B.isSafari())?"100%":"";}

else 
{videoEl.style.height=(!isCover)?"auto":(B.isSafari())?"100%":"";videoEl.style.width=(isCover)?"auto":(B.isSafari())?"100%":"";}

if(this.horizontalAlign==="right"){videoEl.style.right="0";videoEl.style.left="auto";}

else if(this.horizontalAlign==="left"){videoEl.style.right="";videoEl.style.left="";}

else 
{var leftVal=(totalWidth-videoEl.offsetWidth)/2;videoEl.style.left=leftVal+"px";}

}
;
this.destroy=function(){if(this.element){this.element.parentNode.removeChild(this.element);}

delete(VideoDisplay.videos[this.id]);}
;
this.load=function(){if(!this.element){return ;}

this.element.preload="auto";this.element.currentSrc="";this.element.load();}
;
this.queue=function(){if(this.element||(this.lowRes==""&&this.highRes==""&&this.standardRes=="")){return ;}

CssUtil.addClassToEl(this.holder,"a-meta-video-holder");if(B.isSafari()){this.element=this.createForSafari();}

else 
{this.element=this.createForAll();}

VideoDisplay.attachEvents(this);CssUtil.addClassToEl(this.element,"a-meta-no-tile");CssUtil.addClassToEl(this.element,"a_skip");this.element.poster=this.poster;this.setAlign();if(this.autoplay!=="true"){return ;}

VideoDisplay.play(this);}
;
this.createForSafari=function(source){this.safariHolder=cE("iframe",this.holder);CssUtil.addClassToEl(this.safariHolder,"a-meta-no-tile");CssUtil.addClassToEl(this.safariHolder,"a_skip");var doc=video.holder.contentWindow.document;doc.open();var vidString="<html style=\"padding: 0; margin: 0; width: 100%; height: 100%;\"><body style=\"padding: 0; margin: 0; width: 100%; height: 100%;\">";vidString+="<video";if(this.muted!=="false"){vidString+=" muted";}

if(this.loop==="true"){vidString+=" loop";}

vidString+=" preload=\"";if(this.autoplay==="true"){vidString+="auto\"";}

else 
{vidString+="none\"";}

vidString+=" id=\""+this.id+"\"";vidString+=" style=\"width: 100%;\"";vidString+=">";var source=this.getSource(VideoDisplay.quality);var sources=source.split(",");for(var i=0;i<sources.length;i++)
{var typeStr=(sources[i].indexOf("webm")>=0)?"video/webm":"video/mp4";vidString+="<source type=\""+typeStr+"\" src=\""+sources[i];vidString+=" />";}

vidString+="</video></body></html>";doc.write(vidString);doc.close();return this.safariHolder.contentDocument.body.lastElementChild;}
;
this.createForAll=function(){var v=cE("video");v.id=this.id;if(this.muted==="true"){v.muted=true;if(v.setAttribute){v.setAttribute("muted","true");}

}

if(this.loop==="true"){v.loop=true;}

if(this.autoplay==="true"){v.preload="auto";}

else 
{v.preload="none";}

var sourceStr=this.getSource(VideoDisplay.quality);var sources=sourceStr.split(",");for(var i=0;i<sources.length;i++)
{var source=cE("source");source.src=sources[i];source.type=(sources[i].indexOf("mp4")>=0)?"video/mp4":"video/webm";aE(v,source);}

aE(this.holder,v);return v;}
;}
;
;
var VideoDisplay=VideoDisplay||new VideoDisplayBase();function VideoDisplayBase(){this.counter=0;this.videos={}
;this.pendingVideos=[];this.quality="low";this.queing;
this.fixSize=function(){var videos=this.videos;if(!videos||videos.length<=0){return ;}

for(var i in videos)
{video=videos[i];video.fixSize();}

}
;
this.addResizeEvent=function(){var thisObj=this;var resizeFx=function(){thisObj.fixSize();}
;E.add(window,"resize",resizeFx);if(!A.isEditMode()){return ;}

setInterval(resizeFx,500);}
;
this.get=function(videoId){return this.videos[videoId];}
;
this.add=function(video){if((video.id&&this.videos[video.id])||this.pendingVideos.indexOf(video)>=0){return ;}

this.counter++;this.pendingVideos.push(video);}
;
this.queue=function(videoObj){if(this.queing){return ;}

var videoIndex=0;if(videoObj){videoIndex=this.pendingVideos.indexOf(videoObj);videoIndex=(videoIndex<0)?0:videoIndex;}

var video=this.pendingVideos[videoIndex];if(!video){return ;}

this.queing=true;var vidId=video.id||video.holder.id+"-video-"+this.counter;video.id=vidId;this.videos[vidId]=video;video.queue();this.pendingVideos.splice(videoIndex,1);if(video.autoplay==="true"){return ;}

this.queing=false;this.queue();}
;
this.addFromAction=function(videos,holder,defaultEnd,defaultShow){if(!videos||videos.length<=0||!holder||B.isIOS()||B.isAndroid()){return ;}

for(var i=0;i<videos.length;i++)
{var video=new Video();for(var j in videos[i])
{if(j=="onEnd"||j=="onShow"){video[j]=eval(videos[i][j]);continue;}

video[j]=videos[i][j];}

if( typeof video.onEnd!="function"){video.onEnd=eval(defaultEnd);}

if( typeof video.onShow!="function"){video.onShow=eval(defaultShow);}

video.holder=holder;this.add(video);}

this.queue();}
;this.stop=function(videoData){if(!videoData){return ;}

var video=(typeof(videoData)=="object")?videoData:this.get(videoData);if(!video||!video.element){return ;}

CssUtil.removeClassFromEl(video.element,"video-active");video.element.pause();if(video.safariHolder){CssUtil.removeClassFromEl(video.safariHolder,"video-active");}

}


this.play=function(videoData){var video=(typeof(videoData)=="object")?videoData:this.get(videoData);if(!video||!video.element){return ;}

var thisObj=this;var playFx=function(){if(video.loop&&video.played){return ;}

thisObj.playVideo(video);}
;if(video.delay&&video.delay>0){setTimeout(playFx,video.delay);return ;}

else if(video.element.readyState==0){this.load(video);}

if(video.element.readyState<4){video.element.muted=true;video.element.play();video.element.pause();video.element.muted=video.element.defaultMuted;E.add(video.element,"canplaythrough",playFx);return ;}

this.playVideo(video);}
;
this.playVideo=function(video){video.element.play();video.played=true;video.fixSize();CssUtil.addClassToEl(video.element,"video-active");if(video.safariHolder){CssUtil.addClassToEl(video.safariHolder,"video-active");}

if( typeof video.onShow!="function"){return ;}

video.onShow();}
;
this.attachEvents=function(video){if(!video||!video.element){return ;}

var thisObj=this;var loadFx=function(){thisObj.queing=false;if(video.loop&&video.played){return ;}

thisObj.queue();}
;if(video.element.readyState>=3){loadFx();}

else 
{E.add(video.element,"canplay",loadFx);}

var endFx=function(){if( typeof video.onEnd=="function"){video.onEnd();}

if(!video.nextIndex){return ;}

thisObj.play(video.nextIndex);}
;E.add(video.element,"ended",endFx);}
;
this.load=function(videoData){var video=(typeof(videoData)=="object")?videoData:this.get(videoData);if(!video){return ;}

video.load();}
;
this.remove=function(videoHolder){if(!videoHolder){return ;}

var parentEl=( typeof videoHolder=="object")?videoHolder:gE("#"+videoHolder);if(!parentEl){return ;}

for(var i in this.videos)
{var video=this.videos[i];if(video.holder!==parentEl){continue;}

video.destroy();}

CssUtil.removeClassFromEl(parentEl,"a-meta-video-holder");}
;
this.getVideos=function(videoHolder){if(!videoHolder){return ;}

var parentEl=( typeof videoHolder=="object")?videoHolder:gE("#"+videoHolder);if(!parentEl){return ;}

var holderVideos=[];for(var i in this.videos)
{var video=this.videos[i];if(video.holder!=parentEl){continue;}

holderVideos.push(video);}

return holderVideos;}
;
this.initDefaultClasses=function(){var videoClass=null;if(B.isSafari()){videoClass=new CssClass(".a-meta-video-holder iframe");}

else 
{videoClass=new CssClass(".a-meta-video-holder video");}

videoClass.add("width","100%");videoClass.add("height","100%");videoClass.add("position","absolute");videoClass.add("top","0");videoClass.add("left","0");videoClass.add("opacity","0");videoClass.init();var activeVidClass=new CssClass(".video-active");activeVidClass.add("opacity","1 !important");activeVidClass.init();var containerClass=new CssClass(".a-meta-video-holder");containerClass.add("overflow","hidden");containerClass.init();}
;
this.setQualityBySpeed=function(){var rtPlugin=cE("script");rtPlugin.type="text/javascript";rtPlugin.src="https://s3.amazonaws.com/net.eximo.test/Boomerang/rt.js";var boomerangEl=cE("script");boomerangEl.type="text/javascript";boomerangEl.src="https://s3.amazonaws.com/net.eximo.test/Boomerang/boomerang.js";var thisObj=this;var rtLoad=function(){var beaconObj={beacon_url:"https://s3.amazonaws.com/net.eximo.test/Boomerang/bmImages/image-4.png",log:null}
;var afterInitFx=function(o){if(!o.t_done||o.t_done>=4000){return ;}

else if(o.t_done<2000){thisObj.quality="high";}

else 
{thisObj.quality="standard";}

}
;BOOMR.subscribe('before_beacon',afterInitFx);BOOMR.init(beaconObj);}
;var boomLoad=function(){var rtPlugin=cE("script");rtPlugin.type="text/javascript";rtPlugin.src="https://s3.amazonaws.com/net.eximo.test/Boomerang/rt.js";E.add(rtPlugin,"load",rtLoad);aE(document.head,rtPlugin);}
;E.add(boomerangEl,"load",boomLoad);aE(document.head,boomerangEl);}
;this.setQualityBySpeed();this.initDefaultClasses();this.addResizeEvent();}
;

;var VideoHandler=new VideoHandlerBase();function VideoHandlerBase(){this.init=function(actionData,data){var el=gE("#"+data.elId);VideoDisplay.addFromAction(actionData.videos,el,actionData.onEnd,actionData.onShow);}
;}
;ActionHandler.registerAction("videoHandler",VideoHandler);

var CssTransitionUtil=new CssTransitionUtilBase();function CssTransitionUtilBase(){this.map={}
;this.getTransition=function(id){if(!id){return null;}

var t=this.map[id];if(!t){t=new Transition();t.id=id;this.map[id]=t;}

return t;}
;this.getTestClassName=function(stateId,stepIndex){var stepCount=stepIndex+1;return "testCssTransId"+stateId+"_"+stepCount;}
;this.runOnload=function(){if(A.isEditMode()){return ;}

var transitions=getMasterCache().getRecordsByType("css_transition_state");for(var i=0;i<transitions.length;i++)
{var record=transitions[i];var t=CssTransitionUtil.getTransition(record.getId());if(record.getField("do_onload").getValue()){t.status="on";}

t.undoTransition();}

}
;{var thisObj=this;var fx=function(){thisObj.runOnload();}
;BodyOnloader.addFxForBeforeLoad(fx);}

}
;

var UrlUtil=new UrlUtilBase();function UrlUtilBase(){this.isFromOutsideDomain=function(imageEl){var str="http://"+window.location.host;return (imageEl.src.substr(0,str.length)!=str);}
;this.addParamsToUrl=function(url,newParams){var baseUrl=this.getUrlWithNoParams(url);var params=this.parseQueryString(url);for(var i in newParams)
{params[i]=newParams[i];}

var queryStr=this.createQueryString(params);return (!queryStr)?baseUrl:baseUrl+"?"+queryStr;}
;this.removeParamsFromUrl=function(url,paramsToRemove){var baseUrl=this.getUrlWithNoParams(url);var params=this.parseQueryString(url);for(var i=0;i<paramsToRemove.length;i++)
{delete(params[paramsToRemove[i]]);}

var queryStr=this.createQueryString(params);return (!queryStr)?baseUrl:baseUrl+"?"+queryStr;}
;this.getExtension=function(url){var cleanUrl=this.getUrlWithNoParams(url);var start=cleanUrl.lastIndexOf(".");var ext=cleanUrl.substring(start+1);return ext.toLowerCase();}
;this.removeOrigin=function(url){var origin=window.location.origin;if(url.substring(0,origin.length)!=origin){return url;}

return url.substring(origin.length);}
;
this.getUrlWithNoParams=function(url){var end=url.indexOf("?");if(-1==end){return url;}

else 
{return url.substring(0,end);}

}

this.parseQueryString=function(url){var params={}
;var start=url.indexOf("?");if(-1==start){return params;}

var qS=url.substring(start+1);var keyValues=qS.split("&");for(var i=0;i<keyValues.length;i++)
{var kV=keyValues[i];if(""==kV){continue;}

var data=kV.split("=");params[data[0]]=data[1];}

return params;}
;this.createQueryString=function(params){var str="";for(var i in params)
{str+=i+"="+params[i]+"&";}

if("&"==str.charAt(str.length-1)){str=str.substring(0,str.length-1);}

return str;}
;
this.callBackCounter=0;this.getJSONFromUrl=function(url,receiver){var separator="&";if(url.indexOf("?")==-1){separator="?";}

var script=document.createElement("script");var date=new Date();this.callBackCounter=this.callBackCounter+1;var callBack="callBackFunction"+this.callBackCounter;window[callBack]=function(data){receiver(data);}
;script.src=url+separator+"callback="+callBack;document.head.appendChild(script);}
;}
;

;function Transition(){this.id;this.mc=getMasterCache();this.status="off";this.currentStep=-1;this.activeClasses={}
;this.transSheet;this.incrTimerId;this.decrTimerId;}
;Transition.prototype=new TransitionBase();function TransitionBase(){this.doTransition=function(){var record=this.getRecord();if(!record){return ;}

this.clearTimers();this.incrementStatus(record);this.increment(record);}
;this.undoTransition=function(){var record=this.getRecord();if(!record){return ;}

this.clearTimers();this.decrement(record);}
;this.clearTimers=function(){window.clearTimeout(this.decrTimerId);window.clearTimeout(this.incrTimerId);}
;this.addDataToLoad=function(){var mc=this.mc;mc.addRecordToLoad("css_transition_state",this.id);}
;this.addAction=function(actionData,data){var eventType=actionData.event;var isTurnOn=("off"!=actionData.action);var thisObj=this;var fx=function(){if(isTurnOn){thisObj.doTransition();}

else 
{thisObj.undoTransition();}

}
;var el=gE("#"+data.elId);if(eventType=="rightclick"){eventType="contextmenu";}

E.on(el,eventType,fx);}
;this.getRecord=function(){return this.mc.getRecord("css_transition_state",this.id);}
;this.finish=function(){var record=this.getRecord();var doLoop=record.getField("do_loop").getValue();if(doLoop){this.prepareLoop();}

var finishInfo=record.getField("finish_info");var fieldNames=finishInfo.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{this.runFinisher(finishInfo.getChildField(fieldNames[i]));}

}
;this.runFinisher=function(finisher){var id=finisher.getChildField("transition.id").getValue();var transition=new Transition();transition.id=id;transition.doTransition();}
;this.prepareLoop=function(){var record=this.getRecord();this.clearTransitionProp(record);var steps=record.getField("intermediate_steps");var fieldNames=steps.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var step=steps.getChildField(fieldNames[i]);var cssId=step.getChildField("style_sheet.id").getValue();StyleSheetUtil.disableSheetById(cssId);}

this.status="running";this.currentStep=0;this.increment(record);}
;this.increment=function(transRecord){if(-1==this.currentStep){debugger;}

var step=transRecord.getField("intermediate_steps").getChildField(this.currentStep);var cssId=step.getChildField("style_sheet.id").getValue();this.setTransitionProp(transRecord,step);var thisObj=this;var onloadFx=function(){thisObj.onAfterSheetLoad(transRecord);}
;StyleSheetUtil.enableSheetById(cssId,onloadFx);}
;this.onAfterSheetLoad=function(transRecord){var thisObj=this;var fx=function(e){thisObj.finishIncrement(transRecord);}
;var delay=this.getDuration(transRecord);var now=new Date();this.incrTimerId=window.setTimeout(fx,delay);}
;this.finishIncrement=function(transRecord){this.incrementStatus(transRecord);if(this.status=="running"){this.increment(transRecord);}

else if(this.status=="on"){this.finish();}

}
;this.incrementStatus=function(transRecord){if(this.status=="off"){this.status="running";this.currentStep=0;return ;}

if(this.status=="decrementing"){this.currentStep=Math.max(0,this.findCurrentStep(transRecord));this.status="running";return ;}

if((this.currentStep+1)<transRecord.getField("intermediate_steps").getChildFieldCount()){this.currentStep++;}

else 
{this.status="on";}

}
;this.clearTransitionProp=function(transRecord){var sheet=this.getCleanTransSheet();var selectors=transRecord.getField("selectors").getValue();for(var i=0;i<selectors.length;i++)
{var clsStr="."+selectors[i]+"{transition:all 0s linear}";sheet.insertRule(clsStr,0);}

}
;this.setTransitionProp=function(transRecord,step){var prop=step.getChildField("transition_property").getValue();var sheet=this.getCleanTransSheet();var selectors=transRecord.getField("selectors").getValue();for(var i=0;i<selectors.length;i++)
{var clsStr="."+selectors[i]+"{transition:"+prop+"}";sheet.insertRule(clsStr,0);}

}
;this.getCleanTransSheet=function(){if(!this.transSheet){this.transSheet=StyleSheetUtil.createStyleSheet(document);}

var sheet=this.transSheet;for(var i=sheet.cssRules.length-1;i>=0;i--)
{sheet.deleteRule(i);}

return sheet;}
;this.getDuration=function(transRecord){var step=transRecord.getField("intermediate_steps").getChildField(this.currentStep);var value=step.getChildField("transition_property").getValue();var rE=/(\d*\.?\d+)s/;var result=rE.exec(value);if(!result){return 500;}

var duration=parseFloat(result[1]);var delayRE=/(\d*\.?\d+)s$/;var delayResult=delayRE.exec(value);if(delayResult){duration+=parseFloat(delayResult[1]);}

return duration*1000;}
;this.decrement=function(transRecord){if(this.status=="running"&&this.currentStep==1){debugger;}

this.decrementStatus(transRecord);if(this.status=="off"){this.finish();return ;}

var step=transRecord.getField("intermediate_steps").getChildField(this.currentStep);var cssId=step.getChildField("style_sheet.id").getValue();this.setTransitionProp(transRecord,step);StyleSheetUtil.removeSheetById(cssId);var thisObj=this;var fx=function(e){thisObj.decrement(transRecord);}
;var delay=this.getDuration(transRecord)-50;this.decrTimerId=window.setTimeout(fx,delay);}
;this.decrementStatus=function(transRecord){if(this.status=="on"){this.status="decrementing";this.currentStep=transRecord.getField("intermediate_steps").getChildFieldCount()-1;return ;}

if(this.status=="running"){this.currentStep=Math.max(0,(this.findCurrentStep(transRecord)));this.status="decrementing";return ;}

if(this.currentStep>0){this.currentStep--;}

else 
{this.status="off";}

}
;this.findCurrentStep=function(transRecord){var count=-1;var steps=transRecord.getField("intermediate_steps");var fieldNames=steps.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var step=steps.getChildField(fieldNames[i]);var id=step.getChildField("style_sheet.id").getValue();if(StyleSheetUtil.findSheetElById(id)){count++;}

else 
{return count;}

}

return count;}
;}



;;var TransitionAction=new TransitionActionBase();function TransitionActionBase(){this.init=function(actionData,data){if(A.isEditMode()){return ;}

var t=CssTransitionUtil.getTransition(actionData.id);t.addAction(actionData,data);t.addDataToLoad();}
;}

ActionHandler.registerAction("Transition",TransitionAction);

;;;;;;;;;;;;;;;;;;;;;
CONTENT_MARKER_BEGIN='vml.41gp0bHUUtfq.n-mro';

function WCMTransition(){this.gatesClassName;this.contentClassName;this.timeOut=600;this.closeImgPath;}

WCMTransition.prototype=new WCMTransitionBase();function WCMTransitionBase(){
this.init=function(parentEl,htmlStr){this.parentEl=parentEl;this.parentEl.innerHTML="";this.onScreenResize();E.resize(this.onScreenResize);var divDownGate=cE("div",parentEl);divDownGate.className=this.gatesClassName+" tr-gate-off";this.divDownGate=divDownGate;var divUpGate=cE("div",parentEl);divUpGate.className=this.gatesClassName+" tr-gate-off";this.divUpGate=divUpGate;this.appendHTMLcontent(htmlStr);var thisObj=this;var timeOutFunction;var fx=function(){thisObj.divUpGate.className=thisObj.gatesClassName+" tr-Up-gate-on";thisObj.divDownGate.className=thisObj.gatesClassName+" tr-Down-gate-on";thisObj.show(thisObj.htmlStr);clearTimeout(timeOutFunction);}
;timeOutFunction=setTimeout(fx,thisObj.timeOut);}


this.onScreenResize=function(){var parentEl=gE(".active-layover");var header=gE(".header");if(parentEl!=null){parentEl.style.zIndex=CssUtil.getHighestZIndex();header.style.zIndex=CssUtil.getHighestZIndex();}

}


this.appendHTMLcontent=function(htmlStr){var divInfo=cE("div",this.parentEl);divInfo.innerHTML="";divInfo.className="tr-contentOff";this.divInfo=divInfo;var HTMLcontent=cE("div",this.divInfo);HTMLcontent.className="tr-contentOff";this.HTMLcontent=HTMLcontent;this.HTMLcontent.innerHTML=htmlStr;}


this.show=function(){var thisObj=this;var clearTimeAppendContets;var appendCloseButton=function(){thisObj.divInfo.className=thisObj.contentClassName+" tr-contentOn";thisObj.HTMLcontent.className=thisObj.contentClassName+" tr-contentOn";var divCloseButton=cE("div",thisObj.divInfo);divCloseButton.className="closeButton";this.divCloseButton=divCloseButton;var onClick=function(){thisObj.closeFX();}
;var image=cE("img",divCloseButton);image.src=thisObj.closeImgPath;image.style.margin="17px";E.click(image,onClick);clearTimeout(clearTimeAppendContets);}

clearTimeAppendContets=setTimeout(appendCloseButton,this.timeOut);var timeOutFunction;var fx=function(){debugger;thisObj.divUpGate.className=thisObj.gatesClassName+" tr-open-Up-gate";thisObj.divDownGate.className=thisObj.gatesClassName+" tr-open-Down-gate";clearTimeout(timeOutFunction);var onOpenFX=function(){if(thisObj.onOpen){thisObj.onOpen();}

var trSupport=thisObj.isTransitionsSupported(document.createElement('div'));if(trSupport){thisObj.divDownGate.removeEventListener('transitionend',onOpenFX,false);}

}

var trSupport=thisObj.isTransitionsSupported(document.createElement('div'));if(trSupport){thisObj.divDownGate.addEventListener('transitionend',onOpenFX,false);}

else 
{window.setTimeout(onOpenFX,2000);}

}

timeOutFunction=setTimeout(fx,this.timeOut);}


this.isTransitionsSupported=function(element){this.element=element;var transitions={
'MozTransition':'transitionend',
'WebkitTransition':'webkitTransitionEnd',
'transition':'transitionEnd',
'MSTransition':'msTransitionEnd',
'OTransition':'oTransitionEnd'
}
;for(var t in transitions){if(this.element.style[t]!==undefined){return transitions[t];}

}

return ;}


this.closeFX=function(){if(this.onClose){this.onClose();}

var thisObj=this;var timeOutFunction;var initCloseFX=function(){thisObj.divUpGate.className=thisObj.gatesClassName+" tr-Up-gate-on";thisObj.divDownGate.className=thisObj.gatesClassName+" tr-Down-gate-on";thisObj.clearHTMLElements();clearTimeout(timeOutFunction);}

timeOutFunction=setTimeout(initCloseFX,this.timeOut);}


this.clearHTMLElements=function(){var thisObj=this;var timeOutFunction;var finishCloseFx=function(){thisObj.divUpGate.className=thisObj.gatesClassName+" tr-gate-off";thisObj.divDownGate.className=thisObj.gatesClassName+" tr-gate-off";thisObj.divInfo.className=thisObj.contentClassName+" tr-contentOff";thisObj.divInfo.innerHTML="";var clearParentEl=function(){thisObj.parentEl.className="closeParentElCSS";thisObj.divUpGate.removeEventListener('transitionend',clearParentEl,false);}

thisObj.divUpGate.addEventListener('transitionend',clearParentEl,false);clearTimeout(timeOutFunction);}

timeOutFunction=setTimeout(finishCloseFx,this.timeOut);}

}

CONTENT_MARKER_END='vml.41gp0bHUUtfq.n-mro';
