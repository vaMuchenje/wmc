
CONTENT_MARKER_BEGIN='vml.41gp0Sf-ugwSjllVheowmdv';

function redirectToMaster(){if((!g_params.mode||g_params.mode!="visual_edit")&&g_params.fu!="master-page"&&window.top==window){window.location="/master-page#"+g_params.fu;}

}
;redirectToMaster();
CONTENT_MARKER_END='vml.41gp0Sf-ugwSjllVheowmdv';
