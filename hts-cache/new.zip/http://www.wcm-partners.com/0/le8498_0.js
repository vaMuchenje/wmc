

var LiveFieldHandler=new LiveFieldHandlerBase();function LiveFieldHandlerBase(){this.mc;this.converters={}
;this.init=function(data){var element=gE("#"+data.elId);var cType=data.converter||"read";var converter=this.getConverter(data.fieldType,cType);if(converter){converter.init(data,element);}

else 
{this.preventEdit(data,element);}

}
;this.preventEdit=function(data,element){var doNothing=function(){}
;E.click(element,doNothing);}

this.removeAncestorEdit=function(element){while(element.tagName!="BODY")
{LivePage.makeElReadOnly(element);element=element.parentNode;}

}
;this.getConverter=function(fieldTypeName,converterName){var converters=this.converters[converterName];if(!converters){return null;}

return converters[fieldTypeName]||null;}
;this.registerConverter=function(fieldTypeName,converterName,converter){var converters=this.converters[converterName];if(!converters){var converters={}
;this.converters[converterName]=converters;}

converters[fieldTypeName]=converter;}
;this.initHandler=function(mc){this.mc=mc;ATagInitializer.addSpecialModeHandler("visual_edit","field",this);}
;}


var LiveShortTextRead=new LiveShortTextReadBase();function LiveShortTextReadBase(){this.focusEl;this.focusElHtml;this.init=function(data,node){node.contentEditable="true";var thisObj=this;var fx=function(){EditUtil.setEditEl(node);thisObj.focusEl=node;thisObj.focusElHtml=node.outerHTML;}
;E.focus(node,fx);var fx=function(){debugger;if(thisObj.focusEl!=node){thisObj.focusEl=null;return ;}

thisObj.focusEl=null;if(node.outerHTML==thisObj.focusElHtml){return ;}

LivePage.setElementToSave(node);}
;E.blur(node,fx);var doNothing=function(){}
;E.click(node,doNothing);}
;}
;LiveFieldHandler.registerConverter("TEXT","read",LiveShortTextRead);LiveFieldHandler.registerConverter("LONG_TEXT","read",LiveShortTextRead);

var UrlUtil=new UrlUtilBase();function UrlUtilBase(){this.isFromOutsideDomain=function(imageEl){var str="http://"+window.location.host;return (imageEl.src.substr(0,str.length)!=str);}
;this.addParamsToUrl=function(url,newParams){var baseUrl=this.getUrlWithNoParams(url);var params=this.parseQueryString(url);for(var i in newParams)
{params[i]=newParams[i];}

var queryStr=this.createQueryString(params);return (!queryStr)?baseUrl:baseUrl+"?"+queryStr;}
;this.removeParamsFromUrl=function(url,paramsToRemove){var baseUrl=this.getUrlWithNoParams(url);var params=this.parseQueryString(url);for(var i=0;i<paramsToRemove.length;i++)
{delete(params[paramsToRemove[i]]);}

var queryStr=this.createQueryString(params);return (!queryStr)?baseUrl:baseUrl+"?"+queryStr;}
;this.getExtension=function(url){var cleanUrl=this.getUrlWithNoParams(url);var start=cleanUrl.lastIndexOf(".");var ext=cleanUrl.substring(start+1);return ext.toLowerCase();}
;this.removeOrigin=function(url){var origin=window.location.origin;if(url.substring(0,origin.length)!=origin){return url;}

return url.substring(origin.length);}
;
this.getUrlWithNoParams=function(url){var end=url.indexOf("?");if(-1==end){return url;}

else 
{return url.substring(0,end);}

}

this.parseQueryString=function(url){var params={}
;var start=url.indexOf("?");if(-1==start){return params;}

var qS=url.substring(start+1);var keyValues=qS.split("&");for(var i=0;i<keyValues.length;i++)
{var kV=keyValues[i];if(""==kV){continue;}

var data=kV.split("=");params[data[0]]=data[1];}

return params;}
;this.createQueryString=function(params){var str="";for(var i in params)
{str+=i+"="+params[i]+"&";}

if("&"==str.charAt(str.length-1)){str=str.substring(0,str.length-1);}

return str;}
;
this.callBackCounter=0;this.getJSONFromUrl=function(url,receiver){var separator="&";if(url.indexOf("?")==-1){separator="?";}

var script=document.createElement("script");var date=new Date();this.callBackCounter=this.callBackCounter+1;var callBack="callBackFunction"+this.callBackCounter;window[callBack]=function(data){receiver(data);}
;script.src=url+separator+"callback="+callBack;document.head.appendChild(script);}
;}
;

function getAttributes(node,omitAttrs){var filteredAttrs={}
;var omitMap={"_moz_dirty":1,"contentEditable":1,"contenteditable":1,"atag":1}
;if(omitAttrs){for(var i in omitAttrs)
{omitMap[i]=1;}

}

var attributes=node.attributes;for(var i=0;i<attributes.length;i++)
{if(!attributes[i].specified){continue;}

var nodeName=attributes[i].nodeName;if(omitMap[nodeName]){continue;}

else if(IS_IE&&nodeName.toLowerCase()=="style"){if(BrowserUtil.isIE()){filteredAttrs["style"]=node.style.cssText.toLowerCase();}

else {var rE=/[^>]*style=['"]([^'"]*)/i;var result=rE.exec(node.outerHTML);if(result){filteredAttrs["style"]=result[1].toLowerCase();}

}

}

else 
{if(""!=attributes[i].value.trim()){filteredAttrs[nodeName]=attributes[i].value;}

else if(du_booleanAttrs[nodeName]){filteredAttrs[nodeName]="";}

}

}

return filteredAttrs;}
;var du_booleanAttrs={"checked":1,"selected":1,"disabled":1,"readonly":1,"multiple":1,"ismap":1,"isMap":1,"allowfullscreen":1,"allowFullScreen":1}
;function getChildByTagName(element,tagName){var nodes=getChildrenByTagName(element,tagName);return nodes[0];}

function getChildrenByTagName(element,tagName){tagName=tagName.toUpperCase();var nodes=[];for(var i=0;i<element.childNodes.length;i++)
{if(element.childNodes[i].tagName==tagName){nodes.push(element.childNodes[i]);}

}

return nodes;}


function getDescendentsWAttr(node,attributeName){var results=[];getDWAttrHelper(results,node,attributeName);return results;}

function getDWAttrHelper(results,node,attributeName){if(gA(node,attributeName)){results.push(node);}

for(var i=0;i<node.childNodes.length;i++)
{getDWAttrHelper(results,node.childNodes[i],attributeName);}

}

function getAttributeString(node,omitAttrs){var s="";var attrs=getAttributes(node,omitAttrs);for(var name in attrs)
{s+=name;if(attrs[name]){s+="=\""+attrs[name]+"\" ";}

else 
{ahtml+=" ";}

}

return s.substr(0,s.length-1);}
;
function replaceNodeTagName(tagName,originalNode,deepCopy){var parentEl=originalNode.parentElement;parentEl.removeChild(originalNode)
var newNode=cE(tagName,parentEl);var attrList=originalNode.attributes;for(var i=0;i<attrList.length;i++)
{var attr=attrList[i];sA(newNode,attr.nodeName,attr.nodeValue);}

if(deepCopy){var children=originalNode.children;for(var i=0;i<children.length;i++)
{var childNode=children[i].cloneNode(true);aE(newNode,childNode);}

}

return newNode;}


function switchNode(newNode,nodeToReplace){var parentEl=nodeToReplace.parentNode;var child=nodeToReplace.childNodes[0];while(child)
{child=nodeToReplace.removeChild(child);aE(newNode,child);child=nodeToReplace.childNodes[0];}

parentEl.replaceChild(newNode,nodeToReplace);}

function getNonTextChildNodes(element){var nodes=[];for(var i=0;i<element.childNodes.length;i++)
{if(element.childNodes[i].nodeType!=3){nodes.push(element.childNodes[i]);}

}

return nodes;}

function isDescendent(element,ancestor){if(!element||!ancestor){return false;}

while(element&&element.tagName!="BODY")
{if(element==ancestor){return true;}

element=element.parentNode;}

return false;}

function isBeforeSibling(element,sibling){if(!sibling){return false;}

var testEl=sibling.previousSibling;while(testEl)
{if(testEl==element){return true;}

testEl=testEl.previousSibling;}

return false;}

function insertParent(tagName,firstSibling,lastSibling,doc){if(!doc){doc=getParentDocument(firstSibling);}

var newEl=cE(tagName,null,doc);var parentEl=firstSibling.parentNode;parentEl.insertBefore(newEl,firstSibling);do
{var el=newEl.nextSibling.parentNode.removeChild(newEl.nextSibling);aE(newEl,el);}

while(firstSibling!=lastSibling&&newEl.nextSibling!=lastSibling);return newEl;}


function replaceNodeWithHtml(html,elToReplace){elToReplace.innerHTML=html;var isFirst=true;var firstEl=null;var parentEl=elToReplace.parentNode;while(elToReplace.childNodes.length>0)
{var element=elToReplace.removeChild(elToReplace.childNodes[0]);parentEl.insertBefore(element,elToReplace);if(isFirst){firstEl=element;isFirst=false;}

}

parentEl.removeChild(elToReplace);return firstEl;}

function insertAfter(toInsert,sibling){if(sibling.nextSibling){sibling.parentNode.insertBefore(toInsert,sibling.nextSibling);}

else 
{sibling.parentNode.appendChild(toInsert);}

}

function removeChildNodes(node,typesToRemove){for(var i=0;i<node.childNodes.length;i++)
{if(isTagType(node.childNodes[i],typesToRemove)){node.removeChild(node.childNodes[i]);}

}

}


function removeNode(node){if(!node){return ;}

node.normalize();var childs=[];for(var i=0;i<node.childNodes.length;i++)
{childs.push(node.childNodes[i]);}

for(var i=0;i<childs.length;i++)
{node.removeChild(childs[i]);}

var p=node.parentNode;for(var i=0;i<childs.length;i++)
{p.insertBefore(childs[i],node);}

p.removeChild(node);return node;}

function isTagType(node,tagNames){if(!node){return false;}

for(var i=0;i<tagNames.length;i++)
{if(tagNames[i]==node.tagName){return true;}

}

return false;}


function getNearestAncestor(node,tagName){return getAncestor(node,[tagName]);}


function getBlockAncestor(node){return getAncestor(node,du_blockTags);}

function getAncestor(node,tagNames){if(!node){return null;}

for(var i=0;i<tagNames.length;i++)
{tagNames[i]=tagNames[i].toUpperCase();}

while(node)
{for(var i=0;i<tagNames.length;i++)
{if(tagNames[i]==node.tagName){return node;}

}

node=node.parentNode;if(!node){return null;}

if("HTML"==node.tagName){return null;}

}

return null;}

function getAncestorByStyle(node,cssProp,value){if(!node){return null;}

while(node)
{if(value==CssUtil.getStyle(node,cssProp)){return node;}

node=node.parentNode;if(!node){return null;}

if("HTML"==node.tagName){return null;}

}

return null;}

function getPreviousSiblingByStyle(node,cssProp,value){return getSiblingByStyle(node,cssProp,value,true);}

function getNextSiblingByStyle(node,cssProp,value){return getSiblingByStyle(node,cssProp,value,false);}

function getSiblingByStyle(node,cssProp,value,isGoBack){if(!node){return null;}

node=isGoBack?node.previousElementSibling:node.nextElementSibling;while(node)
{if(value==CssUtil.getStyle(node,cssProp)){return node;}

node=isGoBack?node.previousElementSibling:node.nextElementSibling;if(!node){return null;}

}

return null;}

function getAncesterWClass(node,className){if(!node){return null;}

while(node)
{if("HTML"==node.tagName){return null;}

if(CssUtil.elHasClass(node,className)){return node;}

node=node.parentNode;if(!node){return null;}

}

return null;}

function getAncestorByStyles(node,cssProp,values){var valueMap={}
;for(var i in values)
{valueMap[values[i]]=1;}

if(!node){return null;}

while(node)
{if(valueMap[CssUtil.getStyle(node,cssProp)]){return node;}

node=node.parentNode;if(!node){return null;}

if("HTML"==node.tagName){return null;}

}

return null;}

function findSiblingIndex(node){var index=0;while(node.previousSibling)
{index++;node=node.previousSibling;}

return index;}

function findSibling(node,tagNames,isLookForward){while(node)
{if(isTagType(node,tagNames)){return node;}

node=isLookForward?node.nextSibling:node.previousSibling;}

return null;}

function getNextElement(node){if(node.children&&node.children.length>0){return node.children[0];}

else 
{while(!node.nextElementSibling)
{node=node.parentNode;if(!node){return null;}

}

return node.nextElementSibling;}

}

function getNextNode(node){if(node.childNodes&&node.childNodes.length>0){return node.childNodes[0];}

else 
{while(!node.nextSibling)
{node=node.parentNode;if(!node){return null;}

}

return node.nextSibling;}

}

function getPreviousNode(node){if(!node.previousElementSibling){return node.parentNode;}

return getLastDescendent(node.previousElementSibling);}

function getLastDescendent(node){if(node.childNodes.length==0){return node;}

else 
{var newNode;for(var i=node.childNodes.length-1;i>=0;i--)
{var temp=node.childNodes[i];if(temp.nodeType!=3){newNode=temp;break;}

}

if(!newNode){return node;}

return getLastDescendent(newNode)||newNode;}

}

var whiteSpaceTags=["BR"];
function doesContainContent(node){node=node.cloneNode(true);node.innerHTML=node.innerHTML.trim();if(node.innerHTML==""){return false;}

for(var i=0;i<node.childNodes.length;i++)
{if(!isTagType(node.childNodes[i],whiteSpaceTags)){return true;}

}

return false;}

function insertParentForChildren(aBlock,newParent){var children=[];var child=aBlock.firstChild;while(child)
{var nextChild=child.nextSibling;children.push(aBlock.removeChild(child));child=nextChild;}

aE(aBlock,newParent);while(0<children.length)
{aE(newParent,children[0]);children.splice(0,1);}

}



var DebugPopup=new DebugPoupBase();function DebugPoupBase(){this.width=200;this.popup;this.log=function(str){if(!this.popup){this.buildDebugInfo();}

this.debugArea.innerHTML+="<nobr>"+str+"</nobr><br>";}
;this.clear=function(){if(!this.popup){this.buildDebugInfo();}

this.debugArea.innerHTML="";}
;this.totalTime=0;this.start=function(){if(this.startTime){this.stop();}

this.startTime=new Date();}
;this.stop=function(){this.totalTime+=new Date()-this.startTime;this.startTime=null;}
;this.buildDebugInfo=function(){var popup=new Popup();popup.width=this.width;popup.setAsAnchor(document.body);popup.disableBg=false;popup.position="fixed";popup.zIndex=1000000;this.popup=popup;var contentArea=popup.build();contentArea.style.backgroundColor="#DADFE7";contentArea.style.border="3px double #b0b9c7";contentArea.style.overflow="auto";var totalHeight=window.innerHeight||document.body.clientHeight;contentArea.style.maxHeight=totalHeight+"px";this.debugArea=contentArea;popup.align();}
;}
;
;if(!window["DragHandler"]){var DragHandler=new DragHandlerBase();}

function DragHandlerBase(){this.dragInfo;this.dragFramer;this.moveHandler;this.isInited=false;
this.makeDraggable=function(element,props){props=props||{}
;props.triggerEl=props.triggerEl||element;var thisObj=this;var mouseDownFx=function(e){thisObj.attachInitMoveFx(element,props);thisObj.attachInitMouseUpFx(element,props);}
;E.mousedown(props.triggerEl,mouseDownFx);}
;this.coverScreen=function(){if(this.dragCover){return ;}

var cover=cE("div",document.body);cover.style.width="100%";cover.style.height="100%";cover.style.position="absolute";cover.style.top="0px";cover.style.left="0px";cover.style.zIndex=CssUtil.getHighestZIndex();cover.style.overflow="hidden";this.dragCover=cover;}

this.removeScreenCover=function(){if(!this.dragCover){return ;}

this.dragCover.parentElement.removeChild(this.dragCover);this.dragCover=null;}
;this.frameAsDragging=function(element){this.initFramer();this.dragFramer.frame(element);}
;this.hideDragFrame=function(){if(this.dragFramer){this.dragFramer.hideNow();}

}
;this.initFramer=function(){if(this.isInited){return ;}

this.initCss();this.isInited=true;this.dragFramer=new Framer("a-drag-frame-top","a-drag-frame-right","a-drag-frame-bottom","a-drag-frame-left");}
;this.attachInitMoveFx=function(element,props){var thisObj=this;var moveFx=function(e){E.stop(e);thisObj.initDrag(e,element,props);}
;this.initMoveHandler=moveFx;E.add(document.body,"mousemove",moveFx)
}
;this.attachInitMouseUpFx=function(element,props){var thisObj=this;var mouseUpFx=function(ev){var body=document.body;E.remove(body,"mousemove",thisObj.initMoveHandler);E.remove(body,"mouseup",thisObj.initMouseUpHandler);if(props.onClickNoDrag){props.onClickNoDrag(ev);}

}
;this.initMouseUpHandler=mouseUpFx;E.add(document.body,"mouseup",mouseUpFx);}
;this.initDrag=function(e,element,props){var body=document.body;var thisObj=this;E.remove(body,"mousemove",this.initMoveHandler);E.remove(body,"mouseup",this.initMouseUpHandler);var dragInfo={}
;this.dragInfo=dragInfo;dragInfo.elStartCoord=findElCoord(element);dragInfo.startX=e.clientX;dragInfo.startY=e.clientY;this.mouseOverEl=element;if(props.onDragStart){props.onDragStart(e);}

this.attachMoveFx(element,props);this.attachMouseUpFx(props.onDragEnd);}
;this.attachMoveFx=function(element,props){var thisObj=this;var moveFx=function(e){thisObj.coverScreen();E.stop(e);var dragInfo=thisObj.dragInfo;if(dragInfo){var dragEl=dragInfo.draggingEl;}

if(!dragEl){var dragEl;if(props.createDragElFx){dragEl=props.createDragElFx();}

else 
{dragEl=element.cloneNode(true);}

if(dragEl){dragEl.style.position="absolute";dragEl.style.left=dragInfo.elStartCoord.x+"px";dragEl.style.top=dragInfo.elStartCoord.y+"px";dragEl.style.zIndex=0;aE(document.body,dragEl);dragInfo.draggingEl=dragEl;dragInfo.xOffset=(thisObj.getXOffset)?thisObj.getXOffset(dragEl):0;dragInfo.yOffset=(thisObj.getYOffset)?thisObj.getYOffset(dragEl):0;}

}

if(dragEl){dragEl.style.left=Math.floor(dragInfo.elStartCoord.x+e.clientX-dragInfo.startX-dragInfo.xOffset)+"px";dragEl.style.top=Math.floor(dragInfo.elStartCoord.y+e.clientY-dragInfo.startY-dragInfo.yOffset)+"px";}

if(props.onDrag){props.onDrag(e);}

}
;this.moveHandler=moveFx;E.add(document.body,"mousemove",moveFx)
}
;this.attachMouseUpFx=function(onDragEnd){var thisObj=this;var mouseUpFx=function(ev){thisObj.removeScreenCover();var body=document.body;E.remove(body,"mousemove",thisObj.moveHandler);E.remove(body,"mouseup",mouseUpFx);var dragEl=thisObj.dragInfo.draggingEl;if(dragEl){dragEl.parentNode.removeChild(dragEl);}

thisObj.dragInfo=null;thisObj.mouseOverEl=null;thisObj.mouseOverEls=[];if(onDragEnd){onDragEnd();}

}
;E.add(document.body,"mouseup",mouseUpFx);}
;this.initCss=function(){var cssStyle=new css_StyleSheet();var cssClass=new css_CssClass("a-drag-frame-top");cssClass.addStyle("border-bottom","3px dashed #d6e0f5");cssClass.addStyle("height","3px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("a-drag-frame-bottom");cssClass.addStyle("border-top","3px dashed #d6e0f5");cssClass.addStyle("height","3px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("a-drag-frame-left");cssClass.addStyle("border-right","3px dashed #d6e0f5");cssClass.addStyle("width","3px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("a-drag-frame-right");cssClass.addStyle("border-left","3px dashed #d6e0f5");cssClass.addStyle("width","3px");cssStyle.addClass(cssClass);cssStyle.init();}
;}


;;var DragUtil=new DragUtilBase();function DragUtilBase(){this.dragInfo;this.mouseOverEl;this.mouseOverEls=[];this.overHandlers={}
;this.outHandlers={}
;this.dropHandlers={}
;this.handlerCount=0;this.getXOffset;this.getYOffset;
this.doc;this.makeDraggable=function(element,onDragInitialize,onDragStart,onDragEnd,createDragElFx){this.doc=element.ownerDocument;var thisObj=this;var mouseDownFx=function(e){if(onDragInitialize){onDragInitialize();}

var dragInfo={}
;thisObj.dragInfo=dragInfo;dragInfo.elStartCoord=findElCoord(element);dragInfo.startX=e.clientX;dragInfo.startY=e.clientY;thisObj.mouseOverEl=element;if(onDragStart){onDragStart();}

thisObj.attachMoveFx(element,createDragElFx);thisObj.attachMouseUpFx(onDragEnd);}
;eh_attachEvent("onmousedown",element,mouseDownFx,null,true,null,true,false,false);}
;this.attachDragOverEvent=function(element,fx){element.dragOverId=++this.handlerCount;this.overHandlers[element.dragOverId]=fx;}
;this.attachDragOutEvent=function(element,fx){element.dragOutId=++this.handlerCount;this.outHandlers[element.dragOutId]=fx;}
;this.attachDragDropEvent=function(element,fx){element.dragDropId=++this.handlerCount;this.dropHandlers[element.dragDropId]=fx;}
;this.isDragging=function(){return this.dragInfo;}
;this.attachMouseUpFx=function(onDragEnd){var thisObj=this;var mouseUpFx=function(ev){var doc=thisObj.doc;var body=doc.body;eh_removeEventHandler(body,"onmousemove",thisObj.mouseMoveHandler);eh_removeEventHandler(body,"onmouseup",mouseUpFx);thisObj.runDragDrops();var dragEl=thisObj.dragInfo.element;if(dragEl){dragEl.parentNode.removeChild(dragEl);}

thisObj.dragInfo=null;thisObj.mouseOverEl=null;thisObj.mouseOverEls=[];if(onDragEnd){onDragEnd();}

}
;eh_addEvent("onmouseup",this.doc.body,mouseUpFx);}
;this.runDragDrops=function(){var element=this.mouseOverEl;while(element&&element.tagName!="BODY")
{if(element.dragDropId){var fx=this.dropHandlers[element.dragDropId];fx();}

element=element.parentNode;}

}
;this.attachMoveFx=function(element,createDragElFx){var thisObj=this;var moveFx=function(e){crossbrowser_stopEvent(e);var dragInfo=thisObj.dragInfo;var dragEl=dragInfo.element;if(!dragEl){var dragEl;if(createDragElFx){dragEl=createDragElFx();}

else 
{dragEl=element.cloneNode(true);}

dragEl.style.position="absolute";dragEl.style.left=dragInfo.elStartCoord.x+"px";dragEl.style.top=dragInfo.elStartCoord.y+"px";dragEl.style.zIndex=CssUtil.getHighestZIndex();aE(thisObj.doc.body,dragEl);dragInfo.element=dragEl;dragInfo.xOffset=(thisObj.getXOffset)?thisObj.getXOffset(dragEl):0;dragInfo.yOffset=(thisObj.getYOffset)?thisObj.getYOffset(dragEl):0;}

dragEl.style.left=Math.floor(dragInfo.elStartCoord.x+e.clientX-dragInfo.startX-dragInfo.xOffset)+"px";dragEl.style.top=Math.floor(dragInfo.elStartCoord.y+e.clientY-dragInfo.startY-dragInfo.yOffset)+"px";dragEl.style.display="none";var overEl=findElAt(e.clientX,e.clientY,thisObj.doc);thisObj.dispatchMouseEvent(overEl,e,"onmouseover");dragEl.style.display="";if(!thisObj.hasStateChanged(overEl)){return ;}

thisObj.mouseOverEl=overEl;thisObj.runDragOuts(overEl,e);thisObj.runDragOvers();}
;this.mouseMoveHandler=moveFx;eh_addEvent("onmousemove",this.doc.body,moveFx);}
;this.dispatchMouseEvent=function(element,event,eventType){var doc=this.doc;if(event.initMouseEvent){eventType=eventType.substring(2,eventType.length);var mouseEv=doc.createEvent("MouseEvent");mouseEv.initMouseEvent(eventType,true,true,window,0,
event.screenX,event.screenY,event.clientX,event.clientY,
event.ctrlKey,event.altKey,event.shiftKey,event.metaKey,
0,null);element.dispatchEvent(mouseEv);}

else 
{if(doc.createEventObject){var mouseEv=doc.createEventObject(window.event);element.fireEvent(eventType,mouseEv);}

}

}
;this.hasStateChanged=function(currentOverEl){return (this.mouseOverEl!=currentOverEl);}
;this.runDragOvers=function(){var element=this.mouseOverEl;while(element&&element.tagName!="BODY")
{if(element.dragOverId){this.handleDragOver(element);}

element=element.parentNode;}

}
;this.handleDragOver=function(element){for(var i=0;i<this.mouseOverEls.length;i++)
{if(this.mouseOverEls[i]==element){return ;}

}

this.mouseOverEls.push(element);var fx=this.overHandlers[element.dragOverId];fx(this.dragInfo.element);}
;this.runDragOuts=function(overEl,event){var overEl=this.mouseOverEl;for(var i=this.mouseOverEls.length-1;i>=0;i--)
{var outEl=this.mouseOverEls[i];var isOut=this.handleDragOut(outEl,overEl,event);if(isOut){this.mouseOverEls.splice(i,1);}

}

}
;this.handleDragOut=function(outEl,overEl,event){if(isDescendent(overEl,outEl)){return false;}

if(outEl.dragOutId){var fx=this.outHandlers[outEl.dragOutId];fx(this.dragInfo.element,overEl);}

return true;}
;}


function BlockBox(){this.boxTop;this.boxRight;this.boxBottom;this.boxLeft;this.isOverBox=false;this.isOverBlock=false;this.draggingEl;this.isDisabled;this.disable=function(){this.isDisabled=true;this.hideBlockBox();}
;this.enable=function(){this.isDisabled=false;}
;this.showBlockBox=function(block){if(this.isDisabled){return ;}

var coord=findElCoord(block);var thisObj=this;var enterFx=function(){thisObj.onMouseEnter();}
;var leaveFx=function(){thisObj.onMouseLeave();}
;var left=this.boxLeft;left.style.display="";left.style.left=(coord.x-left.offsetWidth)+"px";left.style.height=block.offsetHeight+"px";left.style.top=(coord.y)+"px";left.style.opacity="";E.mouseenter(left,enterFx);E.mouseleave(left,leaveFx);var right=this.boxRight;right.style.display="";right.style.left=(coord.x+block.offsetWidth)+"px";right.style.height=block.offsetHeight+"px";right.style.top=(coord.y)+"px";right.style.opacity="";E.mouseenter(right,enterFx);E.mouseleave(right,leaveFx);var top=this.boxTop;top.style.display="";var topOffset=coord.y-top.offsetHeight+1;top.style.top=topOffset+"px";top.style.left=(coord.x-left.offsetWidth)+"px";top.style.width=block.offsetWidth+left.offsetWidth+right.offsetWidth+"px";top.style.opacity="";fade_setOpacity(top,80);E.mouseenter(top,enterFx);E.mouseleave(top,leaveFx);var bottom=this.boxBottom;bottom.style.display="";bottom.style.left=(coord.x-left.offsetWidth)+"px";bottom.style.width=(block.offsetWidth+left.offsetWidth+right.offsetWidth)+"px";bottom.style.top=(coord.y+block.offsetHeight)+"px";bottom.style.opacity="";E.mouseenter(bottom,enterFx);E.mouseleave(bottom,leaveFx);var optionParent;if(topOffset<0){optionParent=bottom;bottom.style.height="";bottom.className="a_saBoxBottomHandle";}

else 
{optionParent=top;bottom.innerHTML="";bottom.style.height="2px";bottom.className="a_saBoxSide";}

var options=new BlockBoxOptionBar(block,this);options.build(optionParent,this);}
;this.onMouseEnter=function(){this.isOverBox=true;}
;this.onMouseLeave=function(){this.isOverBox=false;this.handleHideBox();}
;this.handleHideBox=function(){var thisObj=this;var fx=function(){if(!thisObj.isOverBlock&&!thisObj.isOverBox){thisObj.hideBlockBox();}

}

window.setTimeout(fx,200);}
;this.hideBlockBox=function(){this.boxTop.style.opacity="0";this.boxBottom.style.opacity="0";this.boxLeft.style.opacity="0";this.boxRight.style.opacity="0";var thisObj=this;var fx=function(){if(thisObj.boxTop.style.opacity!="0"){return ;}

thisObj.boxTop.style.display="none";thisObj.boxBottom.style.display="none";thisObj.boxLeft.style.display="none";thisObj.boxRight.style.display="none";}
;window.setTimeout(fx,300);return ;}
;this.initOptionBoxEls=function(){var div=cE("div",document.body);div.className="a_saBoxTop";div.style.display="none";this.boxTop=div;var div=cE("div",document.body);div.className="a_saBoxSide";div.style.display="none";div.style.width="2px";this.boxRight=div;var div=cE("div",document.body);div.className="a_saBoxSide";div.style.display="none";div.style.height="2px";this.boxBottom=div;var div=cE("div",document.body);div.className="a_saBoxSide";div.style.display="none";div.style.width="2px";this.boxLeft=div;}
;this.initCss=function(){var cssStyle=new css_StyleSheet();var cssClass=new css_CssClass("a_saBoxTop");cssClass.addStyle("border-bottom","1px solid #66ccff");cssClass.addStyle("background-image","url(/upload/custom_screens/sitearchitect/livepage/topBarBg.gif)");cssClass.addStyle("background-repeat","repeat-x");cssClass.addStyle("background-color","#d5f1ff");cssClass.addStyle("height","26px");cssClass.addStyle("z-index","999999999");cssClass.addStyle("position","absolute");cssClass.addStyle("-moz-border-top-left-radius","5px");cssClass.addStyle("border-top-left-radius","5px");cssClass.addStyle("-moz-border-top-right-radius","5px");cssClass.addStyle("border-top-right-radius","5px");cssClass.addStyle("position","absolute");cssClass.addStyle("opacity",".8");cssClass.addStyle("-webkit-transition","opacity .2s linear 0");cssClass.addStyle("transition","opacity .2s linear 0");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("a_saBoxBottomHandle");cssClass.addStyle("border-bottom","1px solid #66ccff");cssClass.addStyle("background-image","url(/upload/custom_screens/sitearchitect/livepage/topBarBg.gif)");cssClass.addStyle("background-repeat","repeat-x");cssClass.addStyle("background-color","#d5f1ff");cssClass.addStyle("height","26px");cssClass.addStyle("z-index","999999999");cssClass.addStyle("position","absolute");cssClass.addStyle("-moz-border-bottom-left-radius","5px");cssClass.addStyle("border-bottom-left-radius","5px");cssClass.addStyle("-moz-border-bottom-right-radius","5px");cssClass.addStyle("border-bottom-right-radius","5px");cssClass.addStyle("position","absolute");cssClass.addStyle("opacity",".8");cssClass.addStyle("-webkit-transition","opacity .2s linear 0");cssClass.addStyle("transition","opacity .2s linear 0");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("a_saBoxSide");cssClass.addStyle("background-color","#66ccff");cssClass.addStyle("z-index","999999999");cssClass.addStyle("position","absolute");cssClass.addStyle("-webkit-transition","opacity .2s linear 0");cssClass.addStyle("transition","opacity .2s linear 0");cssStyle.addClass(cssClass);cssStyle.init();}
;this.initCss();}


function BlockBoxOptionBar(blockEl,blockBox){this.blockEl=blockEl;this.blockBox=blockBox;this.parentEl;this.onDragEnd;this.build=function(parentEl){this.parentEl=parentEl;parentEl.innerHTML="";parentEl.style.overflow="hidden";CssUtil.makeNotSelectable(parentEl);var div=cE("div",parentEl);div.style.position="relative";div.align="center";this.buildGrip(div);this.buildIcons(div);}
;this.buildIcons=function(parentEl){var holder=cE("div",parentEl);holder.style.position="absolute";holder.style.right="8px";holder.style.top="5px";var copy=cE("img",holder);copy.style.cursor="pointer";copy.style.marginRight="8px";copy.src="/upload/custom_screens/html5/livepage/duplicate.png";this.attachHelpTip(copy,"duplicate");var thisObj=this;var copyFx=function(){var newBlock=thisObj.blockEl.cloneNode(true);insertAfter(newBlock,thisObj.blockEl);BlockHandler.initBlock(newBlock);LivePage.setElementToSave(newBlock);}
;E.click(copy,copyFx,{stop:true}
);var deleteX=cE("img",holder);deleteX.style.cursor="pointer";deleteX.src="/upload/custom_screens/sitearchitect/livepage/block_x.gif";this.attachHelpTip(deleteX,"delete");var deleteFx=function(){LivePage.setElementToSave(thisObj.blockEl);thisObj.blockEl.parentNode.removeChild(thisObj.blockEl);}
;E.click(deleteX,deleteFx,{stop:true}
);}
;this.attachHelpTip=function(element,helpTip){var popup=new HoverPopup(element);popup.alignment="aboveCenter";popup.showDelay=200;popup.onShow=function(parentEl){var holder=cE("div",parentEl);holder.style.marginTop="4px";var div=cE("div",holder);div.className="lp_saQuickInfoBox";div.innerHTML=helpTip;}
;popup.init();}
;this.buildGrip=function(parentEl){parentEl.style.cursor="move";var grip=cE("div",parentEl);grip.style.paddingTop="4px";grip.style.width="40px";grip.style.height=(this.parentEl.offsetHeight-2)+"px";CssUtil.makeNotSelectable(parentEl);this.addDragEvents(parentEl);var dotSrc="/upload/custom_screens/architect/components/dropdownmenu/grip_dot.gif";for(var i=0;i<4;i++)
{var dot=cE("img",grip);dot.src=dotSrc;dot.style.margin="2px";}

}
;this.addDragEvents=function(grip){var thisObj=this;DragUtil.getYOffset=function(dragEl){return dragEl.offsetHeight/2;}
;var createDragElFx=function(){var dragEl=thisObj.blockEl.cloneNode(true);dragEl.style.border="3px dashed #d6e0f5";dragEl.style.width=thisObj.blockEl.offsetWidth+"px";BlockHandler.dragFramer.frame(thisObj.blockEl);return dragEl;}
;var onDragStart=function(){thisObj.hideIframes();thisObj.blockBox.hideBlockBox();thisObj.blockBox.draggingEl=thisObj.blockEl;thisObj.blockEl.opacity=0.5;LivePage.setElementToSave(thisObj.blockEl);}
;var onDragEnd=function(){thisObj.showIframes();thisObj.blockEl.opacity="";BlockHandler.dragFramer.hideNow();thisObj.blockBox.draggingEl=null;LivePage.setElementToSave(thisObj.blockEl);}
;DragUtil.makeDraggable(grip,null,onDragStart,onDragEnd,createDragElFx);}
;this.iFrames=[];this.hideIframes=function(){var iFrameEls=document.getElementsByTagName("iframe");if(iFrameEls.length==0){return ;}

var iFrames=[];for(var i=0;i<iFrameEls.length;i++)
{var iFrame=iFrameEls[i];if(iFrame.id=="iconBar"){continue;}

iFrames.push(iFrame);}

for(var j=0;j<iFrames.length;j++)
{this.removeIFrame(iFrames[j]);}

}
;this.showIframes=function(){for(var i=0;i<this.iFrames.length;i++)
{var data=this.iFrames[i];var holder=data.holder;holder.parentNode.replaceChild(data.iFrame,holder);}

}


this.removeIFrame=function(element){var width=element.offsetWidth;var height=element.offsetHeight;var div=cE("div");div.style.width=width+"px";div.style.height=height+"px";div.style.background="#cccccc";element.parentNode.replaceChild(div,element);this.iFrames.push({iFrame:element,holder:div}
);}
;}

;;
var BlockHandler=new BlockHandlerBase();function BlockHandlerBase(){this.blockBox;this.dragFramer;this.init=function(){this.initCss();this.initFramers();}
;this.initFramers=function(){this.dragFramer=new Framer("a_saBlockFrameTop","a_saBlockFrameRight","a_saBlockFrameBottom","a_saBlockFrameLeft");var blockBox=new BlockBox();this.blockBox=blockBox;blockBox.initOptionBoxEls();}
;this.disableFramers=function(){this.blockBox.disable();}
;this.enableFramers=function(){this.blockBox.enable();}
;this.hideFrames=function(){this.dragFramer.hideNow();this.blockBox.hideBlockBox();}
;this.addModule=function(container,moduleId){var mc=new MiniCache();mc.addRecordToLoad("module",moduleId);var thisObj=this;var fx=function(){thisObj.insertModule(mc,moduleId,container);}
;mc.process(fx);}
;this.insertModule=function(mc,moduleId,container){var html=mc.getRecord("module",moduleId).getField("module.ahtml").getValue();var newBlock=iE("div",container,0);newBlock.innerHTML=html;BlockHandler.initBlock(newBlock);LivePage.makeElsEditable(newBlock);LivePage.setElementToSave(newBlock);}
;this.initBlock=function(block){var thisObj=this;var enterFx=function(){if(thisObj.blockBox.draggingEl){var draggingEl=thisObj.blockBox.draggingEl;if(draggingEl==block){return ;}

var isBefore=isBeforeSibling(block,draggingEl);draggingEl.parentNode.removeChild(draggingEl);if(isBefore){block.parentNode.insertBefore(draggingEl,block);}

else 
{insertAfter(draggingEl,block);}

thisObj.dragFramer.frame(draggingEl);}

else 
{thisObj.blockBox.isOverBlock=true;thisObj.blockBox.showBlockBox(block);}

}
;var settings={stop:false}
;E.mouseenter(block,enterFx,settings);var leaveFx=function(){if(!thisObj.blockBox.draggingEl){thisObj.blockBox.isOverBlock=false;thisObj.blockBox.handleHideBox();}

}
;E.mouseleave(block,leaveFx);}
;this.removeBlock=function(block){E.off(block,"mouseenter");E.off(block,"mouseleave");}
;this.initCss=function(){var cssStyle=new css_StyleSheet();var cssClass=new css_CssClass("a_saBlockFrameTop");cssClass.addStyle("border-bottom","3px dashed #d6e0f5");cssClass.addStyle("height","3px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("a_saBlockFrameBottom");cssClass.addStyle("border-top","3px dashed #d6e0f5");cssClass.addStyle("height","3px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("a_saBlockFrameLeft");cssClass.addStyle("border-right","3px dashed #d6e0f5");cssClass.addStyle("width","3px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("a_saBlockFrameRight");cssClass.addStyle("border-left","3px dashed #d6e0f5");cssClass.addStyle("width","3px");cssStyle.addClass(cssClass);cssStyle.init();}
;}
;

function ContainerMenu(containerEl){this.containerEl=containerEl;this.build=function(parentEl){this.addContentItem(parentEl);}
;this.addContentItem=function(parentEl){var div=cE("div",parentEl);var span=cE("span",div);span.style.cursor="pointer";span.innerHTML="+ add content";var thisObj=this;var fx=function(){showProgressIcon("Loading");var afterFx=function(){ContainerHandler.containerFramer.hideNow();var popup=new LibraryPopup();popup.containerEl=thisObj.containerEl;popup.build();}
;sl_loadScript('/0/le8548_0.js',afterFx);afterFx;}
;E.click(span,fx);}
;}


;
var ContainerHandler=new ContainerHandlerBase();function ContainerHandlerBase(){this.blockBox;this.containerFramer;this.init=function(){this.initCss();BlockHandler.init();this.initFramers();var containers=gL(".a_container");for(var i=0;i<containers.length;i++)
{var container=containers[i];this.initContainer(container);}

}
;this.initFramers=function(){var framer=new Framer("a_saContFrameTop","a_saContFrameRight","a_saContFrameBottom","a_saContFrameLeft");framer.paddingTop=28;framer.paddingRight=3;framer.paddingBottom=3;framer.paddingLeft=3;var thisObj=this;framer.onHandleHide=function(){var blockBox=BlockHandler.blockBox;return (!(blockBox.isOverBox||blockBox.isOverBlock));}
;this.containerFramer=framer;}
;this.enableFramers=function(){this.containerFramer.enable();BlockHandler.enableFramers();}
;this.disableFramers=function(){this.containerFramer.disable();BlockHandler.disableFramers();}
;this.initContainer=function(container){var thisObj=this;var enterFx=function(e){thisObj.buildMenu(container);thisObj.handleBlockEnter(e,container);}
;E.mouseenter(container,enterFx);var leaveFx=function(){thisObj.containerFramer.hideIfOut(200);}
;E.mouseleave(container,leaveFx);for(var j=0;j<container.childNodes.length;j++)
{var block=container.childNodes[j];if(block.nodeType==1){BlockHandler.initBlock(block);}

}

}
;this.handleBlockEnter=function(e,container){var draggingEl=BlockHandler.blockBox.draggingEl;if(draggingEl&&container==e.srcElement&&0==container.childElementCount){draggingEl.parentNode.removeChild(draggingEl);aE(container,draggingEl);}

}
;this.hideFrames=function(){this.containerFramer.hideNow();BlockHandler.hideFrames();}
;this.removeContainer=function(container){CssUtil.removeClassFromEl(container,"a_container");this.hideFrames();container.onmouseover=null;container.onmouseout=null;for(var j=0;j<container.childNodes.length;j++)
{var block=container.childNodes[j];if(block.nodeType==1){BlockHandler.removeBlock(block);}

}

}
;this.buildMenu=function(container){var framer=this.containerFramer;var thisObj=this;framer.onFrame=function(){thisObj.onFrame(container);}
;framer.frame(container);}
;this.onFrame=function(container){var framer=this.containerFramer;framer.right.innerHTML="";var coord=findElCoord(framer.right);var holder=cE("div",framer.right);holder.className="a_contTab";holder.style.position="relative";holder.style.left="-105px";holder.style.top="-23px";var menu=new ContainerMenu(container);menu.build(holder);
}
;
this.addModule=function(container,moduleId,insertAsAHtml){var mc=new MiniCache();mc.addRecordToLoad("module",moduleId);var thisObj=this;var fx=function(){thisObj.insertModule(mc,moduleId,container,insertAsAHtml);}
;mc.process(fx);}
;
this.insertModule=function(mc,moduleId,container,insertAsAHtml){var record=mc.getRecord("module",moduleId);if(insertAsAHtml){var name=record.getField("name").getValue();var ahtml="<a_module name=\""+name+"\">";LivePage.insertATag(container,ahtml);}

else {var html=record.getField("module.ahtml").getValue();container.innerHTML+=html;LivePage.setElementToSave(container);}

}
;this.initCss=function(){var cssClass=new CssClass(".a_saContFrameTop");cssClass.add("border-right","1px solid black");cssClass.add("border-left","1px solid black");cssClass.add("background","black");cssClass.add("filter","alpha(opacity=50)");cssClass.add("opacity",".75");cssClass.add("height","3px");cssClass.add("-moz-border-top-left-radius","5px");cssClass.add("border-top-left-radius","5px");cssClass.add("-moz-border-top-right-radius","5px");cssClass.add("border-top-right-radius","5px");cssClass.add("-webkit-transition","opacity .2s linear 0");cssClass.init();var cssClass=new CssClass(".a_saContFrameBottom");cssClass.add("height","3px");cssClass.add("background","black");cssClass.add("-webkit-transition","opacity .2s linear 0");cssClass.init();var cssClass=new CssClass(".a_saContFrameLeft");cssClass.add("width","3px");cssClass.add("background","black");cssClass.add("-webkit-transition","opacity .2s linear 0");cssClass.init();var cssClass=new CssClass(".a_saContFrameRight");cssClass.add("width","3px");cssClass.add("background","black");cssClass.add("-webkit-transition","opacity .2s linear 0");cssClass.init();var cssClass=new CssClass(".a_contTab");cssClass.add("padding","4px");cssClass.add("font-size","12px");cssClass.add("background","black");cssClass.add("color","white");cssClass.add("width","100px");cssClass.add("text-align","center");cssClass.add("border-bottom-left-radius","5px");cssClass.init();}
;}
;

function Framer(topClass,rightClass,bottomClass,leftClass){this.topClass=topClass||"";this.rightClass=rightClass||"";this.bottomClass=bottomClass||"";this.leftClass=leftClass||"";this.onFrame;this.coverRightClick;this.init();}

Framer.prototype=new FramerBase();function FramerBase(){this.paddingTop=0;this.paddingRight=0;this.paddingBottom=0;this.paddingLeft=0;this.maxOpacity=1;this.staggerDrawing=false;this.element;this.onHandleHide;this.ignorePadding=false;this.doHideOnOut=true;this.doHideOnClick=false;this.isOverFrame=false;this.top;this.right;this.bottom;this.left;this.cover=false;this.lastMoveEvent;this.intervalId=0;this.isDisabled;this.isLocked;this.moveFx;this.clickFx;this.frame=function(element){if(this.isDisabled){return ;}

this.element=element;if(!this.staggerDrawing){this.doFrame(element);}

else 
{var thisObj=this;var fx=function(){thisObj.doFrame(element);}
;window.setTimeout(fx,0);}

}
;this.doFrame=function(element){this.setPadding();this.clearHideCheck();this.drawEls();if(this.doHideOnOut){this.initHideCheck();}

if(this.doHideOnClick){this.attachClickHide();}

if(this.onFrame){this.onFrame();}

}
;this.drawEls=function(){var element=this.element;var coord=findElCoord(element);var thisObj=this;var enterFx=function(){thisObj.onMouseEnter();}
;var leaveFx=function(){thisObj.onMouseLeave();}
;var elHeight=this.getRealHeight(element);var z=CssUtil.getZIndex(element);var top=this.top;top.style.display="";var topBorder=CssUtil.pixelToInt(CssUtil.getStyle(top,"border-bottom-width"));var bottom=this.bottom;bottom.style.zIndex=z;bottom.style.display="";var bottomBorder=CssUtil.pixelToInt(CssUtil.getStyle(bottom,"border-top-width"));var left=this.left;left.style.opacity=this.maxOpacity;left.style.zIndex=z;left.style.display="";var leftPx=Math.max(0,coord.x);var topPx=Math.max(0,coord.y);left.style.left=(leftPx-left.offsetWidth-this.paddingLeft)+"px";left.style.height=(elHeight+this.paddingTop+this.paddingBottom+topBorder+bottomBorder)+"px";left.style.top=(topPx-this.paddingTop-topBorder)+"px";E.mouseenter(left,enterFx);E.mouseleave(left,leaveFx);var right=this.right;right.style.opacity=this.maxOpacity;right.style.zIndex=z;right.style.display="";right.style.left=(coord.x+element.offsetWidth+this.paddingRight)+"px";right.style.height=(elHeight+this.paddingTop+this.paddingBottom+topBorder+bottomBorder)+"px";right.style.top=(coord.y-this.paddingTop-topBorder)+"px";E.mouseenter(right,enterFx);E.mouseleave(right,leaveFx);top.style.opacity=this.maxOpacity;top.style.zIndex=z;top.style.display="";top.style.top=(coord.y-top.offsetHeight-this.paddingTop)+"px";top.style.left=(coord.x-left.offsetWidth-this.paddingLeft)+"px";top.style.width=(element.offsetWidth+left.offsetWidth+right.offsetWidth+this.paddingLeft+this.paddingRight)+"px";E.mouseenter(top,enterFx);E.mouseleave(top,leaveFx);var bottom=this.bottom;bottom.style.opacity=this.maxOpacity;bottom.style.display="";bottom.style.left=(coord.x-left.offsetWidth-this.paddingLeft)+"px";bottom.style.width=(element.offsetWidth+left.offsetWidth+right.offsetWidth+this.paddingLeft+this.paddingRight)+"px";bottom.style.top=(coord.y+elHeight+this.paddingBottom)+"px";E.mouseenter(bottom,enterFx);E.mouseleave(bottom,leaveFx);if(this.cover){this.drawCover();}

}
;this.drawCover=function(){var el=this.getCoverEl();el.style.left=this.left.offsetLeft+"px";el.style.top=this.top.offsetTop+"px";el.style.width=this.right.offsetLeft+this.right.offsetWidth-this.left.offsetLeft+"px";el.style.height=this.bottom.offsetTop+this.bottom.offsetHeight-this.top.offsetTop+"px";el.style.zIndex=CssUtil.getZIndex(this.element)-100000;el.style.display="";var rClick=this.coverRightClick;if(rClick){E.add(el,"contextmenu",rClick);}

}
;this.getCoverEl=function(){if(!this.coverEl){var el=cE("div",this.getParentEl());el.style.display="none";el.style.zIndex=-1000;el.style.position="absolute";this.coverEl=el;}

return this.coverEl;}
;this.reframe=function(doASync){this.resetPadding();if(!doASync){this.doReframe();}

else 
{var thisObj=this;var fx=function(){thisObj.doReframe();}

window.setTimeout(fx,0);}

}
;this.doReframe=function(){var element=this.element;if(!isInDom(element)){return ;}

var coord=findElCoord(element);var elHeight=this.getRealHeight(element);var top=this.top;top.style.display="";var topBorder=CssUtil.pixelToInt(CssUtil.getStyle(top,"border-bottom-width"));var bottom=this.bottom;bottom.style.display="";var bottomBorder=CssUtil.pixelToInt(CssUtil.getStyle(bottom,"border-top-width"));var leftPx=Math.max(0,coord.x);var topPx=Math.max(0,coord.y);var left=this.left;left.style.display="";left.style.left=(leftPx-left.offsetWidth-this.paddingLeft)+"px";left.style.height=(elHeight+this.paddingTop+this.paddingBottom+topBorder+bottomBorder)+"px";left.style.top=(topPx-this.paddingTop-topBorder)+"px";var right=this.right;right.style.display="";right.style.left=(coord.x+element.offsetWidth+this.paddingRight)+"px";right.style.height=(elHeight+this.paddingTop+this.paddingBottom+topBorder+bottomBorder)+"px";right.style.top=(coord.y-this.paddingTop-topBorder)+"px";top.style.display="";top.style.top=(coord.y-top.offsetHeight-this.paddingTop)+"px";top.style.left=(coord.x-left.offsetWidth-this.paddingLeft)+"px";top.style.width=(element.offsetWidth+left.offsetWidth+right.offsetWidth+this.paddingLeft+this.paddingRight)+"px";var bottom=this.bottom;bottom.style.display="";bottom.style.left=(coord.x-left.offsetWidth-this.paddingLeft)+"px";bottom.style.width=(element.offsetWidth+left.offsetWidth+right.offsetWidth+this.paddingLeft+this.paddingRight)+"px";bottom.style.top=(coord.y+elHeight+this.paddingBottom)+"px";if(this.cover){this.drawCover();}

}
;this.attachClickHide=function(){if(this.clickFx){return ;}

var thisObj=this;var clickFx=function(){thisObj.hideNow();}
;E.add(document.body,"click",clickFx);this.clickFx=clickFx;}
;this.removeClickHide=function(){var clickFx=this.clickFx;if(!clickFx){return ;}

E.remove(document.body,"click",clickFx);this.clickFx=null;}
;this.setWidth=function(width,isMoveLeft){var element=this.element;if(!element){return ;}

var coord=findElCoord(element);var right=this.right;if(!isMoveLeft){right.style.left=(coord.x+width+this.paddingRight)+"px";}

var left=this.left;var top=this.top;var horizBorderWidth=CssUtil.pixelToInt(CssUtil.getStyle(top,"border-right-width"))+CssUtil.pixelToInt(CssUtil.getStyle(top,"border-left-width"));top.style.width=(width+left.offsetWidth+right.offsetWidth+this.paddingLeft+this.paddingRight-horizBorderWidth)+"px";var bottom=this.bottom;var horizBorderWidth=CssUtil.pixelToInt(CssUtil.getStyle(bottom,"border-right-width"))+CssUtil.pixelToInt(CssUtil.getStyle(bottom,"border-left-width"));bottom.style.width=(width+left.offsetWidth+right.offsetWidth+this.paddingLeft+this.paddingRight-horizBorderWidth)+"px";if(isMoveLeft){var diff=width-element.offsetWidth;left.style.left=(coord.x-left.offsetWidth-this.paddingLeft-diff)+"px";top.style.left=(coord.x-left.offsetWidth-this.paddingLeft-diff)+"px";bottom.style.left=(coord.x-left.offsetWidth-this.paddingLeft-diff)+"px";}

}
;this.setHeight=function(height,isMoveUp){var element=this.element;if(!element){return ;}

var coord=findElCoord(element);var left=this.left;left.style.height=(height+this.paddingTop+this.paddingBottom-1)+"px";var right=this.right;right.style.height=(height+this.paddingTop+this.paddingBottom-1)+"px";var bottom=this.bottom;if(!isMoveUp){bottom.style.top=(coord.y+height+this.paddingBottom)+"px";}

if(isMoveUp){var diff=height-element.offsetHeight;left.style.top=(coord.y-this.paddingTop+1-diff)+"px";right.style.top=(coord.y-this.paddingTop+1-diff)+"px";var top=this.top;top.style.top=(coord.y-top.offsetHeight-this.paddingTop+1-diff)+"px";bottom.style.top=(coord.y+height+this.paddingBottom-diff)+"px";}

}
;this.setPadding=function(){if(!this.ignorePadding){return ;}

this.orgTop=this.paddingTop;this.orgRight=this.paddingRight;this.orgBottom=this.paddingBottom;this.orgLeft=this.paddingLeft;var padding=CssUtil.getStyle(this.element,"padding");var paddings=padding.replaceAll("px","").split(" ");this.paddingTop-=parseInt(paddings[0],10);this.paddingRight-=parseInt(paddings[1],10);this.paddingBottom-=parseInt(paddings[2],10);this.paddingLeft-=parseInt(paddings[3],10);}
;this.resetPadding=function(){if(!this.ignorePadding){return ;}

var padding=CssUtil.getStyle(this.element,"padding");var paddings=padding.replaceAll("px","").split(" ");this.paddingTop=this.orgTop-parseInt(paddings[0],10);this.paddingRight=this.orgRight-parseInt(paddings[1],10);this.paddingBottom=this.orgBottom-parseInt(paddings[2],10);this.paddingLeft=this.orgLeft-parseInt(paddings[3],10);}
;this.disable=function(){this.isDisabled=true;this.clearHideCheck();this.hideNow();}
;this.enable=function(){this.isDisabled=false;}
;this.initHideCheck=function(){var thisObj=this;var fx=function(){thisObj.handleHideOnMove();}
;this.intervalId=setInterval(fx,1000);}
;this.getRealHeight=function(element){return element.offsetHeight;var extra=0;for(var i=0;i<element.childNodes.length;i++)
{var child=element.childNodes[i];var floatValue=CssUtil.getStyle(child,"float");if("left"==floatValue||"right"==floatValue){extra=Math.max(extra,child.offsetHeight);}

}

return element.offsetHeight+extra;}
;this.destroy=function(){this.clearHideCheck();this.top.parentNode.removeChild(this.top);this.right.parentNode.removeChild(this.right);this.bottom.parentNode.removeChild(this.bottom);this.left.parentNode.removeChild(this.left);var coverEl=this.getCoverEl();coverEl.parentNode.removeChild(coverEl);}
;this.clearHideCheck=function(){if(!this.moveFx){return ;}

E.remove(document.body,"mousemove",this.moveFx);clearInterval(this.intervalId);this.moveFx=null;}
;this.onMouseEnter=function(){this.isOverFrame=true;}
;this.onMouseLeave=function(){this.isOverFrame=false;if(this.doHideOnOut){this.hideIfOut();}

}
;this.hideIfOut=function(delay){delay=delay||0;var thisObj=this;var fx=function(){thisObj.handleHideOnMove();}
;window.setTimeout(fx,delay);}
;this.handleHideOnMove=function(){if(document.body.onmousemove){return ;}

if(!this.moveFx){var thisObj=this;var moveFx=function(e){thisObj.handleAfterMove(e);}
;this.moveFx=moveFx;E.add(document.body,"mousemove",moveFx);}

}
;this.handleAfterMove=function(e){if(this.left.style.display=="none"||!this.isOutsideOfFrame(e)){return ;}

this.clearHideCheck();if(this.onHandleHide){if(!this.onHandleHide()){return ;}

}

this.hideNow();}
;this.isVisible=function(){return (this.top.style.display!="none");}
;this.close=function(){this.isLocked=false;var thisObj=this;var afterFx=function(){thisObj.destroy();}
;this.hideNow(afterFx);}
;this.hideNow=function(afterFx){if(this.isLocked){return ;}

this.removeClickHide();this.clearHideCheck();this.top.style.opacity="0";this.bottom.style.opacity="0";this.left.style.opacity="0";this.right.style.opacity="0";var thisObj=this;var fx=function(){if(thisObj.top.style.opacity!="0"){return ;}

thisObj.element=null;thisObj.top.style.display="none";thisObj.bottom.style.display="none";thisObj.left.style.display="none";thisObj.right.style.display="none";if(afterFx){afterFx();}

}
;window.setTimeout(fx,300);}
;this.tempHide=function(){this.top.style.display="none";this.bottom.style.display="none";this.left.style.display="none";this.right.style.display="none";}
;this.isOutsideOfFrame=function(event){if(this.isOverFrame){return false;}
;var mouseX=event.pageX;if(mouseX<findElCoord(this.left).x){return true;}

if(mouseX>findElCoord(this.right).x){return true;}

var mouseY=event.pageY;if(mouseY<findElCoord(this.top).y){return true;}

if(mouseY>(findElCoord(this.bottom).y+this.bottom.offsetHeight)){return true;}

return false;}
;this.getParentEl=function(){var parentEl=Framer.prototype.parentEl;if(parentEl){return parentEl;}

var div=cE("div",document.body);div.style.zIndex=999999999999;div.style.position="absolute";div.style.top=0;div.style.left=0;Framer.prototype.parentEl=div;return div;}
;this.init=function(){var parentEl=this.getParentEl();var cls=new CssClass(".lp_framerSide");cls.add("-webkit-box-sizing","border-box");cls.add("-moz-box-sizing","border-box");cls.add("box-sizing","border-box");cls.init();var top=cE("div",parentEl);top.className="lp_framerSide "+this.topClass;top.style.display="none";top.style.zIndex=-4;top.style.position="absolute";this.top=top;var bottom=top.cloneNode(top);bottom.className="lp_framerSide "+this.bottomClass;bottom.style.zIndex=-4;aE(parentEl,bottom);this.bottom=bottom;var right=top.cloneNode(top);right.className="lp_framerSide "+this.rightClass;aE(parentEl,right);this.right=right;var left=top.cloneNode(top);left.className="lp_framerSide "+this.leftClass;aE(parentEl,left);this.left=left;}
;}


if(!window["EventUtil"]){var E=EventUtil=new EventUtilBase();}

function EventUtilBase(){this.on=function(element,eventType,fx,eventSettings){eventSettings=eventSettings||this.defaultEventSettings;if(!(B.isIE()||B.isFF())){if(eventType=="mouseenter"){this.mouseenter(element,fx,eventSettings);return ;}

else if(eventType=="mouseleave"){this.mouseleave(element,fx,eventSettings);return ;}

}

if(eventType=="rightclick"){eventType="contextmenu";}

var thisObj=this;element["on"+eventType]=function(event){thisObj.run(event,fx,eventSettings);}
;eh_registerEvent(element,"on"+eventType);}
;this.run=function(event,fx,eventSettings){eventSettings=eventSettings||this.defaultEventSettings;event=event||window.event;if(fx){fx(event);}

if(eventSettings&&eventSettings.stop){this.stop(event);}

}
;this.off=function(element,eventType){if(!(B.isIE()||B.isFF())){if("mouseleave"==eventType){var fxId=gA(element,"a_metaMouseleavefxid");var fx=this.mouseLeaveData[fxId];this.remove(document.body,"mouseout",fx);delete(this.mouseLeaveData[fxId]);element.removeAttribute("a_metaMouseleavefxid");}

else if("mouseenter"==eventType){element.onmouseover=null;return ;}

}

element["on"+eventType]=null;}
;this.add=function(element,eventType,fx){if(eventType=="rightclick"){eventType="contextmenu";}

if(!B.isIE()){element.addEventListener(eventType,fx,false);}

else 
{eventType="on"+eventType;element.attachEvent(eventType,fx);}

}
;this.remove=function(element,eventType,fx){if(!(B.isIE()||B.isFF())){if("mouseleave"==eventType){fx=gA("mouseleavefx",element);element=document.body;eventType="mouseout";}

}

element.removeEventListener(eventType,fx,false);}
;
this.stop=function(event){try
{event.stopPropagation();event.preventDefault();}

catch(excep)
{if(B.isIE()){if(!event){event=window.event;}

event.returnValue=false;event.cancelBubble=true;}

}

}
;this.blur=function(element,fx,eventSettings){this.on(element,"blur",fx,eventSettings);}
;this.change=function(element,fx,eventSettings){this.on(element,"change",fx,eventSettings);}
;this.click=function(element,fx,eventSettings){this.on(element,"click",fx,eventSettings);}
;this.dblclick=function(element,fx,eventSettings){this.on(element,"dblclick",fx,eventSettings);}
;this.error=function(element,fx,eventSettings){this.on(element,"error",fx,eventSettings);}
;this.focus=function(element,fx,eventSettings){this.on(element,"focus",fx,eventSettings);}
;this.keydown=function(element,fx,eventSettings){this.on(element,"keydown",fx,eventSettings);}
;this.keypress=function(element,fx,eventSettings){this.on(element,"keypress",fx,eventSettings);}
;this.keyup=function(element,fx,eventSettings){this.on(element,"keyup",fx,eventSettings);}
;this.makeDraggable=function(element,props){DragHandler.makeDraggable(element,props);}
;this.mousedown=function(element,fx,eventSettings){this.on(element,"mousedown",fx,eventSettings);}
;this.mouseenter=function(element,fx,eventSettings){if(B.isIE()||B.isFF()){this.on(element,"mouseenter",fx,eventSettings);}

else 
{var thisObj=this;element.onmouseover=function(event){if(!event){event=window.event;}

if(!isDescendent(event.fromElement,event.currentTarget)&&isDescendent(event.toElement,event.currentTarget)){thisObj.run(event,fx,eventSettings);}

}
;eh_registerEvent(element,"onmouseover");}

}
;this.mouseleave=function(element,fx,eventSettings){if(B.isIE()||B.isFF()){this.on(element,"mouseleave",fx,eventSettings);}

else 
{var outFx=function(event){if(!isInDom(element)){element.ownerDocument.body.removeEventListener("mouseout",outFx,false);}

if(isDescendent(event.srcElement,element)&&!isDescendent(event.toElement,element)){fx(event);}

}
;this.add(element.ownerDocument.body,"mouseout",outFx);var id=this.getNextId();this.mouseLeaveData[id]=outFx;sA(element,"a_metaMouseleavefxid",id);}

}
;this.mousemove=function(element,fx,eventSettings){this.on(element,"mousemove",fx,eventSettings);}
;this.mouseout=function(element,fx,eventSettings){this.on(element,"mouseout",fx,eventSettings);}
;this.mouseover=function(element,fx,eventSettings){this.on(element,"mouseover",fx,eventSettings);}
;this.mouseup=function(element,fx,eventSettings){this.on(element,"mouseup",fx,eventSettings);}
;this.paste=function(element,fx,eventSettings){this.on(element,"paste",fx,eventSettings);}
;this.resize=function(fx,eventSettings){this.add(window,"resize",fx);}
;this.rightclick=function(element,fx,eventSettings){this.on(element,"contextmenu",fx,eventSettings);}
;this.defaultEventSettings={stop:true}
;this.mouseLeaveData={}
;this.counter=0;this.getNextId=function(){this.counter++;return "a_e"+this.counter;}

}


function StandardMenuItem(itemName,onClickFx){this.itemName=itemName;this.onClickFx=onClickFx;this.children=[];this.menu;this.subMenu;
this.buildLabel=function(td){td.style.paddingRight=25;td.style.fontSize=this.menu.fontSize;td.innerHTML=this.itemName;}
;this.addSubMenu=function(subMenu){this.subMenu=subMenu;subMenu.parent=this;}
;}

var B=BrowserUtil=new BrowserUtilBase();function BrowserUtilBase(){this.name;this.version;this.OS;this.isFF=function(){return ("Firefox"==this.name);}
;this.isIE=function(){return ("Explorer"==this.name);}
;this.isChrome=function(){return ("Chrome"==this.name);}
;this.isSafari=function(){return ("Safari"==this.name);}
;this.isOpera=function(){return ("Opera"==this.name);}
;this.getName=function(){return this.name;}
;this.getVersion=function(){return this.version;}
;this.isIOS=function(){return (this.OS=="IOS");}
;this.isAndroid=function(){var ua=navigator.userAgent.toLowerCase();return ua.indexOf("android")>-1;}
;this.getOS=function(){return this.OS;}
;this.init=function(){this.name=this.searchString(this.dataBrowser)||"An unknown browser";this.version=this.searchVersion(navigator.userAgent)||this.searchVersion(navigator.appVersion)||"an unknown version";this.OS=this.searchString(this.dataOS)||"an unknown OS";}
;this.searchString=function(data){for(var i=0;i<data.length;i++)
{var dataString=data[i].string;var dataProp=data[i].prop;this.versionSearchString=data[i].versionSearch||data[i].identity;if(dataString){if(dataString.indexOf(data[i].subString)!=-1){return data[i].identity;}

else if(dataProp){return data[i].identity;}

}

}

}
;this.searchVersion=function(dataString){var index=dataString.indexOf(this.versionSearchString);if(index==-1){return ;}

return parseFloat(dataString.substring(index+this.versionSearchString.length+1));}
;this.dataBrowser=[];var obj={string:navigator.userAgent,subString:"Chrome",identity:"Chrome"}
;this.dataBrowser.push(obj)
var obj={string:navigator.userAgent,subString:"OmniWeb",versionSearch:"OmniWeb/",identity:"OmniWeb"}
;this.dataBrowser.push(obj)
var obj={string:navigator.vendor,subString:"Apple",identity:"Safari",versionSearch:"Version"}
;this.dataBrowser.push(obj)
var obj={prop:window.opera,identity:"Opera"}
;this.dataBrowser.push(obj)
var obj={string:navigator.vendor,subString:"iCab",identity:"iCab"}
;this.dataBrowser.push(obj);var obj={string:navigator.vendor,subString:"KDE",identity:"Konqueror"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Firefox",identity:"Firefox"}
;this.dataBrowser.push(obj);var obj={string:navigator.vendor,subString:"Camino",identity:"Camino"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Netscape",identity:"Netscape"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"MSIE",identity:"Explorer",versionSearch:"MSIE"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Gecko",identity:"Mozilla",versionSearch:"rv"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Mozilla",identity:"Netscape",versionSearch:"Mozilla"}

this.dataBrowser.push(obj);this.dataOS=[];var obj={string:navigator.platform,subString:"Win",identity:"Windows"}

this.dataOS.push(obj);var obj={string:navigator.platform,subString:"Mac",identity:"Mac"}
;this.dataOS.push(obj);var obj={string:navigator.platform,subString:"iPad",identity:"IOS"}
;this.dataOS.push(obj);var obj={string:navigator.userAgent,subString:"iPhone",identity:"IOS"}
;this.dataOS.push(obj);var obj={string:navigator.platform,subString:"Linux",identity:"Linux"}
;this.dataOS.push(obj);this.init();}
;
;
function findElAt(x,y,doc){if(!doc){doc=document;}

return doc.elementFromPoint(x,y);}

function getPosTop(element){if(IS_IE){return element.style.posTop;}

else 
{var topString=element.style.top;return parseInt(topString.substring(0,topString.length-2));}

}

function getEventCoord(event,doc){if(!doc){doc=document;}

if(!event){event=window.event;}

if(event.pageX){return {x:event.pageX,y:event.pageY}
;}

else 
{var x=event.clientX+doc.body.scrollLeft+doc.documentElement.scrollLeft;var y=event.clientY+doc.body.scrollTop+doc.documentElement.scrollTop;return {x:x,y:y}
;}

}

function findElCoord(element,accountForScroll){var curLeft=0;var curTop=0;var mainEl=element;if(element.offsetParent){do
{if("BODY"==element.tagName||element==mainEl){curLeft+=accountForScroll?element.offsetLeft-element.scrollLeft:element.offsetLeft;}

else 
{curLeft+=(element.offsetLeft-element.scrollLeft);}

var bLW=CssUtil.getStyle(element,"border-left-width")
if(element!=mainEl&&bLW){curLeft+=css_pixelToInt(bLW);}

curTop+=(accountForScroll&&"BODY"==element.tagName)?element.offsetTop-element.scrollTop:element.offsetTop;var bTW=CssUtil.getStyle(element,"border-left-width")
if(element!=mainEl&&bTW){curTop+=css_pixelToInt(bTW);}

element=element.offsetParent;}

while(element);}

return {x:curLeft,y:curTop}
;}




;;function DropdownMenu(){this.title;this.menuItems=[];this.menuItemHolder;this.popup;this.parent;this.subMenu;this.subMenuHolder;this.highlightedMenuItem;this.popupContainer;this.useShadow=true;this.showDragger=true;this.minWidth;}

DropdownMenu.prototype=new DropdownMenuBase();function DropdownMenuBase(){this.iconCellWidth=20;this.border="1px solid #C4C4C4";this.padding="1px";this.fontFamily="arial";this.width;this.fontSize="13px";this.fontWeight;this.fontColor="black";this.backgroundColor="#FBFBFB";this.mouseOverBgColor="#5071F2";this.dividerColor="#E3E3E3";this.skipBgShadow=false;this.addMenuItem=function(menuItem){this.menuItems.push(menuItem);menuItem.menu=this;}
;this.addDivider=function(){this.menuItems.push("divider");}
;this.attachRightClick=function(element){var menu=this;var fx=function(event){menu.buildAtEvent(event);}
;eh_attachEvent("oncontextmenu",element,fx,null,true,null,true,false,false);}
;this.build=function(leftOffset,topOffset){var popup=new Popup();popup.setAtCoord(leftOffset,topOffset)
popup.shadow=(!this.skipBgShadow)?"3side":"";popup.ensureOnTop=true;popup.disableBg=true;popup.width=this.width;popup.closeEvents=["oncontextmenu"];popup.doc=this.doc||document;var contentArea=popup.build();this.contentArea=contentArea;contentArea.style.border=this.border;if(this.showDragger){this.createDragger(contentArea,popup);}

var menu=this;popup.onCloseFx=function(){menu.close();}

this.popup=popup;this.buildElements(contentArea);popup.align();}
;this.createDragger=function(parentEl,popup){var dragger=cE("div",parentEl);dragger.align="center";dragger.style.height="8px";dragger.style.paddingTop="3px";dragger.style.fontSize=0;dragger.style.cursor="move";dragger.style.backgroundColor=this.backgroundColor;popup.makeDraggable(dragger);var dotSrc="/upload/custom_screens/architect/components/dropdownmenu/grip_dot.gif";for(var i=0;i<4;i++)
{var dot=cE("img",dragger);dot.src=dotSrc;dot.style.margin="2px";}

}
;this.buildAtEvent=function(event,leftOffset,topOffset){var coordinate=getEventCoord(event);if(leftOffset){coordinate.x+=leftOffset;}

if(topOffset){coordinate.y+=topOffset;}

this.build(coordinate.x,coordinate.y);}
;this.close=function(){if(this.subMenu){this.subMenu.close();}

if(this.popup){this.popup.close();}

this.menuItemHolder=null;}
;this.buildContainer=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.vAlign="top";td.style.height="100%";var iBody=createTable(td);iBody.parentNode.style.height="100%";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);var image=cE("img",iTd);image.src="/upload/js_globals/background_images/ulc.png";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);iTd.style.height="100%";iTd.style.fontSize=0;iTd.style.backgroundImage="url(/upload/js_globals/background_images/l.png)";iTd.innerHTML="&nbsp;";var contentArea=cE("td",tr);contentArea.style.border=this.border;contentArea.style.padding=this.padding+"px";contentArea.style.fontFamily=this.fontFamily;contentArea.style.fontSize=this.fontSize+"px";contentArea.style.width=this.width||"";contentArea.style.backgroundColor=this.backgroundColor;var td=cE("td",tr);td.vAlign="top";td.style.height="100%";var iBody=createTable(td);iBody.parentNode.style.height="100%";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);var image=cE("img",iTd);image.src="/upload/js_globals/background_images/urc.png";var iTr=cE("tr",iBody);var iTd=cE("td",iTr);iTd.style.height="100%";iTd.style.fontSize=0;iTd.style.backgroundImage="url(/upload/js_globals/background_images/r.png)";iTd.innerHTML="&nbsp;";var tr=cE("tr",tBody);var td=cE("td",tr);var image=cE("img",td);image.src="/upload/js_globals/background_images/llc.png";var td=cE("td",tr);td.style.backgroundImage="url(/upload/js_globals/background_images/b.png)";var td=cE("td",tr);var image=cE("img",td);image.src="/upload/js_globals/background_images/lrc.png";return contentArea;}
;this.buildElements=function(parentEl){var container=cE("div",parentEl);container.style.padding=this.padding;container.style.fontFamily=this.fontFamily;container.style.fontSize=this.fontSize;container.style.width=this.width||"";container.style.backgroundColor=this.backgroundColor;var table=cE("table",container);table.cellSpacing=0;table.cellPadding=0;table.style.width="100%      ";var colGroup=cE("colgroup",table);var col1=cE("col",colGroup);col1.vAlign="middle";col1.style.width=this.iconCellWidth+"px";var col2=cE("col",colGroup);col2.vAlign="middle";var col3=cE("col",colGroup);col3.vAlign="middle";col3.style.width=this.iconCellWidth+"px";var tBody=cE("tbody",table);tBody.style.cursor="default";var noOfItems=this.menuItems.length;for(var i=0;i<noOfItems;i++)
{var menuItem=this.menuItems[i];if(menuItem=="divider"){this.drawDivider(tBody);}

else 
{this.drawMenuRow(tBody,menuItem);}

}

}
;this.drawDivider=function(tBody){var tr=cE("tr",tBody);var td=cE("td",tr);td.colSpan=3;var div=cE("div",td);div.style.height="2px";div.style.marginTop="1px";div.style.marginBottom="3px";div.style.borderTop="1px solid "+this.dividerColor;}
;this.drawMenuRow=function(tBody,menuItem){var tr=cE("tr",tBody);tr.style.color=this.fontColor;tr.style.fontWeight=this.fontWeight||"bold";if(menuItem.onClickFx){var onClickFx=function(){menuItem.menu.getRootMenu().popup.close();menuItem.onClickFx();}
;eh_attachEvent("onclick",tr,onClickFx);}

var td=cE("td",tr);if(menuItem.buildIconCell){menuItem.buildIconCell(td);}

else 
{td.innerHTML="&nbsp;";}

var td=cE("td",tr);td.style.padding="3px 0";menuItem.buildLabel(td);var td=cE("td",tr);var image;if(menuItem.subMenu){image=cE("img",td);image.src="/upload/custom_screens/components/dropdownmenu/submenu_arrow.gif";}

this.attachMouseEvents(tr,menuItem,image);}
;this.getRootMenu=function(){var menu=this;while(menu.parent)
{menu=menu.parent.menu;}

return menu;}
;this.buildSubMenu=function(menuItem,tr){var lastTd=tr.childNodes[2];var coord=findElCoord(lastTd,true);coord.x+=lastTd.offsetWidth;var div=cE("div",this.getRootMenu().popupContainer);div.style.position="absolute";div.style.left=coord.x+"px";div.style.top=coord.y+"px";this.subMenuHolder=div;this.subMenu=menuItem.subMenu;menuItem.subMenu.buildElements(div);}
;this.removeSubMenu=function(){if(this.subMenu){this.subMenu.removeSubMenu();this.subMenuHolder.parentNode.removeChild(this.subMenuHolder);this.subMenu=null;}

}
;this.handleSubMenu=function(menuItem,tr){var menu=this;var fx=function(){if(menuItem!=menu.highlightedMenuItem){return ;}

menu.removeSubMenu();if(menuItem.subMenu){menu.buildSubMenu(menuItem,tr);}

}
;setTimeout(fx,300);}
;this.attachMouseEvents=function(tr,menuItem,image){var onselectstartFx=function(){return false}
;eh_attachEvent("onselectstart",tr,onselectstartFx);var menu=this;var onmouseoverFx=function(){tr.style.backgroundColor=menu.mouseOverBgColor;tr.style.color="white";menu.handleSubMenu(menuItem,tr);menu.highlightedMenuItem=menuItem;if(image){image.src="/upload/custom_screens/components/dropdownmenu/white_arrow_left.gif";}

}
;eh_attachEvent("onmouseover",tr,onmouseoverFx);var onmouseoutFx=function(){tr.style.backgroundColor="";tr.style.color=menu.fontColor;if(image){image.src="/upload/custom_screens/components/dropdownmenu/submenu_arrow.gif";}

if(menu.highlightedMenuItem==menuItem){menu.highlightedMenuItem=null;}

}
;eh_attachEvent("onmouseout",tr,onmouseoutFx);}
;}


function objectToField(object,name,typeName,extraInfo){return oft_populateField(object,null,name,typeName,extraInfo);}

if(!otf_objectToFieldFxByType){var otf_objectToFieldFxByType=[];}

function registerConverter(fieldTypeName,conversionFx){if(!otf_objectToFieldFxByType){otf_objectToFieldFxByType=[];}

otf_objectToFieldFxByType[fieldTypeName]=conversionFx;}

function oft_populateField(object,parentField,name,typeName,extraInfo){var objectType=typeof(object);if("function"==objectType){return ;}

var isObject=object&&(objectType=='object');if(typeName){var converterFx=otf_objectToFieldFxByType[typeName];return converterFx(object,name,extraInfo);}

if(isObject){var field=object.length?new array_ArrayType(name,"",0):new collectionfield_Collection(name,"",0);var dO=1;for(var i in object)
{var typeIndicatorName=i+"_ft";var extraInfoName=typeIndicatorName+"i";var childField=oft_populateField(object[i],field,i,object[typeIndicatorName],object[extraInfoName]);if(childField){childField.displayOrder=dO;field.addChildField(childField);dO++;}

}

return field;}

else 
{return new field_String(name,"",0,object,false);}

}

function oft_isTypeIndicator(fieldName){var nameLength=fieldName.length;if(nameLength<=3){return false;}

var suffix=fieldName.substring(nameLength-3,nameLength);return ("_ft"==suffix)
}

;var IS_MOZILLA=document.getElementById&&!document.all;var IS_IE=document.all;var IS_CHROME=navigator.userAgent.toLowerCase().indexOf('chrome')>-1;var crossbrowser_browserName;var crossbrowser_wc3MouseButtons=[];crossbrowser_wc3MouseButtons.left=1;crossbrowser_wc3MouseButtons.middle=4;crossbrowser_wc3MouseButtons.right=2;var crossbrowser_ieMouseButtons=[];crossbrowser_ieMouseButtons.left=1;crossbrowser_ieMouseButtons.middle=4;crossbrowser_ieMouseButtons.right=2;function crossbrowser_findMouseButtonStatus(event,buttonPosition){var buttonNumber=(event)?crossbrowser_wc3MouseButtons[buttonPosition]:crossbrowser_ieMouseButtons[buttonPosition];var isPressed=false;if(!event){event=window.event;}

if(event.which){isPressed=(event.which==buttonNumber);}

else if(event.button){isPressed=(event.button==buttonNumber);}

return isPressed;}
;function crossbrowser_dispatchEvent(element,eventObject){
if(IS_IE){element.fireEvent("on"+eventObject.type,eventObject);}

else if(IS_MOZILLA){element.dispatchEvent(eventObject);}

}

function crossbrowser_isInDom(element){if(!element.parentNode){return false;}

else if(element.parentNode.tagName){return true;}

else 
{return false;}

}

function crossbrowser_getBrowserName(){if(crossbrowser_browserName){return crossbrowser_browserName;}

var userAgent=navigator.userAgent;if(userAgent){if(userAgent.indexOf("MSIE")!=-1){crossbrowser_browserName="Internet Explorer";return crossbrowser_browserName;}

else if(userAgent.indexOf("Firefox")!=-1){crossbrowser_browserName="Firefox";return crossbrowser_browserName;}

else if(userAgent.toLowerCase().indexOf('chrome')>-1){crossbrowser_browserName="Chrome";return crossbrowser_browserName;}

}

var vendor=navigator.vendor;if(vendor){if(userAgent.indexOf("Apple")!=-1){crossbrowser_browserName="Safari";return crossbrowser_browserName;}

}

else if(window.opera){crossbrowser_browserName="Opera";return crossbrowser_browserName;}

crossbrowser_browserName="Unknown";return crossbrowser_browserName;}

function crossbrowser_attachEvent(object,eventName,eventFunction){if(IS_MOZILLA){eventName=eventName.substring(2,eventName.length);object.addEventListener(eventName,eventFunction,false);}

else if(IS_IE){object.attachEvent(eventName,eventFunction);}

}

function crossbrowser_stopEvent(event){if(IS_MOZILLA){event.stopPropagation();event.preventDefault();}

else if(IS_IE){if(!event){event=window.event;}

event.returnValue=false;event.cancelBubble=true;}

}

function crossbrowser_handleEvent(event){if(IS_MOZILLA){event.stopPropagation();event.preventDefault();}

else if(IS_IE){window.event.returnValue=false;window.event.cancelBubble=true;}

}

function crossbrowser_cancelBubble(event){if(IS_MOZILLA){event.stopPropagation();}

else if(IS_IE&&event){event.cancelBubble=true;}

else if(IS_IE&&window.event){window.event.cancelBubble=true;}

}

function crossbrowser_getKeyCode(event){var key;if(IS_MOZILLA){key=(null!=event?event.which:window.event.keyCode);}

else if(IS_IE){key=window.event.keyCode;}

return key;}

function crossbrowser_getAttribute(anObject,attributeName){var value=(anObject[attributeName])?anObject[attributeName]:anObject.getAttribute(attributeName);return value;}

function crossbrowser_removeEvent(element,eventType,eventFunction){if(!eventFunction){return ;}

if(IS_MOZILLA){eventType=eventType.substring(2,eventType.length);element.removeEventListener(eventType,eventFunction,false);}

else if(IS_IE){element.detachEvent(eventType,eventFunction);}

}

function crossbrowser_checkBrowser(messageHandler){var isValidBrowser=true;if(navigator.userAgent.indexOf("Firefox")!=-1){var versionindex=navigator.userAgent.indexOf("Firefox")+8
if(parseInt(navigator.userAgent.charAt(versionindex))<2){crossbrowser_buildBrowserAlert("Firefox",messageHandler);isValidBrowser=false;}

}

else if(navigator.userAgent.indexOf("MSIE")!=-1){var temp=navigator.appVersion.split("MSIE")
var version=parseFloat(temp[1])
if(version<6){crossbrowser_buildBrowserAlert("MSIE",messageHandler);isValidBrowser=false;}

}

else if(navigator.userAgent.indexOf("Safari")!=-1){if(version<3){crossbrowser_buildBrowserAlert("Safari",messageHandler);isValidBrowser=false;}

}

return isValidBrowser;}

function crossbrowser_buildBrowserAlert(browserType,messageHandler){var table=document.createElement("table");table.width="100%";table.cellPadding=0;table.cellSpacing=0;g_cache.popup.editableDiv.appendChild(table);var tbody=document.createElement("tbody");table.appendChild(tbody);var tr=document.createElement("tr");tbody.appendChild(tr);var td=document.createElement("td");td.width=(document.documentElement.clientWidth)?document.documentElement.clientWidth:document.body.clientWidth;td.height=1000;td.style.position="absolute";td.style.backgroundColor="#eeeeee";td.vAlign="middle";td.align="center";tr.appendChild(td);if(browserType=="Firefox"){var element=messageHandler("Firefox","http://www.mozilla.com/en-US/firefox/upgrade");element.style.marginTop=200;td.appendChild(element);}

else if(browserType=="MSIE"){var element=messageHandler("Internet Explorer","http://www.microsoft.com/windows/downloads/ie/getitnow.mspx");td.appendChild(element);}

else if(browserType=="Safari"){var element=messageHandler("Safari","http://www.apple.com/safari/download");td.appendChild(element);}

}

function scrambleString(aString){return aString;}

function util_isInDom(element){if(!element.parentNode){return false;}

else if(element.parentNode.tagName){return true;}

else 
{return false;}

}

function crossbrowser_getIEVersion(){if(navigator.appName=='Microsoft Internet Explorer'){var rv=-1;var ua=navigator.userAgent;var re=new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");var ver=re.exec(ua)[1];if(ver!=null){rv=ver.charAt(0);}

}

return rv;}


function isInDom(element){var parentNode=element.parentNode;if(!parentNode){return false;}

else if(!parentNode.tagName){return false;}

else if(parentNode.tagName.toLowerCase()=="body"){return true;}

else if(parentNode){return isInDom(parentNode);}

else 
{return true;}

}



;var eh_events=[];
function eh_attachEvent(eventType,element,eventFx,eventGroupName,stopEvent,ownerWindow,doReturn,returnValue,allowBubbling){element[eventType]=function(event){ownerWindow=(!ownerWindow)?window:ownerWindow;event=(!event)?ownerWindow.event:event;if(eventFx){eventFx(event);}

if(stopEvent){crossbrowser_stopEvent(event);}

else if(!allowBubbling){crossbrowser_cancelBubble(event);}

if(doReturn){return returnValue;}

}
;eh_registerEvent(element,eventType,eventGroupName);}
;function eh_attachOnMouseEnter(element,fx,ownerWindow){if(BrowserUtil.isIE()||BrowserUtil.isFF()){eh_attachEvent("onmouseenter",element,fx,null,null,ownerWindow);}

else 
{element.onmouseover=function(event){if(!event){ownerWindow=(!ownerWindow)?window:ownerWindow;event=ownerWindow.event;}

if(!isDescendent(event.fromElement,event.currentTarget)&&isDescendent(event.toElement,event.currentTarget)){fx(event);}

}
;eh_registerEvent(element,"onmouseover");}

}

function eh_attachOnMouseLeave(element,fx,ownerWindow){if(BrowserUtil.isIE()||BrowserUtil.isFF()){eh_attachEvent("onmouseleave",element,fx,null,null,ownerWindow);}

else 
{var outFx=function(){if(!isInDom(element)){document.body.removeEventListener("mouseout",outFx,false);}

if(isDescendent(event.srcElement,element)&&!isDescendent(event.toElement,element)){fx(event);}

}

eh_addEvent("onmouseout",document.body,outFx);}

}


function eh_removeEventHandler(element,eventType,eventFx){if(!eventFx){return ;}

if(element.removeEventListener){var evType=eventType.substring(2,eventType.length);element.removeEventListener(evType,eventFx,false);}

else if(element.detachEvent){element.detachEvent(eventType,eventFx);}

}
;
function eh_attachBeforeUnload(onBeforeUnloadFx){var isAlreadyRun=false;var fx=function(){if(!isAlreadyRun){isAlreadyRun=true;onBeforeUnloadFx();}

}

eh_addEvent("onbeforeunload",window,fx);}

function eh_addEvent(eventName,object,eventFunction){if(document.getElementById&&!document.all){eventName=eventName.substring(2,eventName.length);object.addEventListener(eventName,eventFunction,false);}

else if(document.all){object.attachEvent(eventName,eventFunction);}

}

function eh_getSource(event){return event.target||event.srcElement;}


function eh_attachEventNoRegister(eventType,element,eventFx,eventGroupName,stopEvent,ownerWindow,doReturn,returnValue,allowBubbling){element[eventType]=function(event){ownerWindow=(!ownerWindow)?window:ownerWindow;event=(!event)?ownerWindow.event:event;if(eventFx){eventFx(event);}

if(stopEvent){crossbrowser_stopEvent(event);}

else if(!allowBubbling){crossbrowser_cancelBubble(event);}

if(doReturn){return returnValue;}

}
;}

function eh_registerEvent(element,eventType,eventGroupName){if(!IS_IE){return ;}

if(!eventGroupName){eventGroupName="default";}

var eventGroup=eh_events[eventGroupName];if(!eventGroup){eventGroup=[];eh_events[eventGroupName]=eventGroup;}

var eventsByType=eventGroup[eventType];if(!eventsByType){eventsByType=[];eventGroup[eventType]=eventsByType;}

eventsByType.push(element);}


function eh_clearEventGroup(eventGroupName,omitGC){eh_clearEventsNotInDom();}

function eh_clearEventsNotInDom(){for(var groupName in eh_events)
{eh_clearUnusedEvents(eh_events[groupName]);}

if(IS_IE){CollectGarbage();}

}

function eh_clearUnusedEvents(eventGroup){for(var eventType in eventGroup)
{var eventsByType=eventGroup[eventType];var count=eventsByType.length;for(var i=0;i<count;i++)
{try
{if(!isInDom(eventsByType[i])){eventsByType[i][eventType]=null;}

}

catch(e)
{}

}

}

}


function eh_clearAllEvents(){for(var groupName in eh_events)
{eh_clearEventGroup(groupName,true);}

document.body.onunload=null;if(IS_IE){CollectGarbage();}

}

function eh_initalizeGC(){document.body.onunload=eh_clearAllEvents;}



validation_displayFieldError=display_displayAlert;var validation_displayErrors=display_displayAlert;function display_displayAlert(errorList,successList){var errorString="";if(0<errorList.length){for(var i=0;i<errorList.length;i++)
{errorString+=errorList[i].errorMessage+"\n";}

alert(errorString);}

}


var key_keyCodeTranslater=new Array();key_keyCodeTranslater[48]="0";key_keyCodeTranslater[49]="1";key_keyCodeTranslater[50]="2";key_keyCodeTranslater[51]="3";key_keyCodeTranslater[52]="4";key_keyCodeTranslater[53]="5";key_keyCodeTranslater[54]="6";key_keyCodeTranslater[55]="7";key_keyCodeTranslater[56]="8";key_keyCodeTranslater[57]="9";key_keyCodeTranslater[65]="A";key_keyCodeTranslater[66]="B";key_keyCodeTranslater[67]="C";key_keyCodeTranslater[68]="D";key_keyCodeTranslater[69]="E";key_keyCodeTranslater[70]="F";key_keyCodeTranslater[71]="G";key_keyCodeTranslater[72]="H";key_keyCodeTranslater[73]="I";key_keyCodeTranslater[74]="J";key_keyCodeTranslater[75]="K";key_keyCodeTranslater[76]="L";key_keyCodeTranslater[77]="M";key_keyCodeTranslater[78]="N";key_keyCodeTranslater[79]="O";key_keyCodeTranslater[80]="P";key_keyCodeTranslater[81]="Q";key_keyCodeTranslater[82]="R";key_keyCodeTranslater[83]="S";key_keyCodeTranslater[84]="T";key_keyCodeTranslater[85]="U";key_keyCodeTranslater[86]="V";key_keyCodeTranslater[87]="W";key_keyCodeTranslater[88]="X";key_keyCodeTranslater[89]="Y";key_keyCodeTranslater[90]="Z";key_keyCodeTranslater[96]="0";key_keyCodeTranslater[97]="1";key_keyCodeTranslater[98]="2";key_keyCodeTranslater[99]="3";key_keyCodeTranslater[100]="4";key_keyCodeTranslater[101]="5";key_keyCodeTranslater[102]="6";key_keyCodeTranslater[103]="7";key_keyCodeTranslater[104]="8";key_keyCodeTranslater[105]="9";

var year_requiredMsgStr1="The number '";var year_requiredMsgStr2="' is not a valid email year. It has to be a number between 1000 and 2500.";var email_requiredMsgStr1="The address '";var email_requiredMsgStr2="' is not a valid email address.";var dynfield_requiredMsgStr1="Field '";var dynfield_requiredMsgStr2="' is not defined for type '";
var time_timeMsgStr1="The field '";var time_timeMsgStr2="' is not a valid time.";var time_afterTimeMsgStr1="The field '";var time_afterTimeMsgStr2="' should be later than the field '";var time_afterTimeMsgStr3="'.";var time_beforeTimeMsgStr1="The field '";var time_beforeTimeMsgStr2="' should be earlier than the field '";var time_beforeTimeMsgStr3="'.";var time_use24HourFormat=false;var numeric_minMsgStr1="The field '";var numeric_minMsgStr2="' should be greater than ";var numeric_minMsgStr3=".";var numeric_maxMsgStr1="The field '";var numeric_maxMsgStr2="' should be less than ";var numeric_maxMsgStr3=".";var numeric_lessThanMsgStr1="The field '";var numeric_lessThanMsgStr2="' should be less than the field '";var numeric_lessThanMsgStr3="'.";var numeric_lessThanEqualMsgStr1="The field '";var numeric_lessThanEqualMsgStr2="' should be less than or equal to the field '";var numeric_lessThanEqualMsgStr3="'.";var numeric_greaterThanMsgStr1="The field '";var numeric_greaterThanMsgStr2="' should be greater than the field '";var numeric_greaterThanMsgStr3="'.";var numeric_greaterThanEqualMsgStr1="The field '";var numeric_greaterThanEqualMsgStr2="' should be greater than or equal to the field '";var numeric_greaterThanEqualMsgStr3="'.";var numeric_decimalMsgStr1="The field '";var numeric_decimalMsgStr2="' is not a valid decimal.";var required_requiredMsgStr1="The field '";var required_requiredMsgStr2="' is required.";var select_reqSelMsgStr1=" The field '";var select_reqSelMsgStr2="' must have exactly ";var select_reqSelMsgStr3=" options selected.";var select_minSelMsgStr1=" The field '";var select_minSelMsgStr2="' must have a minimum of ";var select_minSelMsgStr3=" options selected.";var select_maxSelMsgStr1=" The field '";var select_maxSelMsgStr2="' must have not have more than ";var select_maxSelMsgStr3=" options selected.";var length_lengthMsgStr1="The field '";var length_lengthMsgStr2="' should be ";var length_lengthMsgStr3=" characters long.";var phone_phoneMsgStr1="The field '";var phone_phoneMsgStr2="' is not a valid phone number.";

var PERIOD_KEYCODE=46;var COMMA_KEYCODE=44;var MINUS_KEYCODE=45;var ZERO_KEYCODE=48;var NINE_KEYCODE=57;var BACKSPACE_KEYCODE=8;var DEFAULT_KEYCODE=0;
var valutility_currentEvent;
function valutility_cancelKeyPress(){crossbrowser_handleEvent(valutility_currentEvent);return null;}


function valutility_isNumeric(){var keyCode=crossbrowser_getKeyCode(valutility_currentEvent);if(keyCode>=ZERO_KEYCODE&&keyCode<=NINE_KEYCODE){return true;}

return false;}


function valutility_isAlphabetic(){var keyCode=crossbrowser_getKeyCode(valutility_currentEvent);if((keyCode>=65&&keyCode<=90)||(keyCode>=97&&keyCode<=122)){return true;}

return false;}


function valutility_isCharacter(keyCode){var keyCodePressed=crossbrowser_getKeyCode(valutility_currentEvent);if(keyCodePressed==keyCode){return true;}

return false;}

;;;;
var validation_ValidationTypes=new Array();
crossbrowser_attachEvent(window,"onload",validation_init);var validation_displayErrors;var validation_displayFieldError;var validation_elTypesToValidate=new Array("input","select","textarea","span","div","nobr","a");function validation_init(){validation_attachValidation();}



function validation_EventFunction(eventName,functionPointer){this.eventName=eventName;this.functionPointer=functionPointer;}


function validation_Error(element,errorMessage){this.element=element;this.errorMessage=errorMessage;}


function validation_ValidationType(name,defaultFunction){this.defaultFunction=defaultFunction;this.eventValidationList=new Array();this.addEventFunction=function(eventName,functionPointer){this.eventValidationList[eventName]=functionPointer;}

validation_ValidationTypes[name.toLowerCase()]=this;}


function validation_getFunctionForValType(valType,eventType){return valType.eventValidationList[eventType];}


function validation_validate(container){if(null==container){container=document.body;}

var errorList=new Array();var successList=new Array();for(var i=0;i<validation_elTypesToValidate.length;i++)
{var elementList=container.getElementsByTagName(validation_elTypesToValidate[i]);validaton_validateCollection(elementList,errorList,successList);}

validation_displayErrors(errorList,successList);return (errorList.length==0)?true:false;}

function validation_validateElement(element){var errorList=new Array();var successList=new Array();var someErrors=validation_validateField(element);for(var j=0;j<someErrors.length;j++)
{errorList.push(someErrors[j]);}

validation_displayErrors(errorList,successList);return (errorList.length==0)?true:false;}

function validation_validateLinks(container){var errorList=new Array();var successList=new Array();validaton_validateCollection(container.getElementsByTagName("a"),errorList,successList);validation_displayErrors(errorList,successList);return (errorList.length==0)?true:false;}

function validation_validateInputs(container){var errorList=new Array();var successList=new Array();validaton_validateCollection(container.getElementsByTagName("input"),errorList,successList);validation_displayErrors(errorList,successList);return (errorList.length==0)?true:false;}


function validaton_validateCollection(aCollection,errorList,successList){for(var i=0;i<aCollection.length;i++)
{var someErrors=validation_validateField(aCollection[i]);for(var j=0;j<someErrors.length;j++)
{errorList.push(someErrors[j]);}

if(0==someErrors.length){successList.push(aCollection[i]);}

}

}


function validation_validateField(anInput){var errorList=new Array();var validationType=validation_getAttribute(anInput,"validationType");if(null!=validationType&&validationType!=""){var valTypeArray=validation_removeSpaces(validationType).split(",");for(var j=0;j<valTypeArray.length;j++)
{var valType=validation_ValidationTypes[valTypeArray[j]];if((undefined!=valType)&&(null!=valType.defaultFunction)){aPossibleError=valType.defaultFunction(anInput);if(null!=aPossibleError){errorList.push(aPossibleError);}

}

}

}

return errorList;}


function validation_ValidateFieldOnEvent(object,eventType,customEventHandler,event){valutility_currentEvent=event;var errorList=new Array();var validationType=validation_getAttribute(object,"validationType");if(null!=validationType){var valTypeArray=validation_removeSpaces(validationType).split(",");for(var j=0;j<valTypeArray.length;j++)
{var valType=validation_ValidationTypes[valTypeArray[j]];var valFunc=validation_getFunctionForValType(valType,eventType);if(null!=valFunc){aPossibleError=valFunc(object);if(null!=aPossibleError){errorList.push(aPossibleError);}

}

}

}

var successList=new Array();if(errorList.length==0){successList.push(object);}

if(window.validation_displayFieldError){validation_displayFieldError(errorList,successList);}

if((errorList.length==0)&&(customEventHandler!=null)){customEventHandler();}

}


function validation_attachValidation(container){if(null==container){container=document.body;}

for(var i=0;i<validation_elTypesToValidate.length;i++)
{var elementList=container.getElementsByTagName(validation_elTypesToValidate[i]);validation_attachValidationToCollection(elementList);}

}


function validation_attachValidationToCollection(aCollection){for(var i=0;i<aCollection.length;i++)
{validation_attachValidationToElement(aCollection[i]);}

}


function validation_attachValidationToElement(anObject){var validationType=validation_getAttribute(anObject,"validationType");if(validationType==null){return ;}

var eventsAdded=new Array();var valTypeArray=validation_removeSpaces(validationType).split(",");for(var j=0;j<valTypeArray.length;j++)
{var validationObject=validation_ValidationTypes[valTypeArray[j].toLowerCase()];if(null!=validationObject){var eventList=validationObject.eventValidationList;for(var k in eventList)
{if(!eventsAdded[k]){var customEventHandler=anObject[k];var temp=k;validation_attachEventToElement(k,anObject,customEventHandler)
if(k=="onload"){validation_ValidateFieldOnEvent(anObject,k,customEventHandler);}

eventsAdded[k]=true;}

}

}

}

}


function validation_attachEventToElement(eventType,anObject,customEventHandler){anObject[eventType]=function(event){validation_ValidateFieldOnEvent(anObject,eventType,customEventHandler,event);}


}


function validation_getAttribute(anObject,attributeName){var value=(anObject[attributeName])?anObject[attributeName]:anObject.getAttribute(attributeName);return value;}


function validation_removeSpaces(aString){return aString.replace(/ /g,"");}


String.prototype.trim=function(){return trim(this)}
;String.prototype.safeGetValue=function(val,defVal){return safeGetValue(val,defVal)}
;String.prototype.escapeStrForSave=function(){return escapeStrForSave(this)}
;String.prototype.unescapeStrFromLoad=function(){return unescapeStrFromLoad(this)}
;String.prototype.escapeStrForXml=function(){return escapeStrForXml(this)}
;String.prototype.unescapeStrFromXml=function(){return unescapeStrFromXml(this)}
;String.prototype.sc={"\\":"\\\\","(":"\\(","^":"\\^","$":"\\$",".":"\\.","|":"\\|","?":"\\?","*":"\\*","+":"\\+",")":"\\)"}
;String.prototype.equals=function(value){return value==this;}
;String.prototype.replaceAll=function(replaceVal,replaceWith){try
{var sc=this.sc
for(var aChar in this.sc)
{var rChar=sc[aChar];replaceVal=replaceVal.replace(aChar,rChar);}

return this.replace(new RegExp(replaceVal,"g"),replaceWith);}

catch(e)
{return this.replace(new RegExp(replaceVal,"g"),replaceWith);}

}

function trim(str){var str=str.replace(/^\s\s*/,'');var ws=/\s/;var i=str.length;while(ws.test(str.charAt(--i))){}
;return str.slice(0,i+1);}

function safeGetValue(val,defVal){if(null!=val){return val;}

return defVal;}

function escapeStrForSave(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("[+]","g"),"!@!plus!@!");strRet=strRet.replace(new RegExp("[\n]","g"),"!@!newline!@!");return strRet;}

function unescapeStrFromLoad(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("!@!plus!@!","g"),"+");strRet=strRet.replace(new RegExp("!@!newline!@!","g"),"\n");return strRet;}

function escapeStrForXml(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("[&]","g"),"&amp;");strRet=strRet.replace(new RegExp("[']","g"),"&apos;");strRet=strRet.replace(new RegExp("[\"]","g"),"&quot;");strRet=strRet.replace(new RegExp("[<]","g"),"&lt;");strRet=strRet.replace(new RegExp("[>]","g"),"&gt;");return strRet;}

function unescapeStrFromXml(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("&amp;","g"),"&");strRet=strRet.replace(new RegExp("&apos;","g"),"'");strRet=strRet.replace(new RegExp("&quot;","g"),"\"");strRet=strRet.replace(new RegExp("&lt;","g"),"<");strRet=strRet.replace(new RegExp("&gt;","g"),">");return strRet;}

;
{if(this.validation_ValidationType){required_required=new validation_ValidationType("required",required_isFilled);}

}

function required_isFilled(object){var emptyValuesFormats={}

var emptyDateFormat;try
{emptyValuesFormats[g_sessionInformation.settings.date_format.empty_date]=true;}

catch(e)
{emptyValuesFormats["mm/dd/yyyy"]=true;}

var field=object.value.trim();if(null==field||""==field||emptyValuesFormats[field]){var errorMessage=required_requiredMsgStr1+object.displayName+required_requiredMsgStr2;return (new validation_Error(object,errorMessage));}

}

;
var date_separator;var date_datePos;var date_monthPos;var date_yearPos;var date_formatGuide;function date_initDateFormat(){try
{var dateFormat=g_sessionInformation.settings.date_format;date_separator=dateFormat.separator;date_datePos=dateFormat.date_pos;date_monthPos=dateFormat.month_pos;date_yearPos=dateFormat.year_pos;date_formatGuide=dateFormat.empty_date;}

catch(e)
{date_separator="/";date_datePos=2;date_monthPos=1;date_yearPos=3;date_formatGuide="MM/dd/yyyy";}

}

date_initDateFormat();var date_dateMsgStr1="The field '";var date_dateMsgStr2="' is not a valid date.";var date_beforeDateMsgStr1="The field '";var date_beforeDateMsgStr2="' should be earlier than the field '";var date_beforeDateMsgStr3="'.";var date_afterDateMsgStr1="The field '";var date_afterDateMsgStr2="' should be later than the field '";var date_afterDateMsgStr3="'.";{var date_date=new validation_ValidationType("date",date_isDate);date_date.addEventFunction("onkeypress",date_filterKeyPress);date_date.addEventFunction("onchange",date_isDate);date_date.addEventFunction("onload",date_formatEmptyDate);date_date.addEventFunction("onfocus",formatDateForEntry);var date_beforeDate=new validation_ValidationType("beforedate",date_isBeforeDate);var date_afterDate=new validation_ValidationType("afterdate",date_isAfterDate);}


function date_ValDate(date,month,year){try
{this.date=parseInt(date,10);this.month=parseInt(month,10);this.year=parseInt(year,10);}

catch(e)
{this.date=date;this.month=month;this.year=year;}

}

function date_ValDateBase(){this.getDayStr=function(index,format){return (format==null||format=="full")?date_days[index]:date_days_short[index]}
;this.getMonthStr=function(index,format){return (format==null||format=="full")?date_months[index]:date_months_short[index]}
;this.getDateString=function(){return date_formatDate(this.date,this.month,this.year)}
;this.getElegantString=function(){return date_toElegantString(this)}
;this.toStdFormat=function(){return date_formatDate(this.date,this.month,this.year);}

this.createDateBeforeThisDate=function(daysToSubstract){return date_createDateBeforeThisDate(this,daysToSubstract)
}
;this.toDbFormat=function(){return date_toDbFormat(this.year,this.month,this.date);}
;this.dateToString=function(format){return date_getFormatedStr(this,format)
}
;this.isSameThanOtherDate=function(otherDate){return date_isSameThanOtherDate(this,otherDate);}
;this.getIntervaDateInterval=function(otherDate){return date_getIntervalBetweenDates(this,otherDate);}
;this.getNextDay=function(){return date_getNextDay(this)
}
;this.getPreviousDay=function(){return date_getPreviousDay(this);}
;this.addDaysToDate=function(numberOfDays){date_change(this,numberOfDays);return this;}

this.clone=function(){return new date_ValDate(this.date,this.month,this.year);}

}

date_ValDate.prototype=new date_ValDateBase();function date_clone(dateObj){return new date_ValDate(dateObj.date,dateObj.month,dateObj.year);}

function date_getPreviousDayOfWeek(dateObj,dayIndex){var newDateObj=new date_ValDate(dateObj.date,dateObj.month,dateObj.year);var thisDayIndex=date_getDayIndex(dateObj);var difference=dayIndex-thisDayIndex;if(difference>0){difference-=7;}

date_change(newDateObj,difference);return newDateObj;}

function date_getMax(date1,date2){return (date_isBeforeOtherDate(date1,date2))?date2:date1;}

function date_getMin(date1,date2){return (date_isBeforeOtherDate(date1,date2))?date1:date2;}

function date_getCurrentDate(){return new date_ValDate(g_currentDateTime.date,g_currentDateTime.month,g_currentDateTime.year);}

function date_createDateBeforeThisDate(thisObj,daysToSubstract){var newDateObj=null;var newDate=thisObj.date-daysToSubstract;if(newDate<=0){var previousMonth=thisObj.month-1;var year=thisObj.year;if(previousMonth<1){previousMonth=12;year--;}

var previousMonthDayCount=date_getDaysInMonth(previousMonth,year);newDateObj=new date_ValDate(previousMonthDayCount+newDate,previousMonth,year);}

else 
{newDateObj=new date_ValDate(newDate,thisObj.month,thisObj.year)
}

return newDateObj;}


function date_isBeforeDate(object){var otherField=document.getElementById(object.dateBefore);if(null==otherField){return ;}

var thisDate=date_toStdFormat(object.value);var otherDate=date_toStdFormat(otherField.value);if((null==thisDate)||(null==otherDate)){return ;}

if(!date_isBeforeOtherDate(thisDate,otherDate)){var errorMessage=date_beforeDateMsgStr1+object.displayName+date_beforeDateMsgStr2+
otherField.displayName+date_beforeDateMsgStr3;return (new validation_Error(object,errorMessage));}

}


function date_isAfterDate(object){var otherField=document.getElementById(object.dateAfter);if(null==otherField){return ;}

var thisDate=date_toStdFormat(object.value);var otherDate=date_toStdFormat(otherField.value);if((null==thisDate)||(null==otherDate)){return ;}

if(!date_isBeforeOtherDate(otherDate,thisDate)){var errorMessage=date_afterDateMsgStr1+object.displayName+date_afterDateMsgStr2+
otherField.displayName+date_afterDateMsgStr3;return (new validation_Error(object,errorMessage));}

}


function date_isSameThanOtherDate(date,otherDate){return ((date.year==otherDate.year)&&(date.month==otherDate.month)&&(date.date==otherDate.date));}


function date_isBeforeOtherDate(date,otherDate){return ((date.year<otherDate.year)||
((date.year==otherDate.year)&&(date.month<otherDate.month))||
((date.year==otherDate.year)&&(date.month==otherDate.month)&&(date.date<otherDate.date)));}


function date_toStdFormat(dateString){re=/\D*(\d*)\D*(\d*)\D*(\d*)\D*/;var result=re.exec(dateString);if(null==result){return null;}

var date=date_parseDatePart(result[date_datePos]);var month=date_parseDatePart(result[date_monthPos]);var year=date_parseYearPart(result[date_yearPos]);if(date_isDateValid(date,month,year)){return (new date_ValDate(date,month,year));}

else 
{return null;}

}

function date_getDayIndex(dateObj){if(dateObj==null){return ;}

var aDate=new Date(dateObj.year,dateObj.month-1,dateObj.date);return aDate.getDay();}

function date_jsFormat(dateObj){var year=dateObj.year;var month=dateObj.month;var date=dateObj.date;if(date>=0&&date<=9){date="0"+date;}

if(month>=0&&month<=9){month="0"+month;}

var jsFormat=""+year+month+date;return parseInt(jsFormat);}

function date_jsMonthFormat(dateObj){var year=dateObj.year;var month=dateObj.month;if(month>=0&&month<=9){month="0"+month;}

var jsFormat=""+year+month;return parseInt(jsFormat);}
;function date_jsFormatToDateObj(jsFormatStr){var jsFormatStr=jsFormatStr+' ';var year=jsFormatStr.substr(0,4);var month=jsFormatStr.substr(4,2);var firstMonthDigit=month.substr(0,1);var secondMonthDigit=month.substr(1,1);var date=jsFormatStr.substr(6,2);var firstDateDigit=date.substr(0,1);var secondDateDigit=date.substr(1,1);if(firstMonthDigit=="0"){month=secondMonthDigit;}

if(firstDateDigit=="0"){date=secondDateDigit;}

return (new date_ValDate(date,month,year))
}
;function date_toString(dateObj){if(null==dateObj||null==dateObj.date){return "";}

return date_formatDate(dateObj.date,dateObj.month,dateObj.year);}
;function date_parseDBFormat(dateDBFormat){var dateObj=dateDBFormat.split("-");return new date_ValDate(dateObj[2],dateObj[1],dateObj[0]);}

function date_toDbString(dateObj){return date_toDbFormat(dateObj.year,dateObj.month,dateObj.date);}

function date_parseDateString(dateStr){var month=dateStr.substr(0,2);var date=dateStr.substr(3,2);var year=dateStr.substr(6,4);if(month.substr(0,1)==0){month=month.substr(1,1);}

if(date.substr(0,1)==0){date=date.substr(1,1);}

var dateObj=new date_ValDate(date,month,year);return dateObj;}
;function date_getNextDay(dateObj){var date=dateObj.date+1;var month=dateObj.month;var year=dateObj.year;var monthDayCount=date_getMonthDayCount(dateObj);if(date>monthDayCount){date=1;month=month+1;}

if(month>12){month=1;year++;}

return (new date_ValDate(date,month,year));}
;
function date_change(dateObj,numberOfDays){if(0==numberOfDays){return }
;var dayOfYear=numberOfDays;var isLeapYear=date_isLeapYear(dateObj.year);var daysInYear=(isLeapYear)?366:365;var daysInFebruary=(isLeapYear)?29:28;var dayCounts=[0,31,daysInFebruary,31,30,31,30,31,31,30,31,30,31];for(var i=1;i<dateObj.month+1;i++)
{if(i==dateObj.month){dayOfYear+=dateObj.date;break;}

dayOfYear+=dayCounts[i];}

while(dayOfYear>daysInYear)
{dayOfYear=dayOfYear-daysInYear;dateObj.year=dateObj.year+1;isLeapYear=date_isLeapYear(dateObj.year);daysInYear=(isLeapYear)?366:365;}

while(dayOfYear<=0)
{isLeapYear=date_isLeapYear(dateObj.year-1);daysInYear=(isLeapYear)?366:365;dayOfYear=daysInYear+dayOfYear;dateObj.year=dateObj.year-1;}

daysInFebruary=(isLeapYear)?29:28;dayCounts=[0,31,daysInFebruary,31,30,31,30,31,31,30,31,30,31];for(var i=1;i<dayCounts.length;i++)
{var dayCount=dayCounts[i];if(dayCount>=dayOfYear){dateObj.month=i;dateObj.date=dayOfYear;break;}

dayOfYear-=dayCount;}

}
;function date_getPreviousDay(dateObj){var date=dateObj.date-1;var month=dateObj.month;var year=dateObj.year;if(date<1){var previousMonth=date_adjustMonth(dateObj,-1);date=date_getMonthDayCount(previousMonth);month=previousMonth.month;year=previousMonth.year;}

return (new date_ValDate(date,month,year));}
;function date_getMonthDayCount(dateObj){var month=dateObj.month;var dayCounts=new Array(0,31,-1,31,30,31,30,31,31,30,31,30,31);var dayCount=dayCounts[month];if(2==month){dayCount=date_isLeapYear(dateObj.year)?29:28;}

return dayCount;}
;function date_adjustMonth(dateObj,addOrSubtract){var month=dateObj.month+addOrSubtract;var year=dateObj.year;var date=dateObj.date;if(1>month){month+=12;year--;}

else if(12<month){month-=12;year++;}

var newMonthDayCount=date_getMonthDayCount(new date_ValDate(1,month,year));date=Math.min(date,newMonthDayCount);return (new date_ValDate(date,month,year));}
;function date_toJsDateObj(dateObj){return new Date(dateObj.year,dateObj.month-1,dateObj.date);}

function date_getDayString(dateObj,format){if(dateObj==null){return ;}

var aDate=new Date(dateObj.year,dateObj.month-1,dateObj.date);var day=(format==null||format=="full")?date_days[aDate.getDay()]:date_days_short[aDate.getDay()];return day;}

function date_DateInYears(dateObj){if(dateObj==null){return ;}

var currentYear=new Date().getYear();return currentYear-dateObj.year;}
;
function date_filterKeyPress(){var allowKey=(!valutility_isAlphabetic());if(!allowKey){valutility_cancelKeyPress();}

return null;}


function date_isDate(object){var dateString=object.value;if(null==dateString||""==dateString||date_formatGuide==dateString){return ;}

var dateObj=date_toStdFormat(dateString);if(null!=dateObj){object.value=date_formatDate(dateObj.date,dateObj.month,dateObj.year);}

else 
{var errorMessage=date_dateMsgStr1+object.displayName+date_dateMsgStr2;return (new validation_Error(object,errorMessage));}

}

function date_formatEmptyDate(inputEl){if(inputEl.value==""){inputEl.value=date_formatGuide;inputEl.style.color="#999999";}

}

function formatDateForEntry(inputEl){if(inputEl.value==date_formatGuide){inputEl.value="";inputEl.style.color="";}

}

function date_formatDate(date,month,year){var dateString="";dateString+=date_selectDatePart(1,date,month,year)+date_separator;dateString+=date_selectDatePart(2,date,month,year)+date_separator;dateString+=date_selectDatePart(3,date,month,year);return dateString;}

function date_toDbFormat(year,month,date){return year+"-"+date_formatDatePart(month)+"-"+date_formatDatePart(date);}

function date_selectDatePart(partNumber,date,month,year){if(partNumber==date_datePos){return date_formatDatePart(date);}

else if(partNumber==date_monthPos){return date_formatDatePart(month);}

else if(partNumber==date_yearPos){return year;}

}


function date_formatDatePart(number){if(number<10){return "0"+number;}

return number;}

function date_parseDatePart(str){return parseInt(date_stripPrecedingZeros(str));}

function date_stripPrecedingZeros(str){var i=0;while(str.charAt(i)=='0')
{i++;}

return str.substring(i,str.length);}

function date_parseYearPart(str){var year=parseInt(date_stripPrecedingZeros(str));if(year<30){year+=2000;}

else if(year>30&&year<100){year+=1900;}

return year;}

function date_isDateValid(date,month,year){if(isNaN(date)||isNaN(month)||isNaN(year)){return false;}

if(month<1||month>12){return false;}

var daysInMonth=date_getDaysInMonth(month,year);if(date>daysInMonth){return false;}

if(year<1000){return false;}

return true;}

function date_getDaysInMonth(month,year){var dayCounts=new Array(31,-1,31,30,31,30,31,31,30,31,30,31);var dayCount;if(month==2){dayCount=date_isLeapYear(year)?29:28;}

else 
{dayCount=dayCounts[month-1];}

return dayCount;}


function date_getIntervalBetweenDates(dateObj1,dateObj2){var interval=0;var dateObj1JSFormat=date_jsFormat(dateObj1);var dateObj2JSFormat=date_jsFormat(dateObj2);var earlierDateObj=null;var laterDateObj=null;if(dateObj1JSFormat<dateObj2JSFormat){earlierDateObj=dateObj1;laterDateObj=dateObj2;}

else if(dateObj1JSFormat>dateObj2JSFormat){earlierDateObj=dateObj2;laterDateObj=dateObj1;}

else 
{return 0;}

while(!date_isSameThanOtherDate(earlierDateObj,laterDateObj))
{interval++;earlierDateObj=date_getNextDay(earlierDateObj);}

return interval;}
;
function date_getString(dateObj){return date_generateStr(dateObj,arguments,1);}

function date_getFormatedStr(dateObj,format){return date_generateStr(dateObj,format,0);}

function date_generateStr(dateObj,args,index){if(null==dateObj){return "";}
;if(args.length<=1){return date_toString(dateObj);}

var monthStr="";var monthPos=-1;var dateStr="";var datePos=-1;var fullStr="";for(var i=index;i<args.length;i++)
{switch(args[i]){
case"monthAbbreviation":
monthStr=date_months_short[dateObj.month-1];fullStr+="!monthStr!";monthPos=i;break;case"dateAbbreviation":
var suffix=(date_suffix[dateObj.date])?date_suffix[dateObj.date]:"th";dateStr=dateObj.date+suffix;fullStr+="!dateStr!";datePos=i;break;case"dayAbbreviation":
fullStr+=date_days_short[date_getDayIndex(dateObj)];break;case"dayString":
fullStr+=date_days[date_getDayIndex(dateObj)];break;case"monthString":
monthStr=date_months[dateObj.month-1];fullStr+="!monthStr!";monthPos=i;break;case"month":
fullStr+="!monthStr!";monthStr=dateObj.month;monthPos=i;break;case"date":
fullStr+="!dateStr!";dateStr=dateObj.date;datePos=i;break;case"year":
fullStr+=dateObj.year;break;default:
fullStr+=args[i];}

}

var usDateFormat="!monthStr!/!dateStr!/"+dateObj.year;if(fullStr.indexOf(usDateFormat)>-1){fullStr=fullStr.replace(usDateFormat,date_toString(dateObj));}

else 
{var isDefaultMonthFirst=(date_monthPos<date_datePos);var isMonthFirst=(monthPos<datePos);if(isDefaultMonthFirst!=isMonthFirst){if(fullStr.indexOf("!dateStr")>0&&fullStr.indexOf("!monthStr")>0){fullStr=fullStr.replaceAll("!dateStr!",monthStr);fullStr=fullStr.replaceAll("!monthStr!",dateStr);}

else 
{fullStr=fullStr.replaceAll("!monthStr!",monthStr);fullStr=fullStr.replaceAll("!dateStr!",dateStr);}

}

else 
{fullStr=fullStr.replaceAll("!dateStr!",dateStr);fullStr=fullStr.replaceAll("!monthStr!",monthStr);}

}

return fullStr;}

var date_suffix={1:"st",2:"nd",3:"rd",21:"st",22:"nd",23:"rd",31:"st"}
;var date_months_short=new Array();date_months_short[0]="Jan";date_months_short[1]="Feb";date_months_short[2]="Mar";date_months_short[3]="Apr";date_months_short[4]="May";date_months_short[5]="Jun";date_months_short[6]="Jul";date_months_short[7]="Aug";date_months_short[8]="Sep";date_months_short[9]="Oct";date_months_short[10]="Nov";date_months_short[11]="Dec";var date_days_short=new Array();date_days_short[0]="Sun";date_days_short[1]="Mon";date_days_short[2]="Tue";date_days_short[3]="Wed";date_days_short[4]="Thu";date_days_short[5]="Fri";date_days_short[6]="Sat";var date_months=new Array();date_months[0]="January";date_months[1]="February";date_months[2]="March";date_months[3]="April";date_months[4]="May";date_months[5]="June";date_months[6]="July";date_months[7]="August";date_months[8]="September";date_months[9]="October";date_months[10]="November";date_months[11]="December";var date_days=new Array();date_days[0]="Sunday";date_days[1]="Monday";date_days[2]="Tuesday";date_days[3]="Wednesday";date_days[4]="Thursday";date_days[5]="Friday";date_days[6]="Saturday";
function date_isLeapYear(year){if(((year%4)==0)&&((year%100)!=0)||((year%400)==0)){return true;}

else 
{return false;}

}

function date_createDate(date,month,year){if(date_isDateValid(date,month,year)){return (new date_ValDate(date,month,year));}

else 
{return null;}

}

function date_toElegantString(dateObj){if(dateObj==null){return ;}

var aDate=new Date(dateObj.year,dateObj.month-1,dateObj.date);var month=date_months[aDate.getMonth()];var day=date_days[aDate.getDay()];return day+", "+month+" "+dateObj.date+", "+dateObj.year;}

function date_toElegantStringNoDay(dateObj){if(dateObj==null){return ;}

var aDate=new Date(dateObj.year,dateObj.month-1,dateObj.date);var month=date_months[aDate.getMonth()];var day=date_days[aDate.getDay()];return month+" "+dateObj.date+", "+dateObj.year;}


function clone(myObj){if(typeof(myObj)!='object'){return myObj;}

if(myObj==null){return myObj;}

var myNewObj=[];if(myObj.length&&myObj[0]!=undefined&&!myObj["0_ft"]){for(var i=0;i<myObj.length;i++)
{myNewObj.push(clone(myObj[i]));}

}

else 
{for(var i in myObj)
{myNewObj[i]=clone(myObj[i]);}

}

return myNewObj;}



if(!mc_fieldTypeExtenders){var mc_fieldTypeExtenders={}
;}


mc_fieldTypeExtenders["RIL2"]=function(dynField){dynField.superGetChildField=dynField.getChildField;extendField(dynField,ril_recordIdListBase);}

var ril_recordIdListBase=new RecordIdListBase();function RecordIdListBase(){this.getIds=function(){if(!this.data.idArray){var idsField=this.getChildField("ids");var idList=idsField.getValue();this.data.idArray=(""==idList)?[]:idList.split("|");for(var i=0;i<this.data.idArray.length;i++)
{var id=this.data.idArray[i];if(id==""){this.data.idArray.splice(i,1);}

}

idsField.setValue("refer to id array",true);}

return this.data.idArray;}
;this.getChildField=function(fieldName){if(fieldName=="ids"){var ids=this.superGetChildField(fieldName);ids.setValue=function(value,isDontSetSave){var liveField=this.getLiveField();this.setFieldValue(this,value,isDontSetSave);if(liveField){this.setFieldValue(liveField,value,isDontSetSave);}

return this;}
;return ids;}

else 
{return this.superGetChildField(fieldName);}

}
;this.clearIds=function(){var liveField=this.getLiveField();this.getChildField("ids").setValue("refer to id array",true);var idArray=[];this.data.idArray=idArray;if(liveField){liveField.data.idArray=idArray;}

this.setDoSave();}
;this.addId=function(id){if(this.contains(id)){return this;}

this.setDoSave();var idsList=this.getIds();idsList.push(id);return this;}
;this.contains=function(id){var ids=this.getIds();for(var i=0;i<ids.length;i++)
{if(ids[i]==id){return true;}

}

return false;}
;this.removeId=function(id){this.setDoSave();var idsList=this.getIds();for(var i=0;i<idsList.length;i++)
{if(idsList[i]==id){idsList.splice(i,1);break;}

}

return this;}
;}



var ADateUtil=new ADateUtilBase();function ADateUtilBase(){
this.MONTH_ABBR="m_abbr";
this.MONTH_STR="m_full";
this.DAY_ABBR="d_abbr";
this.DAY_STR="d_full";
this.DAY_LETTER="day_letter";
this.DATE_ABBR="dt_abbr";
this.DATE="date";
this.MONTH="month";
this.YEAR="year";
this.adjustMonth=function(dateObj,interval){var month=dateObj.month+interval;var year=dateObj.year;if(1>month){month+=12;year--;}

else if(12<month){month-=12;year++;}

var newMonthDayCount=this.getMonthDayCount(month,year);var date=Math.min(dateObj.date,newMonthDayCount);return new ADate(date,month,year);}
;
this.getCurrentDate=function(){var currentDate=g_sessionInformation.current_datetime;return new ADate(currentDate.date,currentDate.month,currentDate.year);}


this.stringToDate=function(dateString,dateObj){var re=new RegExp("\\D*(\\d*)\\D*(\\d*)\\D*(\\d*)\\D*");var result=re.exec(dateString);if(null==result){return null;}

var date=this.parseDatePart(result[this.DATE_POS]);var month=this.parseDatePart(result[this.MONTH_POS]);var year=this.parseDatePart(result[this.YEAR_POS])
if(year<30){year+=2000;}

else if(year>30&&year<100){year+=1900;}

if(this.isValidDate(date,month,year)){if(dateObj!=null){dateObj.date=date;dateObj.month=month;dateObj.year=year;}

else 
{dateObj=new ADate(date,month,year);}

return dateObj;}

else 
{return null;}

}


this.dbFormatToDate=function(str){var dateObj=str.split("-");return new ADate(dateObj[2],dateObj[1],dateObj[0]);}


this.getLabel=function(labelKey,index){var labels=this.getLabels(labelKey);if(null==labels){return null;}

if(labelKey==this.MONTH_ABBR||labelKey==this.MONTH_STR){index--;}

return labels[index];}
;
this.getLabels=function(labelKey){var labels=this.LABEL_KEYS[labelKey];if(null==labels){return null;}

return labels;}


this.getMonthDayCount=function(month,year){var dayCounts=[31,-1,31,30,31,30,31,31,30,31,30,31];var dayCount;if(month==2){dayCount=this.isLeapYear(year)?29:28;}

else 
{dayCount=dayCounts[month-1];}

return dayCount;}


this.getInterval=function(dateObj1,dateObj2){var interval=0;var date1DbFormat=dateObj1.toDbFormat();var date2DbFormat=dateObj2.toDbFormat();var dateA;var dateB;if(date1DbFormat<date2DbFormat){dateA=dateObj1.clone();dateB=dateObj2.clone();}

else if(date1DbFormat>date2DbFormat){dateA=dateObj2.clone();dateB=dateObj1.clone();}

else 
{return 0;}

while(!dateA.equals(dateB))
{interval++;dateA.changeDate(1);}

return interval;}
;
this.TYPE="DATE";
this.EMPTY_DATE="MM/dd/yyyy";
this.SEPARATOR="/";
this.MONTH_POS=1;
this.DATE_POS=2;
this.YEAR_POS=3;
this.NULL_DATE="0000-00-00";
this.LABEL_KEYS=[];{var mAbbr=[];mAbbr.push("Jan");mAbbr.push("Feb");mAbbr.push("Mar");mAbbr.push("Apr");mAbbr.push("May");mAbbr.push("Jun");mAbbr.push("Jul");mAbbr.push("Aug");mAbbr.push("Sep");mAbbr.push("Oct");mAbbr.push("Nov");mAbbr.push("Dec");this.LABEL_KEYS[this.MONTH_ABBR]=mAbbr;}

{var months=[];months.push("January");months.push("February");months.push("March");months.push("April");months.push("May");months.push("June");months.push("July");months.push("August");months.push("September");months.push("October");months.push("November");months.push("December");this.LABEL_KEYS[this.MONTH_STR]=months;}

{var dAbbrv=[];dAbbrv.push("Sun");dAbbrv.push("Mon");dAbbrv.push("Tue");dAbbrv.push("Wed");dAbbrv.push("Thu");dAbbrv.push("Fri");dAbbrv.push("Sat");this.LABEL_KEYS[this.DAY_ABBR]=dAbbrv;}

{var days=[];days.push("Sunday");days.push("Monday");days.push("Tuesday");days.push("Wednesday");days.push("Thursday");days.push("Friday");days.push("Saturday");this.LABEL_KEYS[this.DAY_STR]=days;}

{var days=[];days.push("S");days.push("M");days.push("T");days.push("W");days.push("T");days.push("F");days.push("S");this.LABEL_KEYS[this.DAY_LETTER]=days;}

this.selectDatePart=function(partNumber,date,month,year){if(partNumber==this.DATE_POS){return this.formatDatePart(date);}

else if(partNumber==this.MONTH_POS){return this.formatDatePart(month);}

else if(partNumber==this.YEAR_POS){return year;}

}
;this.formatDatePart=function(number){if(number<10){return "0"+number;}

return parseInt(number,10);}
;this.parseDatePart=function(datePart){var i=0;while(datePart.charAt(i)=='0')
{i++;}

var datePart=datePart.substring(i,datePart.length);return parseInt(datePart,10);}
;
this.isValidDate=function(date,month,year){if(isNaN(date)||isNaN(month)||isNaN(year)){return false;}

if(month<1||month>12){return false;}

var daysInMonth=this.getMonthDayCount(month,year);if(date>daysInMonth){return false;}

if(year<1000){return false;}

return true;}
;
this.isLeapYear=function(year){if(((year%4)==0)&&((year%100)!=0)||((year%400)==0)){return true;}

else 
{return false;}

}
;this.initDateFormat=function(){try
{var dateFormat=g_sessionInformation.settings.date_format;this.EMPTY_DATE=dateFormat.empty_date;this.SEPARATOR=dateFormat.separator;this.DATE_POS=dateFormat.date_pos;this.MONTH_POS=dateFormat.month_pos;this.YEAR_POS=dateFormat.year_pos;}

catch(e)
{}

}
;this.initDateFormat();}
;
;;function ADate(date,month,year){try
{this.date=parseInt(date,10);this.month=parseInt(month,10);this.year=parseInt(year,10);}

catch(e)
{this.date=date;this.month=month;this.year=year;}

}
;ADate.prototype=new ADateBase();function ADateBase(){
this.getDayIndex=function(){var aDate=new Date(this.year,this.month-1,this.date);return aDate.getDay();}
;
this.toDbFormat=function(){if(!ADateUtil.isValidDate(this.date,this.month,this.year)){return ADateUtil.NULL_DATE;}

return this.year+"-"+ADateUtil.formatDatePart(this.month)+"-"+ADateUtil.formatDatePart(this.date);}
;
this.update=function(dateStr){return ADateUtil.stringToDate(dateStr,this);}
;
this.getString=function(params){if(null==params||params.length<1){return this.toDefaultString();}

var monthStr="";var monthPos=-1;var dateStr="";var datePos=-1;var fullStr="";for(var i=0;i<params.length;i++)
{switch(params[i]){
case'm_abbr':
monthStr=ADateUtil.getLabel('m_abbr',this.month);fullStr+="!monthStr!";monthPos=i;break;case'm_full':
monthStr=ADateUtil.getLabel('m_full',this.month);fullStr+="!monthStr!";monthPos=i;break;case'd_abbr':
fullStr+=ADateUtil.getLabel('d_abbr',this.getDayIndex());break;case'd_full':
fullStr+=ADateUtil.getLabel('d_full',this.getDayIndex());break;case'dt_abbr':

alert("do we need to abbreviate dates???");break;case'date':
fullStr+="!dateStr!";dateStr=this.date;datePos=i;break;case'month':
fullStr+="!monthStr!";monthStr=this.month;monthPos=i;break;case'year':
fullStr+=this.year;break;default:
fullStr+=params[i];}

}

var usDateFormat="!monthStr!/!dateStr!/"+this.year;if(fullStr.indexOf(usDateFormat)>-1){fullStr=fullStr.replace(usDateFormat,this.toDefaultString());}

else 
{var isDefaultMonthFirst=(ADateUtil.MONTH_POS<ADateUtil.DATE_POS);var isMonthFirst=(monthPos<datePos);if(isDefaultMonthFirst!=isMonthFirst){if(fullStr.indexOf("!dateStr")>0&&fullStr.indexOf("!monthStr")>0){fullStr=fullStr.replaceAll("!dateStr!",monthStr);fullStr=fullStr.replaceAll("!monthStr!",dateStr);}

else 
{fullStr=fullStr.replaceAll("!monthStr!",monthStr);fullStr=fullStr.replaceAll("!dateStr!",dateStr);}

}

else 
{fullStr=fullStr.replaceAll("!dateStr!",dateStr);fullStr=fullStr.replaceAll("!monthStr!",monthStr);}

}

return fullStr;}
;
this.changeDate=function(numberOfDays){numberOfDays=parseInt(numberOfDays,10);if(0==numberOfDays){return this;}
;var dayOfYear=numberOfDays;var isLeapYear=ADateUtil.isLeapYear(this.year);var daysInYear=(isLeapYear)?366:365;var daysInFebruary=(isLeapYear)?29:28;var dayCounts=[0,31,daysInFebruary,31,30,31,30,31,31,30,31,30,31];for(var i=1;i<this.month+1;i++)
{if(i==this.month){dayOfYear+=this.date;break;}

dayOfYear+=dayCounts[i];}

while(dayOfYear>daysInYear)
{dayOfYear=dayOfYear-daysInYear;this.year=this.year+1;isLeapYear=ADateUtil.isLeapYear(this.year);daysInYear=(isLeapYear)?366:365;}

while(dayOfYear<=0)
{isLeapYear=ADateUtil.isLeapYear(this.year-1);daysInYear=(isLeapYear)?366:365;dayOfYear=daysInYear+dayOfYear;this.year=this.year-1;}

daysInFebruary=(isLeapYear)?29:28;dayCounts=[0,31,daysInFebruary,31,30,31,30,31,31,30,31,30,31];for(var i=1;i<dayCounts.length;i++)
{var dayCount=dayCounts[i];if(dayCount>=dayOfYear){this.month=i;this.date=dayOfYear;break;}

dayOfYear-=dayCount;}

return this;}
;
this.clone=function(){return new ADate(this.date,this.month,this.year);}
;
this.getNextDate=function(){var nextDate=this.clone();nextDate.changeDate(1);return nextDate;}
;
this.getPreviousDate=function(){var nextDate=this.clone();nextDate.changeDate(-1);return nextDate;}
;
this.equals=function(otherDate){return ((this.year==otherDate.year)&&(this.month==otherDate.month)&&(this.date==otherDate.date));}
;
this.isLessThan=function(otherDate){return ((this.year<otherDate.year)||
((this.year==otherDate.year)&&(this.month<otherDate.month))||
((this.year==otherDate.year)&&(this.month==otherDate.month)&&(this.date<otherDate.date)));}
;
this.isLessThanEqual=function(otherDate){var isLessThan=((this.year<otherDate.year)||((this.year==otherDate.year)&&(this.month<otherDate.month))||
((this.year==otherDate.year)&&(this.month==otherDate.month)&&(this.date<otherDate.date)));var isEqual=this.equals(otherDate)
return (isLessThan||isEqual);}
;
this.isBeforeOtherDate=function(otherDate){return this.isLessThan(otherDate);
}
;
this.toDefaultString=function(){if(!ADateUtil.isValidDate(this.date,this.month,this.year)){return ADateUtil.EMPTY_DATE;}

var dateString="";dateString+=ADateUtil.selectDatePart(1,this.date,this.month,this.year)+ADateUtil.SEPARATOR;dateString+=ADateUtil.selectDatePart(2,this.date,this.month,this.year)+ADateUtil.SEPARATOR;dateString+=ADateUtil.selectDatePart(3,this.date,this.month,this.year);return dateString;}
;
this.getDateString=function(){return this.toDefaultString();}
;}



var ATimeUtil=new ATimeUtilBase();function ATimeUtilBase(){this.TYPE="TIME";this.TIME_FORMAT=12;
this.getCurrentTime=function(){return new ATime(g_sessionInformation.current_datetime.minute_offset);}
;
this.timeToString=function(minuteOffset){if(this.TIME_FORMAT==24){timeStr=this.offsetTo24Hr(minuteOffset);}

else 
{timeStr=this.offsetTo12Hr(minuteOffset);}

return timeStr;}
;
this.stringToTime=function(timeStr,timeObj){var offset=this.stringToOffset(timeStr);if(offset<0){return null;}

if(null!=timeObj){timeObj.minuteOffset=offset;}

else 
{timeObj=new ATime(offset)
}

return timeObj;}
;
this.stringToOffset=function(timeString){var re=new RegExp("(\\d\\d*)(:?)(\\d*)\\s*([ap]?)","g");var result=re.exec(timeString.toLowerCase());if(null==result){return -1;}

var hour;var minute;var isPM;if(""==result[2]){if(result[1].length==3){hour=parseInt(result[1].charAt(0),10);minute=parseInt(result[1].charAt(1)+result[1].charAt(2),10);}

else if(result[1].length==4){hour=parseInt(result[1].charAt(0)+result[1].charAt(1),10);minute=parseInt(result[1].charAt(2)+result[1].charAt(3),10);}

else 
{return -1;}

}

else 
{hour=parseInt(result[1],10);var mStr=result[3];if("0"==mStr.charAt(0)){mStr=mStr.charAt(1)
}

minute=parseInt(mStr,10);}

if(minute<0||minute>59||isNaN(minute)||isNaN(hour)){return -1;}

var timeOffset;if(this.TIME_FORMAT==24){if(hour<0||hour>23){return -1;}

timeOffset=this.to24HrToOffset(hour,minute);}

else 
{if(hour<1||hour>12){return -1;}

isPM=("p"==result[4])?true:false;timeOffset=this.to12HrToOffset(hour,minute,isPM);}

return timeOffset;}
;
this.offsetTo12Hr=function(offset){if(offset>=0&&offset<60){return "12:"+this.ensureTwoDigits(offset)+"AM";}

else if(offset>=60&&offset<720){var hour=Math.floor(offset/60);var minute=offset%60;return hour+":"+this.ensureTwoDigits(minute)+"AM";}

else if(offset>=720&&offset<780){var minute=offset%60;return "12:"+this.ensureTwoDigits(minute)+"PM";}

else if(offset>=780&&offset<1440){offset-=12*60;var hour=Math.floor(offset/60);var minute=offset%60;return hour+":"+this.ensureTwoDigits(minute)+"PM";}

}


this.offsetTo24Hr=function(offset){var hour=Math.floor(offset/60);var minute=offset%60;return this.ensureTwoDigits(hour)+":"+this.ensureTwoDigits(minute);}


this.ensureTwoDigits=function(number){var numberStr=number.toString()
var dot=numberStr.indexOf(".");if(dot!=-1){number=parseInt(numberStr.substring(0,dot),10);}

if(number<10){return "0"+number;}

return number;}
;this.to12HrToOffset=function(hour,minute,isPM){var minuteOffset=hour*60+minute;if(isPM){minuteOffset+=60*12;}

if(hour==12){minuteOffset-=60*12;}

return minuteOffset;}
;this.to24HrToOffset=function(hour,minute){return hour*60+minute;}
;this.initTimeFormat=function(){try
{this.TIME_FORMAT=g_sessionInformation.settings.time_format;}

catch(e)
{}

}
;this.isValidValue=function(value){return (this.validValues[value.toLowerCase()])
}
;this.initTimeFormat();this.validValues={closed:true}
;}

;function ATime(minuteOffset){this.minuteOffset=minuteOffset;}

ATime.prototype=new ATimeBase();function ATimeBase(){
this.getString=function(){var timeStr=ATimeUtil.timeToString(this.minuteOffset);return timeStr;}
;
this.toDbString=function(){return ATimeUtil.ensureTwoDigits(this.getHour())+":"+ATimeUtil.ensureTwoDigits(this.getMinute())+":00";}
;
this.clone=function(){return new ATime(this.minuteOffset);}
;
this.getHour=function(){return Math.floor(this.minuteOffset/60);}
;
this.getMinute=function(){return this.minuteOffset%60;}
;
this.changeTime=function(noOfMinutes){this.minuteOffset+=noOfMinutes;if(this.minuteOffset>=1440){this.minuteOffset=1439;}

else if(this.minuteOffset<0){this.minuteOffset=0;}

return this;}
;
this.equals=function(time){return this.minuteOffset==time.minuteOffset;}
;
this.isLessThan=function(time){return this.minuteOffset<time.minuteOffset;}
;
this.isLessThanEqual=function(time){return this.minuteOffset<=time.minuteOffset;}
;
this.isGreaterThan=function(time){return this.minuteOffset>time.minuteOffset;}
;
this.isGreaterThanEqual=function(time){return this.minuteOffset>=time.minuteOffset;}
;
this.update=function(timeStr){return ATimeUtil.stringToTime(timeStr,this);}
;
this.timeToString=function(){var timeStr=ATimeUtil.timeToString(this.minuteOffset);return timeStr;}
;}
;

;;mc_fieldTypeExtenders["TIMESTAMP"]=function(dynField){var timeObj=dynField.getValue().date_time.time;if(null!=timeObj){for(var i in ATime.prototype)
{timeObj[i]=ATime.prototype[i];}
;}
;var dateObj=dynField.getValue().date_time.date;if(null!=dateObj){for(var i in ADate.prototype)
{dateObj[i]=ADate.prototype[i];}

}
;dynField.forceSave=true;dynField.getDate=function(){return this.getValue().date_time.date;}
;dynField.getTime=function(){return this.getValue().date_time.time;}
;}
;

mc_fieldTypeExtenders["FILE2"]=function(dynField){extendField(dynField,f2_file2Base);}

var f2_file2Base=new File2Base();function File2Base(){this.getImagePath=function(width,height,allowSizingUp,fitType){var path=this.data.full_path
var params=ImageUtil.parseQueryString(path);if(width){params["w"]=width;}

if(height){params["h"]=height;}

if(allowSizingUp){params["u"]=allowSizingUp;}

if(fitType){params["f"]=fitType;}

var cleanSrc=ImageUtil.getUrlWithNoParams(path);var newPath=cleanSrc+"?"+ImageUtil.createQueryString(params);return newPath;}


this.setImageRotation=function(rotateCount){var path=this.getOriginalPath()+"?r="+rotateCount;this.getChildField("full_path").setValue(path);}
;
this.incrementRotation=function(rotateCount){var path=this.getChildField("full_path").getValue();var index=path.indexOf("?r=");var newRotation;if(-1==index){newRotation=rotateCount;}

else 
{var current=parseInt(path.charAt(index+3));newRotation=(current+rotateCount)%4;}

this.setImageRotation(newRotation);return newRotation;}


this.getOriginalPath=function(){var fullPath=this.getChildField("full_path").getValue();var end=fullPath.indexOf("?");if(-1==end){return fullPath;}

else 
{return fullPath.substring(0,end);}

}
;}

mc_fieldTypeExtenders["DATETIME"]=function(dynField){extendField(dynField,mc_dateTimeBase);var timeObj=dynField.getValue().time;if(null!=timeObj){for(var i in ATime.prototype)
{timeObj[i]=ATime.prototype[i];}
;}

var dateObj=dynField.getValue().date;if(null!=dateObj){for(var i in ADate.prototype)
{dateObj[i]=ADate.prototype[i];}

}

}

var mc_dateTimeBase=new DateTimeBase();function DateTimeBase(){this.setDate=function(date){this.data.date=date;this.setDoSave();}
;this.setTime=function(time){this.data.time=time;this.setDoSave();}
;this.getString=function(){var dateTime=this.getValue();return dateTime.date.getString()+" "+dateTime.time.getString();}
;}


mc_fieldTypeExtenders["NAME"]=function(dynField){extendField(dynField,name_nameBase);}

var name_nameBase=new NameBase();function NameBase(){this.getFirstMiddleLast=function(){return this.data.first_name+" "+this.data.middle_name+" "+this.data.last_name;}
;this.toString=function(lastNameFirst){var nameObj=this.getValue();if(lastNameFirst){return nameObj.last_name+", "+nameObj.first_name
}

else 
{return nameObj.first_name+" "+nameObj.last_name
}

}
;}


mc_fieldTypeExtenders["MODULE"]=function(dynField){extendField(dynField,mc_moduleBase);}

var mc_moduleBase=new ModuleBase();function ModuleBase(){this.setValueFromEl=function(element,lpSaver){var ahtml=lpSaver.getAhtml(element);this.getChildField("ahtml").setValue(ahtml);}
;this.getBgImageInfo=function(){var bgImageInfo={bgType:null,path:null}
;var record=this.getOwnerRecord();var fullScreenBgImage=record.getField("properties.body_attrs.full_screen_bg_image");var cssValue=record.getField("style_sheet.style_sheet").getAttrValue("body","background-image");if(fullScreenBgImage){bgImageInfo.bgType="full";bgImageInfo.path=fullScreenBgImage.getValue();}

else if(cssValue){bgImageInfo.bgType="tile";var start=cssValue.indexOf("(")+1;var end=cssValue.indexOf(")");bgImageInfo.path=cssValue.substring(start,end);}

return bgImageInfo;}
;this.setBgImageInfo=function(bgType,path,rte){path=path.replaceAll(" ","%20");var record=this.getOwnerRecord();this.clearBgImage(rte);if("full"==bgType){var bodyAttrs=record.getField("properties.body_attrs");bodyAttrs.addChildField("full_screen_bg_image","TEXT",path);BgImageUtil.setRteFullScreenBgImage(path,rte,true);}

else 
{var value="url("+path+")";record.getField("style_sheet.style_sheet").setAttribute("body","background-image",value,rte.doc);}

}
;this.clearBgImage=function(rte){var record=this.getOwnerRecord();record.getField("style_sheet.style_sheet").removeAttribute("body","background-image",rte.doc);record.getField("properties.body_attrs").removeChildField("full_screen_bg_image");BgImageUtil.removeFullScreenBgImage(rte.doc);}
;}


mc_fieldTypeExtenders["TEXT"]=function(dynField){extendField(dynField,mc_shortTextBase);}
;mc_fieldTypeExtenders["LONG_TEXT"]=function(dynField){extendField(dynField,mc_shortTextBase);}
;var mc_shortTextBase=new ShortTextBase();function ShortTextBase(){this.setValueFromEl=function(element,lpSaver){this.setValue(element.innerText);}
;}
;

;;;;;;;mc_fieldTypeExtenders["USERSTAMP"]=function(dynField){dynField.forceSave=true;}

mc_fieldTypeExtenders["C3"]=function(dynField){dynField.setDisplayValue=function(displayValue){var optionValue=null;var options=this.getChildField("category_definition.category_definition.options").data;for(var i in options)
{if(displayValue==options[i]){optionValue=i;break;}

}

if(optionValue){this.getChildField("value").setValue(optionValue);}

}

}

mc_fieldTypeExtenders["RECORD_TYPE"]=function(dynField){dynField.getRecord=function(){var mc=this.ownerRecord.ownerCache;return mc.getRecord(this.getChildField("type").getValue(),this.getChildField("id").getValue());}

dynField.createNewRecord=function(){var mc=this.ownerRecord.ownerCache;var record=mc.createRecord(this.getChildField("type").getValue());this.getChildField("id").setValue(record.id);return record;}
;}

mc_fieldTypeExtenders["RECORD_NAME"]=function(dynField){dynField.setValue=function(value){this.getChildField("recordName").setValue(value);}
;dynField.getValue=function(){return this.getChildField("recordName").getValue();}
;}

mc_fieldTypeExtenders["ARRAY"]=function(dynField){dynField.clear=function(){var length=this.getChildFieldNames().length;for(var i=length-1;i>=0;i--)
{this.removeChildField(i);}

}

}

mc_fieldTypeExtenders["DATE"]=function(dynField){var dateObj=dynField.getValue();if(null==dateObj){return ;}

if(window["ADate"]==undefined){return 
}

for(var i in ADate.prototype)
{dateObj[i]=ADate.prototype[i];}

}
;mc_fieldTypeExtenders["TIME_TYPE_NAME"]=function(dynField){var timeObj=dynField.getValue();if(null==timeObj){return ;}

if(window["ATime"]==undefined){return 
}

for(var i in ATime.prototype)
{timeObj[i]=ATime.prototype[i];}

}
;
;;function DynField(name,data,metaData,parentField,ownerRecord){this.name=name
this.data=data;this.metaData=metaData;this.parentField=parentField;this.ownerRecord=ownerRecord;addExentsions(this);}
;DynField.prototype=new DynFieldBase();function DynFieldBase(){
this.buildField=function(parentEl,converterName,properties){var uiType=this.getUiType()||this.getFieldType();var conversionFx=mc_objectToHtmlFxByType[converterName][uiType];if(!conversionFx){var doc=(properties&&properties.doc)?properties.doc:document;var div=cE("div",parentEl,doc);div.innerHTML="no for drawing type: "+uiType+" with converter '"+converterName+"'";return ;}

return conversionFx(parentEl,this,properties);}
;this.getChildField=function(fieldName){fieldName+="";var ownerRecord=this.ownerRecord;var dotIndex=fieldName.indexOf(".");if(this.data[fieldName]||-1==dotIndex){if("RECORD_TYPE"==this.getFieldType()&&fieldName!="id"&&fieldName!="type"&&fieldName!="createRecord"&&fieldName!="deleteRecord"){if(ownerRecord.isTemplate){var template=ownerRecord.ownerCache.getTemplate(this.data.type);if(null==template){alert("The template for "+this.data.type+" is not loaded. Please add it to load");return null;}

return ownerRecord.ownerCache.getTemplate(this.data.type).getField(fieldName);}

else 
{var record=ownerRecord.ownerCache.getRecord(this.data.type,this.data.id);if(null==record){return null;}

return record.getField(fieldName);}

}

else 
{if(!this.metaData[fieldName+"_ft"]){return null;}

return new DynField(fieldName,this.data[fieldName],this.metaData[fieldName],this,ownerRecord);}

}

else 
{var field=this.getChildField(fieldName.substring(0,dotIndex));if(null==field){return null;}

return field.getChildField(fieldName.substring(dotIndex+1,fieldName.length));}

}
;
this.getChildFields=function(){var childFields=[];var fieldNames=this.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var childField=this.getChildField(fieldNames[i]);if(null!=childField){childFields.push(childField);}

}

return childFields;}
;this.addChildField=function(fieldName,fieldType,value,displayName,displayOrder){var newField=this.addChildFieldData(fieldName,fieldType,value,displayName,displayOrder);var liveField=this.getLiveField();if(liveField){newField=liveField.addChildFieldData(fieldName,fieldType,value,displayName,displayOrder);}

return newField;}
;this.addChildFieldData=function(fieldName,fieldType,value,displayName,displayOrder){var metaValue;if(!value){var defaultData=mc_typeToDefaultValue[fieldType]();value=defaultData.data;metaValue=defaultData.metaData;}

else 
{metaValue=value;}

if("ARRAY"==this.getFieldType()){fieldName=this.data.length;this.data.push(clone(value));var metaData=this.metaData;metaData[fieldName]=clone(metaValue);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName;metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;}

else 
{this.data[fieldName]=clone(value);var metaData=this.metaData;metaData[fieldName]=clone(metaValue);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;}

var childField=this.getChildField(fieldName);childField.setDoSave();return childField;}
;this.getFullFieldName=function(){var fieldName=this.name;var aField=this.parentField;while(aField)
{fieldName=aField.name+"."+fieldName;aField=aField.parentField;}

return fieldName;}

this.insertChildField=function(fieldName,fieldType,field,displayName,displayOrder){field.parentField=this;field.ownerRecord=this.ownerRecord;if("ARRAY"==this.getFieldType()){fieldName=this.data.length;this.data.push(field.data);var metaData=this.metaData;metaData[fieldName]=field.metaData;metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName;metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;metaData[fieldName+"_uit"]=""
}

else 
{field.name=fieldName;this.data[fieldName]=field.data;var metaData=this.metaData;metaData[fieldName]=field.metaData;metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;metaData[fieldName+"_uit"]=""
}

var childField=this.getChildField(fieldName);childField.setDoSave();return childField;}
;this.renameChild=function(newName,previousName){var oldField=this.getChildField(previousName);var fieldType=oldField.getFieldType();var displayName=oldField.getDisplayName();var displayOrder=oldField.getDisplayOrder();var newChild=oldField.cloneField();this.removeChildField(previousName);return this.insertChildField(newName,fieldType,newChild,displayName,displayOrder);}
;this.cloneField=function(){var data=clone(this.data);var metaData=clone(this.metaData);return new DynField(this.name,data,metaData,null,null);}

this.removeChildField=function(fieldName){this.removeChildFieldData(fieldName);var liveField=this.getLiveField();if(liveField){liveField.removeChildFieldData(fieldName);}

}
;this.removeChildFieldData=function(fieldName){if("ARRAY"==this.getFieldType()){var index=parseInt(fieldName);var originalLength=this.data.length;this.data.splice(index,1);var metaData=this.metaData;delete(metaData[index]);delete(metaData[index+"_ft"]);delete(metaData[index+"_dn"]);delete(metaData[index+"_do"]);delete(metaData[index+"_ds"]);delete(metaData[index+"_uit"]);for(var i=index;i<originalLength-1;i++)
{var oldIndex=i+1;metaData[i]=metaData[oldIndex];metaData[i+"_ft"]=metaData[oldIndex+"_ft"];metaData[i+"_dn"]=metaData[oldIndex+"_dn"];metaData[i+"_do"]=metaData[oldIndex+"_do"];metaData[i+"_ds"]=metaData[oldIndex+"_ds"];metaData[i+"_uit"]=metaData[oldIndex+"_uit"];}

delete(metaData[i]);delete(metaData[i+"_ft"]);delete(metaData[i+"_dn"]);delete(metaData[i+"_do"]);delete(metaData[i+"_ds"]);delete(metaData[i+"_uit"]);}

else 
{delete(this.data[fieldName]);var metaData=this.metaData;delete(metaData[fieldName]);delete(metaData[fieldName+"_ft"]);delete(metaData[fieldName+"_dn"]);delete(metaData[fieldName+"_do"]);delete(metaData[fieldName+"_ds"]);delete(metaData[fieldName+"_uit"]);}

this.setDoSave();}
;this.getChildFieldNames=function(){if("ARRAY"==this.getFieldType()){var indexNames=[];for(var i=0;i<this.data.length;i++)
{indexNames[i]=i;}

return indexNames;}

return mc_getFieldNames(this.metaData);}
;this.getChildFieldCount=function(){return this.getChildFieldNames().length;}
;this.getFieldType=function(){var thisMetaData=this.getThisMetaData();return thisMetaData?thisMetaData[this.name+"_ft"]:null;}
;this.getOwnerRecord=function(){var testField=this;while(!testField.ownerRecord&&testField.parentField)
{testField=testField.parentField;}

return testField.ownerRecord;}
;this.getOwnerCache=function(){return this.getOwnerRecord().ownerCache;}
;this.isSetDoSave=function(){return this.getMetaInfo("ds");}
;this.setDoSave=function(){var record=this.getOwnerRecord();if(null==record){return ;}

var metaData=this.getThisMetaData();if(metaData[this.name+"_ds"]){return ;}

metaData[this.name+"_ds"]=true;var parentField=this.parentField;if(!parentField){record.setDoSave();}

else 
{parentField.setDoSave();}

}
;this.setDontSave=function(){this.setMetaInfo(false,"ds");}
;this.resetMetaInfo=function(value,suffix){
var metaData=this.getThisMetaData();metaData[this.name+"_"+suffix]=value;var fieldNames=this.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var childField=this.getChildField(fieldNames[i]);childField.resetMetaInfo(value,suffix);}

}
;this.getThisMetaData=function(){if(this.parentField){return this.parentField.metaData;}

else if(this.ownerRecord){return this.ownerRecord.metaData;}

else 
{return null;}

}
;this.getMetaInfo=function(suffix){return this.getThisMetaData()[this.name+"_"+suffix];}
;this.setMetaInfo=function(value,suffix){var metaData=this.getThisMetaData();metaData[this.name+"_"+suffix]=value;if(!value&&suffix=="ds"){return ;}

this.setDoSave();}
;this.getDisplayOrder=function(){return this.getMetaInfo("do");}
;this.setDisplayOrder=function(displayOrder){this.setMetaInfo(displayOrder,"do");}
;this.getUiType=function(){if(null==this.getMetaInfo("uit")){return "";}

return this.getMetaInfo("uit");}
;this.setUiType=function(uiType){this.setMetaInfo(uiType,"uit");}
;this.getDisplayName=function(){return this.getMetaInfo("dn");}
;this.setDisplayName=function(displayName){this.setMetaInfo(displayName,"dn");}
;
this.getValue=function(){return this.data;}
;
this.getLiveField=function(){var fullFieldName=this.getFullFieldName();var ownerRecord=this.getOwnerRecord();if(null==ownerRecord){return null;}

var liveField=null;try
{liveField=ownerRecord.getRefreshed().getField(fullFieldName);}

catch(e)
{}

return (liveField&&liveField.data!=this.data)?liveField:null;}
;this.setValue=function(value,isDontSetSave){this.setFieldValue(this,value,isDontSetSave);var liveField=this.getLiveField();if(liveField){this.setFieldValue(liveField,value,isDontSetSave);}

return this;}
;this.setValueFromEl=function(element,lpSaver){}
;this.setFieldValue=function(dynField,value,isDontSetSave){if(null==dynField){return ;}

dynField.data=value;if(dynField.parentField){dynField.parentField.data[dynField.name]=value;}

else 
{dynField.ownerRecord.data[dynField.name]=value;}

if(!isDontSetSave){dynField.setDoSave();}

}

}

function addExentsions(dynField){var fieldType=dynField.getFieldType();var extender=mc_fieldTypeExtenders[fieldType];if(extender){extender(dynField);}

}

function extendField(dynField,objectDef){for(var i in objectDef)
{dynField[i]=objectDef[i];}

}
;

;function Record(type,id,data,metaData,ownerCache){this.type=type;this.id=id;this.ownerCache=ownerCache;delete(data.type);delete(data.id);this.data=data;this.metaData=metaData;this.recordCount=++mc_recordCounter;}

Record.prototype=new RecordBase();function RecordBase(type,id,data,metaData,ownerCache){this.getId=function(){if(0>=this.id){var ids=mc_tempToRealId[this.type];if(ids){return ids[this.id]||this.id;}

else 
{return this.id;}

}

return this.id;}

this.getField=function(fieldName){var dotIndex=fieldName.indexOf(".");if(-1==dotIndex){if( typeof (this.metaData[fieldName])!="undefined"){return new DynField(fieldName,this.data[fieldName],this.metaData[fieldName],null,this);}

else 
{return null;}

}

else 
{var field=this.getField(fieldName.substring(0,dotIndex));if(!field){return null;}

return field.getChildField(fieldName.substring(dotIndex+1,fieldName.length));}

}
;this.addField=function(fieldName,fieldType,displayName,displayOrder){var defaultData=mc_typeToDefaultValue[fieldType]();this.data[fieldName]=clone(defaultData.data);var metaData=this.metaData;metaData[fieldName]=clone(defaultData.metaData);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;return this.getField(fieldName);}
;this.cloneRecord=function(mc){var newRecord=mc.createRecord(this.type,this.getId());
var fieldNames=this.getFieldNames();for(var i=0;i<fieldNames.length;i++)
{var field=this.getField(fieldNames[i]);var newField=field.cloneField();newField=newRecord.insertField(field.name,field.getFieldType(),newField,field.getDisplayName(),field.getDisplayOrder());if(field.isSetDoSave()){newField.setDoSave();}

}

return newRecord;}
;this.addName=function(name){this.ownerCache.addRecordName(this,name);}
;this.insertField=function(fieldName,fieldType,field,displayName,displayOrder){field.ownerRecord=this;this.data[fieldName]=field.data;var metaData=this.metaData;metaData[fieldName]=field.metaData;metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;return this.getField(fieldName);}
;this.replaceField=function(fieldName,dynField){var replacedField=this.insertField(fieldName,dynField.getFieldType(),dynField,dynField.getDisplayName(),dynField.getDisplayOrder());replacedField.setDoSave();return replacedField;}

this.setDoSave=function(){if(this.metaData.doProcess){return ;}

this.metaData.doSave=true;this.setDoLoad();}
;this.isSetDoSave=function(){return this.metaData.doSave;}
;this.cancelSave=function(){this.ownerCache.cancelRecordToLoad(this.type,this.id);this.metaData.doSave=false;}
;this.setDoLoad=function(){this.ownerCache.addRecordToLoad(this.type,this.id);}
;this.getFieldNames=function(){return mc_getFieldNames(this.metaData);}
;this.getRefreshed=function(){return this.ownerCache.getRecord(this.type,this.id);}
;this.resetMetaInfo=function(value,suffix){var fieldNames=this.getFieldNames();for(var i=0;i<fieldNames.length;i++)
{var childField=this.getField(fieldNames[i]);childField.resetMetaInfo(value,suffix);}

}
;this.removeUnchangedFields=function(){var names=this.getFieldNames();for(var i=0;i<names.length;i++)
{var field=this.getField(names[i]);if(!field.isSetDoSave()){this.removeField(names[i]);}

}

}
;
this.removeField=function(fieldName){delete(this.data[fieldName]);var metaData=this.metaData;delete(metaData[fieldName]);delete(metaData[fieldName+"_ft"]);delete(metaData[fieldName+"_dn"]);delete(metaData[fieldName+"_do"]);delete(metaData[fieldName+"_ds"]);delete(metaData[fieldName+"_uit"]);}
;
}

var mc_recordCounter=0;

function DynTable(type,data,metaData,settings,ownerCache){this.type=type;this.ownerCache=ownerCache;this.data=data;this.metaData=metaData;this.settings=settings;this.getField=function(fieldName){return new DynField(fieldName,this.data[fieldName],this.metaData[fieldName],null,this);}
;this.setDoSave=function(){this.settings.doSave=true;}
;this.addField=function(fieldName,fieldType,displayName,displayOrder){this.setDoSave();var defaultData=mc_typeToDefaultValue[fieldType]();this.data[fieldName]=clone(defaultData.data);var metaData=this.metaData;metaData[fieldName]=clone(defaultData.metaData);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName;metaData[fieldName+"_do"]=displayOrder;metaData[fieldName+"_ds"]=true;metaData[fieldName+"_uit"]="";return this.getField(fieldName);}
;this.getFieldNames=function(){return mc_getFieldNames(this.metaData);}
;}

if(!mc_typeToDefaultValue){var mc_typeToDefaultValue={}
;}

function mc_insertMetaData(object,fieldName,fieldType,displayName,displayOrder,value){object[fieldName]=value;object[fieldName+"_ft"]=fieldType;object[fieldName+"_dn"]=displayName;object[fieldName+"_do"]=displayOrder;}

mc_typeToDefaultValue["COLLECTION"]=function(){return {data:{}
,metaData:{}
}
;}
;mc_typeToDefaultValue["ARRAY"]=function(){return {data:[],metaData:[]}
;}
;mc_typeToDefaultValue["INTEGER"]=function(){return {data:0,metaData:0}
;}
;mc_typeToDefaultValue["DOUBLE"]=function(){return {data:0.0,metaData:0.0}
;}
;mc_typeToDefaultValue["TIME_TYPE_NAME"]=function(){return {data:null,metaData:null}
;}
;mc_typeToDefaultValue["BOOLEAN"]=function(){return {data:false,metaData:false}
;}
;mc_typeToDefaultValue["RECORD_TYPE"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("type","TEXT");field.addChildField("id","INTEGER");field.addChildField("createRecord","BOOLEAN");field.addChildField("deleteRecord","BOOLEAN");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["RIL2"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("type","TEXT");field.addChildField("ids","LONG_TEXT");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["MODULE"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("ahtml","LONG_TEXT");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["TEXT"]=function(){return {data:"",metaData:""}
;}
;mc_typeToDefaultValue["TREE"]=function(){return {data:"",metaData:""}
;}
;mc_typeToDefaultValue["PASSWORD"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("value","TEXT");field.addChildField("doSave","BOOLEAN",true);return {data:field.data,metaData:field.metaData}
;}
;mc_typeToDefaultValue["DATE"]=function(){return {data:null,metaData:null}
;}
;mc_typeToDefaultValue["DATETIME"]=function(){var field=new DynField(null,{date:null,time:null}
,{}
,null,null);field.addChildField("isGMT","BOOLEAN");return {data:field.data,metaData:field.metaData}
;}
;mc_typeToDefaultValue["LONG_TEXT"]=function(){return {data:"",metaData:""}
;}
;mc_typeToDefaultValue["MS3"]=function(){var data={selected_options:"",category_definition:{type:"cat_def3",id:0,deleteRecord:false,createRecord:false}
}
;var metaData={}
;mc_insertMetaData(metaData,"selected_options","LONG_TEXT","",0,"");mc_insertMetaData(metaData,"category_definition","RECORD_TYPE","",0,{}
);var definitionMeta=metaData.category_definition;mc_insertMetaData(definitionMeta,"type","TEXT","",0,"cat_def3");mc_insertMetaData(definitionMeta,"id","INTEGER","",0,0);mc_insertMetaData(definitionMeta,"createRecord","BOOLEAN","",0,false);mc_insertMetaData(definitionMeta,"deleteRecord","BOOLEAN","",0,false);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["C3"]=function(){var data={default_value:"",value:"",category_definition:{type:"cat_def3",id:0,deleteRecord:false,createRecord:false}
}
;var metaData={}
;mc_insertMetaData(metaData,"default_value","TEXT","",0,"");mc_insertMetaData(metaData,"value","TEXT","",0,"");mc_insertMetaData(metaData,"category_definition","RECORD_TYPE","",0,{}
);var definitionMeta=metaData.category_definition;mc_insertMetaData(definitionMeta,"type","TEXT","",0,"cat_def3");mc_insertMetaData(definitionMeta,"id","INTEGER","",0,0);mc_insertMetaData(definitionMeta,"createRecord","BOOLEAN","",0,false);mc_insertMetaData(definitionMeta,"deleteRecord","BOOLEAN","",0,false);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["TIMESTAMP"]=function(){var data={str_format:"simple",do_update:false,date_time:{date:{date:1,month:1,year:1}
,time:{minuteOffset:0}
}
}
;var metaData={}
;mc_insertMetaData(metaData,"str_format","TEXT","",0,"simple");mc_insertMetaData(metaData,"do_update","BOOLEAN","",0,false);mc_insertMetaData(metaData,"date_time","DATETIME","",0,{}
);var dateTimeMeta=metaData.date_time;mc_insertMetaData(dateTimeMeta,"isGMT","BOOLEAN","",0,true);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["USERSTAMP"]=function(){var data={do_update:false,user_name:'',user_id:0}
;var metaData={}
;mc_insertMetaData(metaData,"user_name","TEXT","",0,"");mc_insertMetaData(metaData,"do_update","BOOLEAN","",0,false);mc_insertMetaData(metaData,"user_id","INTEGER","",0,0);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["RECORD_NAME"]=function(){var data={recordName:'',updateOnImport:true}
;var metaData={}
;mc_insertMetaData(metaData,"recordName","TEXT","",0,"");mc_insertMetaData(metaData,"updateOnImport","BOOLEAN","",0,true);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["TIME_ALLOCATION_TYPE"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("time_allocation_record","RECORD_TYPE");field.addChildField("finder","RECORD_TYPE");field.addChildField("physical_resource","RECORD_TYPE");field.addChildField("event_title","TEXT");field.addChildField("event_status","COLLECTION");field.addChildField("is_double_allowed","BOOLEAN",false);field.addChildField("start_date","DATE");field.addChildField("start_time","TIME_TYPE_NAME");field.addChildField("end_date","DATE");field.addChildField("end_time","TIME_TYPE_NAME");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["RTA2"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("time_allocation_record","RECORD_TYPE");field.addChildField("physical_resource","RECORD_TYPE");field.addChildField("event_title","TEXT");field.addChildField("is_double_allowed","BOOLEAN",false);field.addChildField("start_date","DATE");field.addChildField("start_time","TIME_TYPE_NAME");field.addChildField("end_date","DATE");field.addChildField("end_time","TIME_TYPE_NAME");var recurInfo=field.addChildField("recur_info","COLLECTION");recurInfo.addChildField("recur_type","TEXT","weekly","",1);recurInfo.addChildField("every_nth_week","INTEGER",1,"",2);recurInfo.addChildField("is_monday","BOOLEAN",true,"",3);recurInfo.addChildField("is_tuesday","BOOLEAN",true,"",4);recurInfo.addChildField("is_wednesday","BOOLEAN",true,"",5);recurInfo.addChildField("is_thursday","BOOLEAN",true,"",6);recurInfo.addChildField("is_friday","BOOLEAN",true,"",7);recurInfo.addChildField("is_saturday","BOOLEAN",true,"",8);recurInfo.addChildField("is_sunday","BOOLEAN",true,"",9);recurInfo.addChildField("every_nth_month","INTEGER",1,"",10);recurInfo.addChildField("day_or_date","TEXT","day","",11);field.addChildField("cancelled_dates","COLLECTION");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["NAME"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("prefix","TEXT");field.addChildField("first_name","TEXT");field.addChildField("middle_name","TEXT");field.addChildField("last_name","TEXT");field.addChildField("suffix","TEXT");return field;}
;mc_typeToDefaultValue["FILE2"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("file_name","TEXT");field.addChildField("folder_name","TEXT");field.addChildField("full_path","TEXT");field.addChildField("rename_on_upload","BOOLEAN");return field;}
;mc_typeToDefaultValue["PATH"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("real_path","TEXT");field.addChildField("friendly_path","TEXT");return field;}
;mc_typeToDefaultValue["URL"]=function(){var field=new DynField(null,{}
,{}
,null,null);var fUrl=field.addChildField("friendly_url","TEXT");fUrl.setUiType("FURL");field.addChildField("action_path","TEXT");field.addChildField("params","COLLECTION");field.addChildField("update_on_import","BOOLEAN");field.addChildField("url","RECORD_TYPE");field.addChildField("is_clash","BOOLEAN");field.addChildField("is_public","BOOLEAN",true);field.addChildField("clash_url","RECORD_TYPE");var fUrl=field.addChildField("forward_url","RECORD_TYPE");fUrl.getChildField("type").setValue("url");field.addChildField("screen_title","TEXT");field.addChildField("minicache_input","MCL");return field;}
;mc_typeToDefaultValue["RR"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("range_name","TEXT");field.addChildField("min","TEXT");field.addChildField("max","TEXT");return field;}
;mc_typeToDefaultValue["INPUT"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("value","TEXT");field.addChildField("validationType","TEXT","false");field.addChildField("autoComplete","BOOLEAN",false);return {data:field.data,metaData:field.metaData}
;}
;
function ajax_getStringForXml(string){var xmlRequest=ajax_getXMLHttpRequest();var url="GetHtmlForXml.ajax";xmlRequest.open("POST",url,false);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("html="+string);do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_setFormatedXmlString(xmlRequest.responseText);}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

while(xmlRequest.readyState!=4)}

function ajax_setFormatedXmlString(str){g_processedHtmlForXml=str;}

function ajax_getStringForEditor(string){var xmlRequest=ajax_getXMLHttpRequest();var handlerFunction=ajax_getReadyStateHandler(xmlRequest,ajax_setEditorString);xmlRequest.onreadystatechange=handlerFunction;var url="GetHtmlForEditor.ajax";xmlRequest.open("POST",url,false);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("html="+string);do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_setEditorString(xmlRequest.responseText)
}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

while(xmlRequest.readyState!=4)}

function ajax_setEditorString(str){editor_processedHtmlForEditor=str;}

function ajax_getStringForHtml(string){var xmlRequest=ajax_getXMLHttpRequest();var handlerFunction=ajax_getReadyStateHandler(xmlRequest,ajax_setHtmlString);xmlRequest.onreadystatechange=handlerFunction;var url="GetHtml.ajax";xmlRequest.open("POST",url,false);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("html="+string);do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_setHtmlString(xmlRequest.responseText)
}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

while(xmlRequest.readyState!=4)}

function ajax_setHtmlString(str){editor_processedHtmlForHtml=str;}


;if(!vfc_converters){var vfc_converters={}
;}

function vfc_getValue(dynField){var fieldType=dynField.getFieldType();var converter=vfc_converters[fieldType];if(!converter){return "";}

return converter(dynField);}

function vfc_registerConverter(fieldType,converterFx){vfc_converters[fieldType]=converterFx;}

vfc_converters["DATETIME"]=function(dynField){var dateTimeObj=dynField.data;var value;if(dateTimeObj&&dateTimeObj.date!=null&&dateTimeObj.time!=null){var dateObj=dateTimeObj.date;value=dateObj.toDbFormat()
value+=" "+dateTimeObj.time.toDbString();}

else 
{value="";}

return value;}

vfc_converters["RECORD_TYPE"]=function(dynField){return dynField.data.id;}

vfc_converters["RIL2"]=function(dynField){if(dynField.data.idArray){var idsStr="";var idArray=dynField.data.idArray;for(var i=0;i<idArray.length;i++)
{if(i!=0){idsStr+="|"+idArray[i];}

else 
{idsStr+=idArray[i];}

}

dynField.data.ids=idsStr;delete(dynField.data.idArray);}

return dynField.data.ids;}

function vfc_getCategory3Value(dynField){var definition=dynField.data.category_definition;var miniCache=dynField.ownerRecord.ownerCache;var c3Records=miniCache.records[definition.type];if(!c3Records){return "";}

var definitionRecord=c3Records[definition.id];if(!definitionRecord){return "";}

var value=dynField.data.value;return util_formatForXmlValue(definitionRecord.category_definition.options[value]);}

vfc_registerConverter("C3",vfc_getCategory3Value);function vfc_getRecordTypeValue(dynField){return dynField.data.id;}

vfc_registerConverter("RECORD_TYPE",vfc_getRecordTypeValue);function vfc_getLongTextValue(dynField){return util_formatForXmlValue(dynField.data);}

vfc_registerConverter("LONG_TEXT",vfc_getLongTextValue);function vfc_getDateValue(dynField){if(!dynField.data){return "";}

return dynField.data.toDbFormat();}

vfc_registerConverter("DATE",vfc_getDateValue);function vfc_getGenericValue(dynField){return dynField.getValue();}

vfc_registerConverter("BOOLEAN",vfc_getGenericValue);vfc_registerConverter("INTEGER",vfc_getGenericValue);vfc_registerConverter("DOUBLE",vfc_getGenericValue);function vfc_getTimeValue(dynField){var timeStr="";var timeObj=dynField.data;if(timeObj!=null){timeStr=timeObj.toDbString();}

return timeStr;}

vfc_registerConverter("TIME_TYPE_NAME",vfc_getTimeValue);function vfc_getRecordNameValue(dynField){return dynField.data.recordName;}

vfc_registerConverter("RECORD_NAME",vfc_getRecordNameValue);function vfc_returnNoValue(){return "";}

vfc_registerConverter("COLLECTION",vfc_returnNoValue);vfc_registerConverter("SST",vfc_returnNoValue);vfc_registerConverter("ARRAY",vfc_returnNoValue);vfc_registerConverter("TIMESTAMP",vfc_returnNoValue);vfc_registerConverter("USERSTAMP",vfc_returnNoValue);vfc_registerConverter("CD3",vfc_returnNoValue);vfc_registerConverter("DBI",vfc_returnNoValue);vfc_registerConverter("TIME_ALLOCATION_TYPE",vfc_returnNoValue);vfc_registerConverter("RTA2",vfc_returnNoValue);vfc_registerConverter("NAME",vfc_returnNoValue);vfc_registerConverter("MODULE",vfc_returnNoValue);function vfc_getShortTextValue(dynField){return util_formatForXmlValue(dynField.getValue());}

vfc_registerConverter("TEXT",vfc_getShortTextValue);vfc_registerConverter("TREE",vfc_getShortTextValue);function vfc_getInputValue(dynField){return util_formatForXmlValue(dynField.getChildField("value").getValue());}

vfc_registerConverter("INPUT",vfc_getInputValue);vfc_registerConverter("TEXT_AREA",vfc_getInputValue);vfc_registerConverter("PASSWORD",vfc_getInputValue);function vfc_getNewCategoryValue(dynField){return util_formatForXmlValue(dynField.getChildField("value").getValue());}

vfc_registerConverter("NEW_CATEGORY",vfc_getNewCategoryValue);function vfc_getMs3Value(dynField){return util_formatForXmlValue(dynField.getChildField("selected_options").getValue());}

vfc_registerConverter("MS3",vfc_getMs3Value);function vfc_getRecordNameValue(dynField){return dynField.data.recordName;}

vfc_registerConverter("RECORD_NAME",vfc_getRecordNameValue);function vfc_getUrlValue(dynField){return dynField.getChildField("friendly_url").getValue();}

vfc_registerConverter("URL",vfc_getUrlValue);function vfc_getNamelValue(dynField){try
{dynField.ownerRecord.getField(dynField.name+"_ln").setValue("");}

catch(e){}

return ""
}

vfc_registerConverter("NAME",vfc_getNamelValue);vfc_converters["PATH"]=function(dynField){return dynField.data.real_path;}

vfc_converters["FILE2"]=function(dynField){if(!dynField.data.file_name){return ;}

dynField.getOwnerCache().useFrame=true;return "";}

function photoConverter(dynField){dynField.getChildField("originalImagePath").setValue("");if(!dynField.data.originalImage.image_file.file_name){return ;}

dynField.getOwnerCache().useFrame=true;return "";}

vfc_converters["PHOTO"]=photoConverter;vfc_converters["FILE"]=vfc_returnNoValue;vfc_converters["IMAGE"]=vfc_returnNoValue;vfc_converters["VIDEO"]=vfc_returnNoValue;
;
function mcs_process(miniCache,onAfterProcess,onErrorFx){miniCache.runBeforeProcesses();miniCache.useFrame=false;var xml=mcs_createCacheXml(miniCache);mc_processCache(xml,miniCache,onAfterProcess,onErrorFx);}

function mc_processCache(xml,miniCache,onAfterProcessFx,onErrorFx){if(miniCache.useFrame){mc_processUploadCache(xml,miniCache,onAfterProcessFx);return ;}

var isAsync=(onAfterProcessFx!=null)?true:false;var xmlRequest=ajax_getXMLHttpRequest();var url="ProcessMiniCache.ajax";xmlRequest.open("POST",url,isAsync);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");var requestUrl="cache="+xml;requestUrl+="&screenId="+g_sessionInformation.screen_id;xmlRequest.send(requestUrl);if(isAsync){xmlRequest.onreadystatechange=function(){if(xmlRequest.readyState==4){if(xmlRequest.status==200){if(!mc_isResponseValid(xmlRequest.responseText)){if(onErrorFx){onErrorFx();}

return ;}

mc_setXmlResponseInto(miniCache,xmlRequest.responseText);if(onAfterProcessFx){onAfterProcessFx();}

}

}

}

}

else {do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){mc_setXmlResponseInto(miniCache,xmlRequest.responseText);}

}

}

while(xmlRequest.readyState!=4)return ;}

}

function mc_processUploadCache(xml,miniCache,onAfterProcessFx){var thisWindow=miniCache.ownerWindow||window;var doc=thisWindow.document||document;var body=doc.body;var html="<form id='uploadForm' method='post' action='IFrameCommunicator.do' enctype='multipart/form-data' target='uploadTarget'></form>";html+="<iframe style='display:none' id='uploadTarget' name='uploadTarget'></iframe>";var formHolder=cE("div",body);formHolder.id="uploadElements";formHolder.innerHTML=html;var form=doc.getElementById("uploadForm");var inputs=doc.getElementsByTagName("input");for(var i=inputs.length-1;i>=0;i--)
{var input=inputs[i];if(input.type.toLowerCase()!="file"){continue;}

var removed=input.parentNode.removeChild(input);aE(form,removed);}

var input=doc.createElement("input")
input.type="hidden";input.name="cache";input.id="mc_cache";form.appendChild(input);input.value=xml;thisWindow.mc_onAfterProcessIFrameFx=function(responseText){var uploadElements=doc.getElementById("uploadElements");uploadElements.parentNode.removeChild(uploadElements);if(!mc_isResponseValid(responseText)){return ;}

mc_setXmlResponseInto(miniCache,responseText,"from upload cache");if(onAfterProcessFx){onAfterProcessFx();}

}
;form.submit();}
;

var mc_onAfterProcessIFrameFx;function mc_setXmlResponseInto(miniCache,responseText,errorInfo){try
{eval(responseText);}

catch(e)
{if(!errorInfo){errorInfo="";}

alert("error receiving data: "+errorInfo);return ;}

mc_updateData(miniCache,miniCacheData);if(miniCache.doSyncToMaster){mc_updateData(getMasterCache(),miniCacheData);}

}

function mc_isResponseValid(obj){var errorOccured="error_"+"ocurred";var sessionExpired="session_"+"expired";if(obj==sessionExpired){alert("Your session has expired and you will be re-directed to the home page.");location.reload("");return false;}

if(obj.indexOf(errorOccured)==0){if(errorOccured==obj){alert("A problem has occured and we have been notified. Please try again later");}

else 
{alert(obj);}

return false;}

return true;}

function mc_updateData(miniCache,miniCacheData){mc_updateIds(miniCache,miniCacheData);copyData(miniCacheData.records_by_key,miniCache.records_by_key);var recordTypes=miniCacheData.records;var mcRecordTypes=miniCache.records;for(var i in recordTypes)
{if(!mcRecordTypes[i]){mcRecordTypes[i]=clone(recordTypes[i]);}

else 
{copyData(recordTypes[i],mcRecordTypes[i]);}

}

var recordTypes=miniCacheData.record_meta_data;var mcRecordTypes=miniCache.record_meta_data;for(var i in recordTypes)
{if(!mcRecordTypes[i]){mcRecordTypes[i]=clone(recordTypes[i]);}

else 
{copyData(recordTypes[i],mcRecordTypes[i]);}

}

copyData(miniCacheData.lists,miniCache.lists);copyData(miniCacheData.templates,miniCache.templates);copyData(miniCacheData.template_meta_data,miniCache.template_meta_data);copyData(miniCacheData.dyn_tables,miniCache.dyn_tables);copyData(miniCacheData.temp_to_real_id,mc_tempToRealId);copyData(miniCacheData.values,miniCache.values);}

function mc_updateIds(miniCache,miniCacheData){var records=miniCache.records;var recordMetaData=miniCache.record_meta_data;for(var i in miniCacheData.temp_to_real_id)
{if(!records[i]){continue;}

var idMap=miniCacheData.temp_to_real_id[i];for(var j in idMap)
{var recordsOfType=records[i];var recordMetaDataOfType=recordMetaData[i];if(recordsOfType[j]){var newId=idMap[j];recordsOfType[newId]=recordsOfType[j];recordMetaDataOfType[newId]=recordMetaDataOfType[j];delete(recordMetaDataOfType[j]);delete(recordsOfType[j]);}

}

}

}

function copyData(dataHolder,destinationHolder){for(var i in dataHolder)
{destinationHolder[i]=clone(dataHolder[i]);}

}

function mcs_createCacheXml(miniCache){var xml=constants_LESS_THAN_CHAR+"cache>";xml+=mcs_appendRecordsXml(miniCache);xml+=mcs_appendDynTablesXml(miniCache);xml+=constants_LESS_THAN_CHAR+"/cache>";return xml;}

function mcs_appendDynTablesXml(miniCache){var xml=constants_LESS_THAN_CHAR+"dyntables>";xml+=constants_LESS_THAN_CHAR+"to_save>";var dynTables=miniCache.dyn_tables;for(var i in dynTables)
{var dynTable=miniCache.getDynTable(i);if(dynTable.settings.doSave){xml+=mcs_appendDynTableXml(dynTable);}

}

xml+=constants_LESS_THAN_CHAR+"/to_save>";xml+=mcs_appendTablesToDeleteXml(miniCache);xml+=constants_LESS_THAN_CHAR+"/dyntables>";return xml;}

function mcs_appendTablesToDeleteXml(miniCache){var tablesToDelete=miniCache.tables_to_delete;if(tablesToDelete.length==0){return "";}

var xml=constants_LESS_THAN_CHAR+"to_delete>";for(var i=0;i<tablesToDelete.length;i++)
{xml+=constants_LESS_THAN_CHAR+"f name='"+tablesToDelete[i]+"'/>";}

xml+=constants_LESS_THAN_CHAR+"/to_delete>";return xml;}

function mcs_appendDynTableXml(dynTable){var xml=constants_LESS_THAN_CHAR+"table";xml+=" name='"+dynTable.type;xml+="' dn='"+dynTable.settings.singularName+"'>";xml+=mcs_appendTableFieldsToDelete(dynTable);xml+=mcs_appendTableFieldsToSave(dynTable);xml+=mcs_appendTableSettings(dynTable);xml+=constants_LESS_THAN_CHAR+"/table>";return xml;}

function mcs_appendTableFieldsToDelete(dynTable){var deleteXml="";var fieldsToDelete=dynTable.settings.fieldsToDelete;for(var i in fieldsToDelete)
{deleteXml+=constants_LESS_THAN_CHAR+"f name='"+fieldsToDelete[i]+"'/>";}

delete(dynTable.settings.fieldsToDelete);if(""==deleteXml){return "";}

var xml=constants_LESS_THAN_CHAR+"to_delete>";xml+=deleteXml;xml+=constants_LESS_THAN_CHAR+"/to_delete>";return xml;}

function mcs_appendTableSettings(dynTable){var xml=constants_LESS_THAN_CHAR+"settings>";xml+=constants_LESS_THAN_CHAR+"f ";xml+=" type='"+"DYNTABLE_SETTINGS"+"'>";var settings=dynTable.settings;delete(settings.doSave);for(var i in settings)
{xml+=constants_LESS_THAN_CHAR+"f ";xml+="name='"+i;xml+="' type='"+"TEXT";xml+="' value='"+util_formatForXmlValue(settings[i])+"'/>";}

xml+=constants_LESS_THAN_CHAR+"/f>";xml+=constants_LESS_THAN_CHAR+"/settings>";return xml;}

function mcs_appendTableFieldsToSave(dynTable){var xml="";var fieldNames=mc_getFieldNames(dynTable.metaData);for(var i in fieldNames)
{var field=dynTable.getField(fieldNames[i]);if(field.getMetaInfo("ds")){xml+=mcs_appendFieldXml(field);}

}

if(""==xml){return "";}

return constants_LESS_THAN_CHAR+"to_save>"+xml+constants_LESS_THAN_CHAR+"/to_save>";}

function mcs_appendRecordsXml(miniCache){var xml=constants_LESS_THAN_CHAR+"records>";var recordsMetaData=miniCache.record_meta_data;for(var type in recordsMetaData)
{var records=recordsMetaData[type];for(var id in records)
{var record=miniCache.getRecord(type,id);xml+=mcs_appendRecordXml(record);}

}

xml+=constants_LESS_THAN_CHAR+"/records>";return xml;}

function mcs_appendRecordXml(record){var xml="";if(!record.metaData.doSave&&!record.metaData.doProcess){return xml;}

xml+=constants_LESS_THAN_CHAR+"record type='"+record.type+"'";if(record.metaData.doSave){xml+=" do_save='true' ";}

if(record.metaData.doProcess){xml+=" do_process='true' ";}

xml+="id='"+record.id+"'>";var fieldNames=record.getFieldNames();var fieldXml="";for(var i=0;i<fieldNames.length;i++)
{var dynField=record.getField(fieldNames[i]);if(record.metaData.doSave&&!dynField.getMetaInfo("ds")&&!dynField.forceSave){continue;}

fieldXml+=mcs_appendFieldXml(dynField);}

if(fieldXml==""&&record.id>0){return "";}

xml+=fieldXml+constants_LESS_THAN_CHAR+"/record>"
record.metaData.doSave=false;return xml;}

function mcs_appendFieldXml(dynField){var fieldType=dynField.getFieldType();var xml=constants_LESS_THAN_CHAR+"f ";xml+="name='"+dynField.name;xml+="' dn='"+util_formatForXmlValue(dynField.getMetaInfo("dn"));xml+="' type='"+fieldType;xml+="' do='"+dynField.getMetaInfo("do");xml+="' uit='"+dynField.getUiType();xml+="' value='"+vfc_getValue(dynField)+"'";var childFieldNames=mc_getFieldNames(dynField.metaData);var chidFieldCount=childFieldNames.length;if(0==chidFieldCount){xml+="/>";return xml;}

else 
{xml+=">";for(var i=0;i<chidFieldCount;i++)
{var childFieldName=childFieldNames[i];xml+=mcs_appendFieldXml(dynField.getChildField(childFieldName));}

xml+=constants_LESS_THAN_CHAR+"/f>";return xml;}

}


function createListInput(type,name,startRecord,max,sortField,sortDirection){startRecord=startRecord||0;max=max||-1;sortDirection=sortDirection||"asc";name=name||"temp";var listInput=new DynField(null,{}
,{}
,null,null);listInput.addChildField("record_type","TEXT",type);listInput.addChildField("name","TEXT",name);listInput.addChildField("start_record","INTEGER",startRecord);listInput.addChildField("max_record_count","INTEGER",max);listInput.addChildField("fields_to_load","TEXT","");listInput.addChildField("sort_field","TEXT",sortField);listInput.addChildField("sort_direction","TEXT",sortDirection);listInput.addChildField("search_criteria","ARRAY");extendField(listInput,g_listInputBase);return listInput;}

function turnIntoListInput(field){extendField(field,g_listInputBase);return field;}

var g_listInputBase=new ListInputBase();function ListInputBase(){this.addField=function(fieldName){var fieldsToLoad=this.getChildField("fields_to_load");fieldsToLoad.setValue(fieldsToLoad.getValue()+fieldName+",");return this;}
;this.setMax=function(max){this.getChildField("max_record_count").setValue(max);}
;this.setSortField=function(sortField){this.getChildField("sort_field").setValue(sortField);}
;this.setStartRecord=function(startRecord){this.getChildField("start_record").setValue(startRecord);}
;this.setSortDirection=function(sortDirection){this.getChildField("sort_direction").setValue(sortDirection);}
;this.addSearchTerm=function(fieldName,value,searchType,groupName){var searchCriteria=this.getChildField("search_criteria");var criteria=searchCriteria.addChildField(null,"COLLECTION");criteria.addChildField("criteria_type","TEXT","search_term");criteria.addChildField("field_name","TEXT",fieldName);criteria.addChildField("value","TEXT",value);criteria.addChildField("search_type","INTEGER",searchType);var position=this.getChildField("search_criteria").getChildFieldNames().length;criteria.addChildField("position","INTEGER",position);if(null==groupName){groupName="";}

criteria.addChildField("group","TEXT",groupName);return criteria;}
;this.addOrSearchTerm=function(fieldName,value,searchType,groupName){var criteria=this.addSearchTerm(fieldName,value,searchType);if(null==groupName){groupName="";}

criteria.addChildField("group","TEXT",groupName);var position=this.getChildField("search_criteria").getChildFieldNames().length;criteria.addChildField("position","INTEGER",position);criteria.addChildField("is_or","BOOLEAN",true);}
;this.addConditional=function(fieldName,value,conditionalType){var searchCriteria=this.getChildField("search_criteria");var criteria=searchCriteria.addChildField(null,"COLLECTION");criteria.addChildField("criteria_type","TEXT","conditional");criteria.addChildField("field_name","TEXT",fieldName);criteria.addChildField("value","TEXT",value);criteria.addChildField("conditional_type","INTEGER",conditionalType);}
;this.addDateConditional=function(fieldName,value,conditionalType){alert("need to implement");}
;this.cloneField=function(){var newListInput=createListInput();newListInput.data=clone(this.data);newListInput.metaData=clone(this.metaData);return newListInput;}
;this.getSortFieldName=function(){return this.getChildField("sort_field").getValue();}
;this.getSearchCriteria=function(fieldName){var criteria=[];var searchCriteria=this.getChildField("search_criteria");var childNames=searchCriteria.getChildFieldNames();for(var i=0;i<childNames.length;i++)
{var aCriteria=searchCriteria.getChildField(childNames[i]);if(fieldName==aCriteria.getChildField("field_name").getValue()){criteria.push(aCriteria);}

}

return criteria;}
;this.removeSearchCriteria=function(fieldName){var searchCriteria=this.getChildField("search_criteria");var childNames=searchCriteria.getChildFieldNames();for(var i=0;i<childNames.length;i++)
{var aCriteria=searchCriteria.getChildField(childNames[i]);if(fieldName==aCriteria.getChildField("field_name").getValue()){searchCriteria.removeChildField(childNames[i]);break;}

}

}
;this.getConditionals=function(){var conditionals=[];var criteria=this.getChildField("search_criteria");var fieldNames=criteria.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var field=criteria.getChildField(fieldNames[i]);if("conditional"==field.getChildField("criteria_type").getValue()){conditionals.push(field);}

}

return conditionals;}
;}

var CONDITIONAL_EQUALS=0;var CONDITIONAL_GREATER_THAN=1;var CONDITIONAL_GREATER_THAN_EQUAL=2;var CONDITIONAL_LESS_THAN=3;var CONDITIONAL_LESS_THAN_EQUAL=4;var CONDITIONAL_NOT_EQUAL=5;var SEARCHTERM_CONTAINS=0;var SEARCHTERM_EXACT_MATCH=1;var SEARCHTERM_BEGINS_WITH=2;var SEARCHTERM_ENDS_WITH=3;var SEARCHTERM_NOT_CONTAINS=4;
function li_getSearchCriteria(listInput,fieldName){var criteria=[];var searchCriteria=listInput.getChildField("search_criteria");var childNames=searchCriteria.getChildFieldNames();for(var i in childNames)
{var aCriteria=searchCriteria.getChildField(childNames[i]);if(fieldName==aCriteria.getChildField("field_name").getValue()){criteria.push(aCriteria);}

}

return criteria;}

function li_setFieldsToLoad(listInput,fieldsToLoad){listInput.getChildField("fields_to_load").setValue(fieldsToLoad);}

function li_addSearchTerm(listInput,fieldName,value,searchType,isOr){var searchCriteria=listInput.getChildField("search_criteria");var criteria=searchCriteria.addChildField(null,"COLLECTION");criteria.addChildField("criteria_type","TEXT","search_term");criteria.addChildField("field_name","TEXT",fieldName);criteria.addChildField("value","TEXT",value);criteria.addChildField("search_type","INTEGER",searchType);if(null==isOr){isOr=false;}

criteria.addChildField("is_or","BOOLEAN",isOr);}

function li_removeCriteria(listInput,fieldName){var criteria=listInput.getChildField("search_criteria");var childNames=criteria.getChildFieldNames();for(var i in childNames)
{if(criteria.getChildField(childNames[i]).getChildField("field_name").getValue()==fieldName){criteria.removeChildField(i);break;}

}

}


function createRecordInput(type,id){var recordInput=new DynField(null,{}
,{}
,null,null);recordInput.usedAddField=false;recordInput.addChildField("type","TEXT",type);recordInput.addChildField("id","INTEGER",id);recordInput.addChildField("fields_to_load","TEXT","*");recordInput.addChildField("record_names","TEXT","");
extendField(recordInput,g_recordInputBase);return recordInput;}

function turnIntoRecordInput(field){if(!field){return null;}

extendField(field,g_recordInputBase);return field;}

var g_recordInputBase=new RecordInputBase();function RecordInputBase(){this.clearFieldsToLoad=function(){this.getChildField("fields_to_load").setValue("");}
;this.addField=function(fieldName){var fieldsToLoad=this.getChildField("fields_to_load");var value=fieldsToLoad.getValue();if(!this.usedAddField){this.usedAddField=true;value=fieldName;}

else 
{value+=","+fieldName;}

fieldsToLoad.setValue(value);return this;}
;this.addName=function(recordName){var recordNames=this.getChildField("record_names");var value=recordNames.getValue();if(value){value+=","+recordName;}

else 
{value=recordName;}

recordNames.setValue(value);return this;}
;}


mc_typeToDefaultValue["MCL"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("name","TEXT");field.addChildField("records_to_load","COLLECTION");field.addChildField("records_by_key","COLLECTION");field.addChildField("record_names","COLLECTION");field.addChildField("fields_to_process","COLLECTION");field.addChildField("fields_to_process_first","COLLECTION");field.addChildField("fields_to_process_last","COLLECTION");field.addChildField("lists","ARRAY");field.addChildField("templates","COLLECTION");field.addChildField("dyn_tables","COLLECTION");field.addChildField("values","COLLECTION");return {data:field.data,metaData:field.metaData}
;}

vfc_registerConverter("MCL",vfc_returnNoValue);

function extendList(aList){aList.copyToListInput=function(){if(aList.listInput){return aList.listInput;}

var listInput=createListInput(this.record_type,this.name,this.start_record,this.max_record_count,this.sort_field,this.sort_direction);aList.listInput=listInput;var fields=aList.fields_to_load;for(var i in fields)
{listInput.addField(fields[i]);}

var searchCriteria=aList.search_criteria;for(var i in searchCriteria)
{var criteria=searchCriteria[i];if("search_term"==criteria.criteria_type){if(criteria.is_or){listInput.addOrSearchTerm(criteria.field_name,criteria.value,criteria.search_type,criteria.group);}

else 
{listInput.addSearchTerm(criteria.field_name,criteria.value,criteria.search_type);}

}

else if("conditional"==criteria.criteria_type){listInput.addConditional(criteria.field_name,criteria.value,criteria.conditional_type);}

}

return listInput;}
;aList.getFirstRecord=function(){return this.ownerCache.getRecord(this.record_type,this.ids[0]);}
;return aList;}

function createGeneralExecuter(name,miniCache,instruction,basePackage){var gE=miniCache.createAction(name,"GXT");prepareGE(gE,instruction,basePackage);return gE;}

function createGEToRunFirst(name,miniCache,instruction,basePackage){var gE=miniCache.createFirstAction(name,"GXT");prepareGE(gE,instruction,basePackage);return gE;}

function createGEToRunLast(name,miniCache,instruction,basePackage){var gE=miniCache.createLastAction(name,"GXT");prepareGE(gE,instruction,basePackage);return gE;}

function prepareGE(gE,instruction,basePackage){var instructions=gE.getChildField("instructions");instructions.addChildField(instruction,"TEXT",instruction);gE.getChildField("base_package").setValue(basePackage);}

mc_typeToDefaultValue["GXT"]=function(){var gE=new DynField(null,{}
,{}
,null,null);gE.addChildField("instructions","COLLECTION");gE.addChildField("base_package","TEXT");gE.addChildField("exec_params","COLLECTION");return gE;}

vfc_registerConverter("GXT",vfc_returnNoValue);
mc_fieldTypeExtenders["GXT"]=function(dynField){dynField.getResults=function(){return this.getChildField("exec_res");}

dynField.getResultByName=function(resName){return this.getChildField("exec_res").getChildField(resName)
}

dynField.addExecParamDynField=function(fieldType,dynField,name){if(null==name){name=dynField.name;}

return this.getChildField("exec_params").insertChildField(name,fieldType,dynField);}

dynField.addExecParamObj=function(name,fieldType,value){return this.getChildField("exec_params").addChildField(name,fieldType,value);}

dynField.getExecParam=function(paramName){return this.getChildField("exec_params").getChildField(paramName);}

}

;var rd_counter=0;function createRecordDeleter(miniCache){rd_counter++;var name="deleter"+rd_counter;var deleter=createGeneralExecuter(name,miniCache,"RecordDeleter");addRecordDeleterExtensions(deleter);return deleter;}

function createRecordDeleterToRunFirst(miniCache){rd_counter++;var name="deleter"+rd_counter;var deleter=createGEToRunFirst(name,miniCache,"RecordDeleter");addRecordDeleterExtensions(deleter);return deleter;}

function addRecordDeleterExtensions(deleter){var params=deleter.getChildField("exec_params");params.addChildField("type","TEXT");params.addChildField("ids","TEXT");params.addChildField("is_delete_tas","BOOLEAN",false);deleter.setType=function(type){this.getChildField("exec_params").getChildField("type").setValue(type);}
;deleter.addId=function(id){var ids=this.getChildField("exec_params").getChildField("ids");var value=ids.getValue();value+=id+",";ids.setValue(value);}
;deleter.setIsDeleteTas=function(isDeleteTas){this.getChildField("exec_params").getChildField("is_delete_tas").setValue(isDeleteTas);}
;}


var constants_CUSTOM_SCREEN_TABLE_NAME="custom_screens";var constants_JAVASCRIPT_GLOBALS_TABLE_NAME="js_globals";var constants_EDITOR_PATH="editor";var constants_JS_EDITOR_PATH="jseditor";var constants_CACHE_NODE_NAME="cache";var constants_TO_LOAD_NOAD_NAME="to_load";var constants_TO_SAVE_NODE_NAME="to_save";var constants_TO_DELETE_NODE_NAME="to_delete"
var constants_TO_ADD_NODE_NAME="to_add";var constans_TO_UPDATE_NODE_NAME="to_update";var constants_PRIMARY_TYPE_ATTRIBUTE="primary_type";var constants_PRIMARY_ID_ATTRIBUTE="id";var constants_DYNTABLES_NODE_NAME="dyntables";var constants_RECORDS_NODE_NAME="records";var constants_LISTS_NODE_NAME="lists";var constants_TABLE_NODE_NAME="table";var constants_NAME_ATTRIBUTE="name";var constants_DISPLAY_NAME_ATTRIBUTE="displayName";var constants_RECORD_NODE_NAME="records";var constans_TYPE_ATTRIBUTE="type"
var constants_ID_ATTRIBUTE="id";var contants_FIELD_NODE_NAME="f";var contants_FIELD_TYPE_ATTRIBUTE="type";var contants_NAME_ATTRIBUTE="name";var contants_DISPLAY_NAME_ATTRIBUTE="dn";var contants_DISPLAY_ORDER_ATTRIBUTE="do";var contants_IS_MULTIPLE_ATTRIBUTE="multiple";var contants_VALUE_ATTRIBUTE="value";var contants_NEXT_UNNAMED_CHILD_COUNT_ATTRIBUTE="nucc";var contants_IS_STATIC_ATTRIBUTE="is_static";var constants_LESS_THAN_CHAR="!#"+"lessthanForXml!";var constants_GREATER_THAN_CHAR="!#"+"greaterthanForXml!";var constants_PERCENTAGE_SIGN="!#"+"percentagesing!";var constants_AND_SIGN="!#"+"andsign!";var constants_PLUS_SIGN="!#"+"plussign!";var constants_SPECIFIC_CAT_DEF="specific_category_definition";
function util_isInDom(element){if(!element.parentNode){return false;}

else if(element.parentNode.tagName){return true;}

else 
{return false;}

}

function util_getLength(aList){var counter=0;for(var i in aList)
{counter++;}

return counter;}

function util_replaceAllString(aString,stringValue,replaceString){var re=eval("/"+stringValue+"/g");return aString.replace(re,replaceString);}

function util_addUnderlineEvent(element){element.onmouseover=function(){element.style.textDecoration="underline"}
;element.onmouseout=function(){element.style.textDecoration=""}
;}

var g_processedHtmlForXml=null;function util_formatForXml(value){alert("this function should be used. Please notify Evan");var strForXml=g_processedHtmlForXml;var htmlString=value;htmlString=util_replaceAll(htmlString,"%",constants_PERCENTAGE_SIGN);htmlString=util_replaceAll(htmlString,"&",constants_AND_SIGN);htmlString=util_replaceAll(htmlString,"+",constants_PLUS_SIGN);ajax_getStringForXml(htmlString);var maxTimeTrying=2000;var startTime=new Date();while(null==strForXml&&((new Date()-startTime)<maxTimeTrying))
{strForXml=g_processedHtmlForXml;}

g_processedHtmlForXml=null;return strForXml;}

var util_mswordchars=[]
util_mswordchars[String.fromCharCode(8220)]='"';util_mswordchars[String.fromCharCode(8221)]='"';util_mswordchars[String.fromCharCode(8216)]="'";util_mswordchars[String.fromCharCode(8217)]="'";util_mswordchars[String.fromCharCode(8211)]="-";util_mswordchars[String.fromCharCode(8212)]="--";util_mswordchars[String.fromCharCode(189)]="1/2";util_mswordchars[String.fromCharCode(188)]="1/4";util_mswordchars[String.fromCharCode(190)]="3/4";util_mswordchars[String.fromCharCode(169)]="(C)";util_mswordchars[String.fromCharCode(174)]="(R)";util_mswordchars[String.fromCharCode(8230)]="...";function util_removeMsCharacters(value){for(var msChar in util_mswordchars)
{value=util_replaceAll(value,msChar,util_mswordchars[msChar])
}

return value;}

function util_removeEmbededScripts(html){var scriptStart=html.indexOf("<SCRIPT");var scriptEnd=html.indexOf("<"+"/SCRIPT>");while(scriptStart!=-1&&scriptEnd!=-1)
{var scriptString=html.substring(scriptStart,(scriptEnd+9));html=html.replace(scriptString,"");scriptStart=html.indexOf("<SCRIPT");scriptEnd=html.indexOf("<"+"/SCRIPT>");}

var scriptStart=html.indexOf("<script");var scriptEnd=html.indexOf("<"+"/script>");while(scriptStart!=-1&&scriptEnd!=-1)
{var scriptString=html.substring(scriptStart,(scriptEnd+9));html=html.replace(scriptString,"");scriptStart=html.indexOf("<script");scriptEnd=html.indexOf("<"+"/script>");}

return html;}

function util_addHiddenInput(name,value,container){var input=document.createElement("input")
input.type="hidden";input.value=value;input.name=name;container.appendChild(input);}

function util_clearElement(element){for(var i=element.childNodes.length-1;i>=0;i--)
{element.removeChild(element.childNodes[i]);}

}

function util_openFieldXmlTag(field){var xml=constants_LESS_THAN_CHAR+"f ";xml+="name='"+field.name+"' ";xml+=" dn='"+util_formatForXmlValue(field.displayName);xml+="' type='"+field.TYPE;xml+="' do='"+field.displayOrder+"'";var valueStr=(field.value==null)?">":" value='"+util_formatForXmlValue(field.value)+"'>";xml+=valueStr;return xml;}

function util_closeFieldXmlTag(){return constants_LESS_THAN_CHAR+"/f>";}

var util_reservedXmlChars=new Array();util_reservedXmlChars["'"]='!#'+'singlequote!';util_reservedXmlChars['<']='!#'+'lessthan!';util_reservedXmlChars['>']='!#'+'greaterthan!';util_reservedXmlChars['"']='!#'+'doublequote!';util_reservedXmlChars['&']='!#'+'andsign!';util_reservedXmlChars['%']='!#'+'percentagesing!';util_reservedXmlChars['+']='!#'+'plussign!';util_reservedXmlChars['&nbsp;']=' ';function util_formatValueForHtml(value){if(value==true||value==false){return value;}

else if(value==undefined||value==null||value==""){return "";}

for(var i in util_reservedXmlChars)
{if(i=='&nbsp;'){continue;}

value=util_replaceAll(value,util_reservedXmlChars[i],i);}

return value;}

function util_formatForXmlValue(value){if(value==true||value==false){return value;}

else if(value==undefined||value==null||value==""){return "";}

value=util_newReplaceAll(value,"'","!#"+"singlequote!");value=util_newReplaceAll(value,"<","!#"+"lessthan!");value=util_newReplaceAll(value,">","!#"+"greaterthan!");value=util_newReplaceAll(value,"\"","!#"+"doublequote!");value=util_newReplaceAll(value,"&","!#"+"andsign!");value=util_newReplaceAll(value,"%","!#"+"percentagesing!");value=util_newReplaceAll(value,"\n","!#"+"breakline!");value=util_newReplaceAll(value,"\\+","!#"+"plussign!");value=util_newReplaceAll(value,"&nbsp;"," ");
return value;}

function util_newReplaceAll(aString,replaceStr,replaceValue){if("string"!=typeof(aString)){return aString;}

var rE=new RegExp(replaceStr,"g");return aString.replace(rE,replaceValue);}


function util_replaceAll(aString,replaceStr,replaceValue){try
{var index=aString.indexOf(replaceStr);}

catch(e)
{return aString;}

while(index>-1)
{aString=aString.replace(replaceStr,replaceValue);index=aString.indexOf(replaceStr,index+replaceValue.length);}

return aString;}


function ajax_getXMLHttpRequest(){var xmlreq=null;if(window.XMLHttpRequest){xmlreq=new XMLHttpRequest();}

else if(window.ActiveXObject){try
{xmlreq=new ActiveXObject("Msxml2.XMLHTTP");}

catch(e)
{xmlreq=new ActiveXObject("Microsoft.XMLHTTP");}

}

else 
{alert("This browser does not support this feature");}

return xmlreq;}

function ajax_getReadyStateHandler(xmlRequest,responseXmlHandler){var requestHandler=function(){if(xmlRequest.readyState==4){if(xmlRequest.status==200){responseXmlHandler(xmlRequest.responseText);}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

return requestHandler;}


function sorter_sortAscending(sortProperty,arrayToSort){sorter_sortProperty=sortProperty;arrayToSort.sort(sorter_generalCompare);sorter_sortProperty=null;}
;function sorter_sortDescending(sortProperty,arrayToSort){sorter_sortProperty=sortProperty;arrayToSort.sort(sorter_reverseCompare);sorter_sortProperty=null;}
;var sorter_sortProperty;function sorter_generalCompare(arg1,arg2){if(!sorter_sortProperty){alert("You must set the sort property");}

eval("var value1 = arg1."+sorter_sortProperty);eval("var value2 = arg2."+sorter_sortProperty);if(value1>value2){return 1;}

else if(value1<value2){return -1;}

else 
{return 0;}

}
;function sorter_reverseCompare(arg1,arg2){return sorter_generalCompare(arg2,arg1);}

;function ValidationHandler(){this.valTypes={}
;this.valObjects={}
;this.errors=[];this.errorDisplayFx;this.types={}
;this.valObjectsByType={}

this.errorList={}
;this.errorHandlerByType={}
;}

ValidationHandler.prototype=new ValidationBase();function ValidationBase(){
this.addVal=function(type,valFx){this.valTypes[type]=valFx;}
;
this.addObjectToVal=function(type,object){var objsByType=this.valObjectsByType[type];if(null==objsByType){objsByType=[];this.valObjectsByType[type]=objsByType;}

objsByType.push(object);}
;this.addValidationObject=function(type,valObject){this.valObjects[type]=valObject;}

this.getValObject=function(type){return this.valObjects[type];}


this.setErroDisplayFx=function(errorDisplayFx){this.errorDisplayFx=errorDisplayFx;}


this.validate=function(){this.resetErrors();var objsByType=this.valObjectsByType;for(var type in objsByType)
{var valFx=this.types[type]
if(null==valFx){valFx=this.valTypes[type];}

if(valFx==null){alert("There is not  a validation function registered for the type "+type);return ;}

var objList=objsByType[type];for(var i=0;i<objList.length;i++)
{var element=objList[i];if(null==element){continue;}

if(!isInDom(element)&&element.tagName!=undefined){objList[i]=null;continue;}

var result=valFx(objList[i]);var objectType=typeof(result);if(objectType=="object"){for(var j=0;j<result.length;j++)
{var error=result[j];this.errors.push(error);this.hasErrors=true;}

break}

else if(objectType=="boolean"){if(!result){this.addToErrorList(type,element);}

}

}

}

if(this.hasErrors){this.showErrors();return false;}

return true;}
;this.registerTypeValFx=function(type,valFx){this.types[type]=valFx;}
;this.registerErrorMsgFx=function(type,errorFx){this.errorHandlerByType[type]=errorFx;}
;this.registerValidation=function(type,valFx,error){this.types[type]=valFx;this.errorHandlerByType[type]=error;}
;this.showErrors=function(){var errMsg="";var errorsByType=this.errorList;for(var type in errorsByType)
{var errorFx=this.errorHandlerByType[type]
if(null==errorFx){alert("There is no error handling function registered for the type "+type);return ;}

var errorElList=errorsByType[type];for(var i=0;i<errorElList.length;i++)
{if(typeof(errorFx)=="string"){errMsg+=errorFx+"\n";}

else 
{var aMsg=errorFx(errorElList[i]);if(aMsg.trim()!=""){errMsg+=aMsg+"\n";}

}

}

}

var errors=this.errors;for(var i=0;i<errors.length;i++)
{errMsg+=errors[i]+"\n";}

if(null!=this.errorDisplayFx){this.errorDisplayFx(errMsg.replaceAll("\n","<br>"));}

else if(window.showMessage){showMessage(errMsg.replaceAll("\n","<br>"));}

else 
{alert(errMsg);}

}
;this.resetErrors=function(){this.hasErrors=false;this.errorList={}
;this.errors=[];}
;this.addToErrorList=function(type,element){this.hasErrors=true;var errorListByType=this.errorList[type];if(null==errorListByType){errorListByType=[];this.errorList[type]=errorListByType;}

errorListByType.push(element);}
;}
;if(null==ValidationUtil){var ValidationUtil=new ValidationHandler();}


var KeyCodeUtil=new KeyCodeUtilBase();function KeyCodeUtilBase(){this.getTranslation=function(keyCode){var trans=this.KEY_CODE_TRANSLATOR[keyCode];return trans;}
;this.cancelPressKey=function(event){if(null!=event.stopPropagation){event.stopPropagation();event.preventDefault();}

else 
{window.event.returnValue=false;window.event.cancelBubble=true;}

return null;}
;this.isNumeric=function(event){var keyCode=this.getKeyCode(event);if(keyCode>=48&&keyCode<=57){return true;}

return false;}
;this.isAlphabetic=function(event){var keyCode=this.getKeyCode(event);if((keyCode>=65&&keyCode<=90)||(keyCode>=97&&keyCode<=122)){return true;}

return false;}
;this.getKeyCode=function(event){var key;if(null!=event&&null!=event.which){key=event.which;}

else if(null!=window.event){key=window.event.keyCode;}

return key;}
;this.isNumber=function(keyCode){return ((keyCode>=48&&keyCode<=57)||(keyCode>=96&&keyCode<=105));}
;this.isCharacter=function(event,keyCode){var keyCodePressed=this.getKeyCode(event);if(keyCodePressed==keyCode){return true;}

return false;}

this.isValidCharForNumber=function(event){if(this.isNumeric(event)){return true;}

var isValidCharacter=(this.isCharacter(event,46)||
this.isCharacter(event,44)||
this.isCharacter(event,45)||
this.isCharacter(event,8)||
this.isCharacter(event,0));return isValidCharacter;}

var kc=[];kc[48]="0";kc[49]="1";kc[50]="2";kc[51]="3";kc[52]="4";kc[53]="5";kc[54]="6";kc[55]="7";kc[56]="8";kc[57]="9";kc[65]="A";kc[66]="B";kc[67]="C";kc[68]="D";kc[69]="E";kc[70]="F";kc[71]="G";kc[72]="H";kc[73]="I";kc[74]="J";kc[75]="K";kc[76]="L";kc[77]="M";kc[78]="N";kc[79]="O";kc[80]="P";kc[81]="Q";kc[82]="R";kc[83]="S";kc[84]="T";kc[85]="U";kc[86]="V";kc[87]="W";kc[88]="X";kc[89]="Y";kc[90]="Z";kc[96]="0";kc[97]="1";kc[98]="2";kc[99]="3";kc[100]="4";kc[101]="5";kc[102]="6";kc[103]="7";kc[104]="8";kc[105]="9";this.KEY_CODE_TRANSLATOR=kc;}
;

function getProperty(properties,name,defaultValue){if(properties==null||properties[name]==null){return defaultValue;}

return properties[name];}
;

function RequiredValidation(validationHandler){this.reqElCount=0;this.validationHandler=validationHandler;validationHandler.addValidationObject(this.TYPE,this);validationHandler.registerValidation(this.TYPE,this.validateFx,this.errorFx);}

RequiredValidation.prototype=new RequiredValidationBase();function RequiredValidationBase(){this.TYPE="REQUIRED";var eV={}
;eV[g_sessionInformation.settings.date_format.empty_date]=true;this.emptyValues=eV;this.attachValidation=function(element){if(element.name.trim()==""){element.name="Unnamed element "+this.reqElCount;}

this.validationHandler.addObjectToVal(this.TYPE,element);this.reqElCount++;}
;this.validateFx=function(element){var value=element.value.trim();if(value==""||RequiredUtil.emptyValues[value]){return false;}

return true;}

this.errorFx=function(element){return element.name+" "+"is required.";}
;this.registerEmptyValue=function(val){this.emptyValues[val]=true;}
;}

var RequiredUtil=new RequiredValidation(ValidationUtil);
;;;;
;;;;;;;;;;;;;;;
function MiniCache(){
this.ownerWindow;
this.records_by_key={}
;
this.records={}
;
this.lists={}
;
this.values={}
;
this.record_meta_data={}
;
this.templates={}
;
this.template_meta_data={}
;
this.dyn_tables={}
;
this.tables_to_delete=[];
this.record_names={}
;
this.validationHandler=new ValidationHandler();
this.onBeforeProcessFxs={}
;
this.addBeforeProcessFx=function(fx,name){var count=++mc_processFxCounter;if(!name){name="fx"+count;}

this.onBeforeProcessFxs[name]=fx;}
;
this.removeBeforeProcessFx=function(name){delete(this.onBeforeProcessFxs[name]);}
;
this.runBeforeProcesses=function(){for(var i in this.onBeforeProcessFxs)
{var fx=this.onBeforeProcessFxs[i];fx();}

}
;
this.addRecordName=function(record,name){this.record_names[name]={type:record.type,id:record.getId()}
;}
;
this.getRecordByName=function(name){var info=this.record_names[name];if(!info){return null;}

return this.getRecord(info.type,info.id);}
;this.getValue=function(name){return this.values[name];}
;
this.getDynTable=function(type){var data=this.templates[type];var metaData=this.template_meta_data[type];var settings=this.dyn_tables[type];return new DynTable(type,data,metaData,settings,this);}
;
this.getRecord=function(type,id){id=parseInt(id);if(0>id&&mc_tempToRealId[type]&&mc_tempToRealId[type][id]){id=mc_tempToRealId[type][id];}

var recordsOfType=this.records[type];if(!recordsOfType){if(mc_masterCache&&mc_masterCache.records[type]){this.records[type]=clone(mc_masterCache.records[type]);this.record_meta_data[type]=clone(mc_masterCache.record_meta_data[type]);recordsOfType=this.records[type];}

else 
{return null;}

}

var data=recordsOfType[id];if(!data){if(mc_masterCache&&mc_masterCache.records[type]&&mc_masterCache.records[type][id]){this.records[type][id]=clone(mc_masterCache.records[type][id]);this.record_meta_data[type][id]=clone(mc_masterCache.record_meta_data[type][id]);data=recordsOfType[id];}

else 
{return null;}

}

var metaData=this.record_meta_data[type][id];return new Record(type,id,data,metaData,this);}
;
this.getListByName=function(name){var aList=this.lists[name];if(!aList){if(!mc_masterCache){return null;}

var masterList=mc_masterCache.lists[name];if(null==masterList){return null;}

var masterCache=masterList.ownerCache;masterList.ownerCache=null;aList=clone(masterList);masterList.ownerCache=masterCache;}

if(!aList){return null;}

aList.ownerCache=this;return extendList(aList);}
;
this.getRecordByKey=function(type,fieldName,key){if(mc_masterCache&&mc_masterCache.records_by_key[type+"|"+fieldName+"|"+key]){var recordInfo=clone(mc_masterCache.records_by_key[type+"|"+fieldName+"|"+key]);}

else 
{var recordInfo=this.records_by_key[type+"|"+fieldName+"|"+key];}

var record=null;if(null!=recordInfo){record=this.getRecord(recordInfo.type,recordInfo.id);}

return record;}
;
this.deleteRecord=function(type,id){var deleter=createRecordDeleter(this);deleter.setType(type);deleter.addId(id);this.clearRecord(type,id);}
;
this.clearRecord=function(type,id){var mData=this.record_meta_data[type];if(!mData){return ;}

delete(mData[id]);var recordData=this.records[type];delete(recordData[id]);var isEmpty=true;for(var rId in recordData)
{isEmpty=false;break;}

if(isEmpty){delete(this.record_meta_data[type]);delete(this.records[type]);}

this.cancelRecordToLoad(type,id);}
;
this.clearAllRecords=function(){this.records_by_key={}
;this.records={}
;this.lists={}
;this.record_meta_data={}
;}
;
this.getTemplate=function(type){if(!this.templates[type]&&mc_masterCache.templates[type]){this.templates[type]=clone(mc_masterCache.templates[type]);this.template_meta_data[type]=clone(mc_masterCache.template_meta_data[type]);}

if(this.templates[type]){var template=new Record(type,0,this.templates[type],this.template_meta_data[type],this);template.isTemplate=true;return template;}

return null;}
;
this.createRecord=function(type,id){if(!id){mc_newIdCounter--;id=mc_newIdCounter;}

var templateData=this.getTemplate(type);var record=clone(templateData.data);record.type=type;record.id=id;var recordsOfType=this.records[type];if(!recordsOfType){this.records[type]={}
;recordsOfType=this.records[type];}

recordsOfType[id]=record;var recordMetaData=clone(templateData.metaData);recordMetaData.type=type;recordMetaData.id=id;var metaDataForType=this.record_meta_data[type];if(!metaDataForType){this.record_meta_data[type]={}
;metaDataForType=this.record_meta_data[type];}

metaDataForType[id]=recordMetaData;var record=this.getRecord(type,id);record.setDoSave();return record;}
;this.createTable=function(name,displayName,pluralName,packageName){this.dyn_tables[name]={singularName:displayName,pluralName:pluralName,packageName:packageName,cachingSetting:"",doSave:true}
;this.templates[name]={}
;this.template_meta_data[name]={}
;}
;this.initializeProcessor=function(){this.records["processor"]={}
;this.records["processor"][0]={}
;this.record_meta_data["processor"]={}
;this.record_meta_data["processor"][0]={}
;this.record_meta_data["processor"][0].doProcess=true;var recordToProcess=this.getRecord("processor",0);return recordToProcess.addField("processor","MCL","",0);}
;this.processor=this.initializeProcessor();this.process=function(onAfterProcessFx,onErrorFx){this.syncToMaster();var thisCache=this;var finishFx=function(){thisCache.processor=thisCache.initializeProcessor();if(onAfterProcessFx){onAfterProcessFx();}

}

mcs_process(thisCache,finishFx,onErrorFx);}
;
this.syncProcess=function(){this.syncToMaster();var thisCache=this;mcs_process(thisCache);thisCache.processor=thisCache.initializeProcessor();}
;this.createAction=function(name,fieldType){return this.processor.getChildField("fields_to_process").addChildField(name,fieldType);}
;this.createFirstAction=function(name,fieldType){return this.processor.getChildField("fields_to_process_first").addChildField(name,fieldType);}
;this.createLastAction=function(name,fieldType){return this.processor.getChildField("fields_to_process_last").addChildField(name,fieldType);}
;this.removeActionField=function(name){this.processor.getChildField("fields_to_process_last").removeChildField(name);this.processor.getChildField("fields_to_process_first").removeChildField(name);this.processor.getChildField("fields_to_process").removeChildField(name);}
;this.getActionField=function(name){return this.getRecord(name,0).getField(name);}

this.addKeyedRecordToLoad=function(type,fieldName,key,fieldsToLoad){if(!fieldsToLoad){fieldsToLoad="*";}

var recordsByKey=this.processor.getChildField("records_by_key");var requestId=type+fieldName+key;var recordToLoad=recordsByKey.addChildField(requestId,"COLLECTION",null,null,null);recordToLoad.addChildField("type","TEXT",type,null,null);recordToLoad.addChildField("field_name","TEXT",fieldName,null,null);recordToLoad.addChildField("key","TEXT",key,null,null);recordToLoad.addChildField("fields_to_load","TEXT",fieldsToLoad,null,null);return recordToLoad;}
;this.addRecordToLoad=function(type,id){var recordInput=createRecordInput(type,id);this.addRecordInput(recordInput);return recordInput;}
;this.addRecordInput=function(recordInput){var requestId=recordInput.data.type+recordInput.data.id;this.processor.getChildField("records_to_load").insertChildField(requestId,"COLLECTION",recordInput);}
;this.cancelRecordToLoad=function(type,id){var requestId=type+id;this.processor.getChildField("records_to_load").removeChildField(requestId);}

this.addListToLoad=function(type,name,startRecord,max,sortField,sortDirection){var listInput=createListInput(type,name,startRecord,max,sortField,sortDirection);this.addListInput(listInput);return listInput;}
;this.addListInput=function(listInput){this.processor.getChildField("lists").insertChildField(null,"COLLECTION",listInput);}
;this.addTableToLoad=function(tableName){var tablesToLoad=this.processor.getChildField("dyn_tables");tablesToLoad.addChildField(tableName,"TEXT",tableName);}
;this.addTemplateToLoad=function(tableName){var templates=this.processor.getChildField("templates");templates.addChildField(tableName,"TEXT",tableName);}
;this.syncToMaster=function(){if(this.isMaster||!mc_masterCache){return ;}

var recordsToSave=this.getRecordsToSave();for(var i in recordsToSave)
{var newRecord=recordsToSave[i];var masterRecord=mc_masterCache.getRecord(newRecord.type,newRecord.id);if(!masterRecord){continue;}

mc_cloneContent(newRecord.data,masterRecord.data);mc_cloneContent(newRecord.metaData,masterRecord.metaData);masterRecord.resetMetaInfo(null,"bs");}

}
;this.getRecordsToSave=function(){var recordsToSave=[];var recordsMetaData=this.record_meta_data;for(var type in recordsMetaData)
{var records=recordsMetaData[type];for(var id in records)
{var record=this.getRecord(type,id);if(record.metaData.doSave){recordsToSave.push(record);}

}

}

return recordsToSave;}
;this.getRecordsToSaveOfAType=function(type){var recordsToSave=[];var records=this.record_meta_data[type];for(var id in records)
{var record=this.getRecord(type,id);if(record.metaData.doSave){recordsToSave.push(record);}

}

return recordsToSave;}
;this.getRecordsByType=function(type,sortField,sortDirection){var recordsByType=[];var records=this.record_meta_data[type];for(var id in records)
{var record=this.getRecord(type,id);recordsByType.push(record);}

if(sortField){if(sortDirection=="asc"||!sortDirection){sorter_sortAscending("data."+sortField,recordsByType);}

else 
{sorter_sortDescending("data."+sortField,recordsByType);}

}

return recordsByType;}
;this.syncToMasterOnProcess=function(){this.doSyncToMaster=true;}

this.clearRecordsOfAType=function(type){var records=this.record_meta_data[type];for(var id in records)
{this.clearRecord(type,id);}

}

this.copyTemplate=function(recordType,fromMiniCache){var data=fromMiniCache.templates[recordType];var metaData=fromMiniCache.template_meta_data[recordType]
if(data&&metaData){this.templates[recordType]=clone(data);this.template_meta_data[recordType]=clone(metaData);}

}
;
this.addValType=function(valType,valFx){this.validationHandler.addVal(valType,valFx);return this;}
;
this.addValToObj=function(valType,valObj){this.validationHandler.addObjectToVal(valType,valObj);return this;}
;
this.validate=function(){return this.validationHandler.validate();}
;
this.id=++mc_newCacheIdCounter;
this.setOwnerWindow=function(ownerWindow){this.ownerWindow=ownerWindow;}
;
this.isDataToLoad=function(){var p=this.processor.data;return (this.isEmpty(p.records_by_key)||this.isEmpty(p.records_to_load)||this.isEmpty(p.lists));}
;this.isEmpty=function(object){for(var i in object)
{var notEmpty=object[i];return false;}

return true;}
;}
;function getMasterCache(){if(null==mc_masterCache){mc_masterCache=new MiniCache();mc_masterCache.isMaster=true;mc_masterCache.id="master";}

return mc_masterCache;}

var mc_newIdCounter=0;var mc_newCacheIdCounter=0;var mc_processFxCounter=0;var mc_tempToRealId={}
;if(!mc_masterCache){var mc_masterCache=null;}

if(!mc_objectToHtmlFxByType){var mc_objectToHtmlFxByType={}
;}

function mc_getFieldNames(metaData){var fieldNames=[];for(var i in metaData)
{var nameLength=i.length;if(nameLength<=3){continue;}

var suffix=i.substring(nameLength-3,nameLength);if("_do"==suffix){var fieldName=i.substring(0,nameLength-3);fieldNames.push({name:fieldName,order:metaData[i]}
);}

}

sorter_sortAscending("order",fieldNames);for(var i in fieldNames)
{fieldNames[i]=fieldNames[i].name;}

return fieldNames;}

function mc_clearObject(anObject){for(var i in anObject)
{delete(anObject[i]);}

}


function mc_cloneContent(source,destination){mc_clearObject(destination);for(var i in source)
{destination[i]=clone(source[i]);}

return destination;}

;;;;;;;;function FileDownloader(srcUrl,destPath){this.srcUrl=srcUrl;this.destPath=destPath;this.process=function(afterDownloadFx){var thisObj=this;var miniCache=new MiniCache();var preProcGE=createGeneralExecuter("preProcGE",miniCache,"FileDownloader");var params=preProcGE.getChildField("exec_params");params.addChildField("src_url","TEXT",thisObj.srcUrl);params.addChildField("dest_path","TEXT",thisObj.destPath);var afterProcessFx=function(){var preProcGE=miniCache.getActionField("preProcGE");if(null==preProcGE){return ;}

var result=preProcGE.data.exec_res;if(null!=afterDownloadFx){afterDownloadFx(result);}

}
;miniCache.process(afterProcessFx);}
;}

;

var AviaryEditor=new AviaryEditorBase();function AviaryEditorBase(){
this.img=document.createElement("img");this.originalScrollTop=0;
this.afterSave;
this.onClose;
this.open=function(){this.editor.launch({image:this.img}
);this.originalScrollTop=document.body.scrollTop;var scrollTop=this.originalScrollTop;while(scrollTop>0)
{window.scrollTo(0,scrollTop--);}

}
;
this.save=function(aviaryId,retrieveUrl){var img=this.img;var thisObj=this;var strArray=img.src.split("/");var length=strArray.length;var path="";for(var i=3;i<length;i++)
{if(i==(length-1)){var position=strArray[i].indexOf("?");if(position!=-1){strArray[i]=strArray[i].substr(0,position);}

}

path+="/"+strArray[i];}

var afterDownloadFx=function(){var src=path+"?"+new Date().getTime();thisObj.img.src=src;if(thisObj.afterSave){thisObj.afterSave(thisObj.img);}

}
;new FileDownloader(retrieveUrl,path).process(afterDownloadFx);}
;
this.close=function(){if(this.onClose){this.onClose();}

var scrollTop=0;while(scrollTop<this.originalScrollTop)
{window.scrollTo(0,scrollTop++);}

}
;
this.init=function(){var aviaryScriptEl=document.createElement("script");aviaryScriptEl.type="text/javascript";aviaryScriptEl.src="http://feather.aviary.com/js/feather.js";aviaryScriptEl.onload=function(){var onAviaryEditSave=function(aviaryId,newUrl){AviaryEditor.save(aviaryId,newUrl);}
;var onAviaryEditorClose=function(){AviaryEditor.close();}
;var props={apiKey:"013bcf8ba",apiVersion:2,tools:"all",onSave:onAviaryEditSave,onClose:onAviaryEditorClose}
;AviaryEditor.editor=new Aviary.Feather(props);    
            };   
            document.body.appendChild( aviaryScriptEl );   
      };   
                     
      this.init();   
};

function RadioButton(){this.options=[];
this.layout="vertical";this.cellVAlign="middle";this.labelClass;this.buttonCellClass;this.onChange;this.selectedOption;}

RadioButton.prototype=new RadioButtonBase();function RadioButtonBase(){this.build=function(parentEl,selectedValue){if("custom"==this.layout){this.buildCustomLayout();}

else 
{this.buildLayout(parentEl);}

this.selectValue(selectedValue);}
;
this.addOption=function(label,value,parentEl,onclickFx){this.options.push({label:label,value:value,parentEl:parentEl,onclickFx:onclickFx}
);}
;
this.addDynamicOption=function(value,labelBuilderFx,parentEl,getExtraInfoFx){this.options.push({value:value,labelBuilderFx:labelBuilderFx,parentEl:parentEl,getExtraInfoFx:getExtraInfoFx}
);}
;
this.getOptionByValue=function(value){for(var i=0;i<this.options.length;i++)
{if(value==this.options[i].value){return this.options[i];}

}

return null;}
;this.selectValue=function(value){var option=this.getOptionByValue(value);if(option){this.selectOption(option,true);}

}
;this.getValue=function(){if(!this.selectedOption){return null;}

return this.selectedOption.value;}
;this.buildCustomLayout=function(){for(var i=0;i<this.options.length;i++)
{var option=this.options[i];if(option.parentEl){this.buildOption(option.parentEl,option);}

}

}
;this.buildLayout=function(parentEl){var tBody=createTable(parentEl);if("horizontal"==this.layout){var tr=cE("tr",tBody);}

for(var i=0;i<this.options.length;i++)
{var option=this.options[i];if("vertical"==this.layout){var tr=cE("tr",tBody);}

var td=cE("td",tr);this.buildOption(td,option);}

}
;this.selectOption=function(option,omitOnChange){if(this.selectedOption){this.deselectOption(this.selectedOption);}

this.selectedOption=option;option.radioEl.checked=true;if(this.onChange&&!omitOnChange){this.onChange(this.getValue());}

}

this.deselectOption=function(option){option.radioEl.checked=false;}
;this.buildOption=function(parentEl,option){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.vAlign=this.cellVAlign;td.style.paddingBottom=3;if(this.buttonCellClass){td.className=this.buttonCellClass;}

var rb=cE("input")
rb.type="radio";rb.value=option.value;option.radioEl=rb;aE(td,rb);var thisObj=this;var onclickFx=function(){if(option.onclickFx){option.onclickFx();}
;thisObj.selectOption(option);}
;eh_attachEvent("onclick",rb,onclickFx);var td=cE("td",tr);td.vAlign=this.cellVAlign
td.style.paddingLeft=2;if(this.labelClass){td.className=this.labelClass;}

else 
{td.style.fontSize="12px";td.style.fontFamily="arial";}

if(option.labelBuilderFx){option.labelBuilderFx(td);}

else if(option.label){td.innerHTML=option.label;}

}
;}
;
;
function ImageRotator(imagePath){this.imagePath=imagePath;this.clockwiseCnt=1;this.myName="ImageRotatorRec";this.setName=function(myName){this.myName=myName;return this;}
;this.setRotationCount=function(clockwiseCnt){this.clockwiseCnt=clockwiseCnt;return this;}
;this.rotate=function(afterProcessFx){return imageRotator_rotate(imagePath,this.clockwiseCnt,this.myName,afterProcessFx);}
;this.prepare=function(miniCache){return imageRotator_prepare(miniCache,imagePath,this.clockwiseCnt,this.myName);}
;this.extractResult=function(miniCache){return imageRotator_extractResult(miniCache,this.myName);}
;}

function imageRotator_rotate(imagePath,clockwiseCnt,actionName,afterProcessFx){var miniCache=new MiniCache();imageRotator_prepare(miniCache,imagePath,clockwiseCnt,actionName);if(null==afterProcessFx){miniCache.process();var resPath=imageRotator_extractResult(miniCache,actionName);return resPath;}

var afterFx=function(){var resPath=imageRotator_extractResult(miniCache,actionName);afterProcessFx(resPath);}
;miniCache.process(afterFx);}

function imageRotator_prepare(miniCache,imagePath,clockwiseCnt,actionName){var imgRotateGE=createGeneralExecuter(actionName,miniCache,"ImageRotator");var params=imgRotateGE.getChildField("exec_params");params.addChildField("image_path","TEXT").setValue(imagePath);if(null!=clockwiseCnt){params.addChildField("rotate_clockwise","INTEGER").setValue(clockwiseCnt);}

return imgRotateGE;}

function imageRotator_extractResult(miniCache,actionName){var imgRotateAction=miniCache.getActionField(actionName);if(null==imgRotateAction){return null;}

var result=imgRotateAction.data.exec_res;if(null==result){return null;}

return result.success;}


;;function ImageEditView(imageId,mc){this.imageId=imageId;this.mc=mc;this.imageWidth=350;this.imageHeight=350;this.showDelete=true;this.cancelFx;this.deleteFx;this.imageEl;this.docs=[document.body];this.onRotateFx;this.build=function(parentEl){var holder=cE("div",parentEl);holder.style.padding="15px";var record=this.mc.getRecord("image_library",this.imageId);var div=cE("div",holder);var image=cE("img",div);image.src=record.getField("file").getImagePath(this.imageWidth,this.imageHeight,true,"cover");this.imageEl=image;var div=cE("div",holder);div.style.marginTop="15px";this.buildFields(div,record);var div=cE("div",holder);div.style.marginTop="30px";this.buildButtons(div,record);}
;this.buildButtons=function(parentEl,record){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingLeft="100px";var thisObj=this;var fx=function(){thisObj.cancelFx();showProgressIcon();var finishFx=function(){hideProgressIcon();}
;thisObj.mc.process(finishFx);}
;var button=ButtonUtil.buildButton(td,"Save",fx,"medium");if(this.cancelFx){var thisObj=this;var fx=function(){thisObj.cancelFx();}
;var button=ButtonUtil.buildButton(td,"Cancel",fx,"medium");button.style.marginLeft="6px";}

var td=cE("td",tr);td.align="right";td.style.paddingLeft="50px";if(this.showDelete){this.buildDelete(td,record);}

}
;this.buildDelete=function(parentEl,record){var tBody=createTable(parentEl);var thisObj=this;var onclickFx=function(){showProgressIcon("deleting...");thisObj.mc.deleteRecord("image_library",record.getId());var afterFx=function(){thisObj.deleteFx();hideProgressIcon();}
;thisObj.mc.process(afterFx);}
;eh_attachEvent("onclick",tBody.parentNode,onclickFx);var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";var image=cE("img",td);image.src="/upload/custom_screens/architect/imagelibrary/x_icon.gif";image.style.cursor="pointer";image.style.marginRight="5px";var td=cE("td",tr);td.align="right";td.style.paddingRight="15px";var span=cE("nobr",td);span.style.color="#006699";span.className="il_text";span.innerHTML="Delete";addUnderlineEvents(span,"main");}
;this.buildFields=function(parentEl,record){var tBody=createTable(parentEl);tBody.className="il_text";var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";td.style.paddingRight="10px";td.className="il_boldText";td.innerHTML="Title";var td=cE("td",tr);var props={style:{width:"250px"}
,shadowText:"Enter Title"}
;record.getField("name").buildField(td,"edit",props);var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";td.style.padding="10px 10px 0 0";td.className="il_boldText";td.innerHTML="Date Uploaded";var dateObj=record.getField("created_on.date_time").getValue().date;var td=cE("td",tr);td.style.paddingTop="10px";td.innerHTML=dateObj.getString([ADateUtil.DAY_STR,", ",ADateUtil.MONTH_STR,", ",ADateUtil.DATE,", ",ADateUtil.YEAR]);var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";td.style.padding="10px 10px 0 0";td.className="il_boldText";td.innerHTML="Uploaded By";var td=cE("td",tr);td.style.paddingTop="10px";td.innerHTML=record.getField("created_by.user_name").getValue();var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";td.style.padding="10px 10px 0 0";td.className="il_boldText";td.innerHTML="Rotate";var td=cE("td",tr);td.className="il_linkColor il_text";td.style.paddingTop="10px";var thisObj=this;var div=cE("div",td);div.style.marginBottom="3px";var span=cE("span",div);span.innerHTML="Counter-Clockwise";var fx=function(){thisObj.rotateImage(3);}
;ButtonUtil.turnIntoButton(span,fx,true);var div=cE("div",td);div.style.marginBottom="3px";var span=cE("span",div);span.innerHTML="Flip Upside-down";var fx=function(){thisObj.rotateImage(2);}
;ButtonUtil.turnIntoButton(span,fx,true);var div=cE("div",td);div.style.marginBottom="3px";var span=cE("span",div);span.innerHTML="Clockwise";var fx=function(){thisObj.rotateImage(1);}
;ButtonUtil.turnIntoButton(span,fx,true);}

this.getImageEls=function(){var els=[];var path=this.mc.getRecord("image_library",this.imageId).getField("file.full_path").getValue();path=ImageUtil.getUrlWithNoParams(path);for(var i=0;i<this.docs.length;i++)
{var aDoc=this.docs[i];var images=document.body.getElementsByTagName("IMG");for(var j=0;j<images.length;j++)
{if(images[j].src.indexOf(path)!=-1){els.push(images[j]);}

}

}

return els;}
;this.rotateImage=function(rotateCount){var fileField=this.mc.getRecord("image_library",this.imageId).getField("file");var rValue=fileField.incrementRotation(rotateCount);var images=this.getImageEls();var params={r:rValue}
;for(var i=0;i<images.length;i++)
{ImageUtil.changeImageEl(images[i],params);}

this.mc.process();}
;}


;var ImageUtil=new ImageUtilBase();function ImageUtilBase(){
this.getImagePath=function(imageEl,params){var cleanSrc=this.getUrlWithNoParams(imageEl.src);return cleanSrc+"?"+ImageUtil.createQueryString(params);}
;this.optmize=function(imageEl){var params={f:"cover",u:true}
;var cssWidth=imageEl.style.width;if(cssWidth){params["w"]=CssUtil.pixelToInt(cssWidth);}

var cssHeight=imageEl.style.height;if(cssHeight){params["h"]=CssUtil.pixelToInt(cssHeight);}

var path=this.getImagePath(imageEl,params);imageEl.src=path;imageEl.style.width="";imageEl.style.height="";}
;this.changeImageEl=function(imageEl,paramsToUpate,paramsToRemove){var originalSrc=imageEl.src;var params=this.parseQueryString(originalSrc);for(var i in paramsToUpate)
{params[i]=paramsToUpate[i];}

for(var i in paramsToRemove)
{delete(params[paramsToRemove[i]]);}

var cleanSrc=this.getUrlWithNoParams(originalSrc);var newSrc=cleanSrc+"?"+this.createQueryString(params);if(originalSrc!=newSrc){imageEl.src=newSrc;}

}
;this.changeImagePath=function(imagePath,paramsToUpate,paramsToRemove){var params=this.parseQueryString(imagePath);for(var i in paramsToUpate)
{params[i]=paramsToUpate[i];}

for(var i in paramsToRemove)
{delete(params[paramsToRemove[i]]);}

var cleanSrc=this.getUrlWithNoParams(imagePath);var newSrc=cleanSrc+"?"+this.createQueryString(params);return newSrc;}
;this.getExtension=function(url){var cleanUrl=this.getUrlWithNoParams(url);var start=cleanUrl.lastIndexOf(".");var ext=cleanUrl.substring(start+1);return ext.toLowerCase();}
;
this.getUrlWithNoParams=function(url){var end=url.indexOf("?");if(-1==end){return url;}

else 
{return url.substring(0,end);}

}

this.parseQueryString=function(url){var params={}
;var start=url.indexOf("?");if(-1==start){return params;}

var qS=url.substring(start+1);var keyValues=qS.split("&");for(var i=0;i<keyValues.length;i++)
{var kV=keyValues[i];if(""==kV){continue;}

var data=kV.split("=");params[data[0]]=data[1];}

return params;}
;this.createQueryString=function(params){var str="";for(var i in params)
{str+=i+"="+params[i]+"&";}

return str;}
;this.loadByPath=function(path,mc,afterFx){path=this.getRelativePath(path);var listInput=createListInput("image_library","image_finder",0,1);listInput.addSearchTerm("file",path,SEARCHTERM_BEGINS_WITH);mc.addListInput(listInput);var thisObj=this;var fx=function(){var list=mc.getListByName("image_finder");var record=list.getFirstRecord();afterFx(record);}
;mc.process(fx);}
;this.getRelativePath=function(path){var start=path.indexOf("/upload/");if(start==-1){return null;}

var end=path.indexOf("?");if(end==-1){end=null;}

return path.substring(start,end);}
;
}

;;
function ImageEditorPopup(imageEl,title){this.imageEl=imageEl;this.cloneImageEl=imageEl.cloneNode(true);this.mc=new MiniCache();this.popup;this.title=title;this.disablePreselect;this.sizeRadio;this.alignRadio;this.sizes={thumbnail:80,small:140,medium:250,large:400}
;this.build=function(){var lpPopup=new LpPopup();lpPopup.title="Image Settings";lpPopup.width=613;var popup=lpPopup.popup;this.popup=popup;var contentArea=lpPopup.build();contentArea.style.padding="20px";this.cA=contentArea;this.initCss();this.buildSizeSettings(contentArea);this.buildAlignment(contentArea);var div=cE("div",contentArea);this.marginHolder=div;this.buildMargins();this.buildAltTextInput(contentArea);this.buildLinkSettings(contentArea);LpPopupUtil.buildDivider(contentArea);this.buildButtons(contentArea);popup.setFrameHeight(590);popup.center();}
;this.buildLinkSettings=function(parentEl){var holder=this.linkSettingsEl;if(holder){holder.innerHTML="";}

else 
{holder=cE("div",parentEl);this.linkSettingsEl=holder;}

var contentHolder=LpPopupUtil.buildContentSection(holder,"Linking");var imgParent=this.imageEl.parentElement;if("a"==imgParent.tagName.toLowerCase()){this.setRemoveLink(contentHolder,imgParent.href);}

else 
{this.setInsertLink(contentHolder);}

}
;this.setInsertLink=function(parentEl,elToTransform){var div=cE("div",parentEl);var b=cE("button",div);b.className="lp_darkButton";b.innerHTML="link image";var thisObj=this;var fx=function(){var orgImgEl=thisObj.imageEl;var pE=orgImgEl.parentElement;var imgClone=orgImgEl.cloneNode(true);var linkEl=cE("a");aE(linkEl,imgClone);pE.replaceChild(linkEl,orgImgEl);var linkPopup=new LinkPopup(linkEl);linkPopup.onLink=function(linkEl){thisObj.imageEl=imgClone;thisObj.buildLinkSettings();}
;linkPopup.onCancel=function(){pE.replaceChild(orgImgEl,linkEl);}
;linkPopup.build();}
;E.click(b,fx);}
;this.setRemoveLink=function(parentEl){var div=cE("div",parentEl);var b=cE("button",div);b.className="lp_darkButton";b.innerHTML="unlink image";var thisObj=this;var fx=function(){var imgEl=thisObj.imageEl;var parentRoot=imageEl.parentElement.parentElement;parentRoot.replaceChild(imgEl,imgEl.parentElement);thisObj.buildLinkSettings();}
;E.click(b,fx);}
;this.buildButtons=function(parentEl){var div=cE("div",parentEl);div.align="center";div.style.marginTop="15px";div.style.width="100%";var thisObj=this;var doneFx=function(){var imageEl=thisObj.imageEl;LivePage.setElementToSave(imageEl);thisObj.popup.close();}
;var cancelFx=function(){thisObj.imageEl.parentNode.replaceChild(thisObj.cloneImageEl,thisObj.imageEl);thisObj.popup.close();}
;LpPopupUtil.buildButtonSection(div,"Done",doneFx,"Close",cancelFx);}
;this.buildMargins=function(){var parentEl=this.marginHolder;parentEl.innerHTML="";var contentHolder=LpPopupUtil.buildContentSection(parentEl,"Padding");var tBody=createTable(contentHolder,"100%","100%");var tr=cE("tr",tBody);var td=cE("td",tr);var div=cE("div",td);this.buildMarginInfo(div);}
;this.buildMarginInfo=function(parentEl){var paddingValue="0 5px 0 6px";var tBody=createTable(parentEl);tBody.parentNode.style.margin="8px 0px 10px 6px";var tr=cE("tr",tBody);var thisObj=this;if(this.alignment!="center"){var td=cE("td",tr);td.innerHTML="Left";var td=cE("td",tr);td.style.padding=paddingValue;var thisObj=this;var props={style:{width:"30px"}
,defaultToZero:true}
;props.onAfterChangeFx=function(value){thisObj.imageEl.style.marginLeft=value+"px";}
;props.value=CssUtil.pixelToInt(this.imageEl.style.marginLeft);buildNumberInput(td,props);var td=cE("td",tr);td.style.paddingRight="25px";td.innerHTML="px";var td=cE("td",tr);td.innerHTML="Right";var td=cE("td",tr);td.style.padding=paddingValue;var props={style:{width:30}
,defaultToZero:true}
;props.onAfterChangeFx=function(value){thisObj.imageEl.style.marginRight=value+"px";}
;props.value=CssUtil.pixelToInt(this.imageEl.style.marginRight);buildNumberInput(td,props);var td=cE("td",tr);td.style.paddingRight="25px";td.innerHTML="px";}

var td=cE("td",tr);td.innerHTML="Top";var td=cE("td",tr);td.style.padding=paddingValue;var props={style:{width:30}
,defaultToZero:true}
;props.onAfterChangeFx=function(value){thisObj.imageEl.style.marginTop=value+"px";}
;props.value=CssUtil.pixelToInt(this.imageEl.style.marginTop);buildNumberInput(td,props);var td=cE("td",tr);td.style.paddingRight="25px";td.innerHTML="px";var td=cE("td",tr);td.innerHTML="Bottom";var td=cE("td",tr);td.style.padding=paddingValue;var props={style:{width:30}
,defaultToZero:true}
;props.onAfterChangeFx=function(value){thisObj.imageEl.style.marginBottom=value+"px";}
;props.value=CssUtil.pixelToInt(this.imageEl.style.marginBottom);buildNumberInput(td,props);var td=cE("td",tr);td.style.paddingRight="25px";td.innerHTML="px";}
;this.buildAlignment=function(parentEl){var imgEl=this.imageEl;var alignment=imgEl.style.cssFloat;this.alignment=alignment;var contentHolder=LpPopupUtil.buildContentSection(parentEl,"Image Alignment");var radio=new RadioButton();this.alignRadio=radio;var thisObj=this;radio.onChange=function(value){imgEl.align="";imgEl.style.margin="0px";CssUtil.setFloat(thisObj.imageEl,"");if("left"==value||"right"==value){CssUtil.setFloat(imgEl,value);imgEl.style.marginLeft=("right"==value)?"8px":"0px";imgEl.style.marginRight=("right"==value)?"0px":"8px";}

else if("center"==value){imgEl.style.display="block";imgEl.style.marginLeft="auto";imgEl.style.marginRight="auto";imgEl.style.marginBottom="8px";imgEl.style.marginTop="8px";}

thisObj.alignment=value;thisObj.buildMargins();}
;radio.layout="horizontal";var rbHolder=cE("div",contentHolder);rbHolder.className="esp_rbHolder";this.addRadioOption(radio,"left")
this.addRadioOption(radio,"right")
this.addRadioOption(radio,"center")
radio.build(rbHolder,alignment);}
;this.addRadioOption=function(radio,positionStr){var builderFx=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody)
var td=cE("td",tr)
var img=cE("img",td)
img.src="/upload/custom_screens/html5/livepage/image_"+positionStr+".png";var td=cE("td",tr)
td.vAlign="top"
td.style.padding="0px 20px 0px 5px";var position=positionStr.charAt(0).toUpperCase()+positionStr.slice(1);td.innerHTML=position;}
;radio.addDynamicOption(positionStr,builderFx);}
;this.getSizeChoice=function(){if(-1==this.imageEl.src.indexOf("?")){return "original";}

var height=this.imageEl.offsetHeight;for(var i in this.sizes)
{if(height==this.sizes[i]){return i;}

}

return "custom";}
;this.resizeImage=function(value){this.imageEl.removeAttribute("width",true);this.imageEl.removeAttribute("height",true);this.imageEl.style.width="";this.imageEl.style.height="";var params=ImageUtil.parseQueryString(this.imageEl.src);if("original"==value){var paramsToRemove=["w","h","u","f"];ImageUtil.changeImageEl(this.imageEl,null,paramsToRemove);}

else if("custom"==value){var width=parseInt(this.widthInput.value);var height=parseInt(this.heightInput.value);if(width>0&&height>0){params["w"]=width;params["h"]=height;ImageUtil.changeImageEl(this.imageEl,params);}

}

else 
{var height=this.sizes[value];delete(params["w"]);params["h"]=height;params["u"]=true;ImageUtil.changeImageEl(this.imageEl,params);}

}
;this.buildSizeSettings=function(parentEl){var contentHolder=LpPopupUtil.buildContentSection(parentEl,"Image Size");var divC=cE("div",contentHolder);divC.style.cssFloat="left";divC.style.width="100%";divC.style.padding="10px 0px";var tBody=createTable(divC,"100%","100%");var radio=new RadioButton();this.sizeRadio=radio;radio.layout="custom";radio.buttonCellClass="radioButtonCell";var thisObj=this;radio.onChange=function(value){thisObj.resizeImage(value);}
;var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingBottom="10px";td.colSpan="4";radio.addOption("Original","original",td);var tr=cE("tr",tBody);var td=cE("td",tr)
td.style.paddingBottom="10px";var tableOpt=createTable(td)
var tr=cE("tr",tableOpt)
var td1=cE("td",tr);td1.style.paddingRight="20px";radio.addOption("Thumbnail","thumbnail",td1);var td2=cE("td",tr);td2.style.paddingRight="20px";radio.addOption("Small","small",td2);var td3=cE("td",tr);td3.style.paddingRight="20px";radio.addOption("Medium","medium",td3);var td4=cE("td",tr);td4.style.paddingRight="20px";radio.addOption("Large","large",td4);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingBottom="15px";var labelBuilderFx=function(parentEl){var tBody=createTable(parentEl);tBody.className="text";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="4px";td.innerHTML="Custom"
var td=cE("td",tr);var props={style:{width:"40px"}
}
;if(!thisObj.disablePreselect){props.value=thisObj.imageEl.offsetWidth;}

props.onAfterChangeFx=function(newWidth){var newHeight=Math.round((thisObj.imageEl.offsetHeight*newWidth)/thisObj.imageEl.offsetWidth);thisObj.heightInput.value=newHeight;if("custom"!=radio.getValue()){radio.selectValue("custom");}

thisObj.resizeImage("custom");}
;thisObj.widthInput=buildNumberInput(td,props);var td=cE("td",tr);td.style.padding="0 4px 0 4px";td.innerHTML="by";var td=cE("td",tr);var props={style:{width:"40px"}
}
;if(!thisObj.disablePreselect){props.value=thisObj.imageEl.offsetHeight;}

props.onAfterChangeFx=function(newHeight){var newWidth=Math.round((thisObj.imageEl.offsetWidth*newHeight)/thisObj.imageEl.offsetHeight);thisObj.widthInput.value=newWidth;if("custom"!=radio.getValue()){radio.selectValue("custom");}

thisObj.resizeImage("custom");}
;thisObj.heightInput=buildNumberInput(td,props);var td=cE("td",tr);td.style.paddingLeft="4px";td.innerHTML="pixels";}
;radio.addDynamicOption("custom",labelBuilderFx,td);var selection=thisObj.disablePreselect?null:this.getSizeChoice();radio.build(divC,selection);}
;this.buildAltTextInput=function(parentEl){var imgEl=this.imageEl;var contentHolder=LpPopupUtil.buildContentSection(parentEl,"Alt Text");var divC=cE("div",contentHolder);divC.style.padding="10px 0px";var tBody=createTable(divC,"100%","100%");var tr=cE("tr",tBody);var td=cE("td",tr);var input=cE("input",td)
input.style.width="210px";input.value=(imgEl.alt)?imgEl.alt:"";var fx=function(){var altVal=input.value;if(altVal!=""||altVal!=null){imgEl.alt=altVal;imgEl.title=altVal;}

}
;E.change(input,fx)
}
;this.initCss=function(){var doc=this.doc;var cssClass=new CssClass(".esp_rbHolder")
cssClass.add("padding-top","10px");cssClass.init(doc);var cssClass=new CssClass(".esp_rbHolder td");cssClass.add("vertical-align","top");cssClass.init(doc);}
;}

function ThirdPartyPopup(containerEl){this.containerEl=containerEl;this.isReplace=false;this.placeHolder;this.build=function(){var lpPopup=new LpPopup();lpPopup.width=582;lpPopup.title="Third Party Content";this.popup=lpPopup.popup;var cA=lpPopup.build();cA.className="tpp_contentArea";this.doc=cA.ownerDocument;this.initCss();cA.className="tpp_contentArea";this.buildContentArea(cA);this.popup.setFrameHeight(360);this.popup.center();}
;
this.buildContentArea=function(parentEl){var holder=cE("div",parentEl);var div=cE("div",holder);div.className="tpp_descHolder";div.innerHTML="You can embed third party content such as Google Maps, Google Calendar, YouTube video, ";div.innerHTML+="Vimeo video on your page simply by copying and pasting the iframe code into the box below.";var div=cE("div",holder);div.className="tpp_linkHolder";div.innerHTML="View embed instructions for: ";this.buildLinks(div);var div=cE("div",holder);div.className="tpp_labelHolder";div.innerHTML="Insert iframe code:";var div=cE("div",holder);div.className="tpp_taHolder";var props={style:{width:486,height:150}
}
;props.onAfterChangeFx=function(){
}
;var textArea=buildTextArea(div,props);this.textArea=textArea;var div=cE("div",holder);var thisObj=this;var onClick=function(){var taValue=thisObj.textArea.value;if(taValue.trim()==""||taValue.indexOf("iframe")<0){alert("Please paste code to embed.");return ;}

thisObj.embedContent();}
;var button=cb(div,"Embed",onClick);button.className="lp_darkButton";}
;
this.buildLinks=function(parentEl){var linksData=[];linksData.push({display:"Google Maps",href:"http://support.google.com/maps/bin/answer.py?hl=en&answer=72644"}
);linksData.push({display:"Google Calendar",href:"https://support.google.com/calendar/answer/41207?hl=en"}
);linksData.push({display:"YouTube",href:"http://support.google.com/youtube/bin/answer.py?hl=en&answer=171780"}
);linksData.push({display:"Vimeo",href:"http://vimeo.com/help/faq/embedding"}
);for(var i=0;i<linksData.length;i++)
{if(i>0){var span=cE("span",parentEl);span.innerHTML=", ";}

var link=linksData[i];var anchor=cE("a",parentEl);anchor.href=link.href;anchor.target="_blank";anchor.innerHTML=link.display;}

}
;
this.embedContent=function(){this.popup.close();var frameHolder=this.containerEl||cE("div");frameHolder.innerHTML=this.textArea.value;this.editLinks(frameHolder);if(this.containerEl){LivePage.setElementToSave(frameHolder);}

else 
{this.insertContent(frameHolder);}

}
;
this.insertContent=function(frameHolder){frameHolder.style.width="100%";frameHolder.style.height="100%";var iFrame=frameHolder.getElementsByTagName("iframe")[0];iFrame.width="100%";var block=null;if(null==this.containerEl){var range=EditUtil.getRange();RangeUtil.selectRange(range);RangeUtil.insertNode(range,iFrame);block=getAncestorByStyle(iFrame,"display","block");}

var newBlock=(null!=block)?cE("div",block):iE("div",this.containerEl,0);this.setFrameHeight(newBlock,iFrame);newBlock.innerHTML=frameHolder.innerHTML;if(null!=this.containerEl){BlockHandler.initBlock(newBlock);LivePage.setElementToSave(newBlock);}

}
;
this.setFrameHeight=function(parentEl,iFrame){var parentWidth=parentEl.offsetWidth;var orgWidth=this.originalWidth;var orgHeight=this.originalHeight;if(!isNaN(orgWidth)&&!isNaN(orgHeight)){var percent=(orgHeight*100)/orgWidth;var ratio=orgWidth/orgHeight;iFrame.height=parentWidth/ratio;}

}
;this.editLinks=function(frameHolder){var links=frameHolder.getElementsByTagName("a");if(links.length==0){return ;}

var noHref=window.location.href+"#";for(var i=0;i<links.length;i++)
{var linkEl=links[i];var hrefValue=gA(linkEl,"href");if(hrefValue){sA(linkEl,"a_href",hrefValue);sA(linkEl,"href","");}

var target=gA(linkEl,"target");if(null==target){sA(linkEl,"target","_blank");}

}

}
;this.initCss=function(){var doc=this.doc;var cC=new CssClass(".tpp_mainArea");cC.add("height","350px");cC.init();var cC=new CssClass(".tpp_contentArea");cC.add("padding","25px 0px 25px 25px");cC.add("font","12px arial");cC.add("width","500px");cC.init(doc);var cC=new CssClass(".tpp_descHolder");cC.add("height","55px");cC.init(doc);var cC=new CssClass(".tpp_linkHolder");cC.add("height","35px");cC.init(doc);var cC=new CssClass(".tpp_linkHolder a");cC.add("font","bold 12px arial");cC.add("color","#0099cc");cC.add("text-decoration","none");cC.init(doc);var cC=new CssClass(".tpp_linkHolder a:hover");cC.add("text-decoration","underline");cC.init(doc);var cC=new CssClass(".tpp_labelHolder");cC.add("margin","0px 0px 7px 2px");cC.init(doc);var cC=new CssClass(".tpp_taHolder");cC.add("margin","0px 0px 12px 0px");cC.init(doc);}
;}
;
;function PlaceHolderHandler(){this.build=function(placeHolderEl){var orgElement=LivePage.placeHolders[placeHolderEl.id];var popup=new ThirdPartyPopup();popup.isReplace=true;popup.placeHolder=placeHolderEl;popup.build();}
;}



function SizeSelector(dimension,element){this.dimension=dimension;this.element=element;}

SizeSelector.prototype=new SizeSelectorBase();function SizeSelectorBase(){this.build=function(parentEl){var selection=this.initializeSelection();var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);var selectEl=cE("select",td);var options=[];options.push({name:"Full "+this.dimension,value:"full"}
);options.push({name:"Size to content",value:"size_to_content"}
);options.push({name:"Pixels",value:"pixels"}
);options.push({name:"Percent",value:"percent"}
);for(var i=0;i<options.length;i++)
{var optionData=options[i];var option=cE("option",selectEl);option.innerHTML=optionData.name
option.value=optionData.value;if(selection==optionData.value){option.selected=true;}

}

this.attachSelectOnChange(selectEl);var td=cE("td",tr);td.style.paddingLeft="6px";this.inputCell=td;if(selection=="pixels"||selection=="percent"){this.buildInput(selection);}

}
;
this.initializeSelection=function(){var initialValue=this.element.style[this.dimension];this.initialValue=initialValue;if(!initialValue){return "size_to_content";}

if("100%"==initialValue){return "full";}

if(initialValue.charAt(initialValue.length-1)=="%"){return "percent";}

return "pixels";}
;
this.attachSelectOnChange=function(selectEl){var thisObj=this;var onChange=function(option){var option=selectEl.options[selectEl.selectedIndex];thisObj.inputCell.innerHTML="";var selection=option.value;if("size_to_content"==selection){thisObj.setValue("");}

else if("full"==selection){thisObj.setValue("100%");}

else 
{thisObj.buildInput(selection);}
;}
;E.add(selectEl,"change",onChange);}
;
this.buildInput=function(selection){var thisObj=this;var fx=function(value){if("percent"==selection){value+="%";}

else 
{value+="px";}

thisObj.setValue(value);}
;var inputValue=""
if(selection=="percent"){inputValue=this.initialValue.substring(0,this.initialValue.length-1);}

else if(selection=="pixels"){inputValue=css_pixelToInt(this.initialValue);}

var properties={value:inputValue,onAfterChangeFx:fx,style:{width:50}
}
;buildNumberInput(this.inputCell,properties);}
;this.setValue=function(value){if(this.onValueChange){this.onValueChange();}

this.element.style[this.dimension]=value;}
;}


var HtmlDtd=new HtmlDtdDef();function HtmlDtdDef(){this.isATag=function(tagName){return atags[tagName.toUpperCase()]?true:false;}
;this.isEmptyTag=function(tagName){return emptyTags[tagName.toLowerCase()]?true:false;}

this.isNotEmptyTag=function(tagName){return !this.isEmptyTag(tagName)&&this.isValidTag(tagName);}

this.isValidTag=function(tagName){if(!tagName){}

return tags[tagName.toUpperCase()]?true:false;}

this.getAttributes=function(tagName){return clone(tags[tagName]);}

var emptyTags={area:1,base:1,br:1,col:1,hr:1,img:1,input:1,link:1,meta:1,param:1}
;var atags={}
;this.atags=atags;atags["A_COMPONENT"]=[];atags["A_CYCLE"]=[];atags["A_CRITERIA"]=[];atags["A_FIELD"]=[];atags["A_LIST"]=[];atags["A_MODULE"]=[];atags["A_NAV"]=[];var tags={}
;this.tags=tags;
tags["A"]=["href","tabIndex"];tags["ABBR"]=[];tags["ACRONYM"]=[];tags["ADDRESS"]=[];tags["APPLET"]=[];tags["AREA"]=[];tags["B"]=[];tags["BASE"]=[];tags["BASEFONT"]=[];tags["BDO"]=[];tags["BIG"]=[];tags["BLOCKQUOTE"]=[];tags["BODY"]=["topMargin","rightMargin","bottomMargin","leftMargin"];tags["BR"]=[];tags["BUTTON"]=["tabIndex"];tags["CAPTION"]=[];tags["CENTER"]=[];tags["CITE"]=[];tags["CODE"]=[];tags["COL"]=["align","vAlign"];tags["COLGROUP"]=[];tags["DD"]=[];tags["DEL"]=[];tags["DFN"]=[];tags["DIR"]=[];tags["DIV"]=["align"];tags["DL"]=[];tags["DT"]=[];tags["EM"]=[];tags["FIELDSET"]=[];tags["FONT"]=[];tags["FORM"]=[];tags["FRAME"]=[];tags["FRAMESET"]=[];tags["H1"]=[];tags["H2"]=[];tags["H3"]=[];tags["H4"]=[];tags["H5"]=[];tags["H6"]=[];tags["HEAD"]=[];tags["HR"]=[];tags["HTML"]=[];tags["I"]=[];tags["IFRAME"]=[];tags["IMG"]=["src","alt"];tags["INPUT"]=[];tags["INS"]=[];tags["ISINDEX"]=[];tags["KBD"]=[];tags["LABEL"]=[];tags["LEGEND"]=[];tags["LI"]=[];tags["LINK"]=[];tags["MAP"]=[];tags["MENU"]=[];tags["META"]=[];tags["NOFRAMES"]=[];tags["NOSCRIPT"]=[];tags["OBJECT"]=[];tags["OL"]=[];tags["OPTGROUP"]=[];tags["OPTION"]=[];tags["P"]=["align"];tags["PARAM"]=[];tags["PRE"]=[];tags["Q"]=[];tags["S"]=[];tags["SAMP"]=[];tags["SCRIPT"]=[];tags["SELECT"]=[];tags["SMALL"]=[];tags["SPAN"]=[];tags["STRIKE"]=[];tags["STRONG"]=[];tags["STYLE"]=[];tags["SUB"]=[];tags["SUP"]=[];tags["TABLE"]=["cellSpacing","cellPadding","border","summary"];tags["TBODY"]=[];tags["TD"]=["align","vAlign","colSpan","rowSpan"];tags["TEXTAREA"]=[];tags["TFOOT"]=[];tags["TH"]=[];tags["THEAD"]=[];tags["TITLE"]=[];tags["TR"]=[];tags["TT"]=[];tags["U"]=[];tags["UL"]=[];tags["VAR"]=[];tags["ARTICLE"]=[];tags["ASIDE"]=[];tags["BDI"]=[];tags["COMMAND"]=[];tags["DETAILS"]=[];tags["DIALOG"]=[];tags["SUMMARY"]=[];tags["FIGURE"]=[];tags["FIGCAPTION"]=[];tags["FOOTER"]=[];tags["HEADER"]=[];tags["HGROUP"]=[];tags["MARK"]=[];tags["METER"]=[];tags["NAV"]=[];tags["PROGRESS"]=[];tags["RUBY"]=[];tags["RT"]=[];tags["RP"]=[];tags["SECTION"]=[];tags["TIME"]=[];tags["WBR"]=[];}

function CssClass(selector,media){this.media=media;this.selector=selector;this.properties=[];}
;CssClass.prototype=new CssClassBase();function CssClassBase(){this.sheetsByMedia={}
;this.add=function(property,value){this.properties.push({property:property,value:value}
);}
;
this.init=function(doc){var styleSheet=this.getStyleSheet(doc);var rules=styleSheet.rules;var index=(rules!=null)?rules.length:0;var styleStr="";for(var i=0;i<this.properties.length;i++)
{styleStr+=this.properties[i].property+":"+this.properties[i].value+";"
}

var selectors=this.selector.split(",");for(var i=0;i<selectors.length;i++)
{var aSelector=selectors[i];try
{if(!styleSheet.insertRule){if(!this.media){styleSheet.addRule(aSelector,styleStr,index);}

}

else 
{var classStr="";if(this.media){classStr+="@media "+this.media+" {";}

classStr+=aSelector+"{"+styleStr+"}";if(this.media){classStr+="}";}

styleSheet.insertRule(classStr,index);}

index++;}

catch(e)
{debugger;}

}

}
;
this.getStyleSheet=function(doc){doc=doc||document;if(false&&this.media){if(this.sheetsByMedia[this.media]){return CssClass.prototype.sheetsByMedia[this.media];}

var properties={media:this.media}
;return StyleSheetUtil.createStyleSheet(doc);}

else 
{return StyleSheetUtil.getStyleSheet(doc);}

}
;}
;

;;function css_StyleSheet(aDocument){this.aDocument=!aDocument?document:aDocument;this.classes=[];this.addClass=function(ccsClassObj){this.classes[ccsClassObj.name]=ccsClassObj.styles;}

this.init=function(){css_buildStyleSheet(this)}
;}

function css_CssClass(name){this.name=name;this.styles=[];this.addStyle=function(name,value){this.styles[name]=value;}

}

function css_addRule(doc,className,styleStr,index){var styleSheet=StyleSheetUtil.getStyleSheet(doc);var selector=(HtmlDtd.isValidTag(className)||className.charAt(0)=='.'||className.charAt(0)=='#')?className:"."+className;var selectors=selector.split(",");for(var i=0;i<selectors.length;i++)
{var aSelector=selectors[i];try
{if(IS_IE){styleSheet.addRule(aSelector,styleStr,index);}

else 
{styleSheet.insertRule(aSelector+"{"+styleStr+"}",index);}

}

catch(e)
{}

}

}

function css_changeStyle(doc,className,property,value){var isUpdated=false;var rules=IS_IE?doc.styleSheets[0].rules:doc.styleSheets[0].cssRules;for(var i=0;i<rules.length;i++)
{if(rules[i].selectorText.toUpperCase()==className.toUpperCase()){try
{property=css_getJsProperty(property);rules[i].style[property]=value;isUpdated=true;}

catch(e)
{return false;}

}

}

if(!isUpdated){var styleSheet=new css_StyleSheet(doc);var cssClass=new css_CssClass(className);styleSheet.addClass(cssClass);cssClass.addStyle(property,value);styleSheet.init();}

return true;}

function css_pixelToInt(str){if(!str){return 0;}

var value=parseInt(str.substring(0,str.length-2));if(!value){return 0;}

return value;}

function css_getJsProperty(property){var index=property.indexOf("-");while(-1!=index)
{property=property.substring(0,index)+property.charAt(index+1).toUpperCase()+property.substring(index+2);index=property.indexOf("-");}

return property;}

function css_buildStyleSheet(thisObj){var classCounter=0
var classes=thisObj.classes;for(var className in classes)
{var styleStr=css_buildClass(classes[className]);css_addRule(thisObj.aDocument,className,styleStr,classCounter);classCounter++;}

}

function css_buildClass(styles){var styleStr="";for(var style in styles)
{styleStr+=style+":"+styles[style]+";"
}

return styleStr;}

function css_addClassToEl(element,classToAdd){var className=element.className;var classes=className.split(" ");for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(aClass&&aClass==classToAdd){return ;}

}

var newClassName=element.className+" "+classToAdd;newClassName=newClassName.trim();try
{element.className=newClassName;}

catch(e){}

}

function css_removeClassFromEl(element,classToRemove){var className=element.className;var classes=className.split(" ");var newClassName="";for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(aClass&&aClass!=classToRemove){newClassName+=aClass+"  ";}

}

newClassName=newClassName.trim();try
{element.className=newClassName;}

catch(e){}

}



if(!window["StyleSheetUtil"]){var StyleSheetUtil=new StyleSheetUtilBase();}

function StyleSheetUtilBase(){this.rootStyleSheet;this.idToPath={}
;this.clearIdToPath=function(){this.idToPath={}
;}
;this.getPath=function(styleSheetId){var path=this.idToPath[styleSheetId];if(path){return path;}

var current=new Date();var path="/0/"+styleSheetId+".css?"+current.getTime();this.idToPath[styleSheetId]=path;return path;}
;this.getStyleSheet=function(doc){if(!doc||document==doc){if(!this.rootStyleSheet){this.rootStyleSheet=this.createStyleSheet(doc);}

return this.rootStyleSheet;}

return this.createStyleSheet(doc);}
;this.createStyleSheet=function(doc,properties){doc=doc||document;var index=doc.styleSheets.length;var el=cE("style");el.rel="stylesheet";if(properties){for(var i in properties)
{el[i]=properties[i];}

}

var heads=doc.getElementsByTagName("head");aE(heads[0],el);var sS=doc.styleSheets[index];return sS;}
;this.enableSheetById=function(styleSheetId,afterFx){var linkEl=this.findSheetElById(styleSheetId);if(linkEl){linkEl.removeAttribute("disabled");if(afterFx){afterFx();}

}

else 
{this.appendSheetById(styleSheetId,afterFx);}

}
;this.disableSheetById=function(styleSheetId){var linkEl=this.findSheetElById(styleSheetId);if(linkEl){linkEl.disabled=true;}

}
;this.appendSheetById=function(styleSheetId,afterFx){var path=this.getPath(styleSheetId);this.appendStyleSheet(path,afterFx);}
;this.appendStyleSheet=function(path,afterFx){var headEl=document.getElementsByTagName('head')[0];var cssEl=document.createElement("link");cssEl.rel="stylesheet"
cssEl.href=path;cssEl.type="text/css";aE(headEl,cssEl);var fx=function(){var div=cE("div",document.body);document.body.removeChild(div);if(afterFx){afterFx();}

}
;E.add(cssEl,"load",fx);}
;this.removeSheetById=function(styleSheetId){var headEl=document.getElementsByTagName('head')[0];var links=headEl.getElementsByTagName("link");for(var i=links.length-1;i>=0;i--)
{var aLink=links[i];var href=aLink.href;if(!href){continue;}

var url=UrlUtil.getUrlWithNoParams(href);url=UrlUtil.removeOrigin(url);if(this.getRelativePath(styleSheetId)==url){aLink.parentElement.removeChild(aLink);break;}

}

}
;this.removeStyleSheet=function(path){var headEl=document.getElementsByTagName('head')[0];var links=headEl.getElementsByTagName("link");for(var i=links.length-1;i>=0;i--)
{var aLink=links[i];var href=aLink.href;if(!href){continue;}

var rPath=href.substring(window.location.origin.length);if(rPath.substring(0,path.length)==path){aLink.parentElement.removeChild(aLink);break;}

}

}
;this.findSheetElById=function(styleSheetId){var headEl=document.getElementsByTagName('head')[0];var links=headEl.getElementsByTagName("link");for(var i=links.length-1;i>=0;i--)
{var aLink=links[i];var href=aLink.href;if(!href){continue;}

var url=UrlUtil.getUrlWithNoParams(href);url=UrlUtil.removeOrigin(url);if(this.getRelativePath(styleSheetId)==url){return aLink;}

}

}
;this.getRelativePath=function(styleSheetId){return "/0/"+styleSheetId+".css";}
;}

;;;;if(!window["CssUtil"]){var CssUtil=new CssUtilBase();}

function CssUtilBase(){this.rootStyleSheet;this.isInit=false;this.getHighestZIndex=function(){return this.findHighestZIndex(document.body)+1;}
;this.findHighestZIndex=function(node){if(node.nodeType!=1){return 0;}

var count=node.childNodes.length;var zIndex=parseInt(CssUtil.getStyle(node,"z-index"));var value=isNaN(zIndex)?0:zIndex;for(var i=0;i<count;i++)
{value=Math.max(value,this.findHighestZIndex(node.childNodes[i]));}
;return value;}
;this.getZIndex=function(element){var z=parseInt(CssUtil.getStyle(element,"z-index"));return isNaN(z)?0:z;}
;this.makeNotSelectable=function(element){if(!this.isInit){this.initCss();this.isInit=true;}

this.addClassToEl(element,"notSelectable");}
;this.makeSelectable=function(element){this.removeClassFromEl(element,"notSelectable");}
;this.getNumberUnit=function(value){var index=value.length-1;var unit="";while(index>=0&&isNaN(parseInt(value.charAt(index))))
{unit=value.charAt(index)+unit;index--;}

return unit;}
;this.getNumberVal=function(value){if(!value){return 0;}

var unit=this.getNumberUnit(value);var number=parseFloat(value.substring(0,value.length-unit.length));return number||0;}
;this.getElementsByClassName=function(className,doc){if(null==doc){doc=document;}

var results=[];if(doc.body.getElementsByClassName){return doc.body.getElementsByClassName(className);}

else {var elements=document.all;for(var i=0;i<elements.length;i++)
{if(this.elHasClass(elements[i],className)){results.push(elements[i]);}

}

}

return results;}


this.getStyle=function(element,property){if(!element||element.nodeType==3||element.nodeType==8){return null;}

if(element.currentStyle){return element.currentStyle[property];}

else if(window&&window.getComputedStyle){var style=document.defaultView.getComputedStyle(element);if(!style){return null;}

return style.getPropertyValue(property);}

return "";}
;this.findStyle=function(node,property){if(node.nodeType==3){node=node.parentElement;}

return this.getStyle(node,property);}
;this.setFloat=function(element,value){var prop=BrowserUtil.isIE()?"styleFloat":"cssFloat";element.style[prop]=value;}
;this.getHtmlPropName=function(jsPropName){var parts=[];var partStart=0;for(var i=0;i<jsPropName.length;i++)
{var aChar=jsPropName.charAt(i);if(aChar>='A'&&aChar<='Z'){parts.push(jsPropName.substring(partStart,i));partStart=i;}

}

parts.push(jsPropName.substring(partStart));var propName=parts[0];for(var i=1;i<parts.length;i++)
{propName+="-"+parts[i];}

return propName.toLowerCase();}
;this.pixelToInt=function(str){var strSize=str.length;if(!strSize||(strSize<2)||str.charAt(strSize-2)!="p"||str.charAt(strSize-1)!="x"){return (str=="")?0:str;}

var value=parseInt(str.substring(0,str.length-2));if(!value){return 0;}

return value;}
;this.intToPixel=function(value){return (typeof(value)=="number")?value+"px":value;}
;this.getClasses=function(element,startingWith){var classStr=element.className;var classes=classStr.split(" ");if(!startingWith){if(classes[0]==""){classes.splice(0,1);}

return classes;}

var filtered=[];for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(!aClass){continue;}

if(startingWith==aClass.substring(0,startingWith.length)){filtered.push(aClass);}

}

return filtered;}
;this.elHasClass=function(element,className){var classStr=element.className;if(!classStr){return false;}

var classes=classStr.split(" ");for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(aClass&&aClass==className){return true;}

}

return false;}
;this.addClassToEl=function(element,classToAdd){var className=element.className;var classes=className.split(" ");for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(aClass&&aClass==classToAdd){return ;}

}

var newClassName=element.className+" "+classToAdd;newClassName=newClassName.trim();try
{element.className=newClassName;}

catch(e){}

}
;this.removeClassesStartingWith=function(element,startString){var rE=new RegExp("^"+startString);var className=element.className;var classes=className.split(" ");var newClassName="";for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(!aClass){continue;}

if(!rE.test(aClass)){newClassName+=aClass+" ";}



}

newClassName=newClassName.trim();try
{element.className=newClassName;}

catch(e){}

}
;this.removeClassFromEl=function(element,classToRemove){var className=element.className;var classes=className.split(" ");var newClassName="";for(var i=0;i<classes.length;i++)
{var aClass=classes[i];if(aClass&&aClass!=classToRemove){newClassName+=aClass+" ";}

}

newClassName=newClassName.trim();try
{element.className=newClassName;}

catch(e){}

}
;this.initCss=function(){var cls=new CssClass("notSelectable");cls.add("-moz-user-select","none");cls.add("-khtml-user-select","none");cls.add("-webkit-user-select","none");cls.add("user-select","none");cls.init();}
;}



var ANumberUtil=new ANumberUtilBase()
function ANumberUtilBase(){this.DS=".";this.TS=",";this.formatForDisplay=function(x,decimalPlaces){var decimals=this.occurence(x,this.DS);if(typeof(x)!='number'){var nonNumMatch=new RegExp("[^0-9-.,]","g");var illegalChars=x.match(nonNumMatch);if((null!=illegalChars)||(decimals>1)){return ""
}

}

if(decimalPlaces!=undefined){var decimalPlaces=parseInt(decimalPlaces,10);if(!isNaN(decimalPlaces)){x=this.ensureDecimalPlaces(x,decimalPlaces);}

else 
{x=Math.floor(x);}

}

return this.reformat(x);}
;this.reformat=function(x){if(x==0){return x
}

if(null==x||""==x){return "";}

var re=/(\-?)([^\.]*)\.?(\d*)/;var result=re.exec(x);var sign=result[1];var numberPart=result[2];var decimalPart=result[3];var newNumberPart="";var digitPlace=0;for(var i=numberPart.length-1;i>=0;i--)
{if(isNaN(parseInt(numberPart.charAt(i)))){continue;}

newNumberPart=numberPart.charAt(i)+newNumberPart;digitPlace++;if(digitPlace==3&&i!=0){newNumberPart=this.TS+newNumberPart;digitPlace=0;}

}

decimal=(decimalPart=="")?"":this.DS;return sign+newNumberPart+decimal+decimalPart;}
;this.occurence=function(aString,c){var total=0;for(var i=0;i<aString.length;i++)
{if(c==aString.charAt(i)){total++;}

}

return total;}

this.formatForStorage=function(numStr,isDecimal){numStr=numStr.replaceAll(this.DS,".");numStr=numStr.replaceAll(this.TS,"");var number;if(isDecimal){number=parseFloat(numStr,10);}

else 
{number=parseInt(numStr,10);}

return (isNaN(number))?"":number;}
;this.ensureDecimalPlaces=function(numberString,noOfDecimals){if(null==numberString||""==numberString){return ;}

var re=/(\-?)([^\.]*)\.?(\d*)/;var result=re.exec(numberString);var negativeSign=result[1];var numberPart=result[2];var decimalPart=result[3];var pureNumber=0;var digitPlace=0;for(var i=0;i<numberPart.length;i++)
{var thisNumber=parseInt(numberPart.charAt(i));if(!isNaN(thisNumber)){pureNumber=(10*pureNumber)+thisNumber;}

}

if(noOfDecimals==0){var number=parseFloat(pureNumber+"."+decimalPart);return Math.round(number);}

var orginalNoOfDecimals=decimalPart.length;var decimalNumber=parseInt(decimalPart,10);decimalNumber=(isNaN(decimalNumber))?0:decimalNumber;var allDigits=pureNumber*Math.pow(10,orginalNoOfDecimals)+decimalNumber;if(0==allDigits){var str="0"+this.DS;return this.addZeros(str,noOfDecimals);}

if(negativeSign!=null&&negativeSign!=""){allDigits*=-1;}

var numToRound=allDigits/(Math.pow(10,(orginalNoOfDecimals-noOfDecimals)));var rounded=Math.round(numToRound);var finalNumber=rounded/(Math.pow(10,noOfDecimals));var numberStr=""+finalNumber;var shouldBeLength=(""+rounded).length+1;var retVal;if(numberStr.length==(shouldBeLength-1-noOfDecimals)){retVal=numberStr+this.DS;retVal=this.addZeros(retVal,noOfDecimals);}

else if(shouldBeLength==numberStr.length){retVal=numberStr;}

else 
{var zerosToAdd=shouldBeLength-numberStr.length;retVal=this.addZeros(numberStr,zerosToAdd);}

return retVal;}
;this.addZeros=function(str,noOfZeros){for(var i=0;i<noOfZeros;i++)
{str+="0";}

return str;}
;}
;

;function buildNumberInput(parentEl,properties){var isNoComma=getProperty(properties,"isNoComma",false);var maxLength=getProperty(properties,"maxLength",100);var decimalPlaces=getProperty(properties,"decimalPlaces",null);;var isDecimal=(null!=decimalPlaces)?true:false;var displayName=getProperty(properties,"displayName","");var input=cE("input",parentEl);input.maxLength=maxLength;input.name=displayName;input.type="text";var value=getProperty(properties,"value","");if(value==0&&!getProperty(properties,"defaultToZero",false)){value="";}

input.value=(isNoComma)?value:ANumberUtil.formatForDisplay(value,decimalPlaces);var onAfterChangeFx=getProperty(properties,"onAfterChangeFx",null);var onChangeFx=function(){var value=input.value.trim();if(""!=value&&!isNoComma){input.value=ANumberUtil.formatForDisplay(input.value,decimalPlaces);}

value=ANumberUtil.formatForStorage(value,isDecimal);if(null!=onAfterChangeFx){onAfterChangeFx(value);}

}
;eh_attachEvent("onchange",input,onChangeFx);var validateKeyStroke=function(event){var isValidCharacter=KeyCodeUtil.isValidCharForNumber(event);if(!isValidCharacter){KeyCodeUtil.cancelPressKey(event);return null;}

}
;eh_attachEvent("onkeypress",input,validateKeyStroke);var validationHandler=getProperty(properties,"validationHandler",null);var isRequired=getProperty(properties,"isRequired",false);if(isRequired){var requiredVal=validationHandler.getValObject("REQUIRED")
if(null==requiredVal){requiredVal=new RequiredValidation(validationHandler);}

requiredVal.attachValidation(input);}

setStyles(input,properties);return input;}
;

var ColorsByName=new ColorsByNameBase();function ColorsByNameBase(){this.get=function(colorName){return this.colorsByName[colorName.toLowerCase()];}

this.colorsByName={}
;this.add=function(colorName,hexValue){this.colorsByName[colorName.toLowerCase()]=hexValue;}
;this.add("AliceBlue","#F0F8FF");this.add("AntiqueWhite","#FAEBD7");this.add("Aqua","#00FFFF");this.add("Aquamarine","#7FFFD4");this.add("Azure","#F0FFFF");this.add("Beige","#F5F5DC");this.add("Bisque","#FFE4C4");this.add("Black","#000000");this.add("BlanchedAlmond","#FFEBCD");this.add("Blue","#0000FF");this.add("BlueViolet","#8A2BE2");this.add("Brown","#A52A2A");this.add("BurlyWood","#DEB887");this.add("CadetBlue","#5F9EA0");this.add("Chartreuse","#7FFF00");this.add("Chocolate","#D2691E");this.add("Coral","#FF7F50");this.add("CornflowerBlue","#6495ED");this.add("Cornsilk","#FFF8DC");this.add("Crimson","#DC143C");this.add("Cyan","#00FFFF");this.add("DarkBlue","#00008B");this.add("DarkCyan","#008B8B");this.add("DarkGoldenRod","#B8860B");this.add("DarkGray","#A9A9A9");this.add("DarkGrey","#A9A9A9");this.add("DarkGreen","#006400");this.add("DarkKhaki","#BDB76B");this.add("DarkMagenta","#8B008B");this.add("DarkOliveGreen","#556B2F");this.add("Darkorange","#FF8C00");this.add("DarkOrchid","#9932CC");this.add("DarkRed","#8B0000");this.add("DarkSalmon","#E9967A");this.add("DarkSeaGreen","#8FBC8F");this.add("DarkSlateBlue","#483D8B");this.add("DarkSlateGray","#2F4F4F");this.add("DarkSlateGrey","#2F4F4F");this.add("DarkTurquoise","#00CED1");this.add("DarkViolet","#9400D3");this.add("DeepPink","#FF1493");this.add("DeepSkyBlue","#00BFFF");this.add("DimGray","#696969");this.add("DimGrey","#696969");this.add("DodgerBlue","#1E90FF");this.add("FireBrick","#B22222");this.add("FloralWhite","#FFFAF0");this.add("ForestGreen","#228B22");this.add("Fuchsia","#FF00FF");this.add("Gainsboro","#DCDCDC");this.add("GhostWhite","#F8F8FF");this.add("Gold","#FFD700");this.add("GoldenRod","#DAA520");this.add("Gray","#808080");this.add("Grey","#808080");this.add("Green","#008000");this.add("GreenYellow","#ADFF2F");this.add("HoneyDew","#F0FFF0");this.add("HotPink","#FF69B4");this.add("IndianRed ","#CD5C5C");this.add("Indigo ","#4B0082");this.add("Ivory","#FFFFF0");this.add("Khaki","#F0E68C");this.add("Lavender","#E6E6FA");this.add("LavenderBlush","#FFF0F5");this.add("LawnGreen","#7CFC00");this.add("LemonChiffon","#FFFACD");this.add("LightBlue","#ADD8E6");this.add("LightCoral","#F08080");this.add("LightCyan","#E0FFFF");this.add("LightGoldenRodYellow","#FAFAD2");this.add("LightGray","#D3D3D3");this.add("LightGrey","#D3D3D3");this.add("LightGreen","#90EE90");this.add("LightPink","#FFB6C1");this.add("LightSalmon","#FFA07A");this.add("LightSeaGreen","#20B2AA");this.add("LightSkyBlue","#87CEFA");this.add("LightSlateGray","#778899");this.add("LightSlateGrey","#778899");this.add("LightSteelBlue","#B0C4DE");this.add("LightYellow","#FFFFE0");this.add("Lime","#00FF00");this.add("LimeGreen","#32CD32");this.add("Linen","#FAF0E6");this.add("Magenta","#FF00FF");this.add("Maroon","#800000");this.add("MediumAquaMarine","#66CDAA");this.add("MediumBlue","#0000CD");this.add("MediumOrchid","#BA55D3");this.add("MediumPurple","#9370D8");this.add("MediumSeaGreen","#3CB371");this.add("MediumSlateBlue","#7B68EE");this.add("MediumSpringGreen","#00FA9A");this.add("MediumTurquoise","#48D1CC");this.add("MediumVioletRed","#C71585");this.add("MidnightBlue","#191970");this.add("MintCream","#F5FFFA");this.add("MistyRose","#FFE4E1");this.add("Moccasin","#FFE4B5");this.add("NavajoWhite","#FFDEAD");this.add("Navy","#000080");this.add("OldLace","#FDF5E6");this.add("Olive","#808000");this.add("OliveDrab","#6B8E23");this.add("Orange","#FFA500");this.add("OrangeRed","#FF4500");this.add("Orchid","#DA70D6");this.add("PaleGoldenRod","#EEE8AA");this.add("PaleGreen","#98FB98");this.add("PaleTurquoise","#AFEEEE");this.add("PaleVioletRed","#D87093");this.add("PapayaWhip","#FFEFD5");this.add("PeachPuff","#FFDAB9");this.add("Peru","#CD853F");this.add("Pink","#FFC0CB");this.add("Plum","#DDA0DD");this.add("PowderBlue","#B0E0E6");this.add("Purple","#800080");this.add("Red","#FF0000");this.add("RosyBrown","#BC8F8F");this.add("RoyalBlue","#4169E1");this.add("SaddleBrown","#8B4513");this.add("Salmon","#FA8072");this.add("SandyBrown","#F4A460");this.add("SeaGreen","#2E8B57");this.add("SeaShell","#FFF5EE");this.add("Sienna","#A0522D");this.add("Silver","#C0C0C0");this.add("SkyBlue","#87CEEB");this.add("SlateBlue","#6A5ACD");this.add("SlateGray","#708090");this.add("SlateGrey","#708090");this.add("Snow","#FFFAFA");this.add("SpringGreen","#00FF7F");this.add("SteelBlue","#4682B4");this.add("Tan","#D2B48C");this.add("Teal","#008080");this.add("Thistle","#D8BFD8");this.add("Tomato","#FF6347");this.add("Turquoise","#40E0D0");this.add("Violet","#EE82EE");this.add("Wheat","#F5DEB3");this.add("White","#FFFFFF");this.add("WhiteSmoke","#F5F5F5");this.add("Yellow","#FFFF00");this.add("YellowGreen","#9ACD32");}


;;;function CustomColorPicker(color,onChangeFx){this.color=ColorsByName.get(color)||color;this.fontClass="smallText";this.cellSide=3;this.rgbInputWidth="25px";this.colorInputWidth="50px";this.onChangeFx=onChangeFx;this.build=function(parentEl){this.initStyles();var color=this.color||"#FFFFFF";var rgb=this.hexToRgb(color);this.rgb=rgb;var hsb=this.rgbToHsb(rgb);this.hsb=hsb;this.buildStructure(parentEl);this.buildColorTableHsb(rgb,hsb);this.buildSlideTableHsb();this.updateArrow();}
;this.buildStructure=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingBottom="10px";this.buildSummary(td);var tr=cE("tr",tBody);var td=cE("td",tr);this.buildSlideStructure(td);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingTop="10px";this.buildRGBInputs(td);}
;this.buildSummary=function(parentEl){var tBody=createTable(parentEl);tBody.className=this.fontClass;var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="7px";td.innerHTML="<nobr>Selected Color:</nobr>";var td=cE("td",tr);td.align="left";this.buildColorPreview(td);}
;this.buildRGBInputs=function(parentEl){var tBody=createTable(parentEl);tBody.className=this.fontClass;var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingLeft=15;this.buildRDisplay(td);var td=cE("td",tr);td.style.paddingLeft="12px";this.buildGDisplay(td);var td=cE("td",tr);td.style.paddingLeft="12px";this.buildBDisplay(td);}
;this.buildColorPreview=function(parentEl){var div=cE("div",parentEl);div.style.border="1px solid black";div.style.width="45px";div.style.height="25px";this.displayHolder=div;this.updateDisplay();}
;this.buildSlideStructure=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);var tr=cE("tr",tBody);var td=cE("td",tr);td.vAlign="top";this.tableHolder=td;this.disableSelect(td);var td=cE("td",tr);td.style.width="10px";var td=cE("td",tr);this.sliderHolder=td;this.disableSelect(td);var td=cE("td",tr);td.style.width="10px";}
;this.rgb;this.hsb;this.sliderHolder;this.tableHolder;this.circleAdjLeft=-5;this.circleAdjTop=-5;this.sliderStep=2.4;this.buildRightSide=function(parentEl){var div=cE("div",parentEl);div.style.border="1px solid black";div.style.width="60px";div.style.height="70px";this.displayHolder=div;this.updateDisplay();var div=cE("div",parentEl);div.style.paddingTop="15px";var tBody=createTable(div);tBody.className=this.fontClass;tBody.parentNode.cellPadding=2;this.buildRDisplay(tBody);this.buildGDisplay(tBody);this.buildBDisplay(tBody);var div=cE("div",parentEl);div.style.position="relative";div.style.left="-5px";div.style.paddingTop="10px";this.buildColorStr(div);}
;this.disableSelect=function(element){if(IS_IE){var fx=function(){}
;eh_attachEvent("onselectstart",element,fx,null,true,null,true,false);}

else 
{element.style.mozUserSelect="none";element.style.webkitUserSelect="none";}

}
;this.changeRgbValue=function(rgb){var hex=this.rgbToHex(rgb);this.selectColor(hex,false,true);var hsb=this.rgbToHsb(rgb);this.buildColorTableHsb(rgb,hsb);}
;this.buildBDisplay=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.innerHTML="B";var td=cE("td",tr);td.style.paddingLeft="3px";var thisObj=this;var fx=function(value){value=thisObj.validateRgbValue(value);input.value=value;thisObj.rgb.b=value;thisObj.changeRgbValue(thisObj.rgb);}
;var props={style:{width:this.rgbInputWidth,fontSize:"11px"}
,value:this.rgb.b}
;props.onAfterChangeFx=fx;var input=buildNumberInput(td,props);input.className=this.fontClass;this.bInput=input;}
;this.buildGDisplay=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.className=this.fontClass;td.innerHTML="G";var td=cE("td",tr);td.style.paddingLeft="3px";var input;var thisObj=this;var fx=function(value){value=thisObj.validateRgbValue(value);input.value=value;thisObj.rgb.g=value;thisObj.changeRgbValue(thisObj.rgb);}
;var props={style:{width:this.rgbInputWidth,fontSize:"11px"}
,value:this.rgb.g}
;props.onAfterChangeFx=fx;var input=buildNumberInput(td,props);input.className=this.fontClass;this.gInput=input;}
;this.buildRDisplay=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.className=this.fontClass;td.innerHTML="R";var td=cE("td",tr);td.style.paddingLeft="3px";var thisObj=this;var fx=function(value){value=thisObj.validateRgbValue(value);input.value=value;thisObj.rgb.r=value;thisObj.changeRgbValue(thisObj.rgb);}
;var props={style:{width:this.rgbInputWidth,fontSize:"11px"}
,value:this.rgb.r}
;props.onAfterChangeFx=fx;var input=buildNumberInput(td,props);input.className=this.fontClass;this.rInput=input;}
;this.updateDisplay=function(){if(this.color){this.displayHolder.style.backgroundImage="";this.displayHolder.style.backgroundColor=this.color;}

else 
{this.displayHolder.style.backgroundImage="url(/upload/custom_screens/architect/components/colorpicker/transparent_bg.gif)";}

}
;this.buildColorTableHsb=function(rgb,hsb){parentEl=this.tableHolder;parentEl.innerHTML="";var holder=cE("div",parentEl);holder.style.border="1px solid black";var anchor=cE("div",holder);anchor.style.position="absolute";var picker=cE("img",anchor);picker.style.position="absolute";picker.src="/upload/custom_screens/components/colorpicker/picker.png";this.picker=picker;this.disableSelect(picker);var tBody=createTable(holder);var table=tBody.parentNode;table.style.tableLayout="fixed";this.slideTBody=tBody;var tdTemplate=cE("td");tdTemplate.style.width=this.cellSide+"px";tdTemplate.style.height=this.cellSide+"px";var foundMatch=false;var ymax=101;var ystep=2;var xstep=2;for(x=100;x>-1;x-=xstep)
{var myrow=cE("tr",tBody);aE(tBody,myrow);for(y=0;y<ymax;y+=ystep)
{var rgb=this.hsbToRgb(hsb.h,y,x);var td=tdTemplate.cloneNode(false);td.style.backgroundColor=this.rgbToHex(rgb);myrow.appendChild(td);var current=this.rgb;if(current.r==rgb.r&&current.g==rgb.g&&current.b==rgb.b){foundMatch=true;this.selectCell(td);}

}

}

if(!foundMatch){this.picker.style.display="none";}

var thisObj=this;var mouseDownFx=function(e){thisObj.picker.style.display="none";thisObj.onColorChoose(e);thisObj.tableCoord=findElCoord(table,true);thisObj.rightBound=table.offsetWidth-thisObj.cellSide;thisObj.bottomBound=table.offsetHeight-thisObj.cellSide;var body=table.ownerDocument.body;var moveFx=function(ev){crossbrowser_stopEvent(ev);thisObj.chooseCellFromEvent(ev);}
;eh_attachEvent("onmousemove",body,moveFx);var mouseUpFx=function(e){body.onmousemove=null;body.onmouseup=null;var cell=thisObj.chooseCellFromEvent(e);thisObj.selectCell(cell);thisObj.picker.style.display="";}
;eh_attachEvent("onmouseup",body,mouseUpFx);}
;eh_attachEvent("onmousedown",tBody,mouseDownFx);eh_clearEventsNotInDom();}
;this.chooseCellFromEvent=function(ev){var coord=this.tableCoord;var x=ev.clientX-coord.x;var y=ev.clientY-coord.y;var isInBox=true;if(x<2){x=2;isInBox=false;}

else if(x>this.rightBound){x=this.rightBound;isInBox=false;}

if(y<0){y=0;isInBox=false;}

else if(y>this.bottomBound){y=this.bottomBound;isInBox=false;}

var cell;if(isInBox){cell=ev.target||ev.srcElement;}

else 
{var yIndex=Math.floor(y/this.cellSide);var xIndex=Math.floor(x/this.cellSide);var cell=this.slideTBody.childNodes[yIndex].childNodes[xIndex];}

this.chooseCell(cell);return cell;}
;this.updateArrow=function(){
var syncArrowValue=this.hsb.h;this.leftArrow.style.top=(358-syncArrowValue)/this.sliderStep;this.rightArrow.style.top=(358-syncArrowValue)/this.sliderStep;}
;this.buildSlideTableHsb=function(){parentEl=this.sliderHolder;var syncArrowValue;var value1=100;var value2=100;syncArrowValue=this.hsb.h;var outerTBody=createTable(parentEl);var outerTable=outerTBody.parentNode;var outerTr=cE("tr",outerTBody);var outerTd=cE("td",outerTr);outerTd.vAlign="top";outerTd.style.width="7px";var anchor=cE("div",outerTd);anchor.style.position="absolute";var leftArrow=cE("img",anchor);leftArrow.src="/upload/custom_screens/components/colorpicker/sliderarrow_left.png";leftArrow.style.position="absolute";this.leftArrow=leftArrow;this.disableSelect(leftArrow);var outerTd=cE("td",outerTr);var tBody=createTable(outerTd);var table=tBody.parentNode;table.style.tableLayout="fixed";table.style.border="1px solid black";var colorBody=tBody;var outerTd=cE("td",outerTr);outerTd.vAlign="top";var anchor=cE("div",outerTd);anchor.style.position="absolute";var rightArrow=cE("img",anchor);rightArrow.src="/upload/custom_screens/components/colorpicker/sliderarrow_right.png";rightArrow.style.position="absolute";this.rightArrow=rightArrow;this.disableSelect(rightArrow);var xmax=360;var xstep=this.sliderStep;for(x=xmax;x>-1;x-=xstep)
{var rgb=this.hsbToRgb(x,value2,value1);if(!rgb){break;}

var tr=cE("tr",tBody);var td=cE("td",tr);td.style.width="15px";td.style.height="1px";td.style.backgroundColor=this.rgbToHex(rgb);}

var thisObj=this;var mouseDownFx=function(e){thisObj.sliderCoord=findElCoord(outerTable,true);thisObj.sliderHeight=outerTable.offsetHeight-1;thisObj.slide(e);var body=outerTBody.ownerDocument.body;var moveFx=function(e){crossbrowser_stopEvent(e);thisObj.slide(e);}
;eh_attachEvent("onmousemove",body,moveFx);var mouseUpFx=function(ev){body.onmousemove=null;body.onmouseup=null;var color=colorBody.childNodes[thisObj.slide(ev)].childNodes[0].style.backgroundColor;var rgb=thisObj.parseToRgb(color);var hsb=thisObj.rgbToHsb(rgb);thisObj.buildColorTableHsb(rgb,hsb);var newRgb=thisObj.hsbToRgb(hsb.h,thisObj.hsb.s,thisObj.hsb.b);var hex=thisObj.rgbToHex(newRgb);thisObj.selectColor(hex);}
;eh_attachEvent("onmouseup",body,mouseUpFx);}
;eh_attachEvent("onmousedown",outerTBody,mouseDownFx);}

this.slide=function(ev){var coord=this.sliderCoord;var y=ev.clientY-coord.y-5;if(y<-3){y=-3;}

else if(y>this.sliderHeight-5){y=this.sliderHeight-5;}

this.leftArrow.style.top=y+"px";this.rightArrow.style.top=y+"px";return y+3;}
;this.rgbToHex=function(rgb){return "#"+this.decToHex(rgb.r)+this.decToHex(rgb.g)+this.decToHex(rgb.b);}
;this.decToHex=function(decimal){var hexChars="0123456789ABCDEF";var a=decimal%16;var b=(decimal-a)/16;var hex=""+hexChars.charAt(b)+hexChars.charAt(a);return hex;}
;this.hsbToRgb=function(h,s,v){h=parseFloat(h/360);s=parseFloat(s/100);v=parseFloat(v/100);if(h>=1.0){h%=1.0;}

if(s>1.0){s=1.0;}

if(v>1.0){v=1.0;}

var tov=Math.floor(255*v);if(s==0.0){return {r:tov,g:tov,b:tov}
;}

else 
{h*=6.0;var i=Math.floor(h);var f=h-i;var p=Math.floor(tov*(1.0-s));var q=Math.floor(tov*(1.0-(s*f)));var t=Math.floor(tov*(1.0-(s*(1.0-f))));if(i==0){return {r:tov,g:t,b:p}
;}

if(i==1){return {r:q,g:tov,b:p}
;}

if(i==2){return {r:p,g:tov,b:t}
;}

if(i==3){return {r:p,g:q,b:tov}
;}

if(i==4){return {r:t,g:p,b:tov}
;}

if(i==5){return {r:tov,g:p,b:q}
;}

}

}
;this.hexToRgb=function(hex){var re=/#/gi;hex=hex.replace(re,"");var r=parseInt(hex.substr(0,2),16);var g=parseInt(hex.substr(2,2),16);var b=parseInt(hex.substr(4,2),16);return {r:r,g:g,b:b}
;}
;this.rgbToHsb=function(rgb){var r=parseInt(rgb.r);var g=parseInt(rgb.g);var b=parseInt(rgb.b);var hue;var saturation;var cmax=(r>g)?r:g;if(b>cmax){cmax=b;}

var cmin=(r<g)?r:g;if(b<cmin){cmin=b;}

var brightness=cmax/255.0;if(cmax!=0){saturation=(cmax-cmin)/cmax;}

else 
{saturation=0;}

if(saturation==0){hue=0;}

else 
{var redc=(cmax-r)/(cmax-cmin);var greenc=(cmax-g)/(cmax-cmin);var bluec=(cmax-b)/(cmax-cmin);if(r==cmax){hue=bluec-greenc;}

else if(g==cmax){hue=2.0+redc-bluec;}

else 
{hue=4.0+greenc-redc;}

hue=hue/6.0;if(hue<0){hue=hue+1.0;}

}

var h=Math.round(hue*360);var s=Math.round(saturation*100);var b=Math.round(brightness*100);return {h:h,s:s,b:b}
;}

this.onColorChoose=function(e){var element=e.target||e.srcElement;this.chooseCell(element);}
;this.chooseCell=function(element){if(element.tagName!="TD"){return ;}

var bgColor=element.style.backgroundColor;var hex;if(!IS_IE){var rgb=this.parseToRgb(bgColor);hex=this.rgbToHex(rgb);}

else 
{hex=bgColor;}

this.selectColor(hex);}
;this.getHex=function(element){var bgColor=element.style.backgroundColor;var rE=/rgb(\d*), (\d*), (\d*)/i;var results=bgColor.exec(rE);}
;this.selectCell=function(element){this.picker.style.top=CssUtil.intToPixel(element.offsetTop+this.circleAdjTop);this.picker.style.left=CssUtil.intToPixel(element.offsetLeft+this.circleAdjLeft);this.picker.style.display="";}
;this.selectColor=function(color,updateSlide,cancelOnChange){if(!color){this.color="";this.onChangeFx("");this.updateDisplay();return ;}

this.color=color;var rgb=this.parseToRgb(color);this.rgb=rgb;var hsb=this.rgbToHsb(rgb);this.hsb=hsb;this.updateDisplay();this.rInput.value=rgb.r;this.gInput.value=rgb.g;this.bInput.value=rgb.b;if(updateSlide){this.changeRgbValue(rgb);this.updateArrow();}

if(!cancelOnChange&&this.onChangeFx){this.onChangeFx(color);}

}
;this.initStyles=function(){var cssStyle=new css_StyleSheet();var cssClass=new css_CssClass("colorCell");cssClass.addStyle("width","2px");cssClass.addStyle("height","2px");cssStyle.addClass(cssClass);cssStyle.init();}
;this.parseToRgb=function(cssValue){if(cssValue.substr(0,1)=="#"){return this.hexToRgb(cssValue);}

else 
{var rgb=this.rgbAttrToRgb(cssValue);return rgb||{r:0,g:0,b:0}
;}

}

this.rgbAttrToRgb=function(cssValue){var re=/rgb\((\d+),\s*(\d+),\s*(\d+)/;var result=re.exec(cssValue);if(result){return {r:result[1],g:result[2],b:result[3]}
;}

return null;
}
;this.validateRgbValue=function(value){if(value>255){return 255;}

return value;}
;}


function StandardColorPicker(onChangeFx,onDblClick){this.onDblClick=onDblClick;this.build=function(parentEl){var holder=cE("div",parentEl);var div=cE("div",parentEl);var picker=new DiscreteColorPicker(this.onChangeFx,this.onDblClick);var grays=["#000000","#444444","#666666","#999999","#CCCCCC","#EEEEEE","#F3F3F3","#FFFFFF"];picker.addRow(grays);picker.build(div);var div=cE("div",parentEl);div.style.marginTop="7px";var picker=new DiscreteColorPicker(this.onChangeFx,this.onDblClick);var pure=["#FF0000","#FF9900","#FFFF00","#00FF00","#00FFFF","#0000FF","#9900FF","#FF00FF"];picker.addRow(pure);picker.build(div);var div=cE("div",parentEl);div.style.marginTop="7px";var picker=new DiscreteColorPicker(this.onChangeFx,this.onDblClick);var mix1=["#F4CCCC","#FCE5CD","#FFF2CC","#D9EAD3","#D0E0E3","#CFE2F3","#D9D2E9","#EAD1DC"];picker.addRow(mix1);var mix2=["#EA9999","#F9CB9C","#FFE599","#B6D7A8","#A2C4C9","#9FC5E8","#B4A7D6","#D5A6BD"];picker.addRow(mix2);var mix3=["#E06666","#F6B26B","#FFD966","#93C47D","#76A5AF","#6FA8DC","#8E7CC3","#C27BA0"];picker.addRow(mix3);var mix4=["#CC0000","#E69138","#F1C232","#6AA84F","#45818E","#3D85C6","#674EA7","#A64D79"];picker.addRow(mix4);var mix5=["#990000","#B45F06","#BF9000","#38761D","#134F5C","#0B5394","#351C75","#741B47"];picker.addRow(mix5);var mix6=["#660000","#783F04","#7F6000","#274E13","#0C343D","#073763","#20124D","#4C1130"];picker.addRow(mix6);picker.build(div);}
;this.onChangeFx=onChangeFx;}


function DiscreteColorPicker(onChangeFx,onDblClick){this.onDblClick=onDblClick;this.build=function(parentEl){var tBody=createTable(parentEl);for(var i=0;i<this.rows.length;i++)
{var colors=this.rows[i];this.buildRow(tBody,colors,(i==0));}

}
;this.onChangeFx=onChangeFx;this.rows=[];this.addRow=function(colors){this.rows.push(colors);}
;this.buildRow=function(tBody,colors,doTop){var tr=cE("tr",tBody);for(var i=0;i<colors.length;i++)
{this.buildCell(tr,colors[i],doTop);}

}
;this.buildCell=function(tr,color,doTop){var td=cE("td",tr);td.style.paddingRight="4px";var div=cE("div",td);div.style.border="1px solid black";if(!doTop){div.style.borderTop=0;}

div.style.width="17px";div.style.height="15px";div.style.backgroundColor=color;div.style.fontSize=0;div.style.cursor="hand";var thisObj=this;var onClickFx=function(){if(thisObj.onChangeFx){thisObj.onChangeFx(color);}

}
;eh_attachEvent("onclick",div,onClickFx);var onDblClickFx=function(){if(thisObj.onChangeFx){thisObj.onChangeFx(color);}

if(thisObj.onDblClick){thisObj.onDblClick();}

}
;eh_attachEvent("ondblclick",div,onDblClickFx);}
;}


function FeatureSettings(name,key){this.name=name;this.key=key||null;this.settingsId;this.mc=new MiniCache();this.addSettingsToLoad=function(useThisCache){var mc=useThisCache?this.mc:getMasterCache();var listName=this.getListName();var listInput=mc.addListToLoad("feature_settings",listName);listInput.addSearchTerm("name",this.name,SEARCHTERM_EXACT_MATCH);if(this.key){listInput.addSearchTerm("feature_key",this.key,SEARCHTERM_EXACT_MATCH);}

}
;this.refreshSettings=function(onAfterFx){this.mc.clearRecord("feature_settings",this.settingsId);this.addSettingsToLoad(true);if(onAfterFx){this.mc.process(onAfterFx);}

else 
{this.mc.process();}

}

this.getListName=function(){var name=this.name;if(this.key){name+="|"+this.key;}

return name;}
;this.getSettings=function(){if(!this.settingsId){var listName=this.getListName();var list=this.mc.getListByName(listName);if(!list){return null;}

var record=list.getFirstRecord();if(!record){record=this.mc.createRecord("feature_settings");record.getField("name.recordName").setValue(this.name);if(this.key){record.getField("feature_key").setValue(this.key);}

}

this.settingsId=record.id;}

return this.mc.getRecord("feature_settings",this.settingsId).getField("config");}
;this.getSettingByName=function(name){return this.getSettings().getChildField(name);}
;this.save=function(){this.mc.process();}
;}


;;;;function FullColorPicker(color,onChangeFx,onDblClick){this.color=color;this.onChangeFx=onChangeFx;this.onDblClick=onDblClick;this.onShowMore;this.settings;this.build=function(parentEl){this.settings=new FeatureSettings("org_colors","org_colors");this.buildStructure(parentEl);}
;this.selectColor=function(color){var yPos=document.body.scrollTop;var xPos=document.body.scrollLeft;this.color=color;this.updateHex(color);if(this.customPicker){this.customPicker.selectColor(color,true);}

if(this.onChangeFx){this.onChangeFx(color);}

window.scrollTo(xPos,yPos);}

this.updateHex=function(color){var hex=color;if(hex.charAt(0)=='#'){hex=hex.substring(1,color.length);}

this.hexInput.value=hex.toUpperCase();}
;this.buildStructure=function(parentEl){parentEl.innerHTML="";var customPicker;var thisObj=this;this.buildOrgColors(parentEl);var div=cE("div",parentEl);div.style.margin="5px 10px 0 10px";div.style.border="1px solid gray";div.style.borderBottomColor="white";var div=cE("div",parentEl);div.style.padding="10px";div.style.paddingTop="5px";var thisObj=this;var updateFx=function(color){thisObj.selectColor(color);}
;var standardPicker=new StandardColorPicker(updateFx,this.onDblClick);standardPicker.build(div);var div=cE("div",parentEl);div.style.height="20px";div.style.paddingLeft="10px";var leftDiv=cE("div",div);CssUtil.setFloat(leftDiv,"left");this.buildTransparent(leftDiv);var rightDiv=cE("div",div);rightDiv.style.paddingRight="15px";CssUtil.setFloat(rightDiv,"right");this.buildHexInput(rightDiv);var clearDiv=cE("div",div);clearDiv.clear="both";if(!this.showCustomColorPicker){div.style.height="30px";}

else 
{var div=cE("div",parentEl);div.style.padding="10px";div.style.fontFamily="arial";div.style.fontWeight="bold";div.style.fontSize="12px";div.align="center";div.style.cursor="pointer";div.innerHTML="Show More Colors";var customHolder=div;var thisObj=this;var onClickFx=function(){if(customPicker){return ;}

if(thisObj.onShowMore){thisObj.onShowMore();}

var onChange=function(color){thisObj.color=color;thisObj.updateHex(color);if(thisObj.onChangeFx){thisObj.color=color;thisObj.onChangeFx(color);}

}
;customHolder.innerHTML="";customHolder.style.cursor="";customPicker=new CustomColorPicker(thisObj.color,onChange);customPicker.build(customHolder);customHolder.onclick=null;thisObj.customPicker=customPicker;}
;eh_attachEvent("onclick",customHolder,onClickFx);}

}
;this.buildHexInput=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.fontFamily="arial";td.style.fontSize="12px";td.innerHTML="#";var td=cE("td",tr);td.style.paddingLeft="2px";var thisObj=this;var fx=function(hex){if(hex.charAt(0)!='#'){hex="#"+hex;}

if(!thisObj.validateColor(hex)){hex=thisObj.color
}

thisObj.selectColor(hex);}
;var props={style:{width:"60px"}
,maxLength:7}
;props.onAfterChangeFx=fx;var hexValue=this.color.substring(1,this.color.length);props.value=hexValue.toUpperCase();var input=buildTextInput(td,props);input.style.fontFamily="arial";input.style.fontSize="12px";this.hexInput=input;var keyFx=function(e){var key=IS_IE?event.keyCode:event.which;var isValid=((key>=48&&key<=57)||(key>=65&&key<=70)||(key>=97&&key<=102));if(!isValid){crossbrowser_stopEvent(e);}

}
;eh_attachEvent("onkeypress",input,keyFx);}
;this.validateColor=function(color){var div=cE("div");try
{div.style.backgroundColor=color;}

catch(e)
{return false;}

return (""==div.style.backgroundColor)?false:true;}
;this.buildTransparent=function(parentEl,updateFx){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);var div=cE("div",td);div.style.width="20px";div.style.height="18px";div.style.border="1px solid black";div.style.fontSize=0;div.style.cursor="pointer";div.style.backgroundImage="url(/upload/custom_screens/architect/components/colorpicker/transparent_bg.gif)";var thisObj=this;var onClickFx=function(){thisObj.selectColor("");}
;eh_attachEvent("onclick",div,onClickFx);var onDblClickFx=function(){thisObj.selectColor("");if(thisObj.onDblClick){thisObj.onDblClick();}

}
;eh_attachEvent("ondblclick",div,onDblClickFx);var td=cE("td",tr);td.style.fontFamily="arial";td.style.fontSize="11px";td.style.paddingLeft="4px";td.innerHTML="Transparent";}
;this.buildOrgColors=function(parentEl){var orgData=this.settings.getSettings();if(!orgData){return ;}

var div=cE("div",parentEl);div.className="smallBoldText";div.style.padding="0 0 2px 10px";div.innerHTML=orgData.getChildField("display_name").getValue();var div=cE("div",parentEl);div.style.paddingLeft="10px";var thisObj=this;var updateFx=function(color){thisObj.selectColor(color);}
;var picker=new DiscreteColorPicker(updateFx,this.onDblClick);var orgColors=orgData.getChildField("colors").getValue();picker.addRow(orgColors);picker.build(div);}
;}
;

;;function ColorPopup(positionEl,onChange,color){this.positionEl=positionEl;this.onChange=onChange;this.align="belowRight";this.color=color||"";this.closeFx;this.showCustomColorPicker=true;this.offsetLeft=0;this.offsetTop=0;this.finishFx=function(){this.popup.close();}
;this.build=function(){var popup=new Popup();popup.width=200;this.popup=popup;popup.closeFx=this.closeFx;popup.showX=false;popup.positionEl=this.positionEl;popup.shadow="3side";popup.addDragBar=false;popup.closeEvent="onclick";popup.disableBg=true;popup.fadeBg=false;popup.offsetLeft=this.offsetLeft;popup.offsetTop=this.offsetTop;var contentArea=popup.build();contentArea.style.backgroundColor="#eeeeee";CssUtil.makeNotSelectable(contentArea);var dragger=cE("div",contentArea);dragger.align="center";dragger.style.height="14px";dragger.style.paddingTop="3px";dragger.style.fontSize=0;dragger.style.cursor="move";popup.makeDraggable(dragger);var tBody=createTable(dragger,"97%");var tr=cE("tr",tBody);var td=cE("td",tr);td.style.width="30px";var td=cE("td",tr);td.align="center";var dotSrc="/upload/custom_screens/architect/components/dropdownmenu/grip_dot.gif";for(var i=0;i<4;i++)
{var dot=cE("img",td);dot.src=dotSrc;dot.style.margin="2px";}

var td=cE("td",tr);td.style.width="30px";td.align="right";var img=cE("img",td);img.src="/upload/js_globals/generic_images/popup_close.gif";img.style.cursor="pointer";var closeFx=function(){popup.close();}
;eh_attachEvent("onclick",img,closeFx);var div=cE("div",contentArea);var thisObj=this;var onDblClick=function(){thisObj.finishFx();}
;var onChangeFx=function(color){thisObj.color=color;if(thisObj.onChange){thisObj.onChange(color);}

}
;var colorPicker=new FullColorPicker(this.color,onChangeFx,onDblClick);colorPicker.showCustomColorPicker=this.showCustomColorPicker;colorPicker.build(div);popup.align(this.align);}

}

var g_colorPopup;

;function buildColorInput(parentEl,onChangeFx,color,properties){properties=properties||{}
;properties.style=properties.style||{}
;var tBody=createTable(parentEl);var table=tBody.parentNode;table.style.backgroundColor=properties.style.backgroundColor||"#eeeeee";table.style.border="1px solid gray";table.style.cursor="hand";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.padding="4px";var div=cE("div",td);div.style.backgroundColor=color;div.style.border="1px solid black";div.style.width="24px";div.style.height="14px";div.style.fontSize=0;var colorPreview=div;if(color){colorPreview.style.backgroundColor=color;colorPreview.style.backgroundImage="";}

else 
{colorPreview.style.backgroundImage="url(/upload/custom_screens/architect/components/colorpicker/transparent_bg.gif)";}

var td=cE("td",tr);td.style.padding="5px 3px  5px 3px";var image=cE("img",td);image.src="/upload/custom_screens/components/colorpicker/color_arrow_down.gif";var onClickFx=function(){var fx=function(newColor){if(newColor){color=newColor;colorPreview.style.backgroundColor=newColor;colorPreview.style.backgroundImage="";}

else 
{colorPreview.style.backgroundImage="url(/upload/custom_screens/architect/components/colorpicker/transparent_bg.gif)";}

onChangeFx(newColor);}
;var popup=new ColorPopup(table,fx,color);popup.showCustomColorPicker=(properties.showCustomColorPicker===false)?false:true;popup.align=properties.alignPopup||"belowLeft";popup.build();}

eh_attachEvent("onclick",table,onClickFx);}


;;
function ChangeTablePopup(element,elName){
this.element=element;
this.originalEl=element.cloneNode(true);
this.elName=elName;this.build=function(){this.tagName=this.element.tagName.toLowerCase();var lpPopup=new LpPopup();lpPopup.width=300;lpPopup.title="Change "+this.elName;var contentArea=lpPopup.build();var doc=lpPopup.doc;var cC=new CssClass(".ctp_contentArea");cC.add("padding","10px");cC.init(doc);var cC=new CssClass(".ctp_contentArea table td");cC.add("font-family","arial");cC.add("font-size","12px");cC.init(doc);contentArea.className="ctp_contentArea";this.buildSizeInfo(contentArea);if("table"==this.tagName){this.buildBorderInfo(contentArea);}

if("td"==this.tagName){this.buildAlignInfo(contentArea);}

this.buildBackgroundInfo(contentArea);this.buildButtonRow(contentArea);this.popup=lpPopup.popup;this.popup.center();lpPopup.primaryContentArea.style.height=contentArea.offsetHeight+"px";}
;this.buildButtonRow=function(parentEl){LpPopupUtil.buildDivider(parentEl);var thisObj=this;var doneFx=function(){thisObj.popup.close();}
;var cancelFx=function(){var el=thisObj.element;el.parentNode.replaceChild(thisObj.originalEl,el);thisObj.popup.close();}
;var holder=cE("div",parentEl);LpPopupUtil.buildButtonSection(holder,"Done",doneFx,"cancel",cancelFx);}
;
this.buildSizeInfo=function(parentEl){var el=this.element;var tagName=el.tagName.toLowerCase();var contentHolder=LpPopupUtil.buildContentSection(parentEl,"Size");var tbody=createTable(contentHolder);if("table"==tagName||"td"==tagName){this.buildSizer(tbody,"Width");}

if("table"==tagName||"tr"==tagName){this.buildSizer(tbody,"Height");}

}
;this.buildSizer=function(tbody,label){var tr=cE("tr",tbody);var td=cE("td",tr);td.style.paddingRight="8px";td.innerHTML=label;var td=cE("td",tr);var sizer=new SizeSelector(label.toLowerCase(),this.element);sizer.build(td);if("td"==this.tagName){return ;}

sizer.onValueChange=function(){var columns=el.parentNode.parentNode.getElementsByTagName("td");for(var i=0;i<columns.length;i++)
{columns[i].style.width="";}

}
;}
;this.buildBorderInfo=function(parentEl){var contentHolder=LpPopupUtil.buildContentSection(parentEl,"Border");var tBody=createTable(contentHolder);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="16px";td.innerHTML="Size";var td=cE("td",tr);td.style.paddingLeft="2px";var thisObj=this;var fx=function(value){thisObj.element.border=value;}
;var properties={value:this.element.border,onAfterChangeFx:fx,style:{width:30}
}
;buildNumberInput(td,properties);var tr=cE("tr",tBody);var td=cE("td",tr);td.innerHTML="Color";var td=cE("td",tr);td.style.paddingLeft="2px";var thisObj=this;var fx=function(color){thisObj.element.style.borderColor=color;}
;var props={alignPopup:"rightCenter",style:{backgroundColor:"white"}
}
;buildColorInput(td,fx,this.element.style.borderColor,props);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="16px";td.innerHTML="Style";var td=cE("td",tr);var styleSelect=cE("select",td);var collapseOption=this.element.style.borderCollapse;var options=["separate","collapse"];for(var i=0;i<options.length;i++)
{var val=options[i];var option=cE("option",styleSelect);option.innerHTML=val;option.value=val;if(collapseOption==val){option.selected=true;}

}

var styleChange=function(){var val=styleSelect.options[styleSelect.selectedIndex].value;thisObj.element.style.borderCollapse=val;}
;E.change(styleSelect,styleChange);}
;this.buildBackgroundInfo=function(parentEl){var contentHolder=LpPopupUtil.buildContentSection(parentEl,"Background");var tBody=createTable(contentHolder);var tr=cE("tr",tBody);var td=cE("td",tr);td.innerHTML="Color";var td=cE("td",tr);td.style.paddingLeft="8px";var thisObj=this;var fx=function(color){thisObj.element.style.backgroundColor=color;}
;var props={alignPopup:"rightCenter",style:{backgroundColor:"white"}
}
;buildColorInput(td,fx,this.element.style.backgroundColor,props);}
;this.buildAlignInfo=function(parentEl){var contentHolder=LpPopupUtil.buildContentSection(parentEl,"Alignment");var tBody=createTable(contentHolder);var tr=cE("tr",tBody);var td=cE("td",tr);td.innerHTML="Vertical";var td=cE("td",tr);td.style.paddingLeft="8px";var selectEl=cE("select",td);var vAlign=this.element.style.verticalAlign;if(""==vAlign){vAlign="middle";}

var options=["top","middle","bottom"];for(var i=0;i<options.length;i++)
{var val=options[i];var option=cE("option",selectEl);option.innerHTML=val;option.value=val;if(vAlign==val){option.selected=true;}

}

var thisObj=this;var onChange=function(option){var val=selectEl.options[selectEl.selectedIndex].value;thisObj.element.style.verticalAlign=val;}
;E.add(selectEl,"change",onChange);}
;}
;


var TableHandler=new TableHandlerBase()
function TableHandlerBase(){
this.deleteRow=function(rowEl){this.setElementToSave(rowEl);rowEl.parentNode.removeChild(rowEl);}
;
this.insertRow=function(rowEl,position){var tbody=rowEl.parentNode;var index=rowEl.rowIndex;if(position=="above"){index--;}

else 
{index++;}

var nRow=rowEl.parentNode.parentNode.insertRow(index);for(var i=0;i<rowEl.cells.length;i++)
{var cell=nRow.insertCell(i);cell.innerHTML="&nbsp";}

this.setElementToSave(nRow);}
;
this.deleteColumn=function(colEl){var rows=getNearestAncestor(colEl,"table").rows;for(var i=0;i<rows.length;i++)
{rows[i].deleteCell(colEl.cellIndex);}

this.setElementToSave(nRow);}
;
this.insertColumn=function(colEl,position){var rows=getNearestAncestor(colEl,"table").rows;var index=colEl.cellIndex;if(position=="left"){index--;}

else 
{index++;}

for(var i=0;i<rows.length;i++)
{var cell=rows[i].insertCell(index);cell.innerHTML="&nbsp";cell.style.width=colEl.style.width;}

this.setElementToSave(nRow);}
;this.setElementToSave=function(element){var table=getNearestAncestor(element,"table");LivePage.setElementToSave(table);}
;}
;

var BodyOnloader=new BodyOnloaderBase();function BodyOnloaderBase(){this.fxsForBeforeLoad=[];this.fxsForAfterLoad=[];this.addFxForBeforeLoad=function(fx){this.fxsForBeforeLoad.push(fx);}
;this.addFxForAfterLoad=function(fx){this.fxsForAfterLoad.push(fx);}
;this.addFx=function(fx){this.fxsForBeforeLoad.push(fx);}
;this.runAfterLoad=function(){for(var i=0;i<this.fxsForAfterLoad.length;i++)
{var fx=this.fxsForAfterLoad[i];fx();}

}
;this.run=function(afterFx){for(var i=0;i<this.fxsForBeforeLoad.length;i++)
{var fx=this.fxsForBeforeLoad[i];fx();}

var thisObj=this;var finishFx=function(){thisObj.runAfterLoad();if(afterFx){afterFx();}

}
;var mc=getMasterCache();if(mc.isDataToLoad()){mc.process(finishFx);}

else 
{finishFx();}

}
;}


;var ResponsiveUtil=new ResponsiveUtilBase();function ResponsiveUtilBase(){this.RESPONSIVE_KEY="responsive_ranges";this.DEFAULT_RANGE="default_range";this.fontSizes=[8,9,10,11,12,14,16,18,20,22,24,26,28,32,36,48,72];this.paddingSet=[5,10,15,20,25,30,40,50,75,100,150,200,250,300];this.screenSizesByName={}
;this.screenSizes=[];this.currentSizePrefix;this.tallStyles={}
;this.styleSheet;this.addTallClass=function(height){var heightValue=height+"px";var className="a-meta-r-h-"+heightValue;if(this.tallStyles[heightValue]){return className;}

var cls=new CssClass("."+className);cls.styleSheet=this.getStyleSheet();cls.add("height",heightValue);cls.init();this.tallStyles[height]=true;return className;}
;this.addSize=function(name,minWidth,maxWidth){var sizeId=this.screenSizes.length;var size={name:name,minWidth:minWidth,maxWidth:maxWidth,isInitialized:false,sizeId:sizeId}
;var media="";if(minWidth){media+="(min-width:"+minWidth+"px)";}

else 
{size.minWidth=0;}

if(minWidth&&maxWidth){media+=" and ";}

if(maxWidth){media+="(max-width:"+maxWidth+"px)";}

else 
{size.maxWidth=Infinity;}

size.media=media;this.screenSizesByName[name]=size;this.screenSizes.push(size);var cls=new CssClass(".r-test",media);cls.add("width",sizeId+1+"px");cls.init();}
;this.getCurrentSizePrefix=function(){return "r-"+this.getCurrentSize()+"-";}
;this.getCurrentSize=function(){if(!this.sizeTestEl){var div=cE("div",document.body);div.style.display="none";div.className="r-test";this.sizeTestEl=div;}

var value=CssUtil.getStyle(this.sizeTestEl,"width");var sizeId=CssUtil.pixelToInt(value)-1;var sizeName=null;if(this.screenSizes[sizeId]){sizeName=this.screenSizes[sizeId].name;}

return sizeName||null;}
;this.isLessThan=function(rangeName,otherRangeName){var sizes=this.screenSizesByName;return (sizes[rangeName].minWidth<sizes[otherRangeName].minWidth);}

this.isOverlap=function(range1StartName,range1EndName,range2StartName,range2EndName){var sizes=this.screenSizesByName;var start1=sizes[range1StartName].minWidth;var end1=sizes[range1EndName].maxWidth;var start2=sizes[range2StartName].minWidth;var end2=sizes[range2EndName].maxWidth;return ((start2>=start1&&start2<end1)||(end2>start1&&end2<=end1)||(start2<=start1&&end2>=end1));}
;this.isContained=function(containedStartName,containedEndName,containerStartName,containerEndName){var sizes=this.screenSizesByName;var containedStart=sizes[containedStartName].minWidth;var containedEnd=sizes[containedEndName].maxWidth;var containerStart=sizes[containerStartName].minWidth;var containerEnd=sizes[containerEndName].maxWidth;return ((containerStart<=containedStart)&&(containedEnd<=containerEnd));}
;this.getRangeNameInfo=function(rangeName){if(!rangeName){return null;}

var rE=/^(xxs|xs|s|m|l|xl)$/;var result=rE.exec(rangeName);if(result){var info={}
;info.startSize=result[1];info.endSize=result[1];return info;}

var rE=/^(xxs|xs|s|m|l|xl)-(xxs|xs|s|m|l|xl)?$/;var result=rE.exec(rangeName);if(result){var info={}
;info.startSize=result[1];info.endSize=result[2];return info;}

return null;}
;this.isValidRangeName=function(rangeName){return this.getRangeNameInfo(rangeName)?true:false;
}
;this.getRangeSizes=function(rangeName){
var rE=/^(xxs|xs|s|m|l|xl)$/;var result=rE.exec(rangeName);if(result){return [rangeName];}

var rE=/^(xxs|xs|s|m|l|xl)-(xxs|xs|s|m|l|xl)?$/;var result=rE.exec(rangeName);if(!result){return null;}

var res1=result[1];var res2=result[2];var begin=res1;var end=res2;var sizes=[];var isStarted=false;for(var i=0;i<this.screenSizes.length;i++)
{var name=this.screenSizes[i].name;if(name==begin){isStarted=true;}

if(isStarted){sizes.push(name);}

if(name==end){break;}

}

return sizes;}
;this.update=function(){var prevSize=this.currentSize;var currentSize=this.getCurrentSize();this.currentSize=currentSize;if(prevSize&&prevSize!=this.currentSize){this.clearSize(prevSize);}

this.enforceTall(currentSize);}
;this.clearSize=function(size){this.clearTall(size);}
;this.getStyleSheet=function(){if(!this.styleSheet){this.styleSheet=StyleSheetUtil.getStyleSheet();}

return this.styleSheet;}
;this.attachResize=function(){var thisObj=this;var resizeFx=function(){thisObj.update();}
;E.resize(resizeFx);}
;this.init=function(){var mc=new MiniCache();var rangeList=mc.addListToLoad("feature_settings","ranges",0,-1);rangeList.addSearchTerm("feature_key",this.RESPONSIVE_KEY,SEARCHTERM_EXACT_MATCH);var thisObj=this;var onProcess=function(){thisObj.defineRanges(mc);thisObj.update();thisObj.attachResize();}

mc.process(onProcess);}
;this.defineRanges=function(mc){var rangeIds=mc.getListByName("ranges").ids;if(rangeIds.length==0){this.addSize("xxs",0,480);this.addSize("xs",481,800);this.addSize("s",801,1024);this.addSize("m",1025,1366);this.addSize("l",1367,1600);this.addSize("xl",1601);return ;}

for(var i=0;i<rangeIds.length;i++)
{var rangeRec=mc.getRecord("feature_settings",rangeIds[i]);this.defineSizes(rangeRec);}

}
;this.defineSizes=function(rangeRec){var rangeKey=rangeRec.getField("name.recordName").getValue();var ranges=rangeRec.getField("config").getChildFields();for(var i=0;i<ranges.length;i++)
{var range=ranges[i];var rangeName=range.getChildField("range_name").getValue();var fullRangeName=(rangeKey==this.DEFAULT_RANGE)?rangeName:rangeKey+"-"+rangeName;var min=CssUtil.pixelToInt(range.getChildField("min").getValue());var max=CssUtil.pixelToInt(range.getChildField("max").getValue());this.addSize(fullRangeName,min,max);}

}
;this.getFontPrefix=function(){return "r-"+this.getCurrentSize()+"-f-s-";}
;this.getFontClass=function(pixel){return this.getFontPrefix()+pixel;}
;this.setup=function(){var thisObj=this;var fx=function(){thisObj.init();}
;BodyOnloader.addFxForBeforeLoad(fx);}
;
this.clearTall=function(size){var className="r-"+size+"-tall";var els=CssUtil.getElementsByClassName(className);for(var i=0;i<els.length;i++)
{CssUtil.removeClassesStartingWith(els[i],"a-meta-r-h-");}

}
;this.enforceTall=function(size){var className=this.getCurrentSizePrefix()+"tall";var els=CssUtil.getElementsByClassName(className);for(var i=0;i<els.length;i++)
{CssUtil.removeClassesStartingWith(els[i],"a-meta-r-h-");}

for(var i=0;i<els.length;i++)
{var el=els[i];var height=el.parentElement.offsetHeight;var newClassName=this.addTallClass(height);CssUtil.addClassToEl(el,newClassName);}

}
;this.setup();}
;

function CycleFramer(cycleEl){this.cycleEl=cycleEl;}

CycleFramer.prototype=new CycleFramerBase();function CycleFramerBase(){this.framer;this.resizeFx;this.depth;this.framers=[];this.colors=[{border:"#274E13",bg:"#B6D7A8"}
,{border:"#134F5C",bg:"#A2C4C9"}
];this.frame=function(){this.destroy();var fragInfo=A.getFragInfo(this.cycleEl.id);fragInfo.framer=this;this.fragInfo=fragInfo;var liveCycle=fragInfo.liveCycleObj;if(!liveCycle.isEditMode){liveCycle.setEditMode();}

this.frameCycleEl();debugger;this.frameSlides();this.attachResize();GridManager.reframeAllGrids();}
;this.frameCycleEl=function(){var framer=this.createFramer("cycle-frame",this.cycleEl);}
;this.frameSlides=function(){var slideEls=this.cycleEl.firstElementChild.children;for(var i=0;i<slideEls.length;i++)
{this.frameSlide(slideEls[i]);}

}
;this.frameSlide=function(slideEl){var top="slide-frame-top";var bottom="slide-frame-bottom";var left="slide-frame-left";var right="slide-frame-right";var framer=new Framer(top,right,bottom,left);framer.staggerDrawing=false;framer.paddingLeft=0;framer.paddingRight=0;framer.paddingTop=0;framer.paddingBottom=0;framer.doHideOnOut=false;framer.maxOpacity=".9";debugger;var paddingStr=CssUtil.getStyle(slideEl,"padding");framer.ignorePadding=(paddingStr!="0px");framer.frame(slideEl);this.framers.push(framer);}
;this.createFramer=function(prefix,element){var top=prefix+"-top";var bottom=prefix+"-bottom";var left=prefix+"-left";var right=prefix+"-right";var framer=new Framer(top,right,bottom,left);framer.staggerDrawing=false;framer.paddingLeft=-5;framer.paddingRight=-5;framer.paddingTop=0;framer.paddingBottom=0;framer.doHideOnOut=false;framer.maxOpacity=".9";framer.frame(element);this.framers.push(framer);return framer;}
;this.initCss=function(){var colors=this.colors[0];this.createClasses(".cycle-frame",colors.border,colors.bg);var colors=this.colors[1];this.createClasses(".slide-frame",colors.border,colors.bg);}
;this.attachResize=function(){var thisObj=this;this.resizeFx=function(){var framers=thisObj.framers;for(var i=0;i<framers.length;i++)
{framers[i].tempHide();}

var tO=function(){thisObj.reframe();}

window.setTimeout(tO,1000);}
;E.resize(this.resizeFx);}
;this.reframe=function(){GridManager.reframeAllGrids();var framers=this.framers;for(var i=0;i<framers.length;i++)
{framers[i].reframe(true);}

}
;this.destroy=function(){GridManager.hideAllGrids();var framers=this.framers;for(var i=0;i<framers.length;i++)
{framers[i].destroy();}

this.framers=[];}
;this.createClasses=function(prefix,borderColor,frameColor){var cls=new CssClass(prefix+"-iconRow");cls.add("border","1px solid "+borderColor);cls.add("border-right","0");cls.add("border-top","0");cls.add("background-color",frameColor);cls.add("height","22px");cls.add("width","14px");cls.add("z-index","40");cls.add("position","relative");cls.add("left","-14px");cls.add("-moz-border-bottom-left-radius","5px");cls.add("border-bottom-left-radius","5px");cls.init();var height=(".cycle-frame"==prefix)?"10px":"5px";var width=(".cycle-frame"==prefix)?"10px":"5px";var cls=new CssClass(prefix+"-top");cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("background-color",frameColor);cls.add("height",height);cls.init();var cls=new CssClass(prefix+"-bottom");cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("background-color",frameColor);cls.add("height",height);cls.init();var cls=new CssClass(prefix+"-left");cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("border-bottom","0");cls.add("border-top","0");cls.add("background-color",frameColor);cls.add("width",width);cls.init();var cls=new CssClass(prefix+"-right");cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("border-bottom","0");cls.add("border-top","0");cls.add("background-color",frameColor);cls.add("width",width);cls.init();}
;this.initCss();}
;
;;;;;;;;var RightClickPageOptions=new RightClickPageOptionsBase();function RightClickPageOptionsBase(){this.currentMenu;this.handleRightClick=function(targetEl,x,y){if(this.currentMenu){this.currentMenu.close();}

if(LivePage.isMetaEl(targetEl)){return ;}

if("HTML"==targetEl.tagName){targetEl=targetEl.ownerDocument.body;}

var menu=new DropdownMenu();menu.minWidth="200px";this.currentMenu=menu;this.addImageChangeItems(menu,targetEl,x,y);this.addGridItems(menu,targetEl,x,y);this.addCycleItems(menu,targetEl,x,y);this.addTableChangeItems(menu,targetEl);this.addResponsiveItems(menu,targetEl,x,y);this.addEditCssItem(menu,targetEl,x,y);this.addEditDragDropItems(menu,targetEl,x,y);if(menu.menuItems.length>0){menu.build(x,y);}

}
;this.close=function(){if(this.currentMenu){this.currentMenu.close();}

}
;this.addGridItems=function(menu,targetEl,x,y){var gridEl=getAncesterWClass(targetEl,"a-grid");y-=document.body.scrollTop;x-=document.body.scrollLeft;if(gridEl&&gridEl!=GridEditMenuPopup.gridEl){var editFx=function(){hideProgressIcon();GridEditMenuPopup.setGridEl(gridEl);if(!GridEditMenuPopup.isShowing()){GridEditMenuPopup.show(x,y);}

}
;var item=new StandardMenuItem("Edit Mondrian Grid",editFx);menu.addMenuItem(item);}

if(gridEl){var thisObj=this;var addFx=function(){thisObj.addGridTile(gridEl,x,y);}
;var item=new StandardMenuItem("Add Mondrian Tile",addFx);menu.addMenuItem(item);}

if(!CssUtil.elHasClass(targetEl,"a-grid")){var addFx=function(){var inserter=new GridInserter();inserter.build(targetEl,x,y);}
;var item=new StandardMenuItem("Insert Mondrian Grid",addFx);menu.addMenuItem(item);}

menu.addDivider();if(gridEl){var thisObj=this;var fx=function(){thisObj.showTransitionMenu(x,y);}
;var item=new StandardMenuItem("View Transitions",fx);menu.addMenuItem(item);var thisObj=this;var fx=function(){thisObj.createTransition(targetEl,x,y);}
;var item=new StandardMenuItem("Create New Transition",fx);menu.addMenuItem(item);menu.addDivider();}

}
;this.showTransitionMenu=function(x,y){showProgressIcon();var fx=function(){hideProgressIcon();var popup=new CssTransitionsPopup();popup.build(x,y);}
;fx();}
;this.createTransition=function(targetEl,x,y){showProgressIcon();var moduleId=LivePage.findContainingModuleId(targetEl);var fx=function(){var afterFx=function(newId){var popup=new CssTransitionState(newId);popup.build(x,y);hideProgressIcon();}
;LiveCssTransitionUtil.create(moduleId,afterFx);}
;fx();}
;this.addGridTile=function(gridEl,x,y){var thisObj=this;var afterFx=function(){hideProgressIcon();GridEditMenuPopup.setGridEl(gridEl,x,y);var grid=GridEditMenuPopup.grid;var itemEl=grid.createItem(x,y);var offset=GridEditMenuPopup.width+10;if(itemEl.offsetLeft>offset){x=itemEl.offsetLeft-offset;}

else 
{x=itemEl.offsetLeft+itemEl.offsetWidth;}

GridEditMenuPopup.show(x,y);}
;LiveCss.initialize(gridEl,afterFx);}
;this.addEditCssItem=function(menu,targetEl,x,y){var fx=function(){var sheet=LiveCss.getStyleSheetForEl(targetEl);sheet.buildEditor(x,y);}
;var item=new StandardMenuItem("Edit Style Sheet",fx);menu.addMenuItem(item);menu.addDivider();}
;this.addButtonItems=function(menu,targetEl,x,y){var button=gE("#"+"signInButton");if(!button||!isDescendent(targetEl,button)){return ;}

var fx=function(){}
;var item=new StandardMenuItem("Add Notification To Send On Click",fx);menu.addMenuItem(item);var item=new StandardMenuItem("Add Action To Run On Click",fx);menu.addMenuItem(item);menu.addDivider();}
;this.addTableChangeItems=function(menu,targetEl){var table=getNearestAncestor(targetEl,"table");var theCell=getNearestAncestor(targetEl,"td");if(table==null&&theCell==null){return ;}

var thisObj=this;var fx=function(){var popup=new ChangeTablePopup(table,"Table");popup.build();}
;var item=new StandardMenuItem("Change Table",fx);menu.addMenuItem(item);var fx=function(){var popup=new ChangeTablePopup(theCell.parentNode);popup.build();}
;var item=new StandardMenuItem("Change Row",fx);menu.addMenuItem(item);var fx=function(){var popup=new ChangeTablePopup(theCell,"Cell");popup.build();}
;var item=new StandardMenuItem("Change Cell",fx);menu.addMenuItem(item);menu.addDivider();var fx=function(){TableHandler.insertRow(theCell.parentNode,"above");}
;var item=new StandardMenuItem("Insert Row Above",fx);menu.addMenuItem(item);var fx=function(){TableHandler.insertRow(theCell.parentNode,"below");}
;var item=new StandardMenuItem("Insert Row Below",fx);menu.addMenuItem(item);var fx=function(){TableHandler.insertColumn(theCell,"left");}
;var item=new StandardMenuItem("Insert Column on the Left",fx);menu.addMenuItem(item);var fx=function(){TableHandler.insertColumn(theCell,"right");}
;var item=new StandardMenuItem("Insert Column on the Right",fx);menu.addMenuItem(item);menu.addDivider();var fx=function(){var parentEl=table.parentNode;parentEl.removeChild(table);}
;var item=new StandardMenuItem("Delete Table",fx);menu.addMenuItem(item);var fx=function(){TableHandler.deleteRow(theCell.parentNode);}
;var item=new StandardMenuItem("Delete Row",fx);menu.addMenuItem(item);var fx=function(){alert("delete column");}
;var item=new StandardMenuItem("Delete Column",fx);menu.addMenuItem(item);menu.addDivider();}
;this.addInspectItem=function(menu,targetEl,x,y){menu.addDivider();var fx=function(){var afterFx=function(){var popup=new InspectElementPopup();popup.build(targetEl,x,y);}
;sl_loadScript('/0/le8664_0.js',afterFx);afterFx;}
;var item=new StandardMenuItem("Inspect Element",fx);menu.addMenuItem(item);}
;this.addResponsiveItems=function(menu,targetEl,x,y){var gridEl=getAncesterWClass(targetEl,"respond");if(null==gridEl){return ;}

var thisObj=this;var fx=function(){var afterFx=function(){var popup=new EditLayoutPopup();popup.build(targetEl,x,y);}
;sl_loadScript('/0/le8743_0.js',afterFx);afterFx;}
;var menuName="Edit Responsive Layout ("+ResponsiveUtil.getCurrentSize().toUpperCase()+")";var item=new StandardMenuItem(menuName,fx);menu.addMenuItem(item);menu.addDivider();}
;
this.addCycleItems=function(menu,targetEl,x,y){var cycleEl=this.getAncesterFragByType(targetEl,"cycle");if(null==cycleEl){return ;}

var thisObj=this;var fx=function(){var cycleFramer=new CycleFramer(cycleEl);cycleFramer.frame();}
;var item=new StandardMenuItem("Edit Cycle",fx);menu.addMenuItem(item);menu.addDivider();}
;this.getAncesterFragByType=function(element,fragType){while(element.tagName!="BODY")
{var fragInfo=A.getFragInfo(element.id);if(fragInfo&&fragInfo.fragType==fragType){return element;}

element=element.parentNode;}

return null;}
;this.addImageChangeItems=function(menu,targetEl,x,y){var theImage=getNearestAncestor(targetEl,"img");if(!theImage||theImage.lpPlaceHolder){return ;}

var thisObj=this;var fx=function(){var afterFx=function(){var newX=CssUtil.pixelToInt(menu.popup.anchor.style.left);var newY=CssUtil.pixelToInt(menu.popup.anchor.style.top);var popup=new ReplaceImagePopup(theImage);popup.build(newX-15,newY-15);}
;sl_loadScript('/0/le8333_0.js',afterFx);afterFx;}
;var item=new StandardMenuItem("Replace Image",fx);menu.addMenuItem(item);var fx=function(){LivePage.setElementToSave(theImage);removeNode(theImage);}
;var item=new StandardMenuItem("Delete Image",fx);menu.addMenuItem(item);var editFx=function(){AviaryEditor.img=theImage;AviaryEditor.afterSave=function(img){LivePage.setElementToSave(img);}
;AviaryEditor.open();}
;var item=new StandardMenuItem("Edit Image",editFx);menu.addMenuItem(item);var editSettingsFx=function(){var settingsPopup=new ImageEditorPopup(theImage);settingsPopup.onChange=function(){LivePage.setElementToSave(img);}
;settingsPopup.build();}
;var item=new StandardMenuItem("Edit Settings",editSettingsFx);menu.addMenuItem(item);menu.addDivider();}
;this.addEditDragDropItems=function(menu,targetEl,x,y){if(targetEl.tagName=="HTML"){return ;}

this.addRemoveDragDropItem(menu,targetEl);var thisObj=this;var onClickFx=function(){showProgressIcon("one moment...");var fx=function(){var popup=new EditDragDropPopup(targetEl);popup.build(x,y);hideProgressIcon();}
;sl_loadScript('/0/le8145_0.js',fx);fx;}
;var menuItem=new StandardMenuItem("Edit Drag/Drop Area",onClickFx);menu.addMenuItem(menuItem);menu.addDivider();}
;this.getOwnerContainer=function(element){if(CssUtil.elHasClass(element,"a_container")){return element;}

if("BODY"==element.tagName||"HTML"==element.tagName){return null;}

var temp=element.parentNode;while("BODY"!=temp.tagName)
{if(CssUtil.elHasClass(temp,"a_container")){return temp;}

temp=temp.parentNode;}

return null;}
;this.addRemoveDragDropItem=function(menu,targetEl){var container=this.getOwnerContainer(targetEl);if(!container){return ;}

var thisObj=this;var onClickFx=function(){ContainerHandler.removeContainer(container);}
;var menuItem=new StandardMenuItem("Remove Drag/Drop Area",onClickFx);menu.addMenuItem(menuItem);}
;this.attachResize=function(){var thisObj=this;var fx=function(){thisObj.close();}
;E.resize(fx);}
;this.processEvent=function(event){event.preventDefault();if(event.target.className=="a_popupContainer"){return ;}

var coordinate=getEventCoord(event);var x=coordinate.x;var y=coordinate.y;this.handleRightClick(event.target,x,y);}
;this.init=function(){var thisObj=this;var onRightClick=function(event){thisObj.processEvent(event);
}
;document.addEventListener("contextmenu",onRightClick,true);this.attachResize();}
;}
;

function ElementResizer(){this.framer;this.element;this.build();}

ElementResizer.prototype=new ElementResizerBase();function ElementResizerBase(){this.frame=function(element){this.element=element;this.framer.frame(element);this.alignBoxes();}
;this.alignBoxes=function(){var element=this.element;var resizeBoxes=this.resizeBoxes;var fullWidth=this.framer.top.offsetWidth;var fullHeight=this.framer.left.offsetHeight;var halfWidth=fullWidth/2+"px";var halfHeight=fullHeight/2+"px";fullWidth+="px";fullHeight+="px";resizeBoxes.cL.style.marginTop=halfHeight;resizeBoxes.cR.style.marginTop=halfHeight;resizeBoxes.bL.style.marginTop=fullHeight;resizeBoxes.bR.style.marginTop=fullHeight;}
;this.build=function(){var framer=new Framer("imageFrameTop","imageFrameRight","imageFrameBottom","imageFrameLeft");this.framer=framer;framer.doHideOnOut=false;framer.doHideOnClick=true;framer.type="resizer";var resizeBoxes={}
;this.resizeBoxes=resizeBoxes;var uL=cE("div",framer.left);uL.style.position="absolute";uL.style.width="8px";uL.style.height="8px";uL.style.left="-4px";uL.style.top="-4px";uL.style.border="1px solid black";uL.style.backgroundColor="white";uL.style.cursor="nw-resize";resizeBoxes["uL"]=uL;var thisObj=this;var initULDragFx=function(event){thisObj.initDragFx(event,"left","up");}
;E.mousedown(uL,initULDragFx);var cL=uL.cloneNode(false);aE(framer.left,cL);cL.style.marginTop="50%";cL.style.cursor="w-resize";resizeBoxes["cL"]=cL;var initCLDragFx=function(event){thisObj.initDragFx(event,"left","none");}
;E.mousedown(cL,initCLDragFx);var bL=uL.cloneNode(false);aE(framer.left,bL);bL.style.marginTop="100%";bL.style.cursor="sw-resize";resizeBoxes["bL"]=bL;var initBLDragFx=function(event){thisObj.initDragFx(event,"left","down");}
;E.mousedown(bL,initBLDragFx);var uC=uL.cloneNode(false);aE(framer.top,uC);uC.style.marginLeft="50%";uC.style.cursor="n-resize";resizeBoxes["uC"]=uC;var initUCDragFx=function(event){thisObj.initDragFx(event,"none","up");}
;E.mousedown(uC,initUCDragFx);var bC=uL.cloneNode(false);aE(framer.bottom,bC);bC.style.marginLeft="50%";bC.style.cursor="s-resize";resizeBoxes["bC"]=bC;var initBCDragFx=function(event){thisObj.initDragFx(event,"none","down");}
;E.mousedown(bC,initBCDragFx);var uR=uL.cloneNode(false);aE(framer.right,uR);uR.style.cursor="ne-resize";resizeBoxes["uR"]=uR;var initURDragFx=function(event){thisObj.initDragFx(event,"right","up");}
;E.mousedown(uR,initURDragFx);var cR=uR.cloneNode(false);aE(framer.right,cR);cR.style.marginTop="50%";cR.style.cursor="e-resize";resizeBoxes["cR"]=cR;var initMRDragFx=function(event){thisObj.initDragFx(event,"right","none");}
;E.mousedown(cR,initMRDragFx);var bR=uR.cloneNode(false);aE(framer.right,bR);bR.style.marginTop="80%";bR.style.cursor="se-resize";resizeBoxes["bR"]=bR;var initMRDragFx=function(event){thisObj.initDragFx(event,"right","down");}
;E.mousedown(bR,initMRDragFx);}
;this.initDragFx=function(event,xDir,yDir){var dragInfo={}
;this.dragInfo=dragInfo;dragInfo.startX=event.clientX;dragInfo.startY=event.clientY;dragInfo.startWidth=this.element.offsetWidth;dragInfo.startHeight=this.element.offsetHeight;dragInfo.wHRatio=dragInfo.startWidth/dragInfo.startHeight;this.attachMoveFx(xDir,yDir);this.attachMouseUpFx(xDir,yDir);}
;this.attachMoveFx=function(xDir,yDir){this.framer.isLocked=true;ContainerHandler.disableFramers();var thisObj=this;var moveFx=function(e){thisObj.resizeFrame(e,xDir,yDir);}
;E.mousemove(document.body,moveFx);}
;this.resizeFrame=function(e,xDir,yDir){var dragInfo=this.dragInfo;var newWidth=0;var newHeight=0
if(xDir=="right"&&yDir=="down"){newHeight=dragInfo.startHeight+e.clientY-dragInfo.startY;newWidth=newHeight*dragInfo.wHRatio;}

else if(xDir=="right"&&yDir=="up"){newHeight=dragInfo.startHeight-(e.clientY-dragInfo.startY);newWidth=newHeight*dragInfo.wHRatio;}

else if(xDir=="left"&&yDir=="up"){newHeight=dragInfo.startHeight-(e.clientY-dragInfo.startY);newWidth=newHeight*dragInfo.wHRatio;}

else if(xDir=="left"&&yDir=="down"){newHeight=dragInfo.startHeight+e.clientY-dragInfo.startY;newWidth=newHeight*dragInfo.wHRatio;}

else if(xDir=="right"){newWidth=dragInfo.startWidth+e.clientX-dragInfo.startX;}

else if(xDir=="left"){newWidth=dragInfo.startWidth-(e.clientX-dragInfo.startX);}

else if(yDir=="up"){newHeight=dragInfo.startHeight-(e.clientY-dragInfo.startY);}

else if(yDir=="down"){newHeight=dragInfo.startHeight+(e.clientY-dragInfo.startY);}

if(newWidth){newWidth=Math.round(newWidth);this.framer.setWidth(newWidth,(xDir=="left"));}

if(newHeight){this.framer.setHeight(newHeight,(yDir=="up"));}

this.alignBoxes();return {width:newWidth,height:newHeight}
;}
;this.attachMouseUpFx=function(xDir,yDir){var thisObj=this;var fx=function(e){E.remove(document.body,"mouseup",fx);thisObj.finishResize(e,xDir,yDir);}
;E.add(document.body,"mouseup",fx);}
;this.finishResize=function(e,xDir,yDir){E.off(document.body,"mousemove");var element=this.element;var d=this.resizeFrame(e,xDir,yDir);var width=d.width||element.offsetWidth;var height=d.height||element.offsetHeight;element.style.width=width+"px";element.style.height=height+"px";var thisObj=this;var resetFx=function(){thisObj.framer.isLocked=false;}
;setTimeout(resetFx,1000);this.frame(this.element);ContainerHandler.enableFramers();if(element.tagName=="IMG"&&!UrlUtil.isFromOutsideDomain(element)){ImageUtil.optmize(element);}

LivePage.setElementToSave(element);}
;}
;

function IconGroup(){this.icons=[];}
;IconGroup.prototype=new IconGroupBase();function IconGroupBase(){this.type="group";this.update=function(){for(var i=0;i<this.icons.length;i++)
{var t=this.icons[i];if(t.update){t.update();}

}

}
;this.addIcon=function(icon){this.icons.push(icon);}
;}
;

function FlexDropDown(onChangeFx,onClickFx){this.options=[];this.optionsByValue={}
;this.onChangeFx=onChangeFx;this.onClickFx=onClickFx;}
;FlexDropDown.prototype=new FlexDropDownBase();function FlexDropDownBase(){this.width=30;this.height;this.value;this.displayHolder;this.displayFontSize;this.defaultOption;this.border="1px solid #B2B2B2";this.backgroundColor;this.padding=0;this.ddAlignment="belowRight";this.optionsBoxWidth;this.optionsBoxHeight;this.drawOuterBorder=true;this.offsetLeft=0;this.offsetTop=0;this.onBeforeShowOptions;this.useValueInput=false;this.addOptionEl=function(displayEl,value,isDefault,onMouseEnterFx,onMouseLeaveFx){var optionData={displayEl:displayEl,value:value,onMouseEnterFx:onMouseEnterFx,onMouseLeaveFx:onMouseLeaveFx}
;this.options.push(optionData);this.optionsByValue[value]=optionData;if(isDefault){this.defaultOption=optionData;}

}
;this.build=function(parentEl,width,initialValue){this.width=width;var holder=cE("div",parentEl);holder.style.padding=CssUtil.intToPixel(this.padding)||"";if(this.drawOuterBorder){holder.style.border=this.border||"";}

holder.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/dd_bg.gif)";holder.style.backgroundPosition="0 1px";holder.style.backgroundColor=this.backgroundColor||"white";holder.style.width=CssUtil.intToPixel(this.width);if(this.height){holder.style.height=CssUtil.intToPixel(this.height);}

var tBody=createTable(holder,"100%","100%");var table=tBody.parentNode;table.style.cursor="default";var thisObj=this;var onclickFx=function(){if(thisObj.onClickFx){thisObj.onClickFx();}

thisObj.showOptions(holder);}
;eh_attachEvent("onclick",table,onclickFx);var tr=cE("tr",tBody);var td=cE("td",tr);td.vAlign="middle";td.style.paddingLeft="5px";td.style.borderRight=this.border||"";var div=cE("div",td);div.style.overflow="hidden";div.style.width=CssUtil.intToPixel(this.width-25);this.displayHolder=div;if(this.useValueInput){this.buildValueInput(initialValue);}

else 
{this.selectValue(initialValue);}

var td=cE("td",tr);td.align="center";td.vAlign="middle";td.style.width="20px";td.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/dd_arrow.gif)";td.style.backgroundPosition="center center";return table;}
;this.buildValueInput=function(value){var input=cE("input",this.displayHolder);this.input=input;input.style.width=CssUtil.intToPixel(this.width);input.style.border=0;input.style.outline=0;input.style.fontSize=this.displayFontSize?CssUtil.intToPixel(this.displayFontSize):"12px";input.style.backgroundColor="transparent";input.value=value;var thisObj=this;var fx=function(){thisObj.onChangeFx(input.value);}
;E.change(input,fx);var fx=function(){}
;E.click(input,fx);}
;this.selectValue=function(value){if(this.useValueInput){this.selectInputValue(value);}

else 
{this.selectEnumValue(value);}

}
;this.selectInputValue=function(value){this.input.value=value;}
;this.selectEnumValue=function(value){var yPos=document.body.scrollTop;var xPos=document.body.scrollLeft;this.displayHolder.innerHTML="";var optionData=this.optionsByValue[value];if(!optionData){if(this.defaultOption){optionData=this.defaultOption;}

else 
{var span=cE("span",this.displayHolder);span.style.fontSize=0;span.innerHTML="&nbsp;";return ;}

}

this.value=optionData.value;if(!optionData){var span=cE("span",this.displayHolder);span.style.fontSize=0;span.innerHTML="&nbsp;";return ;}

var element=optionData.displayEl;var displayEl=element.cloneNode(true);displayEl.style.overflow="hidden";displayEl.style.lineHeight="";displayEl.style.width=(this.width-25)+"px";if(this.displayFontSize){displayEl.style.fontSize=CssUtil.intToPixel(this.displayFontSize);}

aE(this.displayHolder,displayEl);window.scrollTo(xPos,yPos);}
;this.showOptions=function(positionEl){var popup=new Popup();popup.doc=this.doc||document;if(this.onBeforeShowOptions){this.onBeforeShowOptions();}

popup.setAsAnchor(positionEl,this.ddAlignment,this.offsetLeft-1,this.offsetTop);var contentArea=popup.build();contentArea.style.border="1px solid #B2B2B2";contentArea.style.cursor="default";contentArea.style.overflowY="auto";var tBody=createTable(contentArea,"100%");var td=cC(tBody);for(var i=0;i<this.options.length;i++)
{this.createOption(td,this.options[i],popup);}

if(this.optionsBoxWidth){contentArea.style.width=CssUtil.intToPixel(this.optionsBoxWidth);}

if(this.optionsBoxHeight){contentArea.style.height=CssUtil.intToPixel(this.optionsBoxHeight);}

popup.align();}
;this.createOption=function(parentEl,optionData,popup){var thisObj=this;var holder=cE("div",parentEl);holder.style.padding="2px 30px 2px 15px";var displayEl=optionData.displayEl.cloneNode(true);aE(holder,displayEl);if(optionData.onMouseEnterFx){var onOverFx=function(){holder.style.backgroundColor="#E0DFE3";if(optionData.onMouseEnterFx){optionData.onMouseEnterFx();}

}
;E.mouseenter(holder,onOverFx);var onOutFx=function(){holder.style.backgroundColor="";if(optionData.onMouseLeaveFx){optionData.onMouseLeaveFx();}

}
;E.mouseleave(holder,onOutFx);var fx=function(value){popup.close();thisObj.selectValue(optionData.value);thisObj.onChangeFx(optionData.value);}
;E.click(holder,fx);}

else 
{var onOverFx=function(){holder.style.backgroundColor="#E0DFE3";}
;eh_attachEvent("onmouseover",holder,onOverFx);var onOutFx=function(){holder.style.backgroundColor="";}
;eh_attachEvent("onmouseout",holder,onOutFx);var fx=function(value){popup.close();thisObj.selectValue(optionData.value);thisObj.onChangeFx(optionData.value);}
;eh_attachEvent("onclick",holder,fx);}

}
;}


;function FontSelector(){this.fontSize=12;this.defaults=["arial","comic sans ms","courier new","garamond","georgia","helvetica","lucida sans unicode","tahoma","times new roman","trebuchet MS","verdana"];this.width=70;this.build=function(parentEl){var holder=cE("div",parentEl);var thisObj=this;var fx=function(value){thisObj.onChange(value);}
;var dd=new FlexDropDown(fx);this.dd=dd;dd.drawOuterBorder=false;dd.height=22;dd.ddAlignment="belowRight";dd.useValueInput=true;dd.doc=(g_params["utw"]=="true")?window.top.document:document;var fonts=this.findFonts(dd);for(var i=0;i<fonts.length;i++)
{this.addFont(fonts[i],dd);}

for(var i=0;i<this.defaults.length;i++)
{this.addFont(this.defaults[i],dd);}

var ddEl=dd.build(holder,this.width,this.getSelFont());var thisObj=this;dd.onBeforeShowOptions=function(){var frame=EditUtil.getIconBar().frame;var coord=findElCoord(frame,false);dd.offsetLeft=coord.x;dd.offsetTop=coord.y+1;}
;}
;this.findFonts=function(dd){var fonts=[];var usedFonts=LiveCss.findFonts();for(var i=0;i<usedFonts.length;i++)
{var fontValue=usedFonts[i];if(!this.ignoreFont(fontValue)){fonts.push(fontValue);}

}

return fonts;}
;this.ignoreFont=function(fontValue){var map=this.getDefaultMap();return (map[fontValue.toLowerCase()])?true:false;}
;this.getDefaultMap=function(){if(this.defaultMap){return this.defaultMap;}

var map=this.defaultMap={}
;for(var i=0;i<this.defaults.length;i++)
{map[this.defaults[i]]=1;}

return map;}
;this.getSelFont=function(){var range=RangeUtil.getSelectedRange();return RangeUtil.getStyle(range,"font-family");}
;this.onChange=function(value){var styleObj={fontFamily:value}
;var range=EditUtil.getIconBar().storedRange;RangeUtil.applyStyles(range,styleObj);}
;this.addFont=function(value,dd,isDefault){var span=cE("span");span.style.fontSize=this.fontSize+"px";span.style.fontFamily=value;span.style.whiteSpace="nowrap";span.innerHTML=value;span.style.color="black";var thisObj=this;var enterFx=function(){thisObj.setTempValue(value);}
;var leaveFx=function(){thisObj.setTempValue(thisObj.realValue);}
;dd.addOptionEl(span,value,isDefault,enterFx,leaveFx);return span;}
;this.setTempValue=function(value){if(!this.realValue){this.realValue=this.getSelFont();}

var styleObj={fontFamily:value}
;var range=EditUtil.getIconBar().storedRange;range=RangeUtil.applyStyles(range,styleObj);EditUtil.getIconBar().storedRange=range;RangeUtil.selectRange(range);}
;this.update=function(){this.dd.selectValue(this.getSelFont());}
;this.getHelpTip=function(){var msg="Font";var current=this.getSelFont();if(current){msg+=" - "+current;}

return msg;}
;}
;

;function FontSizeSelector(){this.width=55;this.dd;this.tempValue;this.build=function(parentEl){var holder=cE("div",parentEl);var thisObj=this;var fx=function(value){thisObj.onChange(value);}
;var dd=new FlexDropDown(fx);this.dd=dd;dd.drawOuterBorder=false;dd.ddAlignment="belowRight";dd.height=22;dd.displayFontSize=12;dd.optionsBoxWidth=60;dd.optionsBoxHeight="90%";dd.useValueInput=true;dd.doc=(g_params["utw"]=="true")?window.top.document:document;this.addFontSize("8","8px",dd);this.addFontSize("9","9px",dd);this.addFontSize("10","10px",dd);this.addFontSize("11","11px",dd);this.addFontSize("12","12px",dd);this.addFontSize("14","14px",dd);this.addFontSize("16","16px",dd);this.addFontSize("18","18px",dd);this.addFontSize("20","20px",dd);this.addFontSize("22","22px",dd);this.addFontSize("24","24px",dd);this.addFontSize("26","26px",dd);this.addFontSize("28","28px",dd);this.addFontSize("36","36px",dd);this.addFontSize("40","40px",dd);this.addFontSize("44","44px",dd);this.addFontSize("48","48px",dd);this.addFontSize("52","52px",dd);this.addFontSize("58","58px",dd);this.addFontSize("64","64px",dd);this.addFontSize("72","72px",dd);this.addFontSize("80","80px",dd);this.addFontSize("86","86px",dd);this.addFontSize("92","92px",dd);this.addFontSize("100","100px",dd);this.addFontSize("110","110px",dd);this.addFontSize("120","120px",dd);this.addFontSize("130","130px",dd);this.addFontSize("140","140px",dd);this.addFontSize("150","150px",dd);this.addFontSize("175","175px",dd);this.addFontSize("200","200px",dd);this.addFontSize("225","225px",dd);this.addFontSize("250","250px",dd);this.addFontSize("300","300px",dd);this.addFontSize("400","400px",dd);this.addFontSize("500","500px",dd);this.addFontSize("600","600px",dd);this.addFontSize("700","700px",dd);this.addFontSize("800","800px",dd);this.addFontSize("900","900px",dd);this.addFontSize("1000","1000px",dd);this.addFontSize("1080","1080px",dd);this.addFontSize("1200","1200px",dd);var ddEl=dd.build(holder,this.width,this.getSelFontSize());dd.onBeforeShowOptions=function(){var frame=EditUtil.getIconBar().frame;var coord=findElCoord(frame,false);dd.offsetLeft=coord.x;dd.offsetTop=coord.y+1;}
;}
;this.update=function(){this.dd.selectValue(this.getSelFontSize());}
;this.getSelFontSize=function(){var range=RangeUtil.getSelectedRange();return RangeUtil.getStyle(range,"font-size");}
;this.selectFontSize=function(value){value=value||"";this.dd.selectValue(value);}
;this.addFontSize=function(displayName,fontSize,dd){var span=cE("span");span.style.fontFamily="helvetica";span.innerHTML=displayName;span.style.color="black";var thisObj=this;var enterFx=function(){thisObj.setTempValue(fontSize);}
;var leaveFx=function(){thisObj.setTempValue(thisObj.realValue);}
;dd.addOptionEl(span,fontSize,false,enterFx,leaveFx);return span;}
;this.setTempValue=function(value){if(!this.realValue){this.realValue=this.getSelFontSize();}

var styleObj={fontSize:value}
;var range=EditUtil.getIconBar().storedRange;range=RangeUtil.applyStyles(range,styleObj);EditUtil.getIconBar().storedRange=range;RangeUtil.selectRange(range);}
;this.onChange=function(value){var styleObj={fontSize:value}
;var range=EditUtil.getIconBar().storedRange;range=RangeUtil.applyStyles(range,styleObj);EditUtil.getIconBar().storedRange=range;RangeUtil.selectRange(range);this.update();}
;this.helpTip="Select Font Size";}
;

function FontColorIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="36px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/font_color_icon.gif)";var anchor=div;var thisObj=this;var onclickFx=function(){var popup=new ColorPopup(anchor,fx);popup.doc=(g_params["utw"]=="true")?window.top.document:document;var fx=function(){thisObj.onChange(popup);}
;popup.onChange=fx;popup.closeFx=function(){fx(popup.color);}
;var frame=EditUtil.getIconBar().frame;var coord=findElCoord(frame,false);popup.offsetLeft=coord.x-1;popup.offsetTop=coord.y+2;popup.build();}

E.click(parentEl,onclickFx);}
;this.onChange=function(popup){var value=popup.color;var range=popup.popup.storedRange;var styleObj={color:value}
;popup.popup.storedRange=RangeUtil.applyStyles(range,styleObj);var selection=window.getSelection();selection.removeAllRanges();}
;this.helpTip="Select Font Color";}


function BackgroundColorIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="36px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/font_bg_color_icon.gif)";var anchor=div;var thisObj=this;var onclickFx=function(){var popup=new ColorPopup(anchor,fx);var fx=function(){thisObj.onChange(popup);}
;popup.onChange=fx;popup.closeFx=function(){fx(popup.color);}
;var frame=EditUtil.getIconBar().frame;var coord=findElCoord(frame,false);popup.offsetLeft=coord.x-1;popup.offsetTop=coord.y+2;popup.build();}
;E.click(parentEl,onclickFx);}
;this.onChange=function(popup){var value=popup.color;var range=popup.popup.storedRange;var styleObj={backgroundColor:value}
;popup.popup.storedRange=RangeUtil.applyStyles(range,styleObj);var selection=window.getSelection();selection.removeAllRanges();}
;this.helpTip="Highlight Color";}
;

function BoldIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/bold_icon.gif)";var thisObj=this;var onclickFx=function(){if(B.isIE()||B.isFF()){alert("embolden");}

else 
{var range=RangeUtil.getSelectedRange();var clickTime=new Date();var value="bold";if(thisObj.lastClickedTime&&((clickTime-thisObj.lastClickedTime<5000))){value=(thisObj.lastPropValue=="bold")?"normal":"bold";}

var styleObj={"fontWeight":value}
;RangeUtil.applyStyles(range,styleObj);thisObj.lastPropValue=value;thisObj.lastClickedTime=new Date();}

}
;E.click(parentEl,onclickFx);}
;this.helpTip="Embolden";}


function ItalicIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/italic_icon.gif)";var thisObj=this;var onclickFx=function(){if(B.isIE()||B.isFF()){alert("embolden");}

else 
{var range=RangeUtil.getSelectedRange();var clickTime=new Date();var value="italic";if(thisObj.lastClickedTime&&((clickTime-thisObj.lastClickedTime<5000))){value=(thisObj.lastPropValue=="italic")?"normal":"italic";}

var styleObj={"fontStyle":value}
;RangeUtil.applyStyles(range,styleObj);thisObj.lastPropValue=value;thisObj.lastClickedTime=new Date();}

}
;E.click(parentEl,onclickFx);}
;this.helpTip="Italicize";}


function UnderlineIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/underline_icon.gif)";var thisObj=this;var onclickFx=function(){if(B.isIE()||B.isFF()){alert("embolden");}

else 
{var range=RangeUtil.getSelectedRange();var clickTime=new Date();var value="underline";if(thisObj.lastClickedTime&&((clickTime-thisObj.lastClickedTime<5000))){value=(thisObj.lastPropValue=="underline")?"none":"underline";}

var styleObj={"textDecoration":value}
;RangeUtil.applyStyles(range,styleObj);thisObj.lastPropValue=value;thisObj.lastClickedTime=new Date();}

}
;E.click(parentEl,onclickFx);}
;this.helpTip="Underline";}


function BulletsIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/ul_icon.gif)";var thisObj=this;var onclickFx=function(){var range=RangeUtil.getSelectedRange();var startBlock=getAncestorByStyle(RangeUtil.getStartContainer(range),"display","block");var endBlock=getAncestorByStyle(RangeUtil.getEndContainer(range),"display","block");if(!startBlock&&!endBlock){return ;}

if(startBlock==endBlock&&isTagType(startBlock,["OL","UL"])){var oldLi=range.startContainer.parentNode;while(!isTagType(oldLi,["LI"]))
{oldLi=oldLi.parentNode;}

var newEl=cE("p");newEl.innerHTML=oldLi.innerHTML;if(null==oldLi.previousElementSibling){startBlock.parentNode.insertBefore(newEl,startBlock);}

else if(startBlock.nextElementSibling){startBlock.parentNode.insertBefore(newEl,startBlock.nextElementSibling);}

else 
{startBlock.parentNode.appendChild(newEl);}

var focusEl=(oldLi.nextElementSibling||oldLi.previousElementSibling||startBlock.nextElementSibling||startBlock.previousElementSibling);if(oldLi.parentNode.children.length==1){oldLi.parentNode.parentNode.removeChild(oldLi.parentNode);}

else 
{oldLi.parentNode.removeChild(oldLi);}

range.setStartBefore(focusEl);range.setEndBefore(focusEl);window.getSelection().removeAllRanges();window.getSelection().addRange(range);return ;}

document.execCommand('InsertUnorderedList',false,null);window.focus();}
;E.click(parentEl,onclickFx);}
;this.helpTip="Insert/Remove Bullets List";}
;

function NumberingIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/ol_icon.gif)";var thisObj=this;var onclickFx=function(){var range=RangeUtil.getSelectedRange();var startBlock=getAncestorByStyle(RangeUtil.getStartContainer(range),"display","block");var endBlock=getAncestorByStyle(RangeUtil.getEndContainer(range),"display","block");if(!startBlock&&!endBlock){return ;}

if(startBlock==endBlock&&isTagType(startBlock,["OL","UL"])){var oldLi=range.startContainer.parentNode;while(!isTagType(oldLi,["LI"]))
{oldLi=oldLi.parentNode;}

var newEl=cE("p");newEl.innerHTML=oldLi.innerHTML;if(null==oldLi.previousElementSibling){startBlock.parentNode.insertBefore(newEl,startBlock);}

else if(startBlock.nextElementSibling){startBlock.parentNode.insertBefore(newEl,startBlock.nextElementSibling);}

else 
{startBlock.parentNode.appendChild(newEl);}

var focusEl=(oldLi.nextElementSibling||oldLi.previousElementSibling||startBlock.nextElementSibling||startBlock.previousElementSibling);if(oldLi.parentNode.children.length==1){oldLi.parentNode.parentNode.removeChild(oldLi.parentNode);}

else 
{oldLi.parentNode.removeChild(oldLi);}

range.setStartBefore(focusEl);range.setEndBefore(focusEl);window.getSelection().removeAllRanges();window.getSelection().addRange(range);return ;}

document.execCommand('InsertOrderedList',false,null);window.focus();}
;E.click(parentEl,onclickFx);}
;this.helpTip="Insert/Remove Bullets List";}
;

function AlignLeftIcon(){this.build=function(parentEl){var div=cE("div",parentEl);div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/align_left_icon.gif)";div.style.width="23px";div.style.height="22px";var onclickFx=function(){LivePage.exec("JustifyLeft");}
;E.click(parentEl,onclickFx);}
;this.helpTip="Align Left";}


function AlignMiddleIcon(){this.build=function(parentEl){var div=cE("div",parentEl);div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/align_middle_icon.gif)";div.style.width="23px";div.style.height="22px";var onclickFx=function(){LivePage.exec("JustifyCenter");}
;E.click(parentEl,onclickFx);}
;this.helpTip="Align Left";}


function AlignRightIcon(){this.build=function(parentEl){var div=cE("div",parentEl);div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/align_right_icon.gif)";div.style.width="23px";div.style.height="22px";var onclickFx=function(){LivePage.exec("JustifyRight");
}
;E.click(parentEl,onclickFx);}
;this.helpTip="Align Left";}


function IndentIcon(){this.indentPixels=40;this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/push_right_icon.gif)";div.style.width="23px";div.style.height="22px";var thisObj=this;var onclickFx=function(event){EditUtil.indent();window.focus();}
;E.click(parentEl,onclickFx);}
;this.helpTip="Indent";}
;

function UnindentIcon(){this.helpTip="Un-indent";this.indentPixels=40;this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/pull_left_icon.gif)";var thisObj=this;var onclickFx=function(){EditUtil.unindent();window.focus();}
;E.click(parentEl,onclickFx);}
;}
;

function LineSpacingIcon(){this.helpTip="Adjust Line Spacing";this.build=function(parentEl){var div=cE("div",parentEl);div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/line_space_icon.gif)";div.style.width="36px";div.style.height="22px";var thisObj=this;var onclickFx=function(){var menu=new DropdownMenu();menu.doc=(g_params["utw"]=="true")?window.top.document:document;menu.showDragger=false;var fx=function(){thisObj.adjustLineSpacing(1);}
;var item=new StandardMenuItem("1.0",fx);menu.addMenuItem(item);var fx=function(){thisObj.adjustLineSpacing(1.15);}
;var item=new StandardMenuItem("1.15",fx);menu.addMenuItem(item);var fx=function(){thisObj.adjustLineSpacing(1.5);}
;var item=new StandardMenuItem("1.5",fx);menu.addMenuItem(item);var fx=function(){thisObj.adjustLineSpacing(1.75);}
;var item=new StandardMenuItem("1.75",fx);menu.addMenuItem(item);var fx=function(){thisObj.adjustLineSpacing(2);}
;var item=new StandardMenuItem("2.0",fx);menu.addMenuItem(item);var fx=function(){thisObj.adjustLineSpacing(2.5);}
;var item=new StandardMenuItem("2.5",fx);menu.addMenuItem(item);var fx=function(){thisObj.adjustLineSpacing(3);}
;var item=new StandardMenuItem("3.0",fx);menu.addMenuItem(item);var frame=EditUtil.getIconBar().frame;var frameLoc=findElCoord(frame,false);var coord=findElCoord(div,true);menu.build(coord.x+frameLoc.x,coord.y+div.offsetHeight+2+frameLoc.y);}
;E.click(parentEl,onclickFx);}
;this.adjustLineSpacing=function(value){var styleObj={lineHeight:value}
;var range=EditUtil.getIconBar().storedRange;RangeUtil.applyStyles(range,styleObj);}
;this.helpTip="Adjust Line Spacing";}


function RemoveFormatIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="24px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/remove_frmt_icon.gif)";var thisObj=this;var onclickFx=function(){if(!B.isIE()){LivePage.exec("RemoveFormat");}

else 
{alert("implement remove format icon for IE");}

}
;E.click(parentEl,onclickFx);}
;this.helpTip="Remove Formatting";}


function TableInserter(){this.showRows=10;this.showColumns=10;this.infoBox;this.popup;this.allowedParents={"body":1,"div":1,"td":1}
;this.build=function(positionIcon){var popup=new Popup();popup.closeFx=this.close;popup.doc=(g_params["utw"]=="true")?window.top.document:document;var frame=EditUtil.getIconBar().frame;var coord=findElCoord(frame,false);var left=coord.x;var top=coord.y+1;popup.setAsAnchor(positionIcon,"belowRight",left,top);this.popup=popup;var contentArea=popup.build();contentArea.style.border="1px solid #ABABAB";contentArea.style.backgroundColor="#CBCBCB";contentArea.style.padding="2px";this.buildGrid(contentArea);this.buildInfoBox(contentArea);popup.align();}
;this.close=function(){this.infoBox=null;this.popup=null;}
;this.buildInfoBox=function(parentEl){var infoBox=cE("div",parentEl);infoBox.style.fontFamily="arial";infoBox.style.fontSize="12px";infoBox.align="center";infoBox.style.border="1px solid #ABABAB";infoBox.style.padding="2px";infoBox.style.margin="2px";infoBox.style.cursor="default";infoBox.innerHTML="Cancel";this.infoBox=infoBox;var tI=this;var onClickFx=function(){tI.popup.close();}
;eh_attachEvent("onclick",infoBox,onClickFx);}
;this.buildGrid=function(parentEl){var tBody=createTable(parentEl);var table=tBody.parentNode;table.cellSpacing=0;table.style.cursor="default";var tI=this;var onMouseOutFx=function(){tI.cancel(tBody);}
;eh_attachEvent("onmouseout",table,onMouseOutFx);for(var i=0;i<this.showRows;i++)
{var tr=cE("tr",tBody);for(var j=0;j<this.showColumns;j++)
{var td=cE("td",tr);td.style.backgroundColor="#CBCBCB";td.row=i;td.column=j;this.attachCellEvent(td,tr,tBody);var div=cE("div",td);div.style.margin="1px";div.style.width="20px";div.style.height="20px";div.style.backgroundColor="white";div.innerHTML="&nbsp;";}

}

}
;this.cancel=function(tBody){for(var i=0;i<tBody.childNodes.length;i++)
{var tr=tBody.childNodes[i];for(var j=0;j<tr.childNodes.length;j++)
{tr.childNodes[j].childNodes[0].style.backgroundColor="white";}

}

this.infoBox.innerHTML="Cancel";}
;this.attachCellEvent=function(td,tr,tBody){var thisObj=this;var onMouseOverFx=function(){for(var i=0;i<tBody.childNodes.length;i++)
{var tr=tBody.childNodes[i];for(var j=0;j<tr.childNodes.length;j++)
{tr.childNodes[j].childNodes[0].style.backgroundColor=(i<=td.row&&j<=td.column)?"#2C61B9":"white";}

}

thisObj.infoBox.innerHTML=(td.row+1)+" x "+(td.column+1)+" Table";}
;eh_attachEvent("onmouseover",td,onMouseOverFx);var onClickFx=function(){thisObj.insertTable(td.row+1,td.column+1);thisObj.popup.close();}
;eh_attachEvent("onclick",td,onClickFx);}
;this.insertTable=function(rows,columns){var placeHolder=cE("span");var range=EditUtil.getRange();RangeUtil.selectRange(range);RangeUtil.insertNode(range,placeHolder);var block=getAncestorByStyle(placeHolder,"display","block");placeHolder.parentNode.removeChild(placeHolder);var table=this.createTable(rows,columns);if(block.nextSibling){block.parentNode.insertBefore(table,block.nextSibing);}

else 
{aE(block.parentNode,table);}

var setting=CssUtil.getStyle(table,"display");if(setting!="table"){table.style.display="table";}

BlockHandler.initBlock(table);LivePage.setElementToSave(table);}

this.createTable=function(rows,columns){var table=cE("table");table.style.width="100%";var colWidth=Math.ceil(100/columns)+"%";var tBody=cE("tbody",table);for(var i=0;i<rows;i++)
{var tr=cE("tr",tBody);for(var j=0;j<columns;j++)
{var td=cE("td",tr);td.innerHTML="&nbsp;";td.style.width=colWidth;}

}

return table;}
;}
;

;function TableIcon(){this.build=function(parentEl){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="24px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/table_icon.gif)";var thisObj=this;var onclickFx=function(){var tableInserter=new TableInserter();tableInserter.build(parentEl);}
;E.click(parentEl,onclickFx);}
;this.helpTip="Insert Table";}


function DividerLineIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="24px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/divider_line_icon.gif)";var thisObj=this;var onclickFx=function(){var range=EditUtil.iconBar.storedRange;var hr=cE("hr");RangeUtil.insertNode(range,hr);}
;E.click(parentEl,onclickFx);}
;this.helpTip="Insert Divider Line";}


function CharacterMapIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="24px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/char_map_icon.gif)";var thisObj=this;var onclickFx=function(){var onInsert=function(charData){var code=charData.htmlCode||charData.numCode;var range=EditUtil.iconBar.storedRange;if(BrowserUtil.isIE()){range.pasteHTML(code);range.select();}

else 
{range.deleteContents();var node=cE("span",null,document);node.innerHTML=code;range.insertNode(node);removeNode(node);}

}
;var fx=function(){var map=new CharacterMap(onInsert);map.build();}
;sl_loadScript('/0/le8585_0.js',fx);fx;}
;E.click(parentEl,onclickFx);}
;this.helpTip="Insert Special Character";}

;;
var dropdown_registry=new Array();var dropdown_count=0;function dropdown_Dropdown(rootElement,optionList,name,onchange,initialValue,inputWidth){this.rootElement=rootElement;this.optionList=dropdown_copyOptionList(optionList);this.name=name;this.onchange=onchange;this.initialValue=initialValue;this.inputWidth=inputWidth;this.maxOptionLength=30;this.id=dropdown_count++;this.ddComponent;this.input;this.valueHolder;this.arrowBox;this.optionHolder;this.optionHolderAnchor;this.fontSize=13;this.highlightedOption;this.previousSelection;this.selectedOption;this.container;this.pendingChange=false;this.resetDD=function(){dropdown_initializeSelection(this,"")}
;this.disableDD=function(){this.input.style.backgroundColor="#ECECF1";dropdown_removeDropdownEvents(this)
}
;this.enableDD=function(){this.input.style.backgroundColor="white";dropdown_attachDropdownEvents(this)
}
;this.init=function(){dropdown_init(this)}
;this.getValue=function(){return dropdown_getValue(this);}
;this.adjustWidth=function(width){dropdown_adjustWidth(this,width)}
;dropdown_registry.push(this);return this;}

var dropdown_activeDropdown;function dropdown_Option(name,value){this.name=name;this.value=value;}

function dropdown_adjustWidth(dropdown,width){if(width==null||width==""){return ;}

dropdown.ddComponent.style.width=dropdown_intToPixel(width);dropdown.input.style.width=dropdown_intToPixel(parseInt(width)-18);dropdown.optionHolder.style.width=dropdown_getOptionContainerWidth(dropdown,width);}

function dropdown_init(thisDD){dropdown_createDropdown(thisDD);}

function dropdown_intToPixel(value){return (typeof(value)=="number")?value+"px":value;}
;function dropdown_copyOptionList(optionList){var newOptionList=new Array();for(var i=0;i<optionList.length;i++)
{newOptionList[i]=new dropdown_Option(optionList[i].name,optionList[i].value);}

return newOptionList;}

function dropdown_getValue(dropdown){return dropdown.selectedOption.value;}

function dropdown_showSelected(dropdown){dropdown.input.style.backgroundColor="#B2B4BF";}

function dropdown_showUnselected(dropdown){dropdown.input.style.backgroundColor="";}

function dropdown_createDropdown(dropdown){dropdown_createDropdownElements(dropdown);dropdown_attachDropdownEvents(dropdown);}

function dropdown_selectOptionByName(dropdown,name){var option=null;for(var i=0;i<dropdown.optionList.length;i++)
{if(dropdown.optionList[i].name==name){option=dropdown.optionList[i];}

}

if(null!=option){dropdown_selectOption(dropdown,option);}

}

function dropdown_selectOptionByValue(dropdown,value){var option=null;for(var i=0;i<dropdown.optionList.length;i++)
{if(dropdown.optionList[i].value==value){option=dropdown.optionList[i];}

}

if(null!=option){dropdown_selectOption(dropdown,option);}

}

function dropdown_selectOption(dropdown,option){try
{if(IS_IE){option.element.focus();}

else if(IS_MOZILLA){option.element.scrollIntoView(false);}

}

catch(e)
{}

dropdown.valueHolder.value=option.value;dropdown.input.value=option.name;dropdown.value=option.value;dropdown.selectedOption=option;dropdown_highlightOption(option,dropdown);if(dropdown.optionHolder.style.display=="none"){dropdown_finishSelection(dropdown);}

}

function dropdown_finishSelection(dropdown){dropdown.optionHolderAnchor.style.display="none";dropdown.pendingChange=false;dropdown.optionHolder.style.display="none";dropdown_adjustDropdownLook(dropdown,false);if(null!=dropdown.onchange&&dropdown.previousSelection!=dropdown.selectedOption){dropdown.onchange(dropdown);}

dropdown.previousSelection=dropdown.selectedOption;document.onselectstart=null;crossbrowser_removeEvent(document,"onclick",dropdown.hideFx);}

function dropdown_initializeSelection(dropdown,value){var option=null;for(var i=0;i<dropdown.optionList.length;i++)
{if(areOptionsEqual(dropdown.optionList[i].value,value)){option=dropdown.optionList[i];break;}

}

if(option){dropdown.valueHolder.value=option.value;dropdown.input.value=option.name;dropdown.value=option.value;dropdown.selectedOption=option;dropdown.previousSelection=dropdown.selectedOption;dropdown_highlightOption(option,dropdown);}

}

function areOptionsEqual(value1,value2){var isValue1Object=(typeof(value1)=='object');var isValue2Object=(typeof(value2)=='object');if(isValue1Object!=isValue2Object){return false;}

else if(!isValue1Object){return (value1==value2);}

else 
{if(value1==null||value2==null){return (value1==value2);}

for(var i in value1)
{if(!areOptionsEqual(value1[i],value2[i])){return false;}

}

return true;}

}

function dropdown_createDropdownElements(dropdown){var table=document.createElement("table");table.cellSpacing=0;table.cellPadding=0;table.style.width=dropdown_intToPixel(dropdown.inputWidth);dropdown.ddComponent=table;dropdown.rootElement.appendChild(table);dropdown.container=table;var tBody=document.createElement("tbody");table.appendChild(tBody);var tr=document.createElement("tr");tBody.appendChild(tr);var td=document.createElement("td");tr.appendChild(td);var input=document.createElement("input");input.type="hidden";if(null!=dropdown.name&&""!=dropdown.name){input.name=dropdown.name;}

td.appendChild(input);dropdown.valueHolder=input;var input=document.createElement("input");input.readOnly=true;input.style.border="1px solid #A5ACB2";input.style.paddingLeft="3px";input.style.height="21px";input.style.width=(dropdown.inputWidth-16)+"px";input.style.cursor="";input.style.fontSize=dropdown_intToPixel(dropdown.fontSize);input.type="text";dropdown.input=input;td.appendChild(input);var td=document.createElement("td");td.vAlign="middle";td.align="center";tr.appendChild(td);var arrowBox=document.createElement("table");arrowBox.cellSpacing=0;arrowBox.cellPadding=0;arrowBox.style.height="21px";arrowBox.style.width="18px";dropdown.arrowBox=arrowBox;td.appendChild(arrowBox);var ntBody=document.createElement("tbody");arrowBox.appendChild(ntBody);var ntr=document.createElement("tr");ntBody.appendChild(ntr);var ntd=document.createElement("td");ntd.vAlign="middle";ntd.align="center";ntr.appendChild(ntd);var image=document.createElement("img");image.src="/upload/js_globals/generic_images/down_arrow.gif";image.style.top="8px";ntd.appendChild(image);var tr=document.createElement("tr");tBody.appendChild(tr);var td=document.createElement("td");tr.appendChild(td);var optionHolderAnchor=document.createElement("div");optionHolderAnchor.style.position="absolute";optionHolderAnchor.style.backgroundColor="white";optionHolderAnchor.style.border="1px solid #A5ACB2";optionHolderAnchor.style.display="none";optionHolderAnchor.style.zIndex=1000;dropdown.optionHolderAnchor=optionHolderAnchor;td.appendChild(optionHolderAnchor);var optionHolder=document.createElement("table");optionHolder.cellPadding=0;optionHolder.cellSpacing=0;optionHolder.style.display="none";optionHolder.style.width=dropdown_intToPixel(dropdown.inputWidth);optionHolderAnchor.appendChild(optionHolder);var optionTBody=document.createElement("tbody");optionHolder.appendChild(optionTBody);var optionTr=document.createElement("tr");optionTBody.appendChild(optionTr);var optionTd=document.createElement("td");optionHolder.align="left";optionHolder.style.fontWeight="normal";dropdown.optionHolder=optionHolder;optionTr.appendChild(optionTd);var optionsLength=dropdown.optionList.length;if(optionsLength>dropdown.maxOptionLength){optionHolderAnchor.style.height="250px";optionHolderAnchor.style.overflowY="scroll";}

dropdown_adjustDropdownLook(dropdown,false);for(var i=0;i<dropdown.optionList.length;i++)
{dropdown_appendOption(dropdown.optionList[i],dropdown,optionTBody);dropdown.optionList[i].index=i;}

dropdown_initializeSelection(dropdown,dropdown.initialValue);}

function dropdown_getOptionContainerWidth(dropdown,width){inputWidth=(width==null)?dropdown.inputWidth:parseInt(width)-2;return (dropdown.optionList.length>30)?inputWidth:inputWidth;}

function dropdown_adjustDropdownLook(dropdown,isActive){var color=isActive?"#A5ACB2":"white";dropdown.input.style.border="1px solid #A5ACB2";dropdown.arrowBox.style.borderRight="1px solid #A5ACB2";dropdown.arrowBox.style.borderTop="1px solid #A5ACB2";dropdown.arrowBox.style.borderBottom="1px   solid  #A5ACB2";dropdown.arrowBox.style.backgroundColor=(isActive)?"#CBCCDA":"#ECECF1";}

function dropdown_appendOption(option,dropdown,optionTBody){var optionTr=document.createElement("tr");optionTBody.appendChild(optionTr);var optionName=option.name
try
{optionName=optionName.replace(/^\s+|\s+$/g,'')
if(optionName==""){optionName="&nbsp;"
}

}

catch(e){}

var optionElement=document.createElement("td");optionElement.style.fontFamily="Arial, Helvetica, sans-serif";optionElement.style.fontSize=dropdown_intToPixel(dropdown.fontSize);optionElement.style.cursor="default";optionElement.style.paddingLeft="3px";optionElement.style.paddingRight="20px";optionElement.innerHTML="<nobr>"+optionName+"</nobr>";optionTr.appendChild(optionElement);option.element=optionElement;var onmouseoverFx=function(){dropdown_highlightOption(option,dropdown)}
;eh_attachEvent("onmouseover",optionElement,onmouseoverFx);var onclickFx=function(event){dropdown_selectOption(dropdown,option);dropdown_finishSelection(dropdown);crossbrowser_stopEvent(event);}

eh_attachEvent("onclick",optionElement,onclickFx);}

function dropdown_highlightOption(option,dropdown){if(null==option){return ;}

if(null!=dropdown.highlightedOption&&'undefined'!=dropdown.highlightedOption){dropdown.highlightedOption.element.style.backgroundColor="";}

dropdown.highlightedOption=option;dropdown.highlightedOption.element.style.backgroundColor="#B2B4BF";}

function dropdown_attachDropdownEvents(dropdown){var onclickFx=function(event){if(IS_MOZILLA){dropdown.input.focus();}

dropdown_openOptions(dropdown,event);}
;eh_attachEvent("onclick",dropdown.arrowBox,onclickFx);var onclickFx=function(event){dropdown_openOptions(dropdown,event);}
;eh_attachEvent("onclick",dropdown.input,onclickFx);var onkeydownFx=function(event){var key=crossbrowser_getKeyCode(event);if(key==9&&dropdown.optionHolder.style.display=="none"){}

else 
{dropdown_handleKeyPress(dropdown,event);}

}
;eh_attachEvent("onkeydown",dropdown.container,onkeydownFx);var onfocusFx=function(){document.onselectstart=null;}
;eh_attachEvent("onfocus",dropdown.input,onfocusFx);var onmouseoverFx=function(){dropdown_adjustDropdownLook(dropdown,true)}
;eh_attachEvent("onmouseover",dropdown.container,onmouseoverFx);var onmouseoutFx=function(){if(!dropdown.pendingChange){dropdown_adjustDropdownLook(dropdown,false);}

}

eh_attachEvent("onmouseout",dropdown.container,onmouseoutFx);var onfocusFx=function(){dropdown_showSelected(dropdown)}
;eh_attachEvent("onfocus",dropdown.input,onfocusFx);var onselectstartFx=function(){return false}
;eh_attachEvent("onselectstart",dropdown.input,onselectstartFx);var onblurFx=function(){dropdown_showUnselected(dropdown)}
;eh_attachEvent("onblur",dropdown.input,onblurFx);}

function dropdown_removeDropdownEvents(dropdown){dropdown.arrowBox.onclick=null;dropdown.input.onclick=null;dropdown.container.onkeydown=null;dropdown.input.onfocus=null;dropdown.container.onmouseover=null;dropdown.container.onmouseout=null;dropdown.input.onblur=null;}

function dropdown_openOptions(dropdown,event){crossbrowser_stopEvent(event);if(dropdown_activeDropdown!=null&&dropdown_activeDropdown.id!=dropdown.id){dropdown_finishSelection(dropdown_activeDropdown);}

dropdown_activeDropdown=dropdown;if(dropdown.pendingChange==true){dropdown_finishSelection(dropdown);}

else 
{dropdown.pendingChange=true;dropdown.optionHolderAnchor.style.display="";dropdown.optionHolder.style.display="";dropdown_adjustDropdownLook(dropdown,true);dropdown_highlightOption(dropdown.selectedOption,dropdown);dropdown_showUnselected(dropdown);document.onselectstart=function(){return false;}

}

var hideFx=function(){dropdown_finishSelection(dropdown);}
;dropdown.hideFx=hideFx;crossbrowser_attachEvent(document,"onclick",hideFx);}

function dropdown_handleKeyPress(dropdown,event){var key=crossbrowser_getKeyCode(event);if(key==40){var nextOption=dropdown_getNextOption(dropdown,dropdown.highlightedOption);if(null!=nextOption){dropdown_selectOption(dropdown,nextOption);}

crossbrowser_handleEvent(event);}

else if(key==38){var previousOption=dropdown_getPreviousOption(dropdown,dropdown.highlightedOption);if(null!=previousOption){dropdown_selectOption(dropdown,previousOption);}

crossbrowser_handleEvent(event);}

else if(key==13){dropdown_selectOption(dropdown,dropdown.highlightedOption);dropdown_finishSelection(dropdown);}

else if(key==27){dropdown_finishSelection(dropdown);}

else if(key==9){dropdown_finishSelection(dropdown);}

else 
{var firstLetter=key_keyCodeTranslater[key];if(firstLetter!=null){var option=dropdown_getNextOptionByLetter(dropdown,dropdown.highlightedOption,firstLetter);if(null!=option){dropdown_selectOption(dropdown,option);}

}

}

crossbrowser_handleEvent(event);}

function dropdown_getNextOptionByLetter(dropdown,nextOption,firstLetter){firstLetter=firstLetter.toLowerCase();for(var i=0;i<dropdown.optionList.length;i++)
{nextOption=dropdown_getNextOptionLoop(dropdown,nextOption);if(nextOption.name.charAt(0).toLowerCase()==firstLetter){return nextOption;}

}

return null;}

function dropdown_getNextOptionLoop(dropdown,option){var nextIndex;if(null==option||'undefined'==option){nextIndex=0;}

else 
{nextIndex=option.index+1;}

if(nextIndex>=dropdown.optionList.length){nextIndex=0;}

return dropdown.optionList[nextIndex];}

function dropdown_getNextOption(dropdown,option){var nextIndex;if(null==option||'undefined'==option){nextIndex=0;}

else 
{nextIndex=option.index+1;}

if(nextIndex>=dropdown.optionList.length){return null;}

return dropdown.optionList[nextIndex];}

function dropdown_getPreviousOption(dropdown,option){var previousIndex=option.index-1;if(previousIndex<0){return null;}

return dropdown.optionList[previousIndex];}

;function HeaderInfo(buildHeaderCellFx,sortField,defaultSortDirection){this.buildHeaderCellFx=buildHeaderCellFx;this.sortField=sortField;this.defaultSortDirection=defaultSortDirection||"asc";}

function ListViewer(aList){this.aList=aList;this.columns=[];this.noResultsCellFx;this.onAfterChangeResultCountFx;this.pluralDisplayName;}

ListViewer.prototype=new ListViewerBase();function ListViewerBase(){this.maxPageLinkCount=10;this.resultCountOptions=[10,25,50,100];this.recordsPerRow=1;this.drawHeader=true;this.leftArrowOn;this.leftArrowOff;this.rightArrowOn;this.rightArrowOff;this.listHolder;this.recordPosHolder;this.paginationHolder;this.resultCountDDHolder;this.layout="table";this.addColumn=function(builderFx,headerInfo,styleObj,className){this.columns.push({builderFx:builderFx,headerInfo:headerInfo,styleObj:styleObj,className:className}
);}
;this.build=function(){this.init();this.buildList();this.buildRecordPosInfo();this.buildPagination();}
;this.init=function(){if(this.isInitialized){return ;}

this.buildResultCountDD();this.isInitialized=true;}
;this.refresh=function(listInput){showProgressIcon("refreshing list...");if(!listInput){listInput=this.aList.copyToListInput();}

var ownerCache=this.aList.ownerCache;ownerCache.addListInput(listInput);var thisObj=this;var onAfterProcessFx=function(){thisObj.aList=ownerCache.getListByName(thisObj.aList.name);thisObj.build();hideProgressIcon();}
;ownerCache.process(onAfterProcessFx);}
;this.getListInputCopy=function(){return this.aList.copyToListInput()
}
;this.buildList=function(parentEl){if(parentEl){this.listHolder=parentEl;}

if(!this.listHolder){return ;}

var aList=this.aList;this.listHolder.innerHTML="";if(this.layout=="table"){this.buildTable();}

else if(this.layout=="custom"){this.buildCustomList();}

else {this.buildInlineList();}

}
;this.buildCustomList=function(){parentEl=this.listHolder;var aList=this.aList;var ownerCache=aList.ownerCache;var columns=this.columns;var recordType=aList.record_type;var recordsPerRow=this.recordsPerRow;var recordNoOnRow=0;var ids=aList.ids;if(ids.length==0){if(this.noResultsCellFx){this.noResultsCellFx(parentEl);}

return ;}

for(var i=0;i<ids.length;i++)
{var id=ids[i];var record=ownerCache.getRecord(recordType,id);this.renderListItemFx(parentEl,record,i);}

}
;this.buildInlineList=function(){parentEl=this.listHolder;var aList=this.aList;var ownerCache=aList.ownerCache;var columns=this.columns;var recordType=aList.record_type;var recordsPerRow=this.recordsPerRow;var recordNoOnRow=0;var ids=aList.ids;if(ids.length==0){if(this.noResultsCellFx){this.noResultsCellFx(parentEl);}

return ;}

for(var i=0;i<ids.length;i++)
{var id=ids[i];var record=ownerCache.getRecord(recordType,id);for(var j=0;j<columns.length;j++)
{var builderFx=columns[j].builderFx;builderFx(parentEl,record,i);}

}

}
;this.buildTable=function(){var div=cE("div",this.listHolder);div.style.width="100%";var table=cE("table",div);table.cellSpacing=0;table.cellPadding=0;table.style.width="100%";var colGroup=cE("colgroup",table);var columns=this.columns;for(var i=0;i<columns.length;i++)
{var col=cE("col",colGroup);if(columns[i].className){col.className=columns[i].className;}

var styleObj=columns[i].styleObj;for(var j in styleObj)
{col.style[j]=styleObj[j];}

}

if(this.drawHeader){var tHead=cE("thead",table);this.buildHeader(tHead);}

var tBody=cE("tbody",table);this.buildRows(tBody);}
;this.buildHeader=function(tHead){var aList=this.aList;var ownerCache=aList.ownerCache;var columns=this.columns;var recordType=aList.record_type;var tr=cE("tr",tHead);for(var j=0;j<this.recordsPerRow;j++)
{for(var i=0;i<columns.length;i++)
{var headerInfo=columns[i].headerInfo;this.buildHeaderCell(tr,headerInfo,aList,ownerCache,recordType);}

}

}
;this.buildHeaderCell=function(tr,headerInfo,aList,ownerCache,recordType){var td=cE("td",tr);var buildHeaderCellFx=headerInfo.buildHeaderCellFx;var template=ownerCache.getTemplate(recordType);var sortInfo=(aList.sort_field==headerInfo.sortField)?aList.sort_direction:null;if(headerInfo.sortField){td.style.cursor="pointer";addUnderlineEvents(td);var thisListViewer=this;var onclickFx=function(){showProgressIcon("one moment...");var listInput=aList.copyToListInput();listInput.setSortField(headerInfo.sortField);var sortDirection;if(aList.sort_field==headerInfo.sortField){sortDirection=(aList.sort_direction=="asc")?"desc":"asc";}

else 
{sortDirection=headerInfo.defaultSortDirection;}

listInput.setSortDirection(sortDirection);ownerCache.addListInput(listInput);var onAfterProcessFx=function(){thisListViewer.aList=ownerCache.getListByName(aList.name);thisListViewer.listHolder.innerHTML="";thisListViewer.build();hideProgressIcon();}
;ownerCache.process(onAfterProcessFx);}
;eh_attachEvent("onclick",td,onclickFx);}

buildHeaderCellFx(td,template,sortInfo);}
;this.buildRows=function(tBody){var aList=this.aList;var ownerCache=aList.ownerCache;var columns=this.columns;var recordType=aList.record_type;var recordsPerRow=this.recordsPerRow;var recordNoOnRow=0;var ids=aList.ids;if(ids.length==0){if(this.noResultsCellFx){var tr=cE("tr",tBody);var td=cE("td",tr);td.colSpan=this.columns.length;this.noResultsCellFx(td);}

return ;}

var onSkipCount=0;for(var i=0;i<ids.length;i++)
{var id=ids[i];var record=ownerCache.getRecord(recordType,id);if(this.skipRowTestFx){var ignoreRow=this.skipRowTestFx(record,ids.length,i);if(ignoreRow){continue;}

else 
{onSkipCount++;}

}

if(recordNoOnRow>=recordsPerRow){recordNoOnRow=0;}

if(0==recordNoOnRow){var tr=cE("tr",tBody);}

recordNoOnRow++;for(var j=0;j<columns.length;j++)
{var td=cE("td",tr);var builderFx=columns[j].builderFx;if(onSkipCount==0){builderFx(td,record,i);}

else 
{builderFx(td,record,i,onSkipCount);}

}

}

}
;this.buildRecordPosInfo=function(parentEl){if(parentEl){this.recordPosHolder=parentEl;}

if(!this.recordPosHolder){return ;}

var aList=this.aList;if(0==aList.total_records){this.recordPosHolder.innerHTML="No Results";}

else 
{var firstRecord=aList.start_record+1;var lastRecord=aList.start_record+aList.ids.length;var info=firstRecord+" - "+lastRecord+" of "+aList.total_records;if(this.pluralDisplayName){info+=" "+this.pluralDisplayName;}

this.recordPosHolder.innerHTML=info;}

}
;this.buildPagination=function(parentEl){if(parentEl){this.paginationHolder=parentEl;}

if(!this.paginationHolder){return ;}

var aList=this.aList;var noOfRecordsShown=aList.max_record_count;var startRecordIndex=aList.start_record;var totalRecords=aList.total_records;var totalPages=Math.ceil(totalRecords/noOfRecordsShown);var recordPage=Math.ceil((startRecordIndex+1)/noOfRecordsShown);var pagesPerSide=Math.round(this.maxPageLinkCount/2);var middleStart=Math.max(1,recordPage-pagesPerSide);var middleEnd=Math.min(totalPages,recordPage+pagesPerSide);this.paginationHolder.innerHTML="";var tBody=createTable(this.paginationHolder);tBody.className="text";tBody.parentNode.align="center";var tr=cE("tr",tBody);var td;if(totalPages>1){td=cE("td",tr);if(recordPage>1){var aLink;if(this.leftArrowOn){var aLink=cE("img",td);aLink.style.cursor="pointer";aLink.src=this.leftArrowOn;td=cE("td",tr);td.style.paddingLeft="5px";}

else 
{aLink=cE("span",td);aLink.innerHTML="&lt;";aLink.style.margin="3px";aLink.style.cursor="pointer";addUnderlineEvents(aLink,"default_list");}

var startRecord=(recordPage-2)*noOfRecordsShown;this.attachNavEvent(aLink,startRecord);}

else if(this.leftArrowOff){var aLink=cE("img",td);aLink.src=this.leftArrowOff;td=cE("td",tr);td.style.paddingLeft="5px";}

if(1<middleStart){var aLink=cE("a",td);aLink.href="#";aLink.innerHTML=1;aLink.style.margin="3px";addUnderlineEvents(aLink,"default_list");this.attachNavEvent(aLink,0);var span=cE("span",td);span.innerHTML="...";}

var linkHolder=cE("span",td);for(var i=middleStart;i<=middleEnd;i++)
{if(i==recordPage){var thisPageLink=cE("span",linkHolder);thisPageLink.style.fontWeight="bold";thisPageLink.style.textDecoration="none";thisPageLink.style.cursor="";thisPageLink.innerHTML=i;thisPageLink.style.margin="3px";}

else 
{var aLink=cE("span",linkHolder);aLink.innerHTML=i;aLink.style.margin="3px";aLink.style.color="#006699";aLink.style.cursor="pointer";addUnderlineEvents(aLink,"default_list");var startRecord=(i-1)*noOfRecordsShown;this.attachNavEvent(aLink,startRecord);}

}

if(middleEnd<totalPages){var span=document.createElement("span");span.innerHTML="...";td.appendChild(span);var aLink=cE("a",td);aLink.href="#";aLink.innerHTML=totalPages;aLink.style.margin="3px";addUnderlineEvents(aLink,"default_list");var startRecord=(totalPages-1)*noOfRecordsShown;this.attachNavEvent(aLink,startRecord);}

if(recordPage<totalPages){if(this.rightArrowOn){td=cE("td",tr);td.style.paddingLeft="5px";var aLink=cE("img",td);aLink.style.cursor="pointer";aLink.src=this.rightArrowOn;}

else 
{var aLink=cE("span",td);aLink.innerHTML=">";aLink.style.margin="3px";aLink.style.cursor="pointer";addUnderlineEvents(aLink,"default_list");}

var startRecord=recordPage*noOfRecordsShown;this.attachNavEvent(aLink,startRecord);}

else if(this.rightArrowOff){td=cE("td",tr);td.style.paddingLeft="5px";var aLink=cE("img",td);aLink.src=this.rightArrowOff;}

}

}

this.attachNavEvent=function(element,startRecord){var thisListViewer=this;var onclickFx=function(){showProgressIcon("one moment...");var listInput=thisListViewer.aList.copyToListInput();listInput.setStartRecord(startRecord);var ownerCache=thisListViewer.aList.ownerCache;ownerCache.addListInput(listInput);var onAfterProcessFx=function(){thisListViewer.aList=ownerCache.getListByName(thisListViewer.aList.name);thisListViewer.build();hideProgressIcon();}
;ownerCache.process(onAfterProcessFx);}
;eh_attachEvent("onclick",element,onclickFx);}

this.buildResultCountDD=function(parentEl){if(parentEl){this.resultCountDDHolder=parentEl;}

if(!this.resultCountDDHolder){return ;}

this.resultCountDDHolder.innerHTML="";var aList=this.aList;var optionDD=cE("select",this.resultCountDDHolder);optionDD.style.width="105px";for(var i=0;i<this.resultCountOptions.length;i++)
{var resultCount=this.resultCountOptions[i];var option=cE("option",optionDD);option.innerHTML=resultCount+" per page";option.value=resultCount;if(resultCount==aList.max_record_count){option.selected=true;}

}

var thisListViewer=this;var onChange=function(){showProgressIcon("one moment...");var value=optionDD.options[optionDD.selectedIndex].value;var listInput=thisListViewer.aList.copyToListInput();listInput.setMax(value);var ownerCache=thisListViewer.aList.ownerCache;ownerCache.addListInput(listInput);var onAfterProcessFx=function(){thisListViewer.aList=ownerCache.getListByName(thisListViewer.aList.name);thisListViewer.build();hideProgressIcon();if(thisListViewer.onAfterChangeResultCountFx){thisListViewer.onAfterChangeResultCountFx(value);}

}
;ownerCache.process(onAfterProcessFx);}
;eh_attachEvent("onchange",optionDD,onChange);}
;}

function EventInserter(eventId,prevLink){this.prevLink=prevLink;this.mc=new MiniCache();this.containerEl;this.eventId=eventId;this.format="full";this.popup;this.build=function(){var lpPopup=new LpPopup();lpPopup.width=400;lpPopup.title="Insert Event";var cA=lpPopup.build();cA.style.padding="30px";this.popup=lpPopup.popup;var rangeStr="";if(null!=EditUtil.iconBar){this.range=EditUtil.iconBar.storedRange;rangeStr=this.range.toString();}

if(null!=this.prevLink){removeNode(this.prevLink);}

var holder=cE("div",cA);var r1Holder=cE("div",holder);r1Holder.style.marginBottom="5px";var r2Holder=cE("div",holder);var radio=new RadioButton();radio.layout="custom";radio.labelClass="mediumBoldText";var textDetails;var fullFx=function(){textDetails.style.display="none";}
;radio.addOption("Full event display","full",r1Holder,fullFx);var textFx=function(){textDetails.style.display="";}
;radio.addOption("Text link","text",r2Holder,textFx);radio.build(null,"full");var div=cE("div",holder);div.style.marginLeft="25px";div.style.display=(this.format=="text")?"":"none";textDetails=div;var div=cE("div",textDetails);div.style.margin="10px 0px 5px 0px";div.className="text";div.innerHTML="Link Display";var props=
{
value:rangeStr,
style:{width:300}

}
;var displayInput=buildTextInput(textDetails,props);this.displayInput=displayInput;var div=cE("div",textDetails);div.style.margin="15px 0px";var tBody=createTable(div);var tr=cE("tr",tBody);var td=cE("td",tr);var checkBox=cE("input");checkBox.type="checkbox";aE(td,checkBox);this.checkBox=checkBox;var td=cE("td",tr);td.style.paddingLeft="3px";td.className="text";td.innerHTML="Open Link in a New Window";var div=cE("div",holder);div.style.width="100%";div.style.float="left";div.style.margin="20px 0px";var mc=this.mc;var thisObj=this;var doneFx=function(){thisObj.insert(radio.getValue());}
;var cancelFx=function(){thisObj.popup.close();}
;LpPopupUtil.buildButtonSection(div,"Insert Event",doneFx,"Cancel",cancelFx)
lpPopup.popup.center();}
;this.insert=function(eventStyle){showProgressIcon("inserting event...");if("full"==eventStyle){this.insertFull();}

else 
{this.insertTextLink();}

}
;this.insertTextLink=function(){if(this.displayInput.value==""){alert("Please enter a link display.");hideProgressIcon();return ;}

var linkEl=cE("a");linkEl.innerHTML=this.displayInput.value;sA(linkEl,"href","http://"+window.location.host+"/events?id="+this.eventId);if(this.checkBox.checked){sA(linkEl,"target","_blank");}

LivePage.disableLink(linkEl);if(null==this.containerEl){RangeUtil.insertNode(this.range,linkEl);}

else 
{var newBlock=iE("div",this.containerEl,0);aE(newBlock,linkEl);BlockHandler.initBlock(newBlock);LivePage.setElementToSave(newBlock);}

hideProgressIcon();this.popup.close();}
;this.insertFull=function(){this.mc.addRecordToLoad("ce_info",this.eventId);var thisObj=this;var fx=function(){thisObj.insertElements();}
;this.mc.process(fx);}
;this.insertElements=function(){var detailView=new EventDetail(this.eventId,this.mc);var eventHolder=detailView.build();if(null==this.containerEl){var placeHolder=cE("span");var range=this.range;RangeUtil.selectRange(range);RangeUtil.insertNode(range,placeHolder);var block=getAncestorByStyle(placeHolder,"display","block");placeHolder.parentNode.removeChild(placeHolder);if(block.nextSibling){block.parentNode.insertBefore(eventHolder,block.nextSibing);}

else 
{aE(block.parentNode,eventHolder);}

BlockHandler.initBlock(eventHolder);LivePage.setElementToSave(eventHolder);}

else 
{var newBlock=iE("div",this.containerEl,0);aE(newBlock,eventHolder);BlockHandler.initBlock(newBlock);LivePage.setElementToSave(newBlock);}

hideProgressIcon();this.popup.close();}
;}
;
;function EventDetail(eventId,mc){this.mc=mc;this.eventId=eventId;this.build=function(){var record=this.mc.getRecord("ce_info",this.eventId);var table=cE("table",null,document);table.cellPadding=0;table.cellSpacing=0;table.style.width="100%";var tBody=cE("tbody",table);var tr=cE("tr",tBody);var imagePath=record.getField("image.originalImagePath").getValue();if(imagePath){var td=cE("td",tr);td.style.width="265px";td.vAlign="top";var img=cE("img",td);img.src="/upload/"+imagePath+"?w=240";}

var td=cE("td",tr);td.vAlign="top";td.style.padding=(!imagePath)?"0px 20px 0px 20px":"0px";this.createInfoTable(td,record);return table;}
;this.createInfoTable=function(parentEl,record){var tbody=createTable(parentEl);tbody.parentNode.style.fontSize="12px";var tr=cE("tr",tbody);var td=cE("td",tr);td.colSpan=2;td.style.paddingBottom="20px";this.buildEventTitle(td,record);var tr=cE("tr",tbody);var td=cE("td",tr);td.style.paddingBottom="4px";td.innerHTML="Location: ";td.style.width="100px";var td=cE("td",tr);td.style.paddingBottom="4px";td.style.fontSize="12px";td.style.width="500px";td.innerHTML=record.getField("location").getValue();var tr=cE("tr",tbody);var td=cE("td",tr);td.style.paddingBottom="4px";td.style.width="100px";td.vAlign="top";td.innerHTML="When: ";var td=cE("td",tr);td.style.paddingBottom="4px";td.style.fontWeight="bold";td.style.width="500px";this.buildDateInfo(td,record);var eventInformation=record;var rsvpDeadline=eventInformation.getField("rsvp_settings.rsvp_info.rsvp_deadline").getValue();if(!rsvpDeadline.date.equals(eventInformation.getField("start_date").getValue())){var tr=cE("tr",tbody);var td=cE("td",tr);td.style.paddingTop="10px";td.style.width="100px";td.innerHTML="RSVP by: ";var dateStr=rsvpDeadline.date.getString([ADateUtil.DAY_STR," ",ADateUtil.MONTH_ABBR," ",ADateUtil.DATE]);dateStr+=", "+rsvpDeadline.time.getString();var td=cE("td",tr);td.style.paddingTop="10px";td.style.width="500px";td.innerHTML=dateStr;}

var pricesHolder=eventInformation.getField("price_holder");if(pricesHolder&&pricesHolder.getChildFieldNames().length>0){var tr=cE("tr",tbody);var td=cE("td",tr);td.style.paddingBottom="4px";td.style.paddingTop="6px";td.vAlign="top";td.style.width="100px";td.innerHTML="Prices: ";var priceStr="";var fieldNames=pricesHolder.getChildFieldNames()
for(var i=0;i<fieldNames.length;i++)
{var price=pricesHolder.getChildField(fieldNames[i]);priceStr+=price.data.label+" $"+ANumberUtil.formatForDisplay(price.data.price,2);if((i+1)<fieldNames.length){priceStr+="; ";}

}

var td=cE("td",tr);td.style.paddingBottom="4px";td.style.paddingTop="6px";td.style.fontWeight="bold";td.style.width="500px";td.innerHTML=priceStr;}

var tr=cE("tr",tbody);var td=cE("td",tr);td.colSpan=2;var hr=cE("hr",td);var tr=cE("tr",tbody);var td=cE("td",tr);td.style.paddingBottom="4px";td.colSpan=2;td.innerHTML=eventInformation.getField("description").getValue();var urlInfo=eventInformation.getField("url_info");if(null!=urlInfo&&urlInfo.getChildField("url").getValue().trim()!=""){var urlDisplay=urlInfo.getChildField("url_display").getValue().trim();var url=urlInfo.getChildField("url").getValue().trim();var tr=cE("tr",tbody);var td=cE("td",tr);td.style.paddingTop="8px";td.colSpan=2;var aHref=cE("a",td);aHref.href="http://"+url;aHref.style.textDecoration="none";aHref.target="_blank";var display=(urlDisplay.trim()!="")?urlDisplay:url;cls(aHref,display,function(){}
);}

}
;this.buildRespondButton=function(parentEl){var linkEl=cE("a",parentEl);sA(linkEl,"href","http://"+window.location.host+"/events?id="+this.eventId);sA(linkEl,"target","_blank");LivePage.disableLink(linkEl);var image=cE("img",linkEl);image.src="/upload/custom_screens/calendar/popups/respond_now_img.gif";image.border=0;}
;this.buildEventTitle=function(parentEl,record){var tbody=createTable(parentEl);var tr=cE("tr",tbody);var td=cE("td",tr);td.style.fontSize="18px";td.style.paddingRight="10px";td.innerHTML=record.getField("event_title").getValue();var td=cE("td",tr);td.align="left";if(record.getField("rsvp_settings.is_restricted").getValue()){var img=cE("img",td);img.src="/upload/custom_screens/invitations/lock.gif";}

var td=cE("td",tr);this.buildRespondButton(td);var tr=cE("tr",tbody);var td=cE("td",tr);td.style.paddingTop="2px";td.style.fontSize="12px";td.colSpan=2;td.innerHTML="("+record.getField("event_type").getValue().selected_option.display+")";}
;this.buildDateInfo=function(parentEl,record){var eventInformation=record;var startDate=eventInformation.getField("start_date").getValue();var endDate=eventInformation.getField("end_date").getValue();var format=eventInformation.getField("date_info.format").getValue();var dateStr=startDate.getString([ADateUtil.DAY_STR," ",ADateUtil.MONTH_ABBR," ",ADateUtil.DATE]);if(format=="single_date"){dateStr+=", "+eventInformation.getField("start_time").getValue().getString();var endTime=eventInformation.getField("end_time").getValue();if(endTime.minuteOffset!=1439){dateStr+=" to "+eventInformation.getField("end_time").getValue().getString();}

parentEl.innerHTML=dateStr;}

else if(format=="multiple_time"){var div=cE("div",parentEl);div.innerHTML=dateStr+", ";var count=1;var timeSets=eventInformation.getField("date_info.times");var fieldNames=timeSets.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var fieldName=fieldNames[i];var startTime=timeSets.getChildField(fieldName+".start_time").getValue();var endTime=timeSets.getChildField(fieldName+".end_time").getValue();var timeStr=startTime.getString()+" to "+endTime.getString();if(fieldNames[i+1]){var fieldName2=fieldNames[i+1];startTime=timeSets.getChildField(fieldName2+".start_time").getValue();endTime=timeSets.getChildField(fieldName2+".end_time").getValue();timeStr+=" / ";timeStr+=startTime.getString()+" to "+endTime.getString();i++;}

var div=cE("div",parentEl);div.innerHTML=timeStr;div.style.paddingTop="2px";}

}

else if(format=="multiple_date"){var params=[];params.push(ADateUtil.DAY_STR);params.push(" ");params.push(ADateUtil.MONTH_ABBR);params.push(" ");params.push(ADateUtil.DATE);var dynField=eventInformation.getField("date_info.dates");if(dynField.getChildFieldNames().length>0){var fieldNames=dynField.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var dateInfo=dynField.getChildField(fieldNames[i]);var date=dateInfo.getChildField("date").getValue();var dateStr=date.getString(params)+", ";var startTime=dateInfo.getChildField("start_time").getValue();if(!startTime){startTime=eventInformation.getField("start_time").getValue();}

dateStr+=startTime.getString();dateStr+=" to ";var endTime=dateInfo.getChildField("end_time").getValue();if(!endTime){endTime=eventInformation.getField("end_time").getValue();}

dateStr+=endTime.getString();var div=cE("div",parentEl);div.innerHTML=dateStr;div.style.paddingTop="2px";}

}

else 
{var dateStr="From "+startDate.getString(params);dateStr+=" at ";dateStr+=eventInformation.getField("start_time").getValue().getString();dateStr+=" to <br>";dateStr+=endDate.getString(params);dateStr+=" at ";dateStr+=eventInformation.getField("end_time").getValue().getString();parentEl.innerHTML=dateStr;}

}

}
;}

;;;function EventChooserPopup(containerEl){this.mc=new MiniCache();this.containerEl=containerEl;this.onClick;this.popup;this.build=function(){var thisObj=this;var fx=function(){thisObj.buildElements();hideProgressIcon();}
;this.addInitialDataToLoad(fx);}
;this.addInitialDataToLoad=function(afterLoad){var mc=this.mc;var maxResults=10;var listInput=mc.addListToLoad("ce_info","event_list",0,maxResults,"start_datetime","asc");listInput.addField("event_title");listInput.addField("event_type");listInput.addField("start_datetime");listInput.addField("created_by");listInput.addField("date_created");listInput.addSearchTerm("event_status","posted",SEARCHTERM_EXACT_MATCH);var currentDate=ADateUtil.getCurrentDate();listInput.addConditional("start_date",currentDate.toDbFormat(),CONDITIONAL_GREATER_THAN_EQUAL);mc.process(afterLoad);}
;this.buildElements=function(){var lpPopup=new LpPopup();lpPopup.width=700;lpPopup.title="Choose An Event";this.popup=lpPopup.popup;var cA=lpPopup.build();this.doc=cA.ownerDocument;this.initCss();cA.style.padding="20px 30px 30px 30px";this.contentArea=cA;this.buildContents(cA);var popup=lpPopup.popup;popup.setFrameHeight(400);popup.center();}
;this.buildContents=function(parentEl){var holder=cE("div",parentEl);var div=cE("div",holder);this.buildTopSection(div);var div=cE("div",holder);div.style.marginBottom="15px";this.buildList(div);}
;this.buildTopSection=function(parentEl){var tBody=createTable(parentEl,"100%");tBody.className="text";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingLeft="15px";var span=cE("span",td);this.recordPosHolder=span;var td=cE("td",tr);td.align="right";this.buildListNav(td);}
;this.buildListNav=function(parentEl){var div=cE("div",parentEl);div.style.padding="8px 15px 8px";var tBody=createTable(div);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="25px";this.paginationHolder=td;var td=cE("td",tr);this.resultCountDDHolder=td;}
;this.buildList=function(parentEl){var holder=cE("div",parentEl);holder.style.overflowY="auto";var eventList=this.mc.getListByName("event_list");var listViewer=new ListViewer(eventList);listViewer.resultCountDDHolder=this.resultCountDDHolder;listViewer.listHolder=holder;listViewer.paginationHolder=this.paginationHolder;listViewer.recordPosHolder=this.recordPosHolder;listViewer.drawHeader=true;listViewer.pluralDisplayName="events";this.createFirstColumn(listViewer);this.createSecondColumn(listViewer);this.createThirdColumn(listViewer);this.createFourthColumn(listViewer);this.createFifthColumn(listViewer);listViewer.noResultsCellFx=function(parentCell){parentCell.align="center";parentCell.className="largeText borderColor";parentCell.style.padding="45px";parentCell.style.borderWidth="0px 0px 1px 0px";parentCell.innerHTML="No Events Found";}
;listViewer.build();}
;this.createFirstColumn=function(listViewer){var thisObj=this;var builderFx=function(parentCell,record,index){parentCell.className="infoCell leftBorder";var title=record.getField("event_title").getValue();var div=cE("div",parentCell);div.innerHTML=title||"Untitled";var rowEl=parentCell.parentNode;var onClickFx=function(){if(thisObj.onClick){thisObj.onClick(record.getId());}

}
;eh_attachEvent("onclick",rowEl,onClickFx);var onMouseOverFx=function(){rowEl.style.backgroundColor="#FDFDE5";}
;eh_attachEvent("onmouseover",rowEl,onMouseOverFx);var onMouseOutFx=function(){rowEl.style.backgroundColor="";}
;eh_attachEvent("onmouseout",rowEl,onMouseOutFx);}
;var buildHeaderCellFx=function(parentCell,template,sortInfo){parentCell.className="headerCell leftBorder";parentCell.innerHTML="Event Title";}
;var headerInfo=new HeaderInfo(buildHeaderCellFx,"event_title","asc");var styleObj={}
;listViewer.addColumn(builderFx,headerInfo,styleObj);}
;this.createSecondColumn=function(listViewer){var thisObj=this;var builderFx=function(parentCell,record,index){parentCell.className="infoCell";var div=cE("div",parentCell);div.innerHTML=record.getField("event_type").getValue().selected_option.display||"--";}
;var buildHeaderCellFx=function(parentCell,template,sortInfo){parentCell.className="headerCell";parentCell.innerHTML="Type";}
;var headerInfo=new HeaderInfo(buildHeaderCellFx,"event_type","asc");listViewer.addColumn(builderFx,headerInfo);}
;this.createThirdColumn=function(listViewer){var thisObj=this;var builderFx=function(parentCell,record,index){parentCell.className="infoCell";var dateTimeObj=record.getField("start_datetime").getValue();var dateObj=dateTimeObj.date;var params=[ADateUtil.DAY_ABBR,", ",ADateUtil.MONTH,"/",ADateUtil.DATE];var div=cE("div",parentCell);div.innerHTML=dateObj.getString(params)+" at ";var div=cE("div",parentCell);div.style.paddingTop="3px";div.innerHTML=dateTimeObj.time.getString();}
;var buildHeaderCellFx=function(parentCell,template,sortInfo){parentCell.className="headerCell";parentCell.innerHTML="Date & Time";}
;var headerInfo=new HeaderInfo(buildHeaderCellFx,"start_datetime","asc");listViewer.addColumn(builderFx,headerInfo);}
;this.createFourthColumn=function(listViewer){var thisObj=this;var builderFx=function(parentCell,record,index){parentCell.className="infoCell";var div=cE("div",parentCell);div.innerHTML=record.getField("created_by.user_name").getValue();}
;var buildHeaderCellFx=function(parentCell,template,sortInfo){parentCell.className="headerCell";parentCell.innerHTML="Created By";}
;var headerInfo=new HeaderInfo(buildHeaderCellFx,"created_by","asc");listViewer.addColumn(builderFx,headerInfo);}
;this.createFifthColumn=function(listViewer){var thisObj=this;var builderFx=function(parentCell,record,index){parentCell.className="infoCell rightBorder";var dateTimeObj=record.getField("date_created.date_time").getValue();var dateObj=dateTimeObj.date;var params=[ADateUtil.DAY_ABBR,", ",ADateUtil.MONTH,"/",ADateUtil.DATE];var div=cE("div",parentCell);div.innerHTML=dateObj.getString(params)+" at ";var div=cE("div",parentCell);div.style.paddingTop="3px";div.innerHTML=dateTimeObj.time.getString();}
;var buildHeaderCellFx=function(parentCell,template,sortInfo){parentCell.className="headerCell rightBorder";parentCell.innerHTML="Created On";}
;var headerInfo=new HeaderInfo(buildHeaderCellFx,"date_created","asc");var styleObj={width:140}
;listViewer.addColumn(builderFx,headerInfo);}
;this.onClick=function(eventId){var inserter=new EventInserter(eventId);inserter.containerEl=this.containerEl;inserter.build();this.popup.close();}
;this.initCss=function(){var doc=this.doc;var cssClass=new CssClass(".headerCell");cssClass.add("background","#f3f3f3 url(/upload/custom_screens/blog/admin/header_bg.gif)");cssClass.add("border-top","1px solid #dddddd");cssClass.add("font","12px arial");cssClass.add("color","#999999");cssClass.add("padding","6px 6px 6px 10px");cssClass.init(doc);var cssClass=new CssClass(".infoCell");cssClass.add("font","12px arial");cssClass.add("border-bottom","1px solid #DDDDDD");cssClass.add("padding-left","16px");cssClass.add("height","40px");cssClass.add("cursor","pointer");cssClass.init(doc);var cssClass=new CssClass(".leftBorder");cssClass.add("border-left","1px solid #DDDDDD");cssClass.init(doc);var cssClass=new CssClass(".rightBorder");cssClass.add("border-right","1px solid #DDDDDD");cssClass.init(doc);}
;}
;
function UrlLink(popup,prevLink){this.popup=popup;this.prevLink=prevLink;this.build=function(parentEl){var div=cE("div",parentEl);div.style.paddingBottom="15px";div.style.fontWeight="bold";div.style.color="#333333";div.innerHTML="Link to an external url";var tBody=createTable(parentEl,300);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="3px";td.className="text";td.innerHTML="http://";var td=cE("td",tr);td.width="100%";var props={style:{width:"100%"}
}
;var urlInput=buildTextInput(td,props);var displayInput=LinkingUtil.buildInnerHTMLInput(parentEl,this.prevLink);var div=cE("div",parentEl);div.style.margin="15px 0px";var tBody=createTable(div);var tr=cE("tr",tBody);var td=cE("td",tr);var checkBox=cE("input");checkBox.type="checkbox";aE(td,checkBox);var td=cE("td",tr);td.style.paddingLeft="3px";td.className="text";td.innerHTML="Open link in a new window";var div=cE("div",parentEl);div.align="center";div.style.marginTop="5px";div.style.width="100%";var mc=this.mc;var thisObj=this;var doneFx=function(){var linkEl=thisObj.prevLink||cE("a",null,document);if(null!=displayInput){linkEl.innerHTML=displayInput.value;}

var noHref=window.location.href+"#";sA(linkEl,"href","http://"+urlInput.value);if(checkBox.checked){sA(linkEl,"target","_blank");}

else 
{sA(linkEl,"target","_parent");}

LivePage.disableLink(linkEl);if(thisObj.prevLink==null){var range=EditUtil.iconBar.storedRange
RangeUtil.selectRange(range);RangeUtil.insertNode(range,linkEl);}

else 
{LivePage.setElementToSave(linkEl);}

if(thisObj.onLink){thisObj.onLink(linkEl);}

thisObj.popup.close();}
;var cancelFx=function(){if(thisObj.onCancel){thisObj.onCancel();}

thisObj.popup.close();}
;LpPopupUtil.buildButtonSection(div,"Insert Link",doneFx,"Cancel",cancelFx)
}
;}

function EmailLink(popup,prevLink){this.popup=popup;this.prevLink=prevLink;this.build=function(parentEl){var div=cE("div",parentEl);div.className="boldText";div.style.colo="#333333";div.innerHTML="Insert a link to an email address";var div=cE("div",parentEl);div.style.margin="25px 0px 5px 0px";div.innerHTML="Email address";var props=
{
value:"",
style:{width:300}
,
shadowText:"Enter E-mail address"
}
;var emailInput=buildTextInput(parentEl,props);var displayInput=LinkingUtil.buildInnerHTMLInput(parentEl,this.prevLink);var div=cE("div",parentEl);div.style.marginTop="15px";div.style.width="100%";var mc=this.mc;var thisObj=this;var doneFx=function(){var linkEl=thisObj.prevLink||cE("a",null,document);if(null!=displayInput){linkEl.innerHTML=displayInput.value;}

var noHref=window.location.href+"#";sA(linkEl,"href","mailto:"+emailInput.value);sA(linkEl,"target","_blank");rA(linkEl,"id");LivePage.disableLink(linkEl);if(thisObj.prevLink==null){var range=EditUtil.iconBar.storedRange
RangeUtil.selectRange(range);RangeUtil.insertNode(range,linkEl);}

else 
{LivePage.setElementToSave(linkEl);}

if(thisObj.onLink){thisObj.onLink(linkEl);}

thisObj.popup.close();}
;var cancelFx=function(){if(thisObj.onCancel){thisObj.onCancel();}

thisObj.popup.close();}
;LpPopupUtil.buildButtonSection(div,"Insert Link",doneFx,"Cancel",cancelFx)
}
;}
;
function HomePageLink(popup){this.popup=popup;this.build=function(parentEl){var div=cE("div",parentEl);div.innerHTML="Insert a Link to Your Home Page";var div=cE("div",parentEl);div.style.margin="25px 0px 5px 0px";div.className="boldText";div.innerHTML="Link Display";var range=EditUtil.iconBar.storedRange;var props=
{
value:range.toString(),
style:{width:300}

}
;var displayInput=buildTextInput(parentEl,props);var div=cE("div",parentEl);div.style.margin="15px 0px";var tBody=createTable(div);var tr=cE("tr",tBody);var td=cE("td",tr);var checkBox=cE("input");checkBox.type="checkbox";aE(td,checkBox);var td=cE("td",tr);td.style.paddingLeft="3px";td.className="text";td.innerHTML="Open Link in a New Window";var div=cE("div",parentEl);div.align="center";div.style.marginTop="30px";var mc=this.mc;var thisObj=this;var onClick=function(){var linkEl=cE("a",null,document);linkEl.innerHTML=displayInput.value;var noHref=window.location.href+"#";sA(linkEl,"href","http://"+window.location.host+"/");if(checkBox.checked){sA(linkEl,"target","_blank");}

LivePage.disableLink(linkEl);RangeUtil.selectRange(range);RangeUtil.insertNode(range,linkEl);thisObj.popup.close();}
;var button=cb(div,"Insert Link",onClick);button.style.margin="0px 5px";var fx=function(){thisObj.popup.close();}
;var button=cb(div,"Cancel",fx);}
;}

var g_lastObj=null;var g_lastUrl=null;var g_lastHandler=null;var g_searchTimer=null;function sendto_sumbitRequest(thisObj,handler){var value=thisObj.input.value;if(""==value){sendto_cancelDelayRequest();return ;}

g_lastObj=thisObj;var url="NameAutoComplete.ajax?value="+value+"&fieldName="+thisObj.fieldName+"&type="+thisObj.type;var myHandler=function(responseText){eval(responseText);handler(list,g_lastObj,g_lastObj);}
;sendto_delaySubmitRequest(url,myHandler);}

function sendto_newSumbitRequest(thisObj,handler){var value=thisObj.input.value;if(""==value){sendto_cancelDelayRequest();return ;}

g_lastObj=thisObj;var url="UserNameAutoComplete.ajax?value="+value;var myHandler=function(responseText){eval(responseText);handler(list,g_lastObj);}
;sendto_delaySubmitRequest(url,myHandler);}

function sendto_delaySubmitRequest(url,handler,delayMillis){if(null!=g_searchTimer){clearTimeout(g_searchTimer);}

if(null==delayMillis||delayMillis<0){delayMillis=300;}

g_lastUrl=url;g_lastHandler=handler
g_searchTimer=setTimeout("sendto_delayProcessRequest( \""+url+"\" )",delayMillis);}

function sendto_delayProcessRequest(url){if(!sendto_isRequestStillValid(url)){return ;}

var xmlRequest=ajax_getXMLHttpRequest();xmlRequest.open("POST",url,true);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.onreadystatechange=function(){if(!sendto_isRequestStillValid(url)){return ;}

if(xmlRequest.readyState==4){if(xmlRequest.status==200){g_lastHandler(xmlRequest.responseText);}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}
;xmlRequest.send(null);}

function sendto_cancelDelayRequest(){if(null!=g_searchTimer){clearTimeout(g_searchTimer);}

g_searchTimer=null;g_lastUrl=null;g_lastObj=null;g_lastUrl=null;g_lastHandler=null;}

function sendto_isRequestStillValid(url){if(g_lastUrl!=url||null==g_lastHandler){return false;}

return true;}

;;function ac_getAcResults(listInputs,value,handler,event){if(ac_nagivationKey(event)){return ;}

if(""==value){sendto_cancelDelayRequest();return ;}

var xmlStr=ac_createXmlStr(listInputs,ac_fromatValueForXml(value));var xmlRequest=ajax_getXMLHttpRequest();var url="NewAutoComplete.ajax?xmlStr="+xmlStr;var myHandler=function(responseText){var evalRes=eval(responseText);handler(evalRes);}
;sendto_delaySubmitRequest(url,myHandler);}

function ac_nagivationKey(event){var key=crossbrowser_getKeyCode(event);if(key==37||key==38||key==39||key==40||key==13){return true;}

return false;}

function ac_fromatValueForXml(value){var lessThan="!!lessthan!!";var singleQuote="!!singlequote!!";var lessThanIndex=value.indexOf("<");while(lessThanIndex!=-1)
{value=value.replace("<",lessThan);lessThanIndex=value.indexOf("<");}

var singleQuoteIndex=value.indexOf("'");while(singleQuoteIndex!=-1)
{value=value.replace("'",singleQuote);singleQuoteIndex=value.indexOf("'");}

return value;}

function ac_createXmlStr(listInputs,value){var xmlStr="<l>";for(var i=0;i<listInputs.length;i++)
{xmlStr+=ac_createLiXml(listInputs[i],value);}

return xmlStr+="</l>"
}

function ac_createLiXml(listObj,value){var xmlStr="<s t='"+listObj.type+"'";xmlStr+=" vf='"+listObj.value_field+"'";xmlStr+=" sf='"+listObj.sort_field+"'";xmlStr+=" sd='"+listObj.sort_dir+"'";xmlStr+=" mr='"+listObj.max_results+"'";xmlStr+=" ftl='"+listObj.fields_to_load+"'>";xmlStr+=ac_addSearchTerms(listObj,value);xmlStr+=ac_addFilters(listObj);xmlStr+="</s>";return xmlStr;}

function ac_addSearchTerms(listObj,value){var searchTerms=listObj.search_terms;if(searchTerms.length<1){return "";}

var xmlStr="<st>";for(var i=0;i<searchTerms.length;i++)
{var st=searchTerms[i];xmlStr+="<st fn='"+st.field_name+"'";if(st.isValueSt){xmlStr+=" v='"+ac_formatValueForXml(value)+"'";}

else 
{xmlStr+=" v='"+ac_formatValueForXml(st.search_value)+"'";}

xmlStr+=" srt='"+st.search_type+"'/>";}

return (xmlStr+"</st>");}

function ac_formatValueForXml(value){try
{var re=eval("/%/g");value=value.replace(re,constants_PERCENTAGE_SIGN);var re=eval("/&/g");value=value.replace(re,constants_AND_SIGN);}

catch(e)
{}

return value;}

function ac_addFilters(listObj){var filters=listObj.filters;if(filters.length<1){return "";}

var xmlStr="<f>";for(var i=0;i<filters.length;i++)
{var filter=filters[i];xmlStr+="<f fn='"+filter.filter_name+"'";xmlStr+=" v='"+filter.filter_value+"'/>";}

return (xmlStr+"</f>");}

function ac_createAcListInput(type,valueField,sortField,maxResults,fieldsToLoad,sortDir){var li={
type:type,
value_field:valueField,
sort_dir:sortDir,
sort_field:sortField,
max_results:maxResults,
fields_to_load:fieldsToLoad,
search_terms:[],
filters:[],
ms_filters:[],
intervals:[],
conditionals:[]
}

return li;}

function ac_addSearchTerm(listObj,fieldName,searchValue,searchType,isValueSt){var st={field_name:fieldName,search_value:searchValue,search_type:searchType}
;listObj.search_terms.push(st);st.isValueSt=isValueSt;}

function ac_addFilter(listObj,fieldName,filterValue){var f={filter_name:fieldName,filter_value:filterValue}
;listObj.filters.push(f);}

function aco_AutocompleteOptions(tableEl,optionHolder,inputEl,onclickFx,optionList){this.tableEl=tableEl;this.optionHolder=optionHolder;this.inputEl=inputEl;this.onclickFx=onclickFx;this.optionList=optionList;this.selectedOption;this.areEventsAttached=true;this.width;this.otherValueFields=[];this.buildHTML=function(){aco_buildOpionList(this)}
;}

function aco_buildOpionList(acoObj){eh_clearEventGroup("autocomplete");var tableEl=acoObj.tableEl;var onKeyDownFx=function(event){aco_handleKeyPress(acoObj,event);}

eh_attachEvent("onkeydown",tableEl,onKeyDownFx,"autocomplete");var optionHolder=acoObj.optionHolder;optionHolder.innerHTML="";var width;if(acoObj.width!=null){width=acoObj.width;}

else 
{width=(IS_IE)?acoObj.inputEl.offsetWidth:(acoObj.inputEl.offsetWidth-2);}

if(!isNaN(width)){width=width+"px";}

var optionHolderAnchor=cE("div",optionHolder);optionHolderAnchor.style.position="absolute";optionHolderAnchor.style.width=width;optionHolderAnchor.style.backgroundColor="white";optionHolderAnchor.style.border="1px solid #A5ACB2";optionHolderAnchor.style.zIndex=3000;optionHolderAnchor.style.height="300px";optionHolderAnchor.style.overflowY="auto";var tbody=createTable(optionHolderAnchor,"100%");var table=tbody.parentNode;table.cellPadding=2;aco_appendOptions(acoObj,tbody);var hideOptionsFx=function(){acoObj.optionHolder.innerHTML="";crossbrowser_removeEvent(document.body,"onclick",hideOptionsFx)
}

if(table.offsetHeight<300){optionHolderAnchor.style.height=table.offsetHeight+"px";optionHolderAnchor.style.overflowY="";}

crossbrowser_attachEvent(document.body,"onclick",hideOptionsFx)
}

function aco_appendOptions(acoObj,tbody){var optionList=acoObj.optionList;if(optionList.length==0){acoObj.optionHolder.innerHTML="";return ;}

for(var i=0;i<optionList.length;i++)
{var option=optionList[i];var tr=cE("tr",tbody);var td=cE("td",tr);td.style.cursor="default";td.style.fontFamily="arial";td.style.fontSize="12px";td.style.padding=acoObj.inputEl.style.padding;td.style.paddingTop="2px";td.style.paddingBottom="2px";td.style.width="100%";option.optionElement=td;if(option.tagName!=null){td.appendChild(option);}

else 
{if(null!=acoObj.printOptionsFx){acoObj.printOptionsFx(td,option);}

else 
{var value=option.value;var otherValue="";for(var j=0;j<acoObj.otherValueFields.length;j++)
{otherValue=option.f[acoObj.otherValueFields[j]];if(otherValue){otherValue=("undefined"==typeof(otherValue))?"":" - "+option.f[acoObj.otherValueFields[j]];}

value+=otherValue;}

td.innerHTML=value;}

}

aco_attachOptionEvents(option,acoObj,i);}

}

function aco_attachOptionEvents(option,acoObj,index){option.index=index;var optionEl=option.optionElement;var onmouseoverFx=function(){aco_highlightSelectedOption(option,acoObj)}
;eh_attachEvent("onmouseover",optionEl,onmouseoverFx,"autocomplete");var onclickFx=function(){if(acoObj.onclickFx){acoObj.onclickFx(option);aco_hideOptionHolder(acoObj);}

}

eh_attachEvent("onclick",optionEl,onclickFx,"autocomplete");}

function aco_highlightSelectedOption(option,thisObj){var selectedOption=thisObj.selectedOption;if(selectedOption!=null){selectedOption.optionElement.style.backgroundColor="white";}

option.optionElement.style.backgroundColor="#B2B4BF";option.optionElement.style.width="100%";thisObj.selectedOption=option;}

function aco_hideOptionHolder(thisObj){thisObj.optionHolder.innerHTML="";thisObj=null;}

function aco_handleKeyPress(thisObj,event){var key=crossbrowser_getKeyCode(event);if(key==40){var option=aco_getNextOption(thisObj);if(null!=option){aco_highlightSelectedOption(option,thisObj);option.optionElement.focus();}

crossbrowser_handleEvent(event);}

else if(key==38){thisObj.isNavigationKey=true;var option=aco_getPreviousOption(thisObj);if(null!=option){aco_highlightSelectedOption(option,thisObj);option.optionElement.focus();}

crossbrowser_handleEvent(event);}

else if(key==27){aco_hideOptionHolder(thisObj);}

else if(key==9){aco_hideOptionHolder(thisObj);}

else if(key==13){if(thisObj.onclickFx&&thisObj.selectedOption){thisObj.onclickFx(thisObj.selectedOption);aco_hideOptionHolder(thisObj);}

}

}

function aco_getNextOption(thisObj){var option=null;if(null==thisObj.selectedOption){option=thisObj.optionList[0];}

else 
{option=thisObj.optionList[thisObj.selectedOption.index+1];}

if(option==null){option=thisObj.optionList[0];}

return option;}

function aco_getPreviousOption(thisObj){var option=null;if(null==thisObj.selectedOption){option=null;}

else 
{option=thisObj.optionList[thisObj.selectedOption.index-1];}

if(option==null){option=thisObj.optionList[thisObj.optionList.length-1];}

return option;}

function EventLinkAutoComplete(){this.build=function(input,optionHolder){var tableEl=input.parentNode.parentNode.parentNode.parentNode;var listInputs=[];var eventListObj=ac_createAcListInput("ce_info","event_title","event_title",15,"event_title,event_status,start_date","asc");ac_addSearchTerm(eventListObj,"event_title","",SEARCHTERM_BEGINS_WITH,true);ac_addSearchTerm(eventListObj,"event_status","posted",SEARCHTERM_EXACT_MATCH,false);listInputs.push(eventListObj);
var thisObj=this;var onKeyUpFx=function(event){var onSelectFx=function(list){var value=input.value;var onclickFx=function(el){input.value=el.option.value;var url=thisObj.buildNewUrl(el)
thisObj.returnFx(url);}

var listElements=thisObj.getOptionList(list,value);var autoCompleteOptions=new aco_AutocompleteOptions(tableEl,optionHolder,input,onclickFx,listElements)
autoCompleteOptions.width="303px";autoCompleteOptions.buildHTML();}

ac_getAcResults(listInputs,input.value,onSelectFx,event);}
;eh_attachEvent("onkeyup",input,onKeyUpFx,true,null,null,null,false);}

this.getOptionList=function(list,value){var optionMap={}

var options=[];for(var i in list)
{var option=list[i];if(null!=optionMap[option.value]){continue;}

var tbody=createTable(cE("div"),"100%");var table=tbody.parentNode;table.option=option;table.cellPadding=3;var tr=cE("tr",tbody);var td=cE("td",tr);td.width=170;td.style.fontSize=12;td.style.fontFamily="Arial";td.innerHTML=this.getHighligthedValue(option.f.event_title,value);var label=(option.type=="trmt_info")?"Tournament":"Event";var td=cE("td",tr);td.style.fontSize=11;td.style.color="#333333";td.style.width=60;td.innerHTML=option.f.start_date.toStdFormat();var td=cE("td",tr);td.style.color=(label=="Event")?"#9c63ce":"#319b16";td.style.fontWeight="bold";td.width=80;td.innerHTML=label;td.style.cursor="default";td.style.fontSize=11;optionMap[option.id]=option;options.push(table);}

return options;}

this.getHighligthedValue=function(resultValue,typedValue){var replaceValue=resultValue.substring(0,typedValue.length);if(replaceValue.toLowerCase()==typedValue.toLowerCase()){resultValue=resultValue.replace(replaceValue,"<span style='font-weight:bold'>"+replaceValue+"</span>");}

return resultValue;}

this.buildNewUrl=function(el){var eventId=el.option.id;var dynUrl;if(el.option.type.indexOf("ce")>=0){dynUrl="/events?id=";}

else 
{dynUrl="/tournaments?id=";}

var newUrl=dynUrl+eventId;return newUrl;}

}
;
function InternalLinkAutoComplete(){this.build=function(input,optionHolder){var tableEl=input.parentNode.parentNode.parentNode.parentNode;var listInputs=[];var internalListObj=ac_createAcListInput("url","friendly_url","friendly_url",15,"friendly_url","asc");ac_addSearchTerm(internalListObj,"friendly_url","",2,true);ac_addSearchTerm(internalListObj,"action_path","FriendlyUrl.do",4);listInputs.push(internalListObj);var thisObj=this;var onKeyUpFx=function(event){var onSelectFx=function(list){var value=input.value;var onclickFx=function(el){input.value=el.option.value;thisObj.returnFx("/"+el.option.f.friendly_url);}

var listElements=thisObj.getOptionList(list,value);var autoCompleteOptions=new aco_AutocompleteOptions(tableEl,optionHolder,input,onclickFx,listElements)
autoCompleteOptions.width="303px";autoCompleteOptions.buildHTML();}

ac_getAcResults(listInputs,input.value,onSelectFx,event);}
;eh_attachEvent("onkeyup",input,onKeyUpFx,true,null,null,null,false);}

this.getOptionList=function(list,value){var optionMap={}

var options=[];for(var i in list)
{var option=list[i];if(null!=optionMap[option.value]){continue;}

var tbody=createTable(cE("div"),"100%");var table=tbody.parentNode;table.option=option;table.cellPadding=3;var tr=cE("tr",tbody);var td=cE("td",tr);td.width="170px";td.style.fontSize="12px";td.style.fontFamily="Arial";td.innerHTML=this.getHighligthedValue(option.f.friendly_url,value);optionMap[option.id]=option;options.push(table);}

return options;}

this.getHighligthedValue=function(resultValue,typedValue){var replaceValue=resultValue.substring(0,typedValue.length);if(replaceValue.toLowerCase()==typedValue.toLowerCase()){resultValue=resultValue.replace(replaceValue,"<span style='font-weight:bold'>"+replaceValue+"</span>");}

return resultValue;}

}
;
;;;;
function InternalPageLink(popup,prevLink){this.popup=popup;this.prevLink=prevLink;this.build=function(parentEl){var div=cE("div",parentEl);div.style.paddingBottom="15px";div.style.fontWeight="bold";div.style.color="#333333";div.innerHTML="Link to a url within the site";var tBody=createTable(parentEl,300);var tr=cE("tr",tBody)
var td=cE("td",tr)
td.style.paddingBottom="5px";td.innerHTML="URL";var td=cE("td",tr);var tr=cE("tr",tBody)
var td=cE("td",tr)
td.colSpan="2";var urlValue=(null==prevLink)?"":gA(prevLink,"a_href");this.urlValue=urlValue;var props=
{
value:(null!=urlValue)?urlValue.substring(1):"",
style:{width:303}
,
shadowText:"Start typing a url"
}
;var input=buildTextInput(td,props);var tr=cE("tr",tBody);var optionHolder=cE("td",tr);optionHolder.style.paddingLeft=8;var acBuilder=new InternalLinkAutoComplete();acBuilder.build(input,optionHolder);var thisObj=this;acBuilder.returnFx=function(url){thisObj.urlValue=url;}
;this.continueBuild(parentEl);}
;this.continueBuild=function(parentEl){var displayInput=LinkingUtil.buildInnerHTMLInput(parentEl,this.prevLink);LinkingUtil.buildUrlLoadOptions(parentEl,this.prevLink,this);var div=cE("div",parentEl);div.style.marginTop="20px";var mc=this.mc;var thisObj=this;var doneFx=function(){var popup=thisObj.popup;var url=thisObj.urlValue;if(null==url){popup.close();return ;}

var linkEl=thisObj.prevLink||cE("a",null,document);if(null!=displayInput){linkEl.innerHTML=displayInput.value;}

sA(linkEl,"href",url);sA(linkEl,"target",thisObj.targetValue);LivePage.disableLink(linkEl);if(thisObj.prevLink==null){var range=EditUtil.iconBar.storedRange
RangeUtil.selectRange(range);RangeUtil.insertNode(range,linkEl);}

else 
{LivePage.setElementToSave(linkEl);}

thisObj.handlePageLoaderAction(linkEl,url);if(thisObj.onLink){thisObj.onLink(linkEl);}

popup.close();}
;var cancelFx=function(){if(thisObj.onCancel){thisObj.onCancel();}

thisObj.popup.close();}
;LpPopupUtil.buildButtonSection(div,"Insert Link",doneFx,"Cancel",cancelFx)
}
;this.handlePageLoaderAction=function(linkEl,url){debugger;var fragInfo=A.getFragInfo(linkEl.id);ActionHandler.removeActions(fragInfo,"pageLoader");if(this.targetValue.indexOf("_ajax")==-1){return ;}

var params=this.loadObj||{}
;params.command="pageLoader";ActionHandler.addAction(linkEl,params);}
;}
;
var LinkingUtil=new LinkingUtilBase();function LinkingUtilBase(){
this.buildInnerHTMLInput=function(parentEl,linkEl){if(null!=linkEl){return ;}

var div=cE("div",parentEl);div.style.margin="15px 0px 5px 0px";div.className="boldText";div.innerHTML="Link display";var range=EditUtil.iconBar.storedRange;var valueStr=range.toString();var props=
{
value:valueStr,
style:{width:300}
,
}
;return buildTextInput(parentEl,props);}
;
this.buildUrlLoadOptions=function(parentEl,linkEl,linkObj){var div=cE("div",parentEl);div.style.margin="15px 0px 8px 0px";div.innerHTML="Display url in";var initValue=(linkEl!=null)?linkEl.target:"_parent";if(""==initValue){initValue="_parent";}

var rbHolder=cE("div",parentEl);var ajaxHolder=cE("div",parentEl);ajaxHolder.style.visibility="hidden";this.buildAjaxOptionsDD(ajaxHolder,initValue,linkObj);var rb=new RadioButton();rb.addOption("Same window","_parent");rb.addOption("New  window","_blank");rb.addOption("Load with ajax","_ajax");var thisObj=this;var onChange=function(targetValue){var options=LivePage.getRegistryItems("AjaxLoad");if("_parent"==targetValue||"_blank"==targetValue||options==null){ajaxHolder.style.visibility="hidden";linkObj.loadObj=null;}

else 
{ajaxHolder.style.visibility="visible";}

linkObj.targetValue=targetValue;}
;rb.onChange=onChange;initValue=(initValue.indexOf("_ajax")>-1)?"_ajax":initValue;rb.build(rbHolder,initValue);onChange(initValue);}
;this.buildAjaxOptionsDD=function(parentEl,curTargetValue,linkObj){var dd=cE("select",parentEl);var option=cE("option",dd);option.innerHTML="Default";option.value=null;var options=LivePage.getRegistryItems("AjaxLoad");if(null==options){return ;}

for(var name in options)
{var option=cE("option",dd);option.innerHTML=name;option.loadObj=options[name];var selectedTarget=curTargetValue.split("#");if(selectedTarget[1]!=undefined&&selectedTarget[1]==name){option.selected=true;linkObj.targetValue="_ajax#"+name;linkObj.loadObj=option.loadObj;}

}

var fx=function(){var selOption=dd.options[dd.selectedIndex];linkObj.targetValue="_ajax#"+selOption.innerHTML;linkObj.loadObj=selOption.loadObj;}
;E.change(dd,fx);}
;}
;
;;;;;;function LinkPopup(prevLink){this.prevLink=prevLink;this.contentArea;this.popup;this.onLink;this.build=function(){var titlePrefix=(this.prevLink!=null)?"Edit":"Insert";var lpPopup=new LpPopup();lpPopup.title=titlePrefix+" Link";lpPopup.width=400;this.popup=lpPopup.popup;var cA=lpPopup.build();cA.style.padding="20px 25px 30px 25px";this.contentArea=cA;this.buildTable(cA);var popup=lpPopup.popup;this.popup=popup;popup.setFrameHeight(230);popup.center();}
;this.buildTable=function(parentEl){var tBody=createTable(parentEl);this.createPageWithinSiteLink(tBody);this.createUrlLink(tBody);this.createEventLink(tBody);this.createEmailLink(tBody);}
;this.createPageWithinSiteLink=function(tBody){var tr=cE("tr",tBody);var thisObj=this;var fx=function(){var parentEl=thisObj.contentArea;parentEl.innerHTML="";var internalLink=new InternalPageLink(thisObj.popup,thisObj.prevLink);internalLink.onLink=thisObj.onLink;internalLink.onCancel=thisObj.onCancel;internalLink.build(parentEl);thisObj.resetHeight(315);}
;E.click(tr,fx);var td=cE("td",tr);td.style.cursor="pointer";td.style.height="45px";var image=cE("img",td);image.src="/upload/custom_screens/html5/livepage/link_page_site.png";var td=cE("td",tr);td.style.cursor="pointer";td.style.paddingLeft="12px";td.style.fontWeight="bold";td.style.color="#333333";td.className="mediumBoldText linkColor";td.innerHTML="Link to a url within the site";addUnderlineEvents(td);}
;this.createEventLink=function(tBody){var tr=cE("tr",tBody);var thisObj=this;var fx=function(){showProgressIcon("loading...");thisObj.popup.close();var parentEl=thisObj.contentArea;parentEl.innerHTML="";var popup=new EventChooserPopup();popup.onClick=function(eventId){popup.popup.close();var inserter=new EventInserter(eventId,thisObj.prevLink);inserter.onLink=thisObj.onLink;inserter.onCancel=thisObj.onCancel;inserter.build();}
;popup.build();}
;E.click(tr,fx);var td=cE("td",tr);td.style.cursor="pointer";td.style.height="45px";var image=cE("img",td);image.src="/upload/custom_screens/html5/livepage/link_to_event.png";var td=cE("td",tr);td.style.cursor="pointer";td.style.paddingLeft="12px";td.style.fontWeight="bold";td.style.color="#333333";td.className="mediumBoldText linkColor";td.innerHTML="Link to an event";addUnderlineEvents(td);}
;this.createUrlLink=function(tBody){var tr=cE("tr",tBody);var thisObj=this;var fx=function(){var parentEl=thisObj.contentArea;parentEl.innerHTML="";var urlLink=new UrlLink(thisObj.popup,thisObj.prevLink);urlLink.onLink=thisObj.onLink;urlLink.onCancel=thisObj.onCancel;urlLink.build(parentEl);thisObj.resetHeight();}
;E.click(tr,fx);var td=cE("td",tr);td.style.cursor="pointer";td.style.height="45px";var image=cE("img",td);image.src="/upload/custom_screens/html5/livepage/link_external_url.png";var td=cE("td",tr);td.style.cursor="pointer";td.style.paddingLeft="12px";td.style.fontWeight="bold";td.style.color="#333333";td.className="mediumBoldText linkColor";td.innerHTML="Link to an external url";addUnderlineEvents(td);}
;this.createEmailLink=function(tBody){var tr=cE("tr",tBody);var thisObj=this;var fx=function(){var parentEl=thisObj.contentArea;parentEl.innerHTML="";var emailLink=new EmailLink(thisObj.popup,thisObj.prevLink);emailLink.onLink=thisObj.onLink;emailLink.onCancel=thisObj.onCancel;emailLink.build(parentEl);thisObj.resetHeight();}
;E.click(tr,fx);var td=cE("td",tr);td.style.cursor="pointer";td.style.height="45px";var image=cE("img",td);image.src="/upload/custom_screens/html5/livepage/link_email_addres.png";var td=cE("td",tr);td.style.cursor="pointer";td.style.paddingLeft="12px";td.style.fontWeight="bold";td.style.color="#333333";td.className="mediumBoldText linkColor";td.innerHTML="Link to an email address";addUnderlineEvents(td);}
;this.resetHeight=function(height){if(!height){height=this.contentArea.offsetHeight;}

this.popup.setFrameHeight(height);}
;}
;
;function EditLinkPopup(aTag){this.aTag=aTag;this.contentArea;this.popup;this.build=function(){var lpPopup=new LpPopup();lpPopup.title="Edit Link";lpPopup.width=300;this.popup=lpPopup.popup;var cA=lpPopup.build();cA.style.padding="25px 20px 25px 5px";this.contentArea=cA;this.completeBuild(cA);this.popup.setFrameHeight(140);this.popup.center();}
;this.completeBuild=function(parentEl){var div=cE("div",parentEl);div.style.textAlign="center";var thisObj=this;var editP=cE("p",div);editP.style.cursor="pointer";editP.style.paddingLeft="12px";editP.style.fontWeight="bold";editP.style.color="#333333";editP.className="mediumBoldText linkColor";editP.innerHTML="Edit the current Link";var editFx=function(){var linkPopup=new LinkPopup(aTag);linkPopup.build();thisObj.popup.close();}
;eh_attachEvent("onclick",editP,editFx);var removeP=cE("p",div);removeP.style.cursor="pointer";removeP.style.paddingLeft="12px";removeP.style.fontWeight="bold";removeP.style.color="#333333";removeP.className="mediumBoldText linkColor";removeP.innerHTML="Remove the Link";var removeFx=function(){removeNode(aTag);thisObj.popup.close();}
;eh_attachEvent("onclick",removeP,removeFx);}
;}
;
;;function LinkIcon(){this.build=function(parentEl){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/link_icon.gif)";var thisObj=this;var onclickFx=function(){var range=EditUtil.iconBar.storedRange;RangeUtil.selectRange(range);var el=BrowserUtil.isIE()?range.parentElement():range.commonAncestorContainer;var aTag=getNearestAncestor(el,"A");var linkPopup;if(aTag){linkPopup=new EditLinkPopup(aTag);}

else 
{var linkPopup=new LinkPopup();}

linkPopup.build();}
;E.click(parentEl,onclickFx);}
;this.helpTip="Insert Link";}

function UnlinkIcon(){this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/unlink_icon.gif)";var thisObj=this;var onclickFx=function(){var range=EditUtil.iconBar.storedRange;RangeUtil.selectRange(range);var el=BrowserUtil.isIE()?range.parentElement():range.commonAncestorContainer;var aTag=getNearestAncestor(el,"A");if(aTag){removeNode(aTag);}

}
;E.click(parentEl,onclickFx);}
;this.helpTip="Remove Link";}

;
function ChooseImageIcon(){this.alignValue="";this.libraryPopup;this.build=function(parentEl){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/image_icon.gif)";var thisObj=this;var onclickFx=function(){showProgressIcon("loading images...");var fx=function(){var imagePopup=new ImagePopup();imagePopup.selectImgFx=function(imageId){var imgRec=imagePopup.mc.getRecord("image_library",imageId);thisObj.insertImage(imgRec);}
;imagePopup.build();thisObj.libraryPopup=imagePopup.popup;hideProgressIcon();}
;sl_loadScript('/0/le8121_0.js',fx);fx;
}
;E.click(parentEl,onclickFx);}
;
this.insertImage=function(record){var width=null;var height=this.imageHeight;var imageField=record.getField("file");var originalPath=imageField.getChildField("full_path").getValue();var path=originalPath;var ext=ImageUtil.getExtension(originalPath);var isJpg=("jpg"==ext||"jpeg"==ext||"png"==ext||"gif"==ext);if(isJpg){path=imageField.getImagePath(width,height,true);}

var img=cE("img")
img.alt=record.getField("name").getValue();img.src=path;if(this.alignValue&&isJpg){img.style["float"]=this.alignValue;}

var range=EditUtil.getRange();RangeUtil.selectRange(range);RangeUtil.insertNode(range,img);this.libraryPopup.close();if(isJpg){var popup=new ImageEditorPopup(img,"Change Image");popup.build();}

}
;this.helpTip="Insert Image";}
;
function UploadImageIcon(){this.imageHeight=140;this.build=function(parentEl,rte){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/image_simple_upload_icon.gif)";var thisObj=this;var onclickFx=function(){showProgressIcon();var fx=function(){var uploadImage=new UploadImagePopup();uploadImage.afterUpload=function(record){thisObj.insertImage(record);}
;uploadImage.build();hideProgressIcon();}
;sl_loadScript('/0/le8517_0.js',fx);fx;}
;E.click(parentEl,onclickFx);}
;this.insertImage=function(record){var width=null;var height=this.imageHeight;var imageField=record.getField("file");var originalPath=imageField.getChildField("full_path").getValue();var path=originalPath;var ext=ImageUtil.getExtension(originalPath);var isJpg=("jpg"==ext||"jpeg"==ext||"png"==ext||"gif"==ext);if(isJpg){path=imageField.getImagePath(width,height,true);}

var img=cE("img")
img.alt=record.getField("name").getValue();img.src=path;if(this.alignValue&&isJpg){img.style["float"]=this.alignValue;}

var range=EditUtil.getRange();RangeUtil.selectRange(range);RangeUtil.insertNode(range,img);if(isJpg){var popup=new ImageEditorPopup(img,"Change Image");popup.build();}

}
;this.helpTip="Upload Image";}

function InsertFileIcon(){this.build=function(parentEl){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/architect/modulerte/icons/insert_file_icon.gif)";var onclickFx=function(){var fx=function(){var popup=new UploadFilePopup();popup.build();}
;sl_loadScript('/0/le8519_0.js',fx);fx;}
;E.click(parentEl,onclickFx);}
;this.helpTip="Insert File";}

function InsertEmbedIcon(){this.build=function(parentEl){var div=cE("div",parentEl);div.style.backgroundColor="#FAFAFA";div.style.width="23px";div.style.height="22px";div.style.backgroundImage="url(/upload/custom_screens/html5/livepage/embed_icon.png)";var onclickFx=function(){var fx=function(){var popup=new ThirdPartyPopup();popup.build();}
;sl_loadScript('/0/le8123_0.js',fx);fx;}
;eh_attachEvent("onclick",parentEl,onclickFx);}
;this.helpTip="Add Third Party Content";}


;function FormatIcon(){this.fontSize=12;this.width=120;this.build=function(parentEl){var holder=cE("div",parentEl);var dd=new FlexDropDown(this.onChange);this.dd=dd;dd.drawOuterBorder=false;dd.height=22;dd.doc=(g_params["utw"]=="true")?window.top.document:document;dd.ddAlignment="belowRight";var span=this.addFormat("Paragraph Format","",dd,true);span.style.fontStyle="italic";this.addFormat("Normal","p",dd);this.addFormat("Heading 1","h1",dd);this.addFormat("Heading 2","h2",dd);this.addFormat("Heading 3","h3",dd);var ddEl=dd.build(holder,this.width,this.value);var thisObj=this;dd.onBeforeShowOptions=function(){var frame=EditUtil.getIconBar().frame;var coord=findElCoord(frame,false);dd.offsetLeft=coord.x+1;dd.offsetTop=coord.y+1;}
;}
;this.onChange=function(value){var range=EditUtil.getIconBar().storedRange;var values=["block"];var elToChange=getAncestorByStyles(range.commonAncestorContainer,"display",values);var newNode=cE(value);switchNode(newNode,elToChange);EditUtil.makeElEditable(newNode);return ;var styleObj={fontFamily:value}
;RangeUtil.applyStyles(range,styleObj);}
;this.addFormat=function(displayName,format,dd,isDefault){var span=cE("span");span.style.fontSize=this.fontSize+"px";span.style.whiteSpace="nowrap";span.innerHTML=displayName;dd.addOptionEl(span,format,isDefault);return span;}
;this.helpTip="Change Format";}
;
;;;;;;;;;;;;;;;;;;;;;;;;;;;function IconBar(){this.iconItems=[];this.storedRange;}
;IconBar.prototype=new IconBarBase();function IconBarBase(){this.popup;this.infoEl;this.doc;this.contentArea;this.frameWidth="600px";this.frameHeight="74px";this.keyDownFx;this.build=function(){var popup=new Popup();this.popup=popup;popup.shadow=true;popup.disableBg=false;popup.fadeBg=false;popup.showX=false;popup.offsetTop=-45;popup.alignment="aboveLeft";popup.isDrawHidden=true;if(g_params["utw"]=="true"){var doc=window.top.document;this.doc=doc;popup.doc=doc;}

var thisObj=this;popup.onEsc=function(){thisObj.hide();}
;var contentArea=popup.build();this.contentArea=contentArea;contentArea.style.backgroundColor="#F5EEF6";CssUtil.makeNotSelectable(contentArea);this.buildTopBar(contentArea);var thisObj=this;var enterFx=function(){thisObj.storedRange=RangeUtil.getSelectedRange();}
;E.mouseenter(contentArea,enterFx);this.setIcons();var div=cE("div",contentArea);var holder=this.buildHolder(div);this.initCss();this.buildIcons(holder);this.attachKeyDown();}
;this.attachKeyDown=function(){if(this.keyDownFx){return ;}

var doc=this.doc||document;var thisObj=this;var fx=this.keyDownFx=function(){thisObj.handleKeyDown();}
;E.add(doc.body,"keyup",fx);}
;this.handleKeyDown=function(){if("none"==CssUtil.getStyle(this.popup.anchor,"display")){this.detachKeyDown();}

this.update();}
;this.detachKeyDown=function(){var doc=this.doc||document;E.remove(doc.body,"keyup",this.keyDownFx);this.keyDownFx=null;}
;this.buildTopBar=function(parentEl){var dragger=cE("div",parentEl);dragger.align="center";dragger.style.paddingTop="3px";dragger.style.height="6px";dragger.style.fontSize=0;dragger.style.cursor="move";dragger.style.position="relative";var thisObj=this;E.click(dragger);var onDragStart=function(){thisObj.coverFrame();}
;var onDragEnd=function(){thisObj.uncoverFrame();RangeUtil.selectRange(thisObj.storedRange);}
;this.popup.makeDraggable(dragger,onDragStart,onDragEnd);var dotSrc="/upload/custom_screens/architect/components/dropdownmenu/grip_dot.gif";for(var i=0;i<4;i++)
{var dot=cE("img",dragger);dot.src=dotSrc;dot.style.margin="2px";}

parentEl.style.position="relative";var img=cE("img",parentEl);img.style.position="absolute";img.style.zIndex=1000;img.style.right="5px";img.style.top="5px";img.src="/upload/js_globals/generic_images/popup_close.gif";img.style.cursor="pointer";var thisObj=this;var closeFx=function(){thisObj.hide();ContainerHandler.enableFramers();}
;E.click(img,closeFx);}
;this.buildHolder=function(parentEl){parentEl.style.position="relative";var cover=cE("div",parentEl);cover.style.position="absolute";this.cover=cover;this.buildInfoPopup(parentEl);var div=cE("div",parentEl);div.innerHTML="<iframe id='iconBar' frameborder='0'></iframe>";var frame=div.firstChild;frame.style.padding=0;frame.style.margin=0;frame.style.width=this.frameWidth;frame.style.height=this.frameHeight;this.frame=frame;var thisObj=this;var fx=function(){thisObj.hideInfo();}
;E.mouseleave(frame,fx);this.editWindow=frame.contentWindow;var doc=frame.contentWindow.document;doc.open();this.iconDoc=doc;doc.write("<!DOCTYPE HTML>");doc.write("<html><head><style type=\"text/css\"></style>");doc.write("</head><body>");doc.write("</body></html>");doc.close();return cE("div",doc.body);}
;this.buildInfoPopup=function(parentEl){var info=cE("div",parentEl);this.infoEl=info;info.className="ib_saQuickInfoBox";info.style.position="absolute";info.style.display="none";info.style.zIndex=CssUtil.getHighestZIndex();}
;this.coverFrame=function(){var cover=this.cover;cover.style.display="";cover.style.width=this.frame.offsetWidth+"px";cover.style.height=this.frame.offsetHeight+"px";cover.style.zIndex=10000;}
;this.uncoverFrame=function(){var cover=this.cover;cover.style.display="none";}
;this.show=function(element,noOverlapEl){var popup=this.popup;popup.positionEl=element;popup.anchor.style.display="";if(popup.doc==element.ownerDocument){popup.align(null,noOverlapEl);}

else 
{var parentFrame=window.top["m-iframe"+g_params.module_id];var frameCoords=findElCoord(parentFrame,false);var noOvCoords=findElCoord(noOverlapEl,true);var top=frameCoords.y+noOvCoords.y-100;var left=frameCoords.x;popup.setAtCoord(left,top);popup.align("coordinate");popup.adjustForOffScreen();}

popup.putOnTop();this.attachKeyDown();}
;this.hide=function(){var popup=this.popup;popup.anchor.style.display="none";}
;this.unhide=function(){var popup=this.popup;popup.anchor.style.display="";}
;this.update=function(){for(var i=0;i<this.iconItems.length;i++)
{var t=this.iconItems[i];if(t.update){t.update();}

}

}
;this.isIconBarOpen=function(){return (this.popup.anchor.style.display!="none");}
;this.addIconGroup=function(group){this.iconItems.push(group);}
;this.buildGroup=function(parentEl,group){var tBody=createTable(parentEl);tBody.parentNode.style.margin="0 6px";var tr=cE("tr",tBody);for(var i=0;i<group.icons.length;i++)
{var td=cE("td",tr);td.style.padding="0 2px";this.buildIcon(td,group.icons[i]);}

}
;this.addLineBreak=function(){var lineBreak={type:"line_break"}
;this.iconItems.push(lineBreak);}
;this.showInfo=function(element,icon){var thisObj=this;var fx=function(){var info=thisObj.infoEl;info.style.display="";var coord=findElCoord(element,false);info.style.left=coord.x+"px";info.style.top=(coord.y-element.offsetHeight-8)+"px";info.innerHTML=icon.getHelpTip?icon.getHelpTip():icon.helpTip;}
;this.infoTimerId=setTimeout(fx,500);}
;this.hideInfo=function(){clearTimeout(this.infoTimerId);var info=this.infoEl;info.style.display="none";}
;this.buildIcon=function(parentEl,icon){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);td.align="center";td.className="ib_icon";var thisObj=this;var enterFx=function(){thisObj.showInfo(td,icon);}
;E.mouseenter(td,enterFx);var leaveFx=function(){thisObj.hideInfo();}
;E.mouseleave(td,leaveFx);var holder=cE("div",td);icon.build(holder);}
;this.buildIcons=function(parentEl){var container=cE("div",parentEl);var tBody=createTable(container);var tr=cE("tr",tBody);for(var i=0;i<this.iconItems.length;i++)
{var td=cE("td",tr);var item=this.iconItems[i];if("group"==item.type){this.buildGroup(td,item);}

else if("icon"==item.type){this.buildIcon(td,item);}

else if("line_break"==item.type){var tBody=createTable(container);if(i>0){tBody.parentNode.style.marginTop="7px";}

tr=cE("tr",tBody);}

}

}
;this.initCss=function(){var cssClass=new CssClass(".ib_saQuickInfoBox");cssClass.add("background-color","#f6f29c");cssClass.add("border","1px solid black");cssClass.add("font-size","11px");cssClass.add("font-family","arial");cssClass.add("padding","2px 4px");cssClass.add("box-shadow","3px 3px 3px #888888");cssClass.init(this.doc);var cssClass=new CssClass(".ib_icon");cssClass.add("border","1px solid #B2B2B2");cssClass.add("height","22px");cssClass.add("border-radius","2px");cssClass.add("cursor","pointer");cssClass.init(this.iconDoc);var cssClass=new CssClass(".ib_icon:hover");cssClass.add("border","1px solid #3399CC");cssClass.init(this.iconDoc);}
;this.setIcons=function(){var group=new IconGroup();group.addIcon(new FontSelector());group.addIcon(new FontSizeSelector());group.addIcon(new FontColorIcon());group.addIcon(new BackgroundColorIcon());this.addIconGroup(group);var group=new IconGroup();group.addIcon(new BoldIcon());group.addIcon(new ItalicIcon());group.addIcon(new UnderlineIcon());this.addIconGroup(group);var group=new IconGroup();group.addIcon(new BulletsIcon());group.addIcon(new NumberingIcon());this.addIconGroup(group);var group=new IconGroup();group.addIcon(new AlignLeftIcon());group.addIcon(new AlignMiddleIcon());group.addIcon(new AlignRightIcon());this.addIconGroup(group);var group=new IconGroup();group.addIcon(new UnindentIcon());group.addIcon(new IndentIcon());this.addIconGroup(group);this.addLineBreak();var group=new IconGroup();group.addIcon(new LineSpacingIcon());this.addIconGroup(group);var group=new IconGroup();group.addIcon(new RemoveFormatIcon());this.addIconGroup(group);var group=new IconGroup();group.addIcon(new LinkIcon());group.addIcon(new UnlinkIcon());this.addIconGroup(group);var group=new IconGroup();group.addIcon(new TableIcon());group.addIcon(new DividerLineIcon());group.addIcon(new CharacterMapIcon());this.addIconGroup(group);var group=new IconGroup();group.addIcon(new ChooseImageIcon());group.addIcon(new UploadImageIcon());group.addIcon(new InsertFileIcon());group.addIcon(new InsertEmbedIcon());this.addIconGroup(group);var group=new IconGroup();group.addIcon(new FormatIcon());this.addIconGroup(group);}
;}
;

function js_isEmpty(object){for(var i in object)
{var notEmpty=object[i];return false;}

return true;}


;var RangeUtil=new RangeUtilBase();function RangeUtilBase(){this.createRange=function(){return document.createRange();}
;this.selectRange=function(range){if(B.isIE()){range.select();}

else 
{var selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);}

}
;this.getStyle=function(range,property){var s=CssUtil.findStyle(range.startContainer,property);var e=CssUtil.findStyle(range.endContainer,property);return (s==e)?s:null;}
;this.insertNode=function(range,node){if(B.isIE()){if(range.parentElement().document!=this.doc){this.body.appendChild(node);}

else 
{range.execCommand("InsertButton",true,"temp");var placeHolder=this.doc.getElementById("temp");placeHolder.parentNode.replaceChild(node,placeHolder);}

}

else 
{range.deleteContents();range.insertNode(node);}

}
;
this.clearSelection=function(){var selection=window.getSelection();selection.removeAllRanges();}
;this.getSelectedRange=function(){var doc=document;if(B.isIE()){var range=this.doc.selection.createRange();if(!RangeUtil.isRangeInDoc(range,this.doc)){range=RangeUtil.createRange(this.doc);}

return range;}

else 
{var selection=window.getSelection();var rangeCount=selection.rangeCount;if(rangeCount==0){var range=doc.createRange();if(doc.body.childNodes.length>0){var posEl=doc.body.childNodes[doc.body.childNodes.length-1];range.setStartAfter(posEl);range.collapse(true);}

selection.addRange(range);return range;}

else if(rangeCount==1){return selection.getRangeAt(0);}

else 
{alert("multiple range selection");return null;}

}

}
;this.getStartContainer=function(range){if(!B.isIE()){return range.startContainer;}

var tester=range.duplicate();tester.collapse(true);return tester.parentElement();}
;this.getEndContainer=function(range){if(!B.isIE()){return range.endContainer;}

var tester=range.duplicate();tester.collapse(false);return tester.parentElement();}
;this.applyStyles=function(range,styleObj){if(IS_IE){this.applyStylesIE(range,styleObj);}

else 
{if(0==range.cloneContents().childNodes.length){var sN=document.createElement("span");sN.innerHTML="&#8203;";for(var j in styleObj)
{sN.style[j]=styleObj[j];}

range.insertNode(sN);range.setStartAfter(sN);range.setEndAfter(sN);var selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);document.body.focus();}

else 
{var selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);var existing=gL("SUP");for(var i=0;i<existing.length;i++)
{css_addClassToEl(existing[i],"rteTemp");existing[i].setAttribute("rteTemp","sup");}

var editEl=range.commonAncestorContainer;if(editEl.nodeType==3){editEl=editEl.parentElement;}

var origValue=editEl.contentEditable;var wasEditable=("true"==origValue);if(!wasEditable){editEl.contentEditable="true";}

document.execCommand("superscript",false,1);if(!wasEditable){editEl.contentEditable=origValue;}

var temp=gL("SUP");var tags=[];for(var i=0;i<temp.length;i++)
{if(!temp[i].getAttribute("rteTemp")){tags.push(temp[i]);}

}

var nodes=[];for(var i=0;i<tags.length;i++)
{var fN=tags[i];var p=fN.parentNode;var sN;if(p.childNodes.length==1&&"SPAN"==p.tagName){sN=p;removeNode(fN);}

else 
{sN=cE("span",null);switchNode(sN,fN);}

nodes.push(sN);for(var j in styleObj)
{sN.style[j]=styleObj[j];}

this.removeChildrenStyles(sN,styleObj);}

temp=[];var els=gL(".rteTemp")
for(var i=0;i<els.length;i++)
{temp.push(els[i]);}

for(var i=0;i<temp.length;i++)
{var supEl=cE("sup",null);switchNode(supEl,temp[i]);}

selection.removeAllRanges();if(0<nodes.length){var range=document.createRange();var temp=document.createRange();range.selectNode(nodes[0]);for(var i=0;i<nodes.length;i++)
{temp.selectNode(nodes[i]);var compare=range.compareBoundaryPoints(Range.START_TO_START,temp);if(compare==1){range.setStartBefore(nodes[i]);}

compare=range.compareBoundaryPoints(Range.END_TO_END,temp);if(compare==-1){range.setEndAfter(nodes[i]);}

}

selection.addRange(range);temp.detach();}

}

}

return range;}
;this.removeChildrenStyles=function(node,styleObj){var emptySpans=[];var spans=node.getElementsByTagName("span");for(var i=0;i<spans.length;i++)
{var span=spans[i];for(var j in styleObj)
{span.style[j]="";}

var attrs=getAttributes(span);if(js_isEmpty(attrs)){emptySpans.push(span);}

}

for(var i=0;i<emptySpans.length;i++)
{removeNode(emptySpans[i]);}

}
;}


var ListElUtil=new ListElUtilBase();function ListElUtilBase(){
this.getRootListEl=function(el){var parentTag=el.parentNode.tagName;while(parentTag=="LI"||parentTag=="UL"||parentTag=="OL")
{el=el.parentNode;parentTag=el.parentNode.tagName;}

return el;}
;this.getBulletDepth=function(li){var bulletUp=li.parentNode.parentNode;if(bulletUp.tagName!="LI"){return 1;}

else 
{return 1+this.getBulletDepth(bulletUp);}

}
;}
;

;var EditUtil=new EditUtilBase();function EditUtilBase(){this.editEl;this.iconBar;this.textTags={H1:1,H2:1,H3:1,H4:1,H5:1,H6:1,P:1,LI:1,TD:1}
;this.indentPixels=40;this.delinkedEls=[];this.isDisabled=false;this.handleMouseUp=function(e){if(!this.isDisabled){this.attemptEdit(e.srcElement);}

}
;this.disable=function(){this.isDisabled=true;}
;this.enable=function(){this.isDisabled=false;}
;this.attemptEdit=function(el){if(el.tagName=="IMG"){this.deselectEditEl();return false;}

var linkEl=getNearestAncestor(el,"A");if(linkEl!=null){this.makeLinkEditable(el,linkEl);this.reLinkEls();return true;}

var range=RangeUtil.getSelectedRange();var firstEl=this.getEditableEl(range.startContainer);var lastEl=this.getEditableEl(range.endContainer);if(firstEl!=lastEl){this.selectEls(firstEl,lastEl);this.reLinkEls();return false;}

var node=range.commonAncestorContainer;if(!this.isElEditable(node)){this.hide();return false;}

var editableEl=this.getEditableEl(node);if(isDescendent(editableEl.parentElement,el)){return false;}

this.makeElEditable(node);var thisObj=this;var fx=function(e){return thisObj.onClick(e);}
;LivePage.setOnClick(fx);this.reLinkEls();return true;}
;this.reLinkEls=function(){var els=this.delinkedEls;for(var i=0;i<els.length;i++)
{sA(els[i],"href");}

}
;this.handleMouseDown=function(e){var linkEl=getNearestAncestor(e.srcElement,"A");if(linkEl==null){return ;}

var hRef=linkEl.href;rA(linkEl,"href");this.delinkedEls.push(linkEl);}
;this.onClick=function(e){var range=RangeUtil.getSelectedRange();var node=range.commonAncestorContainer;if(this.isElEditable(node)){if(this.editEl==this.getEditableEl(node)){var iconBar=this.getIconBar();iconBar.unhide();return true;}

else 
{this.attemptEdit(node);return true;}

}

this.hide();return false;}
;this.hide=function(){this.deselectEditEl();ContainerHandler.enableFramers();}
;this.isElEditable=function(node){if(!LivePage.isBeforeEOF(node)){return false;}

var isClean=true;if(node.nodeType==3){var el=node.parentElement;if(el.tagName=="LI"){return true;}

for(var i=0;i<el.childNodes.length;i++)
{var child=el.childNodes[i];if(child.nodeType==1&&CssUtil.getStyle(child,"display")!="inline"&&(child.tagName!="IMG")){isClean=false;}

}

if(!isClean){var newParent=insertParent("p",node,node);}

return true;}

else 
{if(node.tagName=="LI"){return true;}

var isTextTag=this.textTags[node.tagName];if((node.childNodes.length==0||node.offsetHeight==0)&&!isTextTag){return false;}

if(""==node.innerText.trim()&&!isTextTag){return false;}

for(var i=0;i<node.childNodes.length;i++)
{var child=node.childNodes[i];if(child.nodeType==1&&CssUtil.getStyle(child,"display")!="inline"&&(child.tagName!="IMG")){return false;}

}

return true;}

}
;this.selectEls=function(firstEl,lastEl){var iconBar=this.getIconBar();iconBar.show(firstEl);}
;this.getPrevEditableEl=function(node){node=getPreviousNode(node);if(node==document.body){return null;}

while(node&&!this.isElEditable(node))
{if(node==document.body){return ;}

node=getPreviousNode(node);}

return this.getEditableEl(node);}
;this.getNextEditableEl=function(node){node=getLastDescendent(node);node=getNextElement(node);if(node==document.body){return null;}

while(node&&!this.isElEditable(node))
{if(node==document.body){return ;}

node=getNextElement(node);}

return this.getEditableEl(node);}
;this.getEditableEl=function(node){var values=["block","table","table-cell"];var el=getAncestorByStyles(node,"display",values);if(!el){return null;}

if(el.tagName=="UL"||el.tagName=="OL"||el.tagName=="LI"){el=ListElUtil.getRootListEl(el);}

return el;}
;this.setEditEl=function(node){this.editEl=node;}
;this.makeLinkEditable=function(node,linkEl){this.makeElEditable(node);}
;this.makeElEditable=function(node){if(node.nodeType==3){node=node.parentNode;}

var focusNode=node;var node=this.getEditableEl(node);if(this.editEl==node){return ;}

this.deselectEditEl();ContainerHandler.disableFramers();node.contentEditable="true";focusNode.focus();this.setEditEl(node);var iconBar=this.getIconBar();iconBar.show(node,focusNode);var thisObj=this;var fx=function(){if(thisObj.editEl!=node){thisObj.deselectEditEl();return ;}

if(node.outerHTML==thisObj.focusElHtml){return ;}

LivePage.setElementToSave(node);}
;E.blur(node,fx);this.editableElement=node;return node;}
;this.deselectEditEl=function(){if(!this.editEl){return ;}

this.hideIconBar();CssUtil.removeClassFromEl(this.editEl,"lp_editEl");this.editEl.contentEditable="inherit";this.editEl=null;var highlighted=gL(".lp_editEl");for(var i=0;i<highlighted.length;i++)
{CssUtil.removeClassFromEl(highlighted[i],"lp_editEl");}

}
;this.getIconBar=function(){if(this.iconBar){this.iconBar.update();return this.iconBar;}

var iconBar=new IconBar();this.iconBar=iconBar;iconBar.build();return iconBar;}
;this.hideIconBar=function(){if(!this.iconBar){return ;}

this.iconBar.hide();}
;this.getRange=function(){var range=EditUtil.iconBar.storedRange;if(range.commonAncestorContainer=="body"){alert("out of container");return null;}

return range;}
;this.indent=function(){var range=RangeUtil.getSelectedRange();var startBlock=getAncestorByStyle(RangeUtil.getStartContainer(range),"display","block");var endBlock=getAncestorByStyle(RangeUtil.getEndContainer(range),"display","block");if(!startBlock&&!endBlock){return ;}

if(startBlock==endBlock&&isTagType(startBlock,["OL","UL"])){var tagType=(isTagType(startBlock,["OL"]))?"ol":"ul";var oldLi=range.startContainer;while(!isTagType(oldLi,["LI"]))
{oldLi=oldLi.parentNode;}

var newUlParent=oldLi.previousElementSibling||oldLi.parentNode;var newUl=cE(tagType);if(newUlParent==oldLi.parentNode){newUlParent.insertBefore(newUl,oldLi.nextElementSibling);}

else 
{newUlParent.appendChild(newUl);}

newUl.appendChild(oldLi);range.setStartBefore(oldLi);range.setEndBefore(oldLi);window.getSelection().removeAllRanges();window.getSelection().addRange(range);}

else 
{var block=startBlock;while(block)
{var prop=("TD"==block.tagName)?"paddingLeft":"marginLeft";block.style[prop]=CssUtil.pixelToInt(block.style[prop])+this.indentPixels+"px";if(block==endBlock){break;}

else 
{block=getNextSiblingByStyle(block,"display","block");}

}

}

}
;this.unindent=function(){var range=RangeUtil.getSelectedRange();var startBlock=getAncestorByStyle(RangeUtil.getStartContainer(range),"display","block");var endBlock=getAncestorByStyle(RangeUtil.getEndContainer(range),"display","block");if(!startBlock&&!endBlock){return ;}

if(startBlock==endBlock&&isTagType(startBlock,["OL","UL"])){var newLi=range.startContainer.parentNode;while(!isTagType(newLi,["LI"]))
{newLi=newLi.parentNode;}

var oldUl=newLi.parentNode;var oldUlParent=oldUl.parentNode;if(!isTagType(oldUlParent,["LI","OL","UL"])){return ;}

if(isTagType(oldUlParent,["LI"])){if(oldUlParent.nextElementSibling){oldUlParent.parentNode.insertBefore(newLi,oldUlParent.nextElementSibling);}

else 
{oldUlParent.parentNode.appendChild(newLi);}

}

else 
{if(!oldUl.nextElementSibling){oldUlParent.appendChild(newLi);}

else 
{oldUlParent.insertBefore(newLi,oldUl.nextElementSibling);}

}

range.setStartBefore(newLi);range.setEndBefore(newLi);window.getSelection().removeAllRanges();window.getSelection().addRange(range);if(oldUl.children.length==0){oldUlParent.removeChild(oldUl);}

}

else 
{var blockEl=startBlock;while(blockEl)
{var prop=("TD"==blockEl.tagName)?"paddingLeft":"marginLeft";var newPos=CssUtil.pixelToInt(blockEl.style[prop])-this.indentPixels;if(this.indentPixels<=newPos){blockEl.style[prop]=newPos+"px";}

else 
{blockEl.style[prop]="";}

if(blockEl==endBlock){break;}

else 
{blockEl=getNextSiblingByStyle(blockEl,"display","block");}

}

}

}
;this.reset=function(){this.editabeElement=null;}
;}
;

function ToolBarPopup(){this.storedRange;this.isDragging=false;}
;ToolBarPopup.prototype=new ToolBarPopupBase();function ToolBarPopupBase(){this.popup;this.infoEl;this.contentWidth;this.contentHeight;this.onEnter;this.onLeave;this.closeFx;this.isIsolate=true;this.build=function(){var popup=new Popup();this.popup=popup;popup.shadow=true;popup.disableBg=false;popup.fadeBg=false;popup.showX=false;popup.alignment="belowRight";popup.isDrawHidden=true;popup.doc=this.doc||document;var thisObj=this;popup.closeFx=function(){if(thisObj.closeFx){thisObj.closeFx();}

}
;var contentArea=popup.build();contentArea.style.backgroundColor="#F5EEF6";CssUtil.makeNotSelectable(contentArea);this.buildTopBar(contentArea);var enterFx=function(){if(thisObj.isDragging){return ;}

thisObj.storedRange=RangeUtil.getSelectedRange();if(thisObj.onEnter){thisObj.onEnter();}

}
;E.mouseenter(contentArea,enterFx);var leaveFx=function(){if(thisObj.isDragging){return ;}

if(thisObj.onLeave){thisObj.onLeave();}

}
;E.mouseleave(contentArea,leaveFx);var div=cE("div",contentArea);if(this.isIsolate){return this.buildHolder(div);}

else 
{if(this.contentWidth){div.style.width=this.contentWidth;}

return div;}

}
;this.close=function(){this.popup.close();}
;this.showAt=function(element,offsetLeft,offsetTop){var yPos=document.body.scrollTop;var xPos=document.body.scrollLeft;var popup=this.popup;popup.positionEl=element;popup.anchor.style.display="";popup.offsetLeft=offsetLeft;popup.offsetTop=offsetTop;popup.align();window.scrollTo(xPos,yPos);}
;this.buildTopBar=function(parentEl){var dragger=cE("div",parentEl);dragger.align="center";dragger.style.paddingTop="6px";dragger.style.height="10px";dragger.style.fontSize=0;dragger.style.cursor="move";dragger.style.position="relative";var thisObj=this;E.click(dragger);var onDragStart=function(){CssUtil.makeNotSelectable(document.body);thisObj.isDragging=true;thisObj.coverFrame();}
;var onDragEnd=function(){CssUtil.makeSelectable(document.body);thisObj.uncoverFrame();RangeUtil.selectRange(thisObj.storedRange);thisObj.isDragging=false;}
;this.popup.makeDraggable(dragger,onDragStart,onDragEnd);var dotSrc="/upload/custom_screens/architect/components/dropdownmenu/grip_dot.gif";for(var i=0;i<4;i++)
{var dot=cE("img",dragger);dot.src=dotSrc;dot.style.margin="2px";}

parentEl.style.position="relative";var img=cE("img",parentEl);img.style.position="absolute";img.style.right="5px";img.style.top="5px";img.src="/upload/js_globals/generic_images/popup_close.gif";img.style.zIndex=10000;img.style.cursor="pointer";var thisObj=this;var closeFx=function(){thisObj.close();}
;E.click(img,closeFx);}
;this.setContentHeight=function(height){this.contentHeight=height
this.frame.style.height=height;}
;this.buildHolder=function(parentEl){parentEl.style.position="relative";var cover=cE("div",parentEl);cover.style.position="absolute";this.cover=cover;var div=cE("div",parentEl);div.innerHTML="<iframe frameborder='0'></iframe>";var frame=div.firstChild;frame.style.padding=0;frame.style.margin=0;frame.style.width=this.contentWidth;frame.style.height=this.contentHeight;this.frame=frame;this.editWindow=frame.contentWindow;var doc=frame.contentWindow.document;doc.open();this.doc=doc;doc.write("<!DOCTYPE HTML>");doc.write("<html><head><style type=\"text/css\"></style>");doc.write("</head><body>");doc.write("</body></html>");doc.close();doc.body.style.padding=0;doc.body.style.margin=0;var holder=cE("div",doc.body);return holder;}
;this.coverFrame=function(){if(!this.cover){return ;}

var cover=this.cover;cover.style.display="";cover.style.width=this.frame.offsetWidth+"px";cover.style.height=this.frame.offsetHeight+"px";cover.style.zIndex=10000;}
;this.uncoverFrame=function(){if(!this.cover){return ;}

var cover=this.cover;cover.style.display="none";}
;this.show=function(element){var popup=this.popup;popup.positionEl=element;popup.anchor.style.display="";popup.align();}
;this.hide=function(){var popup=this.popup;popup.anchor.style.display="none";}
;}
;

;;function ColorPopup(positionEl,onChange,color){this.positionEl=positionEl;this.onChange=onChange;this.color=color||"";this.closeFx;this.showCustomColorPicker=true;this.offsetLeft=0;this.offsetTop=0;this.popup;this.build=function(){var popup=new ToolBarPopup();popup.doc=(g_params["utw"]=="true")?window.top.document:document;this.popup=popup;popup.contentWidth="225px";popup.contentHeight="225px";var contentArea=popup.build();var thisObj=this;var onDblClick=function(){thisObj.popup.close();}
;var onChangeFx=function(color){thisObj.color=color;if(thisObj.onChange){thisObj.onChange(color);}

}
;popup.closeFx=function(){RangeUtil.selectRange(popup.storedRange);}
;var colorPicker=new FullColorPicker(this.color,onChangeFx,onDblClick);colorPicker.showCustomColorPicker=this.showCustomColorPicker;colorPicker.build(contentArea);colorPicker.onShowMore=function(){popup.setContentHeight("440px");popup.popup.adjustForOffScreen();}
;
popup.onLeave=function(){RangeUtil.selectRange(popup.storedRange);}
;popup.showAt(this.positionEl,this.offsetLeft,this.offsetTop);}
;
}
;

var PasteHandler=new PasteHandlerBase();function PasteHandlerBase(){this.init=function(){var thisObj=this;var fx=function(e){if(LivePage.isBeforeEOF(e.srcElement)){thisObj.handlePaste(e);}

}
;var settings={stop:false}
;E.paste(document,fx,settings);}
;this.handlePaste=function(event){var range=RangeUtil.getSelectedRange();range.deleteContents();var el=cE("textarea");el.style.height="1px";el.style.width="1px";el.style.fontSize="1px";el.style.outline=0;el.style.border=0;el.style.resize="none";el.style.overflow="hidden";el.style.color="transparent";range.insertNode(el);el.focus();var thisObj=this;var fx=function(){thisObj.handleAfterPaste(el);}
;window.setTimeout(fx,50);}
;this.handleAfterPaste=function(el){var values=["block","table-cell","box","flex-box","list-item"];var block=getAncestorByStyles(el,"display",values);var newText=el.value;var range=RangeUtil.createRange();range.selectNode(el);range.deleteContents();var node;var lines=newText.split("\n");if(1<=lines.length){var text=lines[0];if(text.charCodeAt(0)==8226){var ul=cE("ul");insertAfter(ul,block);node=cE("li",ul);node.innerHTML=text.substring(1).trim();block=ul;}

else 
{node=document.createTextNode(lines[0]);range.insertNode(node);range.collapse(false);}

}

if(1==lines.length){range.selectNode(node);range.collapse(false);RangeUtil.selectRange(range);return ;}

for(var i=1;i<lines.length;i++)
{var text=lines[i];if(text.charCodeAt(0)==8226){if(node.tagName=="LI"){var depth=ListElUtil.getBulletDepth(node);ul=node.parentNode;for(var j=depth;j>1;j--)
{ul=ul.parentNode.parentNode;}

node=cE("li",ul);node.innerHTML=text.substring(1).trim();block=ul;}

else 
{var ul=cE("ul");insertAfter(ul,block);node=cE("li",ul);node.innerHTML=text.substring(1).trim();block=ul;}

}

else if(text.charCodeAt(0)==111&&block.tagName=="UL"){var depth=ListElUtil.getBulletDepth(node);var ul;if(depth==1){ul=cE("ul",node);}

else 
{ul=node.parentNode;for(var j=depth;j>2;j--)
{ul=ul.parentNode.parentNode;}

}

node=cE("li",ul);node.innerHTML=text.substring(1).trim();block=ul;}

else if(text.charCodeAt(0)==61607&&block.tagName=="UL"){var depth=ListElUtil.getBulletDepth(node);for(var j=depth;j<=3;j++)
{ul=cE("ul",node);}

node=cE("li",ul);node.innerHTML=text.substring(1).trim();block=ul;}

else 
{node=cE("p");node.innerHTML=text;insertAfter(node,block);block=node;}

}

EditUtil.makeElEditable(node);range.selectNodeContents(node);range.collapse(false);RangeUtil.selectRange(range);}
;}

;var KeyHandler=new KeyHandlerBase();function KeyHandlerBase(){this.init=function(){var thisObj=this;var fx=function(e){thisObj.handleKeyDown(e);}
;var settings={stop:false}
;E.keydown(document.body,fx,settings);var thisObj=this;var fx=function(e){thisObj.handleKeyUp(e);}
;var settings={stop:false}
;E.keyup(document.body,fx,settings);PasteHandler.init();}
;this.handleKeyDown=function(event){var srcEl=event.srcElement;if(!LivePage.isBeforeEOF(srcEl)&&srcEl.tagName!="BODY"){return ;}

if(event.ctrlKey){return ;}

this.handleSelection(event);var fxName=this.keyDownFxs[this.getKeyCode(event)];var fx=this[fxName];if(fx){fx.call(this,event);}

}
;this.handleSelection=function(event){var code=this.getKeyCode(event);if(!((code>46&&code<=90)||code==13||code==8||code==9||(code>=96&&code<=111)||(code>=186&&code<=222))){return ;}

this.deleteSelection(event);}

this.deleteSelection=function(event){var range=RangeUtil.getSelectedRange();var firstEl=EditUtil.getEditableEl(range.startContainer);var lastEl=EditUtil.getEditableEl(range.endContainer);var isMulti=(firstEl!=lastEl);if(isMulti&&0==range.endOffset){var lastEditEl=EditUtil.getPrevEditableEl(range.endContainer);if(lastEditEl.childNodes.length==0){alert("fix");}

var end=lastEditEl.childNodes[lastEditEl.childNodes.length-1];range.setEndAfter(end);range.deleteContents();RangeUtil.selectRange(range);return ;}

range.deleteContents();RangeUtil.selectRange(range);if(isMulti){this.combineEls(firstEl,lastEl);}

}
;this.handleKeyUp=function(event){if(!LivePage.isBeforeEOF(event.srcElement)){return ;}

var fxName=this.keyUpFxs[this.getKeyCode(event)];var fx=this[fxName];if(fx){fx.call(this,event);}

}
;this.isMultiBlockSel=function(){var range=RangeUtil.getSelectedRange();var firstEl=EditUtil.getEditableEl(range.startContainer);var lastEl=EditUtil.getEditableEl(range.endContainer);return (firstEl!=lastEl);}
;this.isRangeAtElStart=function(range,element){if(!element){return false;}

var testRange=range.cloneRange();testRange.setStartBefore(element);return testRange.toString().trim()=="";}
;this.isRangeAtElEnd=function(range,element){var testRange=range.cloneRange();testRange.setEndAfter(element);return testRange.toString().trim()=="";}
;this.onBackSpaceDown=function(e){var range=RangeUtil.getSelectedRange();var editEl=EditUtil.editEl;var test=this.isRangeAtElStart(range,editEl);if(!test){return ;}

var prevEl=EditUtil.getPrevEditableEl(editEl);if(!prevEl||prevEl.parentElement!=editEl.parentElement){return ;}

E.stop(e);var editableEl=EditUtil.makeElEditable(prevEl);editableEl.focus();this.combineEls(prevEl,editEl);}
;this.onDeleteDown=function(e){var range=RangeUtil.getSelectedRange();var isSelEmpty=(range.toString()=="");if(!isSelEmpty){E.stop(e);this.deleteSelection(e);return ;}

var editEl=EditUtil.editEl;var test=this.isRangeAtElEnd(range,editEl);if(!test){return ;}

E.stop(e);var nextEl=EditUtil.getNextEditableEl(editEl);if(""==editEl.innerText){removeNode(editEl);if(nextEl){this.putCursorAtFront(nextEl);}

}

else if(!nextEl||!isDescendent(nextEl,editEl.parentElement)){return ;}

else 
{this.combineEls(editEl,nextEl);}

}
;this.combineEls=function(el,nextEl){var newStart;while(nextEl.childNodes[0])
{var node=nextEl.removeChild(nextEl.childNodes[0]);if(node.tagName=="LI"){while(node.childNodes[0])
{var subNode=node.removeChild(node.childNodes[0]);if(!newStart){newStart=subNode;}

aE(el,subNode);}

continue;}

if(!newStart){newStart=node;}

aE(el,node);}

nextEl.parentNode.removeChild(nextEl);this.putCursorAtFront(newStart);}
;this.putCursorAtFront=function(element){var range=RangeUtil.createRange();range.selectNode(element);range.collapse(true);EditUtil.makeElEditable(range.startContainer);RangeUtil.selectRange(range);}
;this.onEnterDown=function(e){if(e.shiftKey){return ;}

var range=RangeUtil.getSelectedRange();var values=["block","table-cell","box","flex-box","list-item"];var elToSplit=getAncestorByStyles(range.commonAncestorContainer,"display",values);if(elToSplit.tagName=="LI"){this.enterOnLi(elToSplit,e);return ;}

E.stop(e);var tempEl=cE("b");RangeUtil.insertNode(range,tempEl);this.splitEl(elToSplit,tempEl);}
;this.enterOnLi=function(liEl,e){if(""!=liEl.innerText.trim()){return ;}

E.stop(e);var rootListEl=ListElUtil.getRootListEl(liEl);var next=liEl.nextElementSibling;if(next&&next.tagName=="LI"){this.splitEl(rootListEl,liEl);}

else 
{var parent=liEl.parentNode;parent.removeChild(liEl);var pEl=cE("p");insertAfter(pEl,rootListEl);var editableEl=EditUtil.makeElEditable(pEl);editableEl.focus();var range=RangeUtil.createRange();range.selectNodeContents(pEl);range.collapse(true);RangeUtil.selectRange(range);}

}
;this.splitEl=function(elToSplit,splitPointEl){var splittingEl=splitPointEl.parentNode;var parent=elToSplit.parentNode;do
{var splitCond=(splitPointEl.nextSibling==splittingEl.lastChild&&splittingEl.lastChild.nodeType==3&&splittingEl.lastChild.data.search(/\S/)<0);var frontEl=splittingEl.cloneNode(false);var tempEl=splittingEl.childNodes[0];while(tempEl&&tempEl!=splitPointEl)
{var nextEl=tempEl.nextSibling;splittingEl.removeChild(tempEl);aE(frontEl,tempEl);tempEl=nextEl;}

var backEl=(splitCond)?cE("p"):splittingEl.cloneNode(false);tempEl=tempEl.nextSibling;while(tempEl)
{var nextEl=tempEl.nextSibling;splittingEl.removeChild(tempEl);aE(backEl,tempEl);tempEl=nextEl;}

var next=splittingEl.parentNode;splitPointEl.parentNode.removeChild(splitPointEl);insertAfter(backEl,splittingEl);insertAfter(splitPointEl,splittingEl);insertAfter(frontEl,splittingEl);splittingEl.parentNode.removeChild(splittingEl);splittingEl=next;}

while(splittingEl!=parent);splitPointEl.parentNode.removeChild(splitPointEl);EditUtil.makeElEditable(backEl);}
;this.onRightArrowDown=function(e){var range=RangeUtil.getSelectedRange();var editEl=EditUtil.editEl;var testRange=range.cloneRange();testRange.collapse(false);var test=this.isRangeAtElEnd(testRange,editEl);if(!test){return ;}

var nextEl=EditUtil.getNextEditableEl(editEl);if(!nextEl){return ;}

E.stop(e);if(range.collapsed){var editableEl=EditUtil.makeElEditable(nextEl);editableEl.focus();var range=RangeUtil.createRange();range.selectNodeContents(nextEl);range.collapse(true);RangeUtil.selectRange(range);}

}
;
this.getCoordInfo=function(){var range=RangeUtil.getSelectedRange();var beforeSpan=cE("span");this.storedRange.surroundContents(beforeSpan);var afterSpan=cE("span");range.surroundContents(afterSpan);var c1=findElCoord(beforeSpan);var c2=findElCoord(afterSpan);removeNode(beforeSpan);removeNode(afterSpan);range.detach();return {c1:c1,c2:c2}
;}
;this.onDownArrowDown=function(e){var range=RangeUtil.getSelectedRange();var editEl=EditUtil.editEl;var test=this.isRangeAtElEnd(range,editEl);if(!test){return ;}

var nextEl=EditUtil.getNextEditableEl(editEl);if(!nextEl){return ;}

E.stop(e);var editableEl=EditUtil.makeElEditable(nextEl);if(!editableEl){return ;}

editableEl.focus();var range=RangeUtil.createRange();range.selectNodeContents(editableEl);range.collapse(true);RangeUtil.selectRange(range);}
;this.onUpArrowDown=function(e){var range=RangeUtil.getSelectedRange();var editEl=EditUtil.editEl;var test=this.isRangeAtElStart(range,editEl);if(!test){return ;}

var prevEl=EditUtil.getPrevEditableEl(editEl);if(!prevEl){return ;}

E.stop(e);var editableEl=EditUtil.makeElEditable(prevEl);editableEl.focus();var range=RangeUtil.createRange();range.selectNodeContents(editableEl);range.collapse(false);RangeUtil.selectRange(range);}
;this.onLeftArrowDown=function(e){var range=RangeUtil.getSelectedRange();var editEl=EditUtil.editEl;var test=this.isRangeAtElStart(range,editEl);if(!test){return ;}

var prevEl=EditUtil.getPrevEditableEl(editEl);if(!prevEl){return ;}

E.stop(e);var editableEl=EditUtil.makeElEditable(prevEl);editableEl.focus();var range=RangeUtil.createRange();range.selectNodeContents(editableEl);range.collapse(false);RangeUtil.selectRange(range);}
;this.onTabDown=function(e){if(!EditUtil.editEl){return ;}

E.stop(e);if(e.shiftKey){EditUtil.unindent();}

else 
{EditUtil.indent();}

}
;this.clearRange=function(){if(this.storedRange){this.storedRange.detach();this.storedRange=null;}

}
;this.storeRange=function(){this.storedRange=RangeUtil.getSelectedRange();}
;this.getKeyCode=function(event){return B.isIE()?event.keyCode:event.which;}
;this.keyDownFxs={8:"onBackSpaceDown",40:"onDownArrowDown",39:"onRightArrowDown",37:"onLeftArrowDown",38:"onUpArrowDown",13:"onEnterDown",9:"onTabDown",46:"onDeleteDown"}
;this.keyUpFxs={40:"onDownArrowUp",38:"onUpArrowUp"}
;}


var g_curHoverPopup=null;function HoverPopup(positionEl){this.positionEl=positionEl;this.onShow;this.onBeforeShow;
this.alignment="upperRight";
this.position="absolute";
this.closeDelay=500;
this.showDelay=0;this.skipAlign=false;this.doc;this.popup;this.isOverPopup=false;this.isOverEl=false;}

HoverPopup.prototype=new HoverPopupBase();function HoverPopupBase(){this.init=function(){var thisObj=this;var enterFx=function(){thisObj.onMouseEnter();}
;E.mouseenter(this.positionEl,enterFx,{stop:false}
);var thisObj=this;var leaveFx=function(){thisObj.onMouseLeave();}
;E.mouseleave(this.positionEl,leaveFx);}
;this.onMouseEnter=function(){if(g_curHoverPopup!=null){g_curHoverPopup.close();g_curHoverPopup=null;}

this.isOverEl=true;this.handleShow();}
;this.show=function(){if(this.popup||!this.isOverEl){return ;}

if(this.onBeforeShow){if(!this.onBeforeShow()){return ;}

}

var popup=new Popup();popup.position=this.position;this.popup=popup;g_curHoverPopup=popup;if(this.doc){popup.doc=this.doc;}

popup.setAsAnchor(this.positionEl,this.alignment);popup.disableBg=false;var contentArea=popup.build();this.addPopupEvents(contentArea);this.onShow(contentArea);if(!this.skipAlign){popup.align();}
;}
;this.addPopupEvents=function(contentArea){var thisObj=this;var enterFx=function(){thisObj.isOverPopup=true;}
;E.mouseenter(contentArea,enterFx,{stop:false}
);var thisObj=this;var leaveFx=function(){thisObj.isOverPopup=false;thisObj.onMouseLeave();}
;E.mouseleave(contentArea,leaveFx);}
;this.onMouseLeave=function(){this.isOverEl=false;this.handleClose();}
;this.handleShow=function(){var thisObj=this;var fx=function(){thisObj.show();}
;window.setTimeout(fx,this.showDelay);}
;this.handleClose=function(){var thisObj=this;var fx=function(){thisObj.close();}
;window.setTimeout(fx,this.closeDelay);}
;this.close=function(){if(this.popup&&(this.isOverEl||this.isOverPopup)){return ;}

this.forceClose();}
;this.forceClose=function(){if(!this.popup){return ;}

this.popup.close();this.popup=null;}
;}
;
function LiveCyclePopup(){this.cycleEl;this.fragInfo;this.isDragging=false;this.draggingEl;this.frameTBody;this.liveCycle;this.popup;this.closeFx;this.framesDiv;this.build=function(){var cycleEl=this.cycleEl;this.fragInfo=A.getFragInfo(cycleEl.id);var thisObj=this;debugger;var popup=new Popup();this.popup=popup;popup.width=370;popup.title="Cycle Editor";popup.positionEl=cycleEl;var coord=findElCoord(cycleEl,true);if(coord.x>this.width){popup.alignment="upperLeft";popup.offsetLeft=-10;}

else 
{popup.alignment="outsideUpperRight";}

popup.titleDragBarClass="lp_popupTitleBar";popup.closeImg="/upload/custom_screens/html5/livepage/close_icon.gif";popup.showX=true;popup.useFrame=false;popup.disableBg=false;popup.fadeBg=false;popup.ensureOnTop=true;var thisObj=this;var closeFx=function(){thisObj.fragInfo.liveCycleObj.exitEditMode();if(null!=thisObj.closeFx){thisObj.closeFx();}

}
;popup.closeFx=closeFx;var contentArea=popup.build();contentArea.style.fontFamily="arial";contentArea.style.fontSize="14px";CssUtil.makeNotSelectable(contentArea);CssUtil.addClassToEl(contentArea,"lp_reset");this.framesDiv=cE("div",contentArea);this.framesDiv.style.padding="6px";this.buildFrames(this.framesDiv);var autoPlay=this.liveCycle.fragInfo.params.autoplay;if(autoPlay&&autoPlay=="yes"){var div=cE("div",contentArea);div.style.padding="6px";this.buildInterval(div);}

var buttonHolder=cE("div",contentArea);buttonHolder.style.padding="10px 0";buttonHolder.style.margin="auto 43%";var doneEl=cE("button",buttonHolder);doneEl.className="lp_darkButton";doneEl.innerHTML="DONE";var thisObj=this;var doneFx=function(){closeFx();}
;E.click(doneEl,doneFx);popup.align();}
;this.buildControl=function(){var parentEl=this.controlHolder;parentEl.innerHTML="";var thisObj=this;var span=cE("span",parentEl);span.style.cursor="pointer";span.innerHTML="Apply Changes";var startFx=function(){thisObj.liveCycle.startCycle();thisObj.buildControl(parentEl);}
;E.click(span,startFx);}
;this.buildInterval=function(parentEl){var tBody=createTable(parentEl);tBody.style.fontSize="14px";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.fontWeight="bold";td.innerHTML="Time Interval";var td=cE("td",tr);td.style.paddingLeft="6px";var thisObj=this;var fx=function(value){thisObj.liveCycle.changeInterval(value);}
;var properties={onAfterChangeFx:fx,"decimalPlaces":1,"displayName":"Cycle Interval","value":(this.fragInfo.interval),style:{width:"30px",textAlign:"right",paddingRight:"5px"}
}
;buildNumberInput(td,properties);var td=cE("td",tr);td.style.fontSize="12px";td.style.paddingLeft="6px";td.innerHTML="seconds";}
;this.syncFrameOrder=function(){var modules=[];var str="";var rows=this.frameTBody.childNodes;for(var i=0;i<rows.length;i++)
{var moduleInfo={moduleId:gA(rows[i],"moduleId"),modulePath:gA(rows[i],"modulePath")}
;modules.push(moduleInfo);var lastIteration=(i<rows.length-1)?false:true;str+=(lastIteration)?moduleInfo.modulePath:moduleInfo.modulePath+", ";}

this.fragInfo.modules=modules;this.fragInfo.params.modules=str;}
;this.buildFrames=function(parentEl){if(parentEl.children.length>0){parentEl.innerHTML="";}

var div=cE("div",parentEl);div.style.fontWeight="bold";div.style.marginBottom="4px";div.innerHTML="Slides";var tBody=createTable(parentEl);this.frameTBody=tBody;tBody.style.fontSize="14px";var modules=this.fragInfo.modules;for(var i=0;i<modules.length;i++)
{var moduleInfo=modules[i];this.buildFrame(tBody,moduleInfo);}

var div=cE("div",parentEl);div.style.fontSize="12px";div.style.margin="4px 0 0 8px";div.style.cursor="pointer";div.innerHTML="+ add slide";var thisObj=this;var addFx=function(){showProgressIcon("creating slide");var mc=new MiniCache();mc.addTemplateToLoad("module");mc.addTemplateToLoad("style_sheet");var createModule=function(){var newModuleName="slides."+new Date().toLocaleString();var moduleRec=mc.createRecord("module");moduleRec.getField("name").setValue(newModuleName);moduleRec.getField("feature_key").setValue("site_editor");var styleSheetRec=mc.createRecord("style_sheets");styleSheetRec.getField("resource_name").setValue(newModuleName);moduleRec.getField("style_sheet.id").setValue(styleSheetRec.id);var onProcess=function(){debugger;var newModuleId=mc.getRecord("module",moduleRec.id).id;thisObj.liveCycle.addModule(newModuleId,newModuleName);thisObj.buildFrames(thisObj.framesDiv);}
;mc.process(onProcess);hideProgressIcon();}

mc.process(createModule);}
;E.click(div,addFx);}
;this.buildFrame=function(tBody,moduleInfo){var tr=cE("tr",tBody);sA(tr,"modulePath",moduleInfo.modulePath);sA(tr,"moduleId",moduleInfo.moduleId);var thisObj=this;var fx=function(){if(!thisObj.isDragging){return ;}

var draggingEl=thisObj.draggingEl;if(draggingEl==tr){return ;}

var isBefore=isBeforeSibling(tr,draggingEl);draggingEl.parentNode.removeChild(draggingEl);if(isBefore){tr.parentNode.insertBefore(draggingEl,tr);}

else 
{insertAfter(draggingEl,tr);}

}
;E.mouseenter(tr,fx);var td=cE("td",tr);td.style.width="20px";td.style.padding="1px";var deleteIcon=cE("img",td);deleteIcon.style.cursor="pointer";deleteIcon.src="/upload/custom_screens/html5/livepage/lp_delete_frame_icon.gif";var deleteFx=function(){
thisObj.liveCycle.deleteModule(moduleInfo.moduleId);tBody.removeChild(tr);}
;E.click(deleteIcon,deleteFx);var td=cE("td",tr);td.style.width="20px";td.style.padding="1px";var editIcon=cE("img",td);editIcon.style.cursor="pointer";editIcon.src="/upload/custom_screens/html5/livepage/lp_edit_frame_icon.jpg";var editFx=function(){debugger;thisObj.liveCycle.editModule(moduleInfo.moduleId);}
;E.click(editIcon,editFx);var td=cE("td",tr);td.style.width="250px";td.style.padding="1px 0 1px 5px";td.innerHTML=moduleInfo.modulePath;var td=cE("td",tr);td.style.width="60px";td.style.fontSize="12px";td.style.cursor="move";td.innerHTML="re-order";this.addDragEvents(td,tr);}
;this.addDragEvents=function(grip,frameRow){var thisObj=this;DragUtil.getXOffset=function(dragEl){return 300;}
;DragUtil.getYOffset=function(dragEl){return 0;}
;var createDragElFx=function(){var dragEl=frameRow.cloneNode(true);dragEl.className="a_tools";dragEl.style.border="3px dashed #d6e0f5";dragEl.style.width=grip.parentNode.offsetWidth+"px";return dragEl;}
;var onDragStart=function(){fade_setOpacity(frameRow,50);thisObj.isDragging=true;thisObj.draggingEl=frameRow;}
;var onDragEnd=function(){thisObj.isDragging=false;fade_resetOpacity(frameRow);thisObj.syncFrameOrder();thisObj.liveCycle.initCycle();thisObj.liveCycle.setToSave();}
;DragUtil.makeDraggable(grip,null,onDragStart,onDragEnd,createDragElFx);}
;}
;
;;function LiveCycle(){this.cycleEl;this.isEditMode=false;this.fragInfo;this.originalHeight;this.modulesByPath={}
;this.init=function(data){data.liveCycleObj=this;this.fragInfo=data;var el=gE("#"+data.elId);this.cycleEl=el;var isNew=(data.elId.indexOf("temp")>-1);if(isNew){var cycleFramer=new CycleFramer(el);cycleFramer.frame();}

this.initCycle();}
;this.changeInterval=function(value){this.fragInfo.params.interval=value;this.setToSave();}
;this.setEditMode=function(){this.isEditMode=true;var el=this.cycleEl;var framer=this.fragInfo.framer;var onScroll=function(){framer.reframe();}
;this.onScroll=onScroll;E.add(el,"scroll",onScroll);CssUtil.removeClassFromEl(el,"a-meta-live-cycle");CssUtil.addClassToEl(el,"a-meta-live-cycle");var cycleObj=this.fragInfo.cycleObj;if(cycleObj){cycleObj.pause();}

var cycleEl=this.cycleEl;var fragInfo=A.getFragInfo(cycleEl.id);var popup=new LiveCyclePopup();popup.liveCycle=fragInfo.liveCycleObj;popup.cycleEl=this.cycleEl;popup.build();this.fragInfo.editPopup=popup;}
;this.exitEditMode=function(){var el=this.cycleEl;E.remove(el,"scroll",this.onScroll);var fI=this.fragInfo;fI.framer.destroy();fI.framer=null;this.isEditMode=false;debugger;el.scrollLeft=0;CssUtil.removeClassFromEl(el,"a-meta-live-cycle");this.startCycle();}
;this.setToSave=function(){LivePage.setElementToSave(this.cycleEl.parentNode);}
;this.deleteModule=function(moduleId){var modules=this.fragInfo.modules;var params=this.fragInfo.params;params.modules="";for(var i=0;i<modules.length;i++)
{if(modules[i].moduleId==moduleId){modules.splice(i,1);LivePage.setElementToSave(this.cycleEl.parentNode);break;}

}

for(var i=0;i<modules.length;i++)
{var module=modules[i];var path=module.modulePath;var separator=(i<modules.length-1)?", ":"";params.modules+=modules[i].modulePath+separator;}

this.initCycle();this.setToSave();}
;this.editModule=function(moduleId){var cycleObj=this.fragInfo.cycleObj;var modules=this.fragInfo.modules
for(var i=0;i<modules.length;i++)
{var moduleInfo=modules[i];if(moduleInfo.moduleId==moduleId){cycleObj.showSlide(i);break;}

}
;}
;this.startCycle=function(){this.isEditMode=false;this.initCycle();}
;this.initCycle=function(afterInit){var fragInfo=this.fragInfo;var el=gE("#"+fragInfo.elId);var cycle=new Cycle(el);cycle.liveCycle=true;this.addParams(cycle,fragInfo.params);cycle.modules=[];var startCount=0;var orgCycleEl=fragInfo.cycleObj;var modules=fragInfo.params.modules.split(",");for(var i=startCount;i<modules.length;i++)
{var path=modules[i].trim();if(""==path){continue;}

var module=this.modulesByPath[path];if(!module){var module={path:path,status:"notLoaded"}
;this.modulesByPath[path]=module;}

cycle.modules.push(module);}

var orgCycleEl=fragInfo.cycleObj;if(null!=orgCycleEl){el.removeChild(orgCycleEl.controlEl);}

var slideHolder=el.firstElementChild;this.removeSlides(slideHolder);var thisObj=this;var onInit=function(){if(afterInit){afterInit();return ;}

var framer=thisObj.fragInfo.framer;if(framer){framer.destroy();var tO=function(){framer.frame();}

window.setTimeout(tO,1000);}

}
;cycle.init(onInit);fragInfo.cycleObj=cycle;}
;
this.removeSlides=function(slideHolder){var slideEls=slideHolder.children;for(var i=0;i<slideEls.length;i++)
{var slideEl=slideEls[i];var firstChild=slideEl.children[0];if(null!=firstChild){LivePage.removeFragInfo(firstChild.id);}

}

slideHolder.innerHTML="";}
;this.addParams=function(cycle,p){cycle.interval=5;cycle.elType="div";cycle.delay=0;cycle.autoplay=true;cycle.fixedHeight=false;cycle.buttonControls=false;cycle.arrowControls=false;cycle.numberButtons=false;cycle.useDynamicMargin=false;for(var i in p)
{if(null==p[i]||p[i]==""){continue;}

if(i=="interval"){cycle.interval=p[i];}

else if(i=="elementType"){cycle.elType=(p[i]!="ul")?"div":"ul";}

else if(i=="delay"){cycle.delay=p[i];}

else if(i=="autoplay"){cycle.autoplay=(p[i]=="no")?false:true;}

else if(i=="isFixedHeight"){cycle.fixedHeight=(p[i]=="true")?true:false;}

else if(i=="controls"){cycle.buttonControls=(p[i].indexOf("buttons")>-1)?true:false;cycle.arrowControls=(p[i].indexOf("arrows")>-1)?true:false;cycle.numberButtons=(p[i].indexOf("numbered")>-1)?true:false;}

else if(i=="useDynamicMargin"){cycle.useDynamicMargin=(p[i]=="true"||p[i]=="yes")?true:false;}

else 
{cycle[i]=p[i];}

}

}
;this.addModule=function(moduleId,modulePath){var newModule={}
;newModule.moduleId=moduleId;newModule.modulePath=modulePath;var modules=this.fragInfo.modules;var params=this.fragInfo.params;params.modules="";modules.push(newModule);LivePage.setElementToSave(this.cycleEl.parentNode);for(var i=0;i<modules.length;i++)
{var module=modules[i];var path=module.modulePath;var separator=(i<modules.length-1)?", ":"";params.modules+=modules[i].modulePath+separator;}

var thisObj=this;var afterInit=function(){thisObj.editModule(moduleId);}
;this.initCycle(afterInit);}
;this.initLiveCssClass=function(){var cC=new CssClass(".a-meta-live-cycle");cC.add("overflow-x","scroll");cC.init();}
;this.initLiveCssClass();}
;

;var LiveCycleHandler=new LiveCycleHandlerBase();function LiveCycleHandlerBase(){this.init=function(data){var cycle=new LiveCycle();cycle.init(data);}
;this.initHandler=function(){ATagInitializer.addSpecialModeHandler("visual_edit","cycle",this);}
;}

var SaCss=new SiteArchitectCss();function SiteArchitectCss(){this.init=function(){this.initExistingStyles();this.initNewStyles();this.initButtonStyles();}

this.initNewStyles=function(){var cls=new CssClass("*, *:before, *:after");cls.add("-webkit-box-sizing","border-box");cls.add("-moz-box-sizing","border-box");cls.add("box-sizing","border-box");cls.init();var cls=new CssClass("html, body");cls.add("padding","0px");cls.add("margin","0px");cls.add("width","100%");cls.add("height","100%");cls.add("overflow","hidden");cls.add("-webkit-box-sizing","border-box");cls.add("-moz-box-sizing","border-box");cls.add("box-sizing","border-box");cls.add("background-color","#2c3e50");cls.init();var cls=new CssClass("body");cls.add("margin","0px");cls.add("padding","0px");cls.add("overflow","hidden");cls.add("font-family","Open Sans, arial");cls.init();var cls=new CssClass("button");cls.add("font-family","Open Sans");cls.add("font-size","14px");cls.add("font-weight","600");cls.init();var cls=new CssClass("span");cls.add("display","inline");cls.init();var cls=new CssClass("#screenContainer");cls.add("height","100%");cls.add("width","100%");cls.init();var cls=new CssClass(".sa_bgColor");cls.add("background-color","#2c3e50");cls.init();var cls=new CssClass(".sa_whiteText");cls.add("color","#ffffff");cls.init();var cls=new CssClass(".sa_regularTextSize");cls.add("font-size","14px");cls.init();var cls=new CssClass(".sa_stretchBar");cls.add("background-color","#2c3e50");cls.add("width","5px");cls.init();var cls=new CssClass(".flexColGrip");cls.add("background-color","#a7b6c5");cls.add("margin-bottom","2px");cls.add("width","2px");cls.add("height","2px");cls.init();var cls=new CssClass(".sa_toolbarHeader");cls.add("background-color","#f5f5f5");cls.add("height","25px");cls.add("border-bottom","1px solid #ffffff");cls.init();var cls=new CssClass(".sa_toolbar");cls.add("font-size","12px");cls.add("color","#333333");cls.add("font-weight","bold");cls.init();var cls=new CssClass(".sa_organizeLink");cls.add("color","#3498db");cls.add("font-size","11px");cls.add("margin-right","10px");cls.add("font-weight","600");cls.add("position","relative");cls.add("top","-2px");cls.init();var cls=new CssClass(".sa_siteLinksButtonHolder");cls.add("padding","0px 8px");cls.init();var cls=new CssClass(".sa_siteLinksCenterButtonHolder");cls.add("border-right","1px solid #5f81a0");cls.add("border-left","1px solid #5f81a0");cls.add("padding","0px 10px");cls.init();var cls=new CssClass(".sa_siteLinksJsButtonHolder");cls.add("border-right","1px solid #5f81a0");cls.add("padding","0px 10px");cls.init();var cls=new CssClass(".sa_transparentIcon");cls.add("opacity","0.65");cls.add("filter","alpha(opacity=65)");cls.init();var cls=new CssClass(".sa_transparentIcon:hover");cls.add("opacity","1");cls.add("filter","alpha(opacity=100)");cls.init();var cls=new CssClass(".sa_iconHolder");cls.add("padding","0px 8px 0px 8px");cls.init();var cls=new CssClass(".sa_centerIconHolder");cls.add("border-right","1px solid #5f81a0");cls.add("border-left","1px solid #5f81a0");cls.add("padding","0px 12px 0px 12px");cls.init();var cls=new CssClass(".sa_btnHolder");cls.add("display","inline");cls.init();var cls=new CssClass(".sa_pageTitle");cls.add("font-size","24px");cls.add("margin-bottom","10px");cls.add("color","#ffffff");cls.init();var cls=new CssClass(".sa_blankPageName");cls.add("font-style","italic");cls.add("color","#c0c8d0");cls.init();var cls=new CssClass(".sa_pageUrl");cls.add("font-size","14px");cls.add("color","#c0c8d0");cls.init();var cls=new CssClass(".sa_urlInput");cls.add("font-size","14px");cls.add("color","#ffffff");cls.add("font-weight","600");cls.add("background-color","#1abc9c");cls.add("padding","2px 5px 2px 5px");cls.add("margin-left","2px");cls.add("border","0px");cls.init();var cls=new CssClass(".sa_urlEdit");cls.add("font-size","14px");cls.add("color","#000000");cls.add("background-color","#ffffff");cls.add("padding","2px 5px 2px 5px");cls.add("margin-left","2px");cls.add("border","0px");cls.init();var cls=new CssClass(".sa_nameEdit");cls.add("color","#000000");cls.add("background-color","#ffffff");cls.add("padding","2px 5px 2px 5px");cls.add("margin-left","2px");cls.add("border","0px");cls.init();var cls=new CssClass(".sa_rightLabel");cls.add("font-size","14px");cls.add("color","#c0c8d0");cls.add("background-color","#385774");cls.add("font-weight","600");cls.add("text-align","left");cls.add("padding","5px 0px 5px 12px")
cls.init();var cls=new CssClass(".sa_radioLabel");cls.add("font-size","14px");cls.add("color","#cccccc");cls.init();var cls=new CssClass(".sa_radioLabelOn");cls.add("color","#1abc9c");cls.init();var cls=new CssClass(".sa_radioCont");cls.add("padding","18px 0px 18px 0px");cls.init();var cls=new CssClass(".sa_buttonCell");cls.add("padding-left","12px");cls.init();var cls=new CssClass(".sa_pageTitleInput");cls.add("width","213px");cls.add("height","25px");cls.add("font-size","16px");cls.add("padding-left","5px");cls.add("-webkit-border-radius","6px");cls.add("-moz-border-radius","6px");cls.add("border-radius","6px");cls.init();var cls=new CssClass(".sa_regularInput");cls.add("width","250px");cls.add("height","25px");cls.add("padding-left","5px");cls.add("-webkit-border-radius","6px");cls.add("-moz-border-radius","6px");cls.add("border-radius","6px");cls.init();var cls=new CssClass(".sa_mR10");cls.add("margin-right","10px");cls.init();var cls=new CssClass(".sa_popupHeader");cls.add("background-color","#34495e");cls.add("height","30px");cls.add("line-height","30px");cls.add("width","100%");cls.add("color","#ffffff");cls.add("text-align","left");cls.init();var cls=new CssClass(".sa_popupTitle");cls.add("font-weight","bold");cls.init();var cls=new CssClass(".sa_pageName");cls.add("color","#ffffff");cls.init();var cls=new CssClass(".sa_plusMinus");cls.add("position","relative");cls.add("top","2px");cls.add("cursor","pointer");cls.init();var cls=new CssClass(".sa_treeNode");cls.add("-webkit-border-radius","6px");cls.add("-moz-border-radius","6px");cls.add("border-radius","6px");cls.add("background-color","#e5eaeb");cls.add("cursor","move");cls.init();var cls=new CssClass(".sa_relative");cls.add("position","relative");cls.init();var cls=new CssClass(".sa_italic");cls.add("font-style","italic");cls.init();var cls=new CssClass(".sa_labelText");cls.add("font-size","14px");cls.add("color","#c0c8d0");cls.init();var cls=new CssClass(".sa_addField");cls.add("font-size","14px");cls.add("font-weight","bold");cls.add("color","#3498db");cls.add("margin","0px 5px 8px");cls.add("font-style","italic");cls.add("cursor","pointer");cls.init();var cls=new CssClass(".sa_addField:hover");cls.add("text-decoration","underline");cls.init();var cls=new CssClass(".sa_openInExplorer");cls.add("font-size","14px");cls.add("font-weight","bold");cls.add("color","#3498db");cls.add("margin-left","384px");cls.add("cursor","pointer");cls.init();var cls=new CssClass(".sa_openInExplorer:hover");cls.add("text-decoration","underline");cls.init();var cls=new CssClass(".sa_tableDefaultVals");cls.add("background","-webkit-gradient(linear, left top, right top, from(#f1f1f1), to(#ffffff))");cls.add("background","-moz-linear-gradient(left, #f1f1f1, #ffffff)");cls.add("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr='#f1f1f1', endColorstr='#ffffff)");cls.init();var cls=new CssClass(".sa_activateBtn");cls.add("-webkit-transition","0.25s");cls.add("-moz-transition","0.25s");cls.add("-o-transition","0.25s");cls.add("transition","0.25s");cls.add("opacity","0.80");cls.add("filter","alpha(opacity=80)");cls.add("float","left");cls.add("margin-left","10px");cls.add("margin-top","2px");cls.add("cursor","pointer");cls.init();var cls=new CssClass(".sa_activateBtn:hover");cls.add("opacity","1");cls.add("filter","alpha(opacity=100)");cls.init();var cls=new CssClass(".sa_pushPopupText");cls.add("font-family","Open Sans");cls.add("font-size","18px");cls.init();var cls=new CssClass(".sa_pushPopupBoldText");cls.add("font-weight","bold");cls.init();var cls=new CssClass(".ok-btn");cls.add("width","154px");cls.add("height","36px");cls.add("margin-top","40px");cls.init();var cls=new CssClass(".sa_testClass");cls.add("background-color","white");cls.init();var cls=new CssClass(".sa_hoverPopup");cls.add("background-color","#333333");cls.add("color","#ffffff");cls.add("padding","3px 0px 5px 10px");cls.add("border","1px solid #ffffff");cls.add("font-size","12px");cls.add("font-family","Open Sans");cls.add("position","relative");cls.init();var cls=new CssClass(".sa_previewAdjust");cls.add("top","35px");cls.add("left","47px");cls.init();var cls=new CssClass(".sa_duplicateAdjust");cls.add("top","35px");cls.add("left","50px");cls.init();var cls=new CssClass(".sa_deleteAdjust");cls.add("top","35px");cls.add("left","40px");cls.init();var cls=new CssClass(".sa_imgLibAdjust");cls.add("top","50px");cls.add("left","10px");cls.init();var cls=new CssClass(".sa_globalCssAdjust");cls.add("top","50px");cls.add("left","25px");cls.init();var cls=new CssClass(".sa_propsAdjust");cls.add("top","50px");cls.add("left","25px");cls.init();var cls=new CssClass(".sa_tipAdjust1");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-52px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa-push-tip");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-100px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa-img-upload-tip");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-120px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa_tipAdjust2");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-68px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa_tipAdjust3");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-35px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa_tipAdjust4");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-40px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa_tipAdjust5");cls.add("position","relative");cls.add("top","-16px");cls.add("left","-55px");cls.add("z-index",2000);cls.init();var cls=new CssClass(".sa_createNewCont");cls.add("text-align","center");cls.add("padding","6px 0px 10px 0px");cls.init();var cls=new CssClass(".sa_createNewButton");cls.add("padding-left","10px !important");cls.add("padding-right","10px !important");cls.add("width","120px");cls.init();var cls=new CssClass(".sa_publishBtn");cls.add("width","92px");cls.init();
var cls=new CssClass(".sa_globalSaveBtn");cls.add("width","92px");cls.init();var cls=new CssClass(".sa_glbSptBtn1");cls.add("width","100px");cls.init();var cls=new CssClass(".sa_glbSptBtn2");cls.add("width","220px");cls.add("margin-left","10px");cls.init();var cls=new CssClass(".sa_glbSptBtn3");cls.add("width","240px");cls.add("margin-left","10px");cls.init();var cls=new CssClass(".sa_topConsoleRightArea");cls.add("width","350px");cls.add("padding-right","20px");cls.init();var cls=new CssClass(".sa_folderHolder");cls.add("background-color","#ffffff");cls.init();var cls=new CssClass(".sa_scriptViewBtns");cls.add("width","92px");cls.add("margin-left","10px");cls.init();var cls=new CssClass(".sa_expBtn");cls.add("width","166px");cls.init();var cls=new CssClass(".sa_listBtn");cls.add("width","90px");cls.init();var cls=new CssClass(".sa_recBtn");cls.add("width","112px");cls.init();var cls=new CssClass(".sa_newRecsBtn");cls.add("width","215px");cls.init();var cls=new CssClass(".sa_addValBtn");cls.add("width","103px");cls.init();
var cls=new CssClass(".sa_tabOn");cls.add("background-color","#ffffff");cls.add("font-weight","bold");cls.add("color","#666666");cls.add("font-size","14px");cls.add("padding","5px 12px");cls.init();var cls=new CssClass(".sa_tabOff");cls.add("color","#c2c4c6");cls.add("background-color","#385774");cls.add("padding","5px 12px");cls.add("font-size","14px");cls.init();var cls=new CssClass(".sa_tabOff:hover");cls.add("color","#ffffff");cls.add("text-decoration","none");cls.init();var cls=new CssClass(".sa_tabSpacing");cls.add("width","2px");cls.init();}

this.initExistingStyles=function(){var cssStyle=new css_StyleSheet();var cssClass=new css_CssClass("*");cssClass.addStyle("-webkit-box-sizing","border-box");cssClass.addStyle("-moz-box-sizing","border-box");cssClass.addStyle("box-sizing","border-box");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("leftSideTabOff");cssClass.addStyle("font-size","14px");cssClass.addStyle("font-weight","600");cssClass.addStyle("color","#666666");cssClass.addStyle("background-color","#e9e9e9");cssClass.addStyle("padding","5px 9px");cssClass.addStyle("margin-right","4px");cssClass.addStyle("width","50%");cssClass.addStyle("text-align","center");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("leftSideTabOn");cssClass.addStyle("font-weight","600");cssClass.addStyle("font-size","14px");cssClass.addStyle("background-color","#ffffff");cssClass.addStyle("color","#666666");cssClass.addStyle("padding","5px 9px");cssClass.addStyle("margin-right","4px");cssClass.addStyle("width","50%");cssClass.addStyle("text-align","center");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("iconFont");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("treeNodeFont");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("linkColor");cssClass.addStyle("color","#1A1A68");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("link:hover");cssClass.addStyle("text-decoration","underline");cssClass.addStyle("cursor","pointer");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("link td");cssClass.addStyle("cursor","pointer");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("smallText");cssClass.addStyle("font-size","12px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("smallBoldText");cssClass.addStyle("font-weight","bold");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("text");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("boldText");cssClass.addStyle("font-weight","bold");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("mediumText");cssClass.addStyle("font-size","16px");cssClass.addStyle("font-family","Open Sans, arial");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("mediumBoldText");cssClass.addStyle("font-weight","bold");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("largeText");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("hugeText");cssClass.addStyle("font-size","36px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("buttonFontOff");cssClass.addStyle("font-weight","bold");cssClass.addStyle("color","#36373A");cssClass.addStyle("padding-left","12px");cssClass.addStyle("padding-right","12px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("popupBg");cssClass.addStyle("background-color","#EDEDED");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("buttonFontOn");cssClass.addStyle("font-weight","bold");cssClass.addStyle("color","#266AE6");cssClass.addStyle("padding-left","12px");cssClass.addStyle("padding-right","12px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("body");cssClass.addStyle("overflow-y","auto");cssClass.addStyle("padding","0px");cssClass.addStyle("margin","0px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("smallHeader");cssClass.addStyle("border-top","1px solid #98A7BD");cssClass.addStyle("border-bottom","1px solid #98A7BD");cssClass.addStyle("background-image","url(/upload/custom_screens/rte/tag_editor_bar_bg.gif)");cssClass.addStyle("background-repeat","repeat-x");cssClass.addStyle("padding-left","10px");cssClass.addStyle("color","#2B3A51");cssClass.addStyle("font-weight","bold");cssClass.addStyle("background-color","#A8B6CA");cssClass.addStyle("margin-top","5px");cssClass.addStyle("margin-bottom","5px");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("right_panel_header");cssClass.addStyle("background-image","url(/upload/custom_screens/moduleeditor/section_header.gif)");cssClass.addStyle("height","19px");cssClass.addStyle("font-weight","bold");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("borderColor");cssClass.addStyle("border","1px solid #CCCCCC");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("folderOn");cssClass.addStyle("font-weight","bold");cssClass.addStyle("padding","5px 35px");cssClass.addStyle("background-color","#EEEAF9");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("folderOff");cssClass.addStyle("font-weight","bold");cssClass.addStyle("padding","5px 35px");cssClass.addStyle("background-color","");cssStyle.addClass(cssClass);var cssClass=new css_CssClass("altBg");cssClass.addStyle("background-color","");cssStyle.addClass(cssClass);cssStyle.init();}
;this.initButtonStyles=function(){var cls=new CssClass(".btn");cls.add("border","none");cls.add("cursor","pointer");cls.add("background","#bdc3c7");cls.add("color","#ffffff");cls.add("padding","4px 12px 4px");cls.add("line-height","22px");cls.add("text-decoration","none");cls.add("text-shadow","none");cls.add("-webkit-border-radius","6px");cls.add("-moz-border-radius","6px");cls.add("border-radius","6px");cls.add("-webkit-box-shadow","none");cls.add("-moz-box-shadow","none");cls.add("box-shadow","none");cls.add("-webkit-transition","0.25s");cls.add("-moz-transition","0.25s");cls.add("-o-transition","0.25s");cls.add("transition","0.25s");cls.add("-webkit-backface-visibility","hidden");cls.init();var cls=new CssClass(".btn:hover, .btn:focus .btn-group:focus .btn.dropdown-toggle");cls.add("background-color","#cacfd2");cls.add("color","#ffffff");cls.add("outline","none");cls.add("-webkit-transition","0.25s");cls.add("-moz-transition","0.25s");cls.add("-o-transition","0.25s");cls.add("transition","0.25s");cls.add("-webkit-backface-visibility","hidden");cls.init();var cls=new CssClass(".btn:active, .btn-group.open .btn.dropdown-toggle, .btn.active");cls.add("background-color","#a1a6a9");cls.add("color","rgba(255, 255, 255, 0.75)");cls.add("-webkit-box-shadow","none");cls.add("-moz-box-shadow","none");cls.add("box-shadow","none");cls.init();var cls=new CssClass(".btn.blue-btn");cls.add("background-color","#3498db");cls.add("padding","4px 28px 4px");cls.init();var cls=new CssClass(".btn.blue-btn:hover, .btn.blue-btn:focus");cls.add("background-color","#5dade2");cls.init();var cls=new CssClass(".btn.blue-btn-info:active, .btn.blue-btn:active");cls.add("background-color","#2c81ba");cls.init();var cls=new CssClass(".btn.aqua-btn");cls.add("background-color","#1abc9c");cls.add("padding","4px 0px 4px");cls.init();var cls=new CssClass(".btn.aqua-btn:hover, .btn.aqua-btn:focus");cls.add("background-color","#48c9b0");cls.init();var cls=new CssClass(".btn.aqua-btn-info:active, .btn.aqua-btn:active");cls.add("background-color","#16a085");cls.init();var cls=new CssClass(".btn.aqua-btn:disabled");cls.add("background-color","#bdc3c7");cls.add("cursor","default");cls.init();var cls=new CssClass(".btn.gray-btn");cls.add("background-color","#7f8c9a");cls.add("padding","4px 0px 4px");cls.add("width","92px");cls.init();var cls=new CssClass(".btn.gray-btn:hover, .btn.gray-btn:focus");cls.add("background-color","#bdc3c7");cls.init();var cls=new CssClass(".btn.gray-btn-info:active, .btn.gray-btn:active");cls.add("background-color","#16a085");cls.init();}
;}
;
;function PageTreeNode(pageRecord,pageTree){this.pageId=pageRecord.getId();this.pageName=pageRecord.getField("name").getValue();this.pageType=pageRecord.getField("item_type").getValue();if(this.pageType==""){this.pageType="page";}

this.tree=pageTree;this.childNodes=[];this.childrenById={}
;this.container;this.plusOrMinusIconHolder;this.plusOrMinusImage;this.isExpanded=false;}

PageTreeNode.prototype=new PageTreeNodeBase();function PageTreeNodeBase(){this.build=function(parentEl){if(UserSettingsMgr.getProperty(this.tree.userSettingsKey,this.getNodeId().replaceAll(".","_"))){this.isExpanded=true;}

var container=cE("div",parentEl);container.style.height=this.tree.lineHeight+"px";this.container=container;var anchor=cE("div",container);anchor.style.paddingLeft=this.offsetLeft+"px";var tBody=createTable(anchor);var table=tBody.parentNode;table.style.height=this.tree.lineHeight+"px";table.className="text";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.width=this.tree.indentPixels+"px";td.style.minWidth=this.tree.indentPixels+"px";td.align="center";td.vAlign="middle";this.plusOrMinusIconHolder=td;var thisObj=this;if(this.childNodes.length>0){var onClickFx=function(){thisObj.toggleNode();}
;ButtonUtil.turnIntoButton(this.plusOrMinusIconHolder,onClickFx);var img=cE("img",this.plusOrMinusIconHolder);img.src=this.isExpanded?this.tree.expandedIcon:this.tree.collapsedIcon;img.style.margin="0px 3px 0px 3px";this.plusOrMinusImage=img;}

else 
{var img=cE("img",this.plusOrMinusIconHolder);img.style.width=this.tree.indentPixels+"px";img.style.visibility="hidden";}

var td=cE("td",tr);td.align="center";td.vAlign="middle";td.style.width=this.tree.indentPixels+"px";var iconImage=cE("img",td);iconImage.style.cursor="pointer";iconImage.src=this.tree.getIcon(this.pageType);var td=cE("td",tr);td.vAlign="middle";td.style.paddingLeft="3px";var labelHolder=cE("nobr",td);labelHolder.style.cursor="pointer";labelHolder.innerHTML=this.pageName||"Untitled";if(this.tree.fontClass){labelHolder.className=this.tree.fontClass;}

this.labelHolder=labelHolder;if(this.tree.onClick){var onClickFx=function(){thisObj.tree.onClick(thisObj)
}
;eh_attachEvent("onclick",labelHolder,onClickFx,null,true);eh_attachEvent("onclick",iconImage,onClickFx,null,true);}

if(this.tree.onRightClick){var onClickFx=function(event){thisObj.tree.onRightClick(thisObj,event);crossbrowser_stopEvent(event);crossbrowser_cancelBubble(event);return false;}
;eh_addEvent("oncontextmenu",labelHolder,onClickFx);eh_addEvent("oncontextmenu",iconImage,onClickFx);}

var childCount=this.childNodes.length;if(childCount>0){var childHolder=cE("div",parentEl);this.childHolder=childHolder;if(!this.isExpanded){childHolder.style.display="none";}

else 
{for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].build(childHolder);}

}

}

}
;this.toggleNode=function(){this.isExpanded=!this.isExpanded;if(this.isExpanded){for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].build(this.childHolder);}

this.childHolder.style.display="";this.plusOrMinusImage.src=this.tree.expandedIcon;var nodeId=this.getNodeId();UserSettingsMgr.setProperty(this.tree.userSettingsKey,nodeId.replaceAll(".","_"),"true");}

else 
{this.childHolder.style.display="none";this.childHolder.innerHTML="";this.plusOrMinusImage.src=this.tree.collapsedIcon;var nodeId=this.getNodeId();UserSettingsMgr.deleteProperty(this.tree.userSettingsKey,nodeId.replaceAll(".","_"));}

}
;this.getNodeId=function(){var id=this.pageId;var temp=this;while(temp.parentNode)
{var temp=temp.parentNode;id=temp.pageId+"."+id;}

return id+"";}
;this.addChild=function(childNode){this.childrenById[childNode.pageId]=childNode;this.childNodes.push(childNode);childNode.parentNode=this;var offsetLeft=this.offsetLeft+this.tree.indentPixels;childNode.offsetLeft=offsetLeft;}
;}
;

;function PageTree(){this.childNodes=[];this.childrenById={}
;this.onClick;this.parentEl;this.rootHolder;this.userSettingsKey="page_tree";}

PageTree.prototype=new PageTreeBase();function PageTreeBase(){this.lineHeight=22;this.indentPixels=18;this.expandedIcon="upload/custom_screens/sitearchitect/arrow-down.png";this.collapsedIcon="upload/custom_screens/sitearchitect/arrow-right.png";this.pageIcon="/upload/custom_screens/rteeditor/html_icon.gif";this.build=function(parentEl){if(parentEl){this.parentEl=parentEl;}

else 
{parentEl=this.parentEl;}

var fx=function(){}
;eh_attachEvent("onselectstart",parentEl,fx,null,true,null,true,false);var div=cE("div",parentEl);this.rootHolder=div;for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].build(div);}

}
;this.addPageAndDraw=function(pageRecord){var node=this.addPage(pageRecord);node.build(this.rootHolder);}

this.addPage=function(pageRecord,ancestry){var activeNode=this;if(!ancestry){var familyTreePos=pageRecord.getField("family_tree_pos").getValue();ancestry=familyTreePos.split(".");ancestry.splice(0,1);ancestry.splice(ancestry.length-1,1);}

for(var i=0;i<ancestry.length-1;i++)
{var childNode=activeNode.childrenById[ancestry[i]];if(!childNode){break;}

activeNode=childNode;}

var node=new PageTreeNode(pageRecord,this);activeNode.addChild(node);return node;}
;this.addChild=function(childNode){this.childNodes.push(childNode);this.childrenById[childNode.pageId]=childNode;childNode.offsetLeft=0;}
;this.getIcon=function(type){var iconPath=this.icons[type];if(null==iconPath){iconPath=this.icons.default;    
            }    
                
            return iconPath;    
      };    
          
      this.initIcons = function()    
      {    
            var icons = {}    
            icons.page = "/upload/custom_screens/sitearchitect/page_sm.png";    
            icons.folder = "/upload/custom_screens/sitearchitect/folder_sm.png";    
            icons.default = icons.page;    
               
            this.icons = icons;   
      };    
          
      this.initIcons();    
}



function cE(tagName,parentEl,doc){if(!doc){doc=getParentDocument(parentEl);}

var element=doc.createElement(tagName);if(parentEl){parentEl.appendChild(element);}

return element;}


function gL(selectors){return document.querySelectorAll(selectors);}


function gE(selector,doc){if(!doc){doc=document;}

return doc.querySelector(selector);}


function sA(element,name,value){element.setAttribute(name,value);}


function rA(element,name){element.removeAttribute(name);}


function gA(element,name){if(element.nodeType!=1){return null;}

return element.getAttribute(name);}


function cC(tBody){var tr=cE("tr",tBody);var td=cE("td",tr);return td;}


function iE(tagName,parentEl,insertIndex){var doc=getParentDocument(parentEl);var element=doc.createElement(tagName);try
{parentEl.insertBefore(element,parentEl.childNodes[insertIndex]);}

catch(e)
{parentEl.appendChild(element);}

return element;}


function aE(parentEl,element){parentEl.appendChild(element);}


function createTable(parentEl,width,height){var doc=getParentDocument(parentEl);var table=doc.createElement("table");table.cellPadding=0;table.cellSpacing=0;if(width){table.style.width=(!isNaN(width))?width+"px":width;}

if(height){table.style.height=(!isNaN(height))?height+"px":height;}

parentEl.appendChild(table);var tBody=doc.createElement("tbody");table.appendChild(tBody);return tBody;}


function getPlainText(element){var linesArray=new Array();var fx=function(element,linesArray){var displayType=CssUtil.getStyle(element,"display");if(!(displayType=="inline"||displayType=="inline-block")&&linesArray[linesArray.length-1]!=""){linesArray.push("");}

if(element.nodeType==3){linesArray[linesArray.length-1]=linesArray[linesArray.length-1]+element.data;}

else if(element.firstChild){fx(element.firstChild,linesArray);}

if(element.nextSibling){fx(element.nextSibling,linesArray);}

}
;fx(element,linesArray);return linesArray;}
;
function getParentDocument(element){var doc=null;if(element==null||element.ownerDocument==null){doc=document;}

else 
{doc=element.ownerDocument;}

return doc;}

function cls(parentEl,label,onclickFx,eventGroupName){var s=cE("span",parentEl);s.className="text linkColor";s.innerHTML=label;addUnderlineEvents(s,"main");var clickFx=(onclickFx)?onclickFx:function(){}
;eh_attachEvent("onclick",s,clickFx,eventGroupName);return s;}

function cli(parentEl,src,onclickFx,eventGroupName){var i=cE("img",parentEl);i.src=src;i.style.cursor="pointer";eh_attachEvent("onclick",i,onclickFx,eventGroupName);return i;}

function cb(parentEl,label,onclickFx,eventGroupName){var b=cE("button",parentEl);b.className="text";b.innerHTML=label;b.setAttribute('type',"button");eh_attachEvent("onclick",b,onclickFx,eventGroupName);return b;}
;function docGetEl(id){return document.getElementById(id);}

function addUnderlineEvents(element,eventGroupName){var mouseOverFx=function(){element.style.textDecoration='underline'}
;eh_attachEvent("onmouseover",element,mouseOverFx,eventGroupName,false,null,null,null,true);var mouseOutFx=function(){element.style.textDecoration=''}
;eh_attachEvent("onmouseout",element,mouseOutFx,eventGroupName,false,null,null,null,true);element.style.cursor="pointer";}
;
function position_getXYCoords(event){var coord=null;if(event){coord=new position_Coord(event.clientX,event.clientY)
}

else 
{coord=new position_Coord(window.event.clientX,window.event.clientY)
}

return coord;}

function position_findElementPosition(element){var curleft=0;var curtop=0;if(element.offsetParent){do
{curleft+=element.offsetLeft;curtop+=element.offsetTop;}

while(element=element.offsetParent);}

return [curleft,curtop];}

function position_findElementPositionWithScroll(element){var curleft=0;var curtop=0;if(IS_CHROME){if(element.parentNode){do
{curleft+=element.offsetLeft-element.scrollLeft;curtop+=("BODY"==element.tagName)?element.offsetTop:element.offsetTop-element.scrollTop;element=("DIV"==element.parentNode.tagName)?element.parentNode:element.offsetParent;}

while(element);}

}

else 
{if(element.offsetParent){do
{curleft+=element.offsetLeft-element.scrollLeft;curtop+=("BODY"==element.tagName)?element.offsetTop:element.offsetTop-element.scrollTop;}

while(element=element.offsetParent);}

}

return [curleft,curtop];}
;
function position_pixelToInt(pixelString){if(null==pixelString){return 0;}

var pixelValue=parseInt(pixelString.substring(0,pixelString.length-2));return (isNaN(pixelValue))?0:pixelValue;}

function position_Coord(x,y){this.x=x;this.y=y;}

function position_findXYCoordinates(element){var ua=navigator.userAgent.toLowerCase();var isOpera=(ua.indexOf('opera')>-1);var isSafari=(ua.indexOf('safari')>-1);var isIE=(window.ActiveXObject);var parent=null;var pos=[];var box;var coord;if(element.getBoundingClientRect){box=element.getBoundingClientRect();var doc=document;var sTop=Math.max(doc.documentElement.scrollTop,doc.body.scrollTop);var sLeft=Math.max(doc.documentElement.scrollLeft,doc.body.scrollLeft);pos[0]=box.left+sLeft;pos[1]=box.top+sTop
}

else 
{pos=[element.offsetLeft,element.offsetTop];parent=element.offsetParent;if(parent!=element){while(parent)
{pos[0]+=parent.offsetLeft;pos[1]+=parent.offsetTop;parent=parent.offsetParent;}

}

if(element.style.position=='absolute'){pos[0]-=document.body.offsetLeft;pos[1]-=document.body.offsetTop;}

}

parent=(element.parentNode)?element.parentNode:null
while(parent&&parent.tagName.toUpperCase()!='BODY'&&parent.tagName.toUpperCase()!='HTML')
{if(parent.style.display!='inline'){pos[0]-=parent.scrollLeft;pos[1]-=parent.scrollTop;}

parent=(parent.parentNode)?parent.parentNode:null;}

var coord=((pos[0]==0&&pos[1]==0)||(pos[0]==undefined&&pos[1]==undefined))?
position_getAlternateCoordinates(element):new position_Coord(pos[0],pos[1]);return coord;}
;
;;;function tree_Tree(parentEl){this.typeToIcon=[];this.indentPixels=13;this.lineHeight=22;this.childNodes=[];this.childrenByName={}
;this.parentEl=parentEl;this.expandedIcon="/upload/custom_screens/generic_images/cm_tree_minus.gif";this.collapsedIcon="/upload/custom_screens/generic_images/cm_tree_plus.gif";this.fontClass;this.addChild=function(childNode){this.childNodes.push(childNode);this.childrenByName[childNode.label]=childNode;childNode.offsetLeft=0;childNode.treeObj=this;}
;this.addDescendent=function(fullName,branchType,branchOnClickFx,branchDblClickFx,branchRightClickMenu,
leafType,leafOnClickFx,leafOnDblClickFx,leafOnRightClickFx,leafProperties){var activeNode=this;var names=fullName.split(".");for(var i=0;i<names.length-1;i++)
{var childNode=activeNode.childrenByName[names[i]];if(!childNode){childNode=new tree_Node(names[i],branchType,branchOnClickFx,branchDblClickFx,branchRightClickMenu);activeNode.addChild(childNode);}

activeNode=childNode;}

var leafNode=new tree_Node(names[names.length-1],leafType,leafOnClickFx,leafOnDblClickFx,leafOnRightClickFx,leafProperties);activeNode.addChild(leafNode);}
;this.addRootNode=function(node,parentEl){tree_buildNode(node,parentEl);}

this.removeRootNode=function(){}

this.build=function(){tree_build(this)}
;}

function tree_Node(label,type,onClickFx,ondblclickFx,onRightClickFx,properties){this.label=label;this.type=type;this.onClickFx=onClickFx;this.ondblclickFx=ondblclickFx;this.onRightClickFx=onRightClickFx;this.properties=properties;this.onclick;this.parentNode;this.offsetLeft;this.isExpanded=false;this.childrenContainer;this.plusOrMinusIconHolder;this.plusOrMinusImage;this.nodesToDelete=[];this.treeObj;this.childNodes=[];this.childrenByName={}
;}

tree_Node.prototype=new tree_NodeBase();function tree_NodeBase(){this.addChild=function addChildNode(childNode){this.childrenByName[childNode.label]=childNode;this.childNodes.push(childNode);childNode.treeObj=this.treeObj;childNode.parentNode=this;childNode.offsetLeft=this.offsetLeft+this.treeObj.indentPixels;}
;this.getFullName=function(){var node=this;var fullName=node.label;while(node.parentNode)
{var node=node.parentNode;fullName=node.label+"."+fullName;}

return fullName;}
;this.updateLabel=function(newLabel){this.label=newLabel;this.labelHolder.innerHTML=newLabel;}
;this.remove=function(){this.nodesToDelete=[];var sourceNode=this;if(!sourceNode.isExpanded){tree_removeNode(sourceNode);}

else 
{this.nodesToDelete.push(sourceNode);tree_setNodesToRemove(sourceNode,this);tree_runThroughNodesToRemove(this.nodesToDelete);}

}
;this.getDescendentList=function(list){if(!list){list=[];}

for(var i in this.childNodes)
{list.push(this.childNodes[i]);this.childNodes[i].getDescendentList(list);}

return list;}

}

function tree_setNodesToRemove(sourceNode,thisObj){for(var i=0;i<sourceNode.childNodes.length;i++)
{var node=sourceNode.childNodes[i];thisObj.nodesToDelete.push(node);if(node.isExpanded){tree_setNodesToRemove(node,thisObj);}

}

}

function tree_runThroughNodesToRemove(nodes){for(var i=nodes.length;i>0;i--)
{var node=nodes[i-1];tree_removeNode(node);}

}

function tree_removeNode(node){tree_removeChildNodes(node);if(node.parentNode){var parentNode=node.parentNode;tree_removeChildNodes(parentNode);delete(parentNode.childrenByName[node.label]);if(parentNode.childNodes.length==0&&parentNode.plusOrMinusImage){parentNode.plusOrMinusIconHolder.innerHTML="";}

}

node.container.parentNode.removeChild(node.container);}

function tree_removeChildNodes(node){for(var i=0;i<node.childNodes.length;i++)
{node.childNodes.splice(i,1);break;}

}

function tree_build(treeObj){var parentEl=treeObj.parentEl;var fx=function(){}
;eh_attachEvent("onselectstart",parentEl,fx,null,true,null,true,false);var div=cE("div",parentEl);for(var i=0;i<treeObj.childNodes.length;i++)
{tree_buildNode(treeObj.childNodes[i],div);}

}

var processed=false;function tree_buildNode(thisObj,parentEl){var lineHeight=thisObj.treeObj.lineHeight;var container=cE("div",parentEl);container.style.height=lineHeight+"px";var fx=function(){}
;eh_attachEvent("onselectstart",container,fx,null,true,null,true,false);thisObj.container=container;var tBody=createTable(container);var table=tBody.parentNode;table.style.marginLeft=thisObj.offsetLeft+"px";table.style.height=lineHeight+"px";table.className="text";var tr=cE("tr",tBody);var plusOrMinusIconHolder=cE("td",tr);plusOrMinusIconHolder.style.width=thisObj.treeObj.indentPixels;thisObj.plusOrMinusIconHolder=plusOrMinusIconHolder;var onclickFx=function(){tree_toggleNode(thisObj)}
;eh_attachEvent("onclick",plusOrMinusIconHolder,onclickFx);if(thisObj.childNodes.length>0){var img=cE("img",plusOrMinusIconHolder);img.src=thisObj.isExpanded?thisObj.treeObj.expandedIcon:thisObj.treeObj.collapsedIcon;img.style.cursor="pointer";thisObj.plusOrMinusImage=img;}

var td=cE("td",tr);td.style.width=thisObj.treeObj.indentPixels+"px";var iconImage=cE("img",td);iconImage.style.cursor="pointer";iconImage.src=(thisObj.treeObj.typeToIcon[thisObj.type])?thisObj.treeObj.typeToIcon[thisObj.type]:tree_typeToIcon[thisObj.type];var td=cE("td",tr);var labelHolder=cE("nobr",td);labelHolder.style.cursor="pointer";labelHolder.style.marginLeft="3px";labelHolder.innerHTML=thisObj.label;if(thisObj.treeObj.fontClass){labelHolder.className=thisObj.treeObj.fontClass;}

thisObj.labelHolder=labelHolder;if(thisObj.onClickFx){var onClickFx=function(){thisObj.onClickFx(thisObj)}
;eh_attachEvent("onclick",labelHolder,onClickFx,null,true);eh_attachEvent("onclick",iconImage,onClickFx,null,true);}

if(thisObj.ondblclickFx){var ondblclickFx=function(){thisObj.ondblclickFx(thisObj)}
;eh_attachEvent("ondblclick",labelHolder,ondblclickFx,null,true);eh_attachEvent("ondblclick",iconImage,ondblclickFx,null,true);}

if(thisObj.onRightClickFx){var onRightClickFx=function(event){thisObj.onRightClickFx(event)}
;eh_attachEvent("oncontextmenu",labelHolder,onRightClickFx,null,true);eh_attachEvent("oncontextmenu",iconImage,onRightClickFx,null,true);}

var childCount=thisObj.childNodes.length;if(childCount>0){var nodeContainer=cE("div",parentEl);thisObj.childrenContainer=nodeContainer;for(var i=0;i<thisObj.childNodes.length;i++)
{if(!thisObj.isExpanded){nodeContainer.style.display="none";}

tree_buildNode(thisObj.childNodes[i],nodeContainer);}

}

}

function tree_toggleNode(nodeObj){nodeObj.isExpanded=!nodeObj.isExpanded;if(nodeObj.isExpanded){nodeObj.childrenContainer.style.display="";nodeObj.plusOrMinusImage.src=nodeObj.treeObj.expandedIcon;}

else 
{nodeObj.childrenContainer.style.display="none";nodeObj.plusOrMinusImage.src=nodeObj.treeObj.collapsedIcon;}

}

function tree_toggleIsExpanded(thisObj){if(thisObj.parentNode!=null){tree_toggleIsExpanded(thisObj.parentNode);tree_toggleNode(thisObj.parentNode);}

}


function createTemplateBasedPageCreator(fieldName,miniCache,templateId,pageName,displayInNav,parentPageId,url){var getter=createGeneralExecuter(fieldName,miniCache,"CreatePageFromTemplate");var params=getter.getChildField("exec_params");params.addChildField("module_template_id","INTEGER",templateId);params.addChildField("name","TEXT",pageName);params.addChildField("display_in_nav","BOOLEAN",displayInNav);params.addChildField("parent_page_id","INTEGER",parentPageId);if(url){params.addChildField("url","TEXT",url);}

return getter;}

function fade_fadeElement(fadeEl,startOpacity,endOpacity,timeInterval,iterations,startTime,onAfterFadeFx){var fadeTrigger=[];var timeToTrigger=startTime;var opacityIncrement=(endOpacity-startOpacity)/iterations;var opacity=startOpacity;for(var i=0;i<iterations;i++)
{if((iterations-1)==i){opacity=endOpacity;}

fadeTrigger.push(fade_addTimeOut(fadeEl,opacity,timeToTrigger));timeToTrigger+=timeInterval;opacity+=opacityIncrement;}

if(onAfterFadeFx){window.setTimeout(onAfterFadeFx,timeToTrigger);}

return fadeTrigger;}

function fade_setOpacity(element,opacity){if(IS_IE){element.style.filter="alpha(opacity="+opacity+")";}

else 
{element.style.opacity=opacity/100;}

if("none"==element.style.display){element.style.display="";}

}

function fade_resetOpacity(element){if(IS_IE){element.style.filter="";}

else 
{element.style.opacity="";}

}
;function fade_addTimeOut(fadeEl,opacity,timeToTrigger){var adjustOpacityFx=function(){fade_setOpacity(fadeEl,opacity);}
;return window.setTimeout(adjustOpacityFx,timeToTrigger);}

function fade_cancel(fadeTrigger){for(var i=0;i<fadeTrigger.length;i++)
{window.clearTimeout(fadeTrigger[i]);}

}
;
;;;;;function LiveNav(){this.element;this.isDragging;this.fragInfo;this.init=function(data){this.fragInfo=data;var element=gE("#"+data.elId);CssUtil.addClassToEl(element,"a_metaHideSubNavMenus");this.element=element;var lis=gL("#"+data.elId+" li");for(var i=0;i<lis.length;i++)
{this.initLi(lis[i]);}

}
;this.initLi=function(li){var thisObj=this;var enterFx=function(){thisObj.frameLi(li);}
;E.mouseenter(li,enterFx);}
;this.frameLi=function(li){var framer=LiveNavHandler.navFramer;framer.frame(li);framer.top.innerHTML="";var bar=cE("div",framer.top);bar.className="lp_navBarTop";bar.style.height="20px";bar.style.backgroundColor="black";bar.style.color="white";bar.style.fontSize="12px";bar.style.position="relative";bar.style.opacity=".75";this.addDragEvents(bar,li);var div=cE("div",bar);div.className="lp_navBarTopOpen";div.innerHTML="open";var thisObj=this;var fx=function(){var params={}
;params.mode="visual_edit";var linkEl=li.getElementsByTagName("a")[0];var href=gA(linkEl,"a_href");window.location.href=UrlUtil.addParamsToUrl(href,params);}
;E.click(div,fx);var editDiv=cE("div",bar);editDiv.className="lp_navBarTopEdit";var span=cE("span",editDiv);span.innerHTML="+";var thisObj=this;var fx=function(){thisObj.showEditOptions(editDiv);}
;E.click(editDiv,fx);var div=cE("div",bar);div.style.clear="both";bar.style.top=-bar.offsetHeight+"px";}
;this.showEditOptions=function(positionEl){var coord=findElCoord(positionEl,true);var menu=new DropdownMenu();menu.minWidth="200px";var thisObj=this;var fx=function(){var afterFx=function(){showProgressIcon("Loading");thisObj.loadWebsiteData();}
;sl_loadScript('/0/le8650_0.js',afterFx);afterFx;}
;var menuItem=new StandardMenuItem("Add New Page",fx);menu.addMenuItem(menuItem);menu.build(coord.x,coord.y);}
;this.loadWebsiteData=function(){var siteId=1;var mc=new MiniCache();var recordInput=mc.addRecordToLoad("website",siteId);recordInput.addField("*")
recordInput.addField("style_sheet.*");mc.addTemplateToLoad("style_sheets");mc.addTemplateToLoad("module");mc.addTemplateToLoad("screen_module");mc.addTemplateToLoad("module_template");mc.addTemplateToLoad("action_log");var thisObj=this;var fx=function(){var afterLoadFx=function(){SaCss.init();hideProgressIcon();var popup=new CreatePopup(siteId,mc);popup.displayInNav=true;popup.initOnPageCreation=true;popup.afterCreatePageFx=function(cP,newPageId){var mc=cP.mc;var newPageRec=mc.getRecord("page",newPageId);var friendlyUrl=newPageRec.getField("screen_module.url.friendly_url").getValue();window.location=friendlyUrl;}
;popup.afterCreateFolderFx=function(cP){debugger}
;popup.afterCreateTemplateFx=function(cP){debugger}
;popup.afterCreateModuleFx=function(cP){debugger}
;popup.build();}

sl_loadScript('/0/le8650_0.js',afterLoadFx);afterLoadFx;}
;mc.process(fx);}
;
this.addPage=function(){var popup=new NewPagePopup();popup.parentPageId=this.fragInfo.pageId;popup.build();}
;this.addDragEvents=function(grip,li){var thisObj=this;var fx=function(){if(!thisObj.isDragging){return ;}

var draggingEl=thisObj.draggingEl;if(draggingEl==li){return ;}

var isBefore=isBeforeSibling(li,draggingEl);draggingEl.parentNode.removeChild(draggingEl);if(isBefore){li.parentNode.insertBefore(draggingEl,li);}

else 
{insertAfter(draggingEl,li);}

}
;E.mouseenter(li,fx);var leaveFx=function(){thisObj.initLi(li);}
;E.mouseleave(li,leaveFx);var framer=LiveNavHandler.navFramer;var thisObj=this;DragUtil.getYOffset=function(dragEl){return dragEl.offsetHeight/2;}
;var createDragElFx=function(){var dragEl=li.cloneNode(true);dragEl.style.border="3px dashed #d6e0f5";dragEl.style.width=li.offsetWidth+"px";dragEl.style.height=li.offsetHeight+"px";return dragEl;}
;var onDragStart=function(){thisObj.isDragging=true;framer.disable();fade_setOpacity(li,50);thisObj.draggingEl=li;}
;var onDragEnd=function(){thisObj.isDragging=false;fade_resetOpacity(li);framer.enable();thisObj.sync();}
;DragUtil.makeDraggable(grip,null,onDragStart,onDragEnd,createDragElFx);}
;this.sync=function(){var mc=LivePage.mc;var lis=gL("#"+this.element.id+" li");for(var i=0;i<lis.length;i++)
{var id=lis[i].id;var pageId=id.substr(id.lastIndexOf("-p")+2);page=mc.createRecord("page",pageId);var fieldNames=page.getFieldNames();for(var j=0;j<fieldNames.length;j++)
{if(fieldNames[j]!="sibling_pos"){page.removeField(fieldNames[j]);}

}

page.getField("sibling_pos").setValue(i);}

}
;}


;var LiveNavHandler=new LiveNavHandlerBase();function LiveNavHandlerBase(){this.navFramer;this.init=function(data){if(data.params.js=="HorizontalNavMenu"){var fx=function(){var el=gE("#"+data.elId);var menu=new HorizontalNavMenu(el);menu.isLive=true;menu.fragInfo=data;menu.build();data.jsComponent=menu;}

sl_loadScript('/0/le8510_0.js',fx);fx;}

else 
{var el=gE("#"+data.elId);var menu=new GenericNavMenu(el);menu.isLive=true;menu.fragInfo=data;menu.build();data.jsComponent=menu;}

}
;this.initHandler=function(){this.initCss();this.initFramer();ATagInitializer.addSpecialModeHandler("visual_edit","nav",this);}
;this.initFramer=function(){var framer=new Framer("lp_navFrameTop","lp_navFrameRight","lp_navFrameBottom","lp_navFrameLeft");this.navFramer=framer;}
;this.initCss=function(){var cls=new CssClass(".a_metaHideSubNavMenus ul");cls.add("display","none");cls.init();var cls=new CssClass(".lp_navBarTopOpen");cls.add("color","#cccccc");cls.add("cursor","pointer");cls.add("font","11px arial");cls.add("width","27px");cls.add("float","left");cls.add("margin","3px 0px 0px 4px");cls.init();var cls=new CssClass(".lp_navBarTopOpen:hover");cls.add("color","white");cls.init();var cls=new CssClass(".lp_navBarTopEdit");cls.add("color","#cccccc");cls.add("cursor","pointer");cls.add("font","bold 14px arial");cls.add("border","1px solid #cccccc");cls.add("text-align","center");cls.add("width","12px");cls.add("height","12px");cls.add("float","right");cls.add("margin","3px 7px 0px 0px");cls.init();var cls=new CssClass(".lp_navBarTopEdit:hover");cls.add("color","white");cls.add("border","1px solid white");cls.init();var cls=new CssClass(".lp_navBarTopEdit span");cls.add("position","relative");cls.add("top","-2px");cls.init();var cls=new CssClass(".lp_navBarTop");cls.add("cursor","move");cls.add("border-right","1px solid black");cls.add("border-left","1px solid black");cls.add("background","black");cls.add("filter","alpha(opacity=75)");cls.add("opacity",".75");cls.add("border-top-left-radius","5px");cls.add("-moz-border-top-left-radius","5px");cls.add("border-top-right-radius","5px");cls.add("-moz-border-top-right-radius","5x");cls.add("-webkit-transition","opacity .2s linear 0");cls.init();var cls=new CssClass(".lp_navFrameTop");cls.add("border-right","1px solid black");cls.add("border-left","1px solid black");cls.add("background","black");cls.add("filter","alpha(opacity=50)");cls.add("opacity",".75");cls.add("height","3px");cls.add("-moz-border-top-left-radius","10px");cls.add("border-top-left-radius","10px");cls.add("-moz-border-top-right-radius","10px");cls.add("border-top-right-radius","10px");cls.add("opacity","1");cls.add("-webkit-transition","opacity .2s linear 0");cls.init();var cls=new CssClass(".lp_navFrameBottom");cls.add("height","3px");cls.add("background","black");cls.add("filter","alpha(opacity=50)");cls.add("opacity",".5");cls.add("opacity","1");cls.add("-webkit-transition","opacity .2s linear 0");cls.init();var cls=new CssClass(".lp_navFrameLeft");cls.add("width","3px");cls.add("background","black");cls.add("filter","alpha(opacity=50)");cls.add("opacity",".5");cls.add("opacity","1");cls.add("-webkit-transition","opacity .2s linear 0");cls.init();var cls=new CssClass(".lp_navFrameRight");cls.add("width","3px");cls.add("background","black");cls.add("filter","alpha(opacity=50)");cls.add("opacity",".5");cls.add("opacity","1");cls.add("-webkit-transition","opacity .2s linear 0");cls.init();}
;}


if(window["sl_loadedScript"]==undefined){var sl_loadedScript=[];}
;if(window["sl_onAfterLoadFx"]==undefined){var sl_onAfterLoadFx=[];}
;function sl_loadScript(scriptPath,onAfterLoadFx){if(sl_loadedScript[scriptPath]){if(onAfterLoadFx){onAfterLoadFx();}

return ;}

sl_onAfterLoadFx[scriptPath]=onAfterLoadFx;var scriptToLoad=document.createElement("script");scriptToLoad.src=scriptPath;scriptToLoad.type="text/javascript";document.body.appendChild(scriptToLoad);sl_loadedScript[scriptPath]=true;}


;function col_fieldToHtml(parentEl,dynField,properties){if(!properties){properties={}
;}

var isEditable=properties.isEditable;var refreshFx=function(){parentEl.innerHTML="";col_fieldToHtml(parentEl,dynField,properties);}

var div=cE("div",parentEl);div.className="text";div.style.padding=5;var tBody=createTable(div);tBody.className="text";var table=tBody.parentNode;table.border=1;table.cellPadding=5;var fieldNames=dynField.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var childField=dynField.getChildField(fieldNames[i]);var tr=cE("tr",tBody);if(isEditable){var td=cE("td",tr);td.style.paddingRight=8;col_buildDeleteField(td,dynField,childField,refreshFx);}

var td=cE("td",tr);td.style.paddingRight=10;var displayName=childField.getMetaInfo("dn");if(!displayName){displayName=childField.name;}

td.innerHTML=displayName;var td=cE("td",tr);var cfProps=clone(properties);childField.buildField(td,"edit",cfProps);if(isEditable){var td=cE("td",tr);td.style.paddingRight=8;td.innerHTML=childField.getFieldType();var td=cE("td",tr);td.style.paddingRight=8;var displayOrder=i+1;col_buildDisplayOrder(td,childField,displayOrder,refreshFx);}

}

if(isEditable){var div=cE("div",parentEl);div.style.padding=5;var span=cE("span",div);span.className="linkColor text";span.innerHTML="+ add child field";addUnderlineEvents(span);var onclickFx=function(){showProgressIcon("One momemt...");var onAddFieldClickFx=function(fieldData){var newField=dynField.addChildField(fieldData.fieldName,fieldData.fieldType);newField.setDoSave();refreshFx();}
;var onAfterLoadFx=function(){buildNewFieldPopup(onAddFieldClickFx,false);}
;sl_loadScript('/0/le5227_0.js',onAfterLoadFx);onAfterLoadFx;}
;eh_attachEvent("onclick",span,onclickFx);if(!dynField.parentField){var div=cE("div",parentEl);div.style.padding=5;div.style.paddingTop=10;var span=cE("span",div);span.className="linkColor text";span.innerHTML="done";addUnderlineEvents(span);var onclickFx=function(){properties.isEditable=false;refreshFx();}
;eh_attachEvent("onclick",span,onclickFx);}

}

else if(!dynField.parentField){var div=cE("div",parentEl);div.style.padding=5;div.style.paddingTop=10;var span=cE("span",div);span.className="linkColor text";span.innerHTML="edit collection";addUnderlineEvents(span);var onclickFx=function(){properties.isEditable=true;refreshFx();}
;eh_attachEvent("onclick",span,onclickFx);}

var fieldType=dynField.getFieldType();if(fieldType=="ACOMP"||fieldType=="VIDEO"){dynField.setDoSave();}

}

function col_buildDeleteField(parentEl,dynField,childField,refreshFx){var image=cE("img",parentEl);image.src="upload/custom_screens/explorer/table/icon_delete.gif";image.style.cursor="hand";var onclickFx=function(){dynField.removeChildField(childField.name);refreshFx();}
;eh_attachEvent("onclick",image,onclickFx);}

function col_buildDisplayOrder(parentEl,childField,displayOrder,refreshFx){var pr={}
;pr.onAfterChangeFx=function(value){childField.setMetaInfo(value,"do");childField.setDoSave();}

pr.value=displayOrder;pr.decimalPlaces=1;pr.style={width:40}
;buildNumberInput(parentEl,pr);}

registerHtmlConverter("RS","edit",col_fieldToHtml);registerHtmlConverter("COLLECTION","edit",col_fieldToHtml);registerHtmlConverter("SST","edit",col_fieldToHtml);registerHtmlConverter("MCL","edit",col_fieldToHtml);registerHtmlConverter("SYSTEM_SETTINGS","edit",col_fieldToHtml);registerHtmlConverter("URL","edit",col_fieldToHtml);registerHtmlConverter("ACOMP","edit",col_fieldToHtml);registerHtmlConverter("VIDEO","edit",col_fieldToHtml);registerHtmlConverter("LIVEURL","edit",col_fieldToHtml);registerHtmlConverter("RR","edit",col_fieldToHtml);

function ObjectMap(){this.objByKey={}
;this.length=0;this.keys=[];this.registeredKeys={}
;this.put=function(key,val){this.objByKey[key]=val;if(this.registeredKeys[key]!=true){this.registeredKeys[key]=true;this.keys.push(key);}

this.length=this.keys.length;return this;}
;this.get=function(key){return this.objByKey[key];}
;this.getAt=function(idx){if(idx<0||idx>=this.length){return null;}

var key=this.keys[idx];return this.get(key);}
;this.size=function(){return this.length;}
;this.getKeyAt=function(idx){if(idx<0||idx>=this.length){return null;}

return this.keys[idx];}
;this.pushOnTop=function(key,val){this.objByKey[key]=val;if(this.registeredKeys[key]!=true){this.registeredKeys[key]=true;this.keys.unshift(key);}

this.length=this.keys.length;return this;}
;this.remove=function(key){delete(this.objByKey[key]);delete(this.registeredKeys[key]);this.length--;for(var i=0;i<this.keys.length;i++)
{var aKey=this.keys[i];if(aKey==key){this.keys.splice(i,1);break;}

}

}
;}

;
var lds_onAfterLoadFx=window["lds_onAfterLoadFx"]||{}
;
var lds_noResourceFound=window["lds_noResourceFound"]||{}
;
var lds_nextId=window["lds_nextId"]||0;
var lds_scriptLoadMap=new ObjectMap();
var lds_loadCheckCntMap=new ObjectMap();
function resetDynamicScripts(){lds_onAfterLoadFx={}
;lds_noResourceFound={}
;lds_nextId=0;lds_scriptLoadMap=new ObjectMap();lds_loadCheckCntMap=new ObjectMap();}


function loadDynamicScript(resourceNames,onAfterLoadFx,dynamicIdNotifyFx,bNoDoubleLoad){if(null==resourceNames||resourceNames.length<=0){return ;}

var myDynamicId=lds_nextId++;if(null!=dynamicIdNotifyFx){dynamicIdNotifyFx(myDynamicId);}

var miniCache=new MiniCache();var gE=createGeneralExecuter("get_script_name",miniCache,"GetDynamicScriptPath");var params=gE.getChildField("exec_params");var nameHolder=params.addChildField("resource_names","ARRAY");for(var i=0;i<resourceNames.length;i++)
{nameHolder.addChildField(null,"TEXT",resourceNames[i]);}

var myKey=lds_calculateKeyForId(myDynamicId);lds_onAfterLoadFx[myKey]=onAfterLoadFx;var onAfterProcessFx=function(){var execResObj=miniCache.getActionField("get_script_name").getChildField("exec_res");lds_noResourceFound[myKey]=execResObj.getChildField("no_resource_found");var scriptPath=execResObj.getChildField("file_name").getValue();var loadingStatus=lds_scriptLoadMap.get(scriptPath);if(null==loadingStatus||(true!=bNoDoubleLoad)){lds_scriptLoadMap.put(scriptPath,"loading");var afterScriptLoadFx=function(){lds_scriptLoadMap.put(scriptPath,"loaded");onAfterLoadFx();}

lds_onAfterLoadFx[scriptPath]=afterScriptLoadFx;var scriptToLoad=document.createElement("script");scriptToLoad.src=scriptPath;document.body.appendChild(scriptToLoad);var cssFilePath=execResObj.getChildField("css_file_name");if(null!=cssFilePath){var cssEl=document.createElement("link");cssEl.rel="stylesheet"
cssEl.href=cssFilePath.getValue();cssEl.type="text/css";document.body.appendChild(cssEl);}

}

else if("loaded"==loadingStatus){onAfterLoadFx();}

else if("loading"==loadingStatus){lds_startScriptLoadingCheckTimerFor(myKey,scriptPath);}

else 
{alert("Uknown loading status: '"+loadingStatus+"'");}

}

miniCache.process(onAfterProcessFx);}

function getNoResourceFoundObjFor(dynamicId){var myKey=lds_calculateKeyForId(dynamicId);return lds_noResourceFound[myKey];}

function lds_calculateKeyForId(dynamicId){return "fx"+dynamicId;}


function lds_startScriptLoadingCheckTimerFor(myKey,scriptLoadKey){var t=setTimeout("lds_scriptLoadingCheckTimer( '"+myKey+"', '"+scriptLoadKey+"') ",300);return t;}


var lds_maxCheckCnt=20;function lds_scriptLoadingCheckTimer(myKey,scriptLoadKey){var curCnt=lds_loadCheckCntMap.get(myKey);if(null==curCnt){curCnt=lds_maxCheckCnt;lds_loadCheckCntMap.put(myKey,curCnt);}

if("loaded"!=lds_scriptLoadMap.get(scriptLoadKey)&&curCnt-->0){lds_loadCheckCntMap.put(myKey,curCnt);lds_startScriptLoadingCheckTimerFor(myKey,scriptLoadKey);return ;}

var afterLoadFx=lds_onAfterLoadFx[myKey];if(null!=afterLoadFx){afterLoadFx();}

}

var ComponentEditorUtil=new ComponentEditorUtilBase();function ComponentEditorUtilBase(){this.buildLabelTd=function(parentEl,label){if(!this.isInitialized){this.initCss(parentEl.ownerDocument);}

return LpPopupUtil.buildContentSection(parentEl,label);}
;this.buildInput=function(parentEl,paramName,label,params,width){var span=cE("span",parentEl);span.innerHTML=label;span.className="acomp_labelHolder";var input=cE("input",parentEl);input.style.width=(width!=null)?width:"50px";input.value=params[paramName];input.style.margin="0px 8px 0px 4px";var onChange=function(){params[paramName]=input.value;}

E.change(input,onChange);return input;}
;this.buildCheckBox=function(parentEl,paramName,label,params){var chkBox=document.createElement("input");chkBox.type="checkbox";chkBox.checked=(params[paramName]=="true");chkBox.style.margin="0px";aE(parentEl,chkBox);var onClick=function(){params[paramName]=""+chkBox.checked;}
;E.click(chkBox,onClick,{stopEvent:false}
);var span=cE("span",parentEl);span.className="acomp_lchkLabelHolder";span.innerHTML=label;}
;this.buildDD=function(parentEl,paramName,label,params,options){var span=cE("span",parentEl);span.innerHTML=label;span.className="acomp_labelHolder";var dd=cE("select",parentEl);var selectedOption=params[paramName];for(var i=0;i<options.length;i++)
{var optionVal=options[i];var option=cE("option",dd);option.innerHTML=optionVal;option.value=optionVal;if(optionVal==selectedOption){option.selected=true;}

}

var onChange=function(){params[paramName]=dd.options[dd.selectedIndex].value;}

E.change(dd,onChange);return dd;}
;this.initCss=function(doc){var cC=new CssClass(".acomp_lchkLabelHolder");cC.add("padding","0px 15px 0px 3px");cC.add("font-size","12px");cC.init(doc);var cC=new CssClass(".acomp_labelHolder");cC.add("padding-right","8px");cC.add("font-size","12px");cC.init(doc);}
;}
;
;;;
function ComponentParamSetter(componentRec,params){this.componentRecord=componentRec;this.params=params;this.runtimeParams=componentRec.getField("runtime_params");this.execParams=componentRec.getField("exec_params");this.name=componentRec.getField("name.recordName").getValue();this.onInsertFx;}
;ComponentParamSetter.prototype=new ComponetParamSetterBase();function ComponetParamSetterBase(){this.build=function(){showProgressIcon("loading");var paramCount=this.execParams.getChildFieldCount();if(0==paramCount){if(!this.isInserted){var aTag=this.createATag();this.onInsertFx(aTag,paramCount);}

hideProgressIcon();return ;}

var jsPath=this.runtimeParams.getChildField("js").getValue();if(jsPath.trim()==""){this.finishBuild();}

else {var thisObj=this;var afterLoad=function(){thisObj.editorName=thisObj.name+"Editor";thisObj.finishBuild();}

loadDynamicScript([jsPath+"Editor"],afterLoad);}

}
;
this.finishBuild=function(){var lpPopup=new LpPopup();lpPopup.width=650;lpPopup.zIndex=100000000000;lpPopup.title="Component Configuration";var popup=lpPopup.popup;this.popup=popup;var cA=lpPopup.build();cA.style.padding="15px";if(undefined==window[this.editorName]){this.buildDefaultParamEditor(cA);}

else 
{var params=this.params;if(null==params){params=clone(this.execParams.data);this.params=params;}

var ComponentEditor=eval(this.editorName);var editor=new ComponentEditor(this.componentRecord,params)
editor.build(cA);}

LpPopupUtil.buildDivider(cA)
var buttonHolder=cE("div",cA);var thisObj=this;var insertFx=function(){var aTag=thisObj.createATag();thisObj.onInsertFx(aTag);popup.close();}
;var closeFx=function(){popup.close();}
;LpPopupUtil.buildButtonSection(buttonHolder,"Insert Component",insertFx,"Close",closeFx)
this.popup.setFrameHeight(cA.offsetHeight);popup.center();hideProgressIcon();}
;this.buildDefaultParamEditor=function(parentEl){var nameHolder=cE("div",parentEl);nameHolder.style.marginBottom="10px";var span=cE("span",nameHolder);span.innerHTML="Component name:"
var span=cE("span",nameHolder);span.innerHTML=this.name;span.style.fontWeight="bold";span.style.fontStyle="italic";this.params=clone(this.execParams.data);if(this.execParams.getChildFieldCount()>0){var paramHolder=cE("div",parentEl);paramHolder.style.maxHeight="460px";paramHolder.style.overflow="auto";paramHolder.style.border="1px solid gray";paramHolder.style.marginBottom="10px";this.execParams.buildField(paramHolder,"edit",{isEditable:false}
);}

}
;
this.createATag=function(){var aTag="<a_component name=\""+this.name+"\" ";var params=this.params;for(var paramName in params)
{var paramValue=params[paramName]
if(""==paramValue){continue;}

aTag+=paramName+"=\""+paramValue+"\" "
}

aTag=aTag.trim()+">";return aTag;}
;}

;function LiveComponent(){this.init=function(data){this.initCss();var parentEl=gE("#"+data.elId);if(null==parentEl){alert("Element with ID "+data.elId+" not found");return ;}

parentEl.className="lp_component";var AComponent=eval(data.componentName);if(AComponent){var aComponent=new AComponent();aComponent.build(parentEl);}

var thisObj=this;var createCover=function(){var anchor=cE("div",parentEl);anchor.style.position="relative";anchor.className="a_skip";coverEl=cE("div",anchor);coverEl.style.top=(-1*parentEl.offsetHeight)+"px";coverEl.style.left="0px";coverEl.className="lp_componentCover";coverEl.style.width=parentEl.offsetWidth+"px";coverEl.style.height=parentEl.offsetHeight+"px";parentEl.anchor=anchor;var editFx=function(event){thisObj.launchParamEditor(parentEl,data);return false;}
;E.mouseup(coverEl,function(){}
,{stop:true}
)
E.click(coverEl,editFx,{stop:true}
);var removeCover=function(){parentEl.anchor=null;parentEl.removeChild(anchor);}
;E.add(coverEl,"mouseout",removeCover);}
;E.add(parentEl,"mouseenter",createCover);}
;
this.initCss=function(){var cls=new CssClass(".lp_component td");cls.add("outline","0");cls.init();var cls=new CssClass(".lp_componentCover");cls.add("position","absolute");cls.add("cursor","pointer");cls.add("z-index","10000");cls.init();}
;
this.launchParamEditor=function(parentEl,data){var mc=new MiniCache();mc.addKeyedRecordToLoad("a_component","name",data.params.name);var thisObj=this;var onProcess=function(){var componentRec=mc.getRecordByKey("a_component","name",data.params.name);var componentEditor=new ComponentParamSetter(componentRec,data.params);componentEditor.isInserted=true;componentEditor.onInsertFx=function(aTag){thisObj.insertEditedComponent(parentEl,aTag);}
;componentEditor.build();}

mc.process(onProcess);}
;
this.insertEditedComponent=function(parentEl,aTag){parentEl.innerHTML="";LivePage.insertATag(parentEl,aTag);}
;}
;
;var LiveComponentHandler=new LiveComponentHandlerBase();function LiveComponentHandlerBase(){this.init=function(data){var component=new LiveComponent();component.init(data);}
;this.initHandler=function(){ATagInitializer.addSpecialModeHandler("visual_edit","component",this);}
;}

var AHtmlInserter=new AHtmlInserterBase();function AHtmlInserterBase(){this.processInsert=function(parentEl,data){eval("var miniCacheData= "+data.mcData);var mc=getMasterCache();mc_updateData(mc,miniCacheData);var html=data.html;eval("var jsData= "+data.json);var mFragInfo=jsData.fragInfo;for(var fragId in mFragInfo)
{A.addFragInfo(fragId,mFragInfo[fragId]);}

var styles=data.styles;var scripts=data.scripts;if(styles.length==0&&scripts.length==0){this.insertHtml(parentEl,html,mFragInfo);}

else 
{this.injectResources(styles,scripts,mFragInfo,parentEl,html,mFragInfo);}

}
;
this.injectResources=function(styles,scripts,fragInfo,parentEl,html){var headEl=document.getElementsByTagName('head')[0];for(var i=0;i<styles.length;i++)
{var src=styles[i];var start=src.lastIndexOf("/")+1;var end=src.lastIndexOf(".css")
var name=src.substring(start,end);var cssInclude=gE("#css"+name);if(null!=cssInclude){continue;}

var cssEl=document.createElement("link");cssEl.rel="stylesheet"
cssEl.href=src;cssEl.id="css"+name;cssEl.type="text/css";aE(headEl,cssEl);}

this.triggerScriptLoad(scripts,0,parentEl,html,fragInfo);}
;
this.triggerScriptLoad=function(scripts,index,parentEl,html,fragInfo){if(scripts.length==0){this.insertHtml(parentEl,html,fragInfo);return ;}

var scriptEl=document.createElement("script");scriptEl.src=scripts[index];scriptEl.type="text/javascript";var thisObj=this;var onLoad=function(){if(index==[scripts.length-1]){thisObj.insertHtml(parentEl,html,fragInfo);}

else 
{thisObj.triggerScriptLoad(scripts,index+1,parentEl,html,fragInfo);}

}
;aE(document.body,scriptEl);E.add(scriptEl,"load",onLoad);}
;this.insertHtml=function(parentEl,html,fragInfo){if(null==parentEl){A.launchPoupForHtml(html);}

else 
{parentEl.innerHTML=html;}

ATagInitializer.init(null,fragInfo);}
;}
;
;;
function AHtmlGetter(aHtml){var mc=new MiniCache();this.mc=mc;var gE=createGeneralExecuter("ahtml_getter",mc,"AHtmlGetter");var suffix=A.createTempId();this.suffix=gE.addExecParamObj("suffix","TEXT",suffix);this.aHtml=gE.addExecParamObj("ahtml","LONG_TEXT",aHtml);this.inputs=gE.addExecParamObj("inputs","COLLECTION");}
;AHtmlGetter.prototype=new AHtmlGetterBase();function AHtmlGetterBase(){this.count=0;
this.execute=function(afterExecute){var mc=this.mc;var onProcess=function(){var results=mc.getActionField("ahtml_getter").getResults().data;afterExecute(results);}
;mc.process(onProcess);}
;
this.addRecordInput=function(inputName,recordType,recordId){var inputData=this.createInput(inputName,"record");var recordData=inputData.addChildField("inputData","COLLECTION");recordData.addChildField("type","TEXT",recordType);recordData.addChildField("id","INTEGER",recordId);}
;
this.createInput=function(inputName,inputType){var anInput=this.inputs.addChildField(inputName,"COLLECTION");anInput.addChildField("inputType","TEXT",inputType);return anInput;}


this.addListInput=function(listName,listInput){var input=this.createInput(listName,"list");input.insertChildField("listInput","COLLECTION",listInput);}
;}
;

var NamingUtil=new NamingUtilBase();function NamingUtilBase(){this.createName=function(name,maxLength){name=name.toLowerCase().replace(/\s/g,'_');var newName="";for(var i=0;i<name.length;i++)
{if((name.charAt(i)>='a'&&name.charAt(i)<='z')||
(name.charAt(i)>='0'&&name.charAt(i)<='9')||
(name.charAt(i)=='_')){newName+=name.charAt(i);}

}

newName.substring(0,maxLength);return newName;}

}
;

;
function TableUpdater(mc){this.mc=mc;this.params;this.init();}

TableUpdater.prototype=new TableUpdaterBase();function TableUpdaterBase(){this.init=function(){var gE=createGeneralExecuter("tu",this.mc,"TableUpdater");this.params=gE.getChildField("exec_params");var params=this.params;params.addChildField("table_name","TEXT");params.addChildField("package","TEXT");params.addChildField("singular_display_name","TEXT");params.addChildField("plural_display_name","TEXT");params.addChildField("fields_to_update","COLLECTION");params.addChildField("fields_to_delete","ARRAY");}
;this.addField=function(displayName,fieldType){var fieldName=NamingUtil.createName(displayName,60);var newField=this.params.getChildField("fields_to_update").addChildField(fieldName,fieldType);newField.setDisplayName(displayName)
}
;this.getTableName=function(){return this.params.getChildField("table_name");}
;this.getDisplayName=function(){return this.params.getChildField("singular_display_name");}
;}
;

function AddFieldPopup(tableUpdater){this.tableUpdater=tableUpdater;this.build=function(){var popup=new Popup();this.popup=popup;popup.title="Add Field";popup.disableBg=true;popup.width=400;popup.height=300;var contentArea=popup.build();contentArea.style.padding="20px";var div=cE("div",contentArea);div.innerHTML="Field Name";var div=cE("div",contentArea);var properties={style:{width:"100%"}
}
;this.display=buildTextInput(div,properties);var div=cE("div",contentArea);div.style.marginTop="15px";div.innerHTML="Data Type";this.buildSelect(contentArea);var div=cE("div",contentArea);div.style.marginTop="25px";div.align="center";this.buildButton(div);popup.center();}
;this.addField=function(){this.tableUpdater.addField(this.display.value,this.dd.value);}
;this.buildButton=function(parentEl){var button=cE("button",parentEl);button.style.marginTop="25px";button.innerHTML="Add Field";var thisObj=this;var fx=function(){thisObj.addField();}
;E.click(button,fx);}
;this.buildSelect=function(parentEl){var dd=cE("select",parentEl);this.dd=dd;this.buildOption(dd,"Short Text","TEXT")
this.buildOption(dd,"Long Text","LONG_TEXT")
this.buildOption(dd,"Rich Text","MODULE")
this.buildOption(dd,"Category","C3")
this.buildOption(dd,"Multi-Select","MS3")
this.buildOption(dd,"Date","DATE")
this.buildOption(dd,"Time","TIME_TYPE_NAME")
this.buildOption(dd,"Date & Time","DATETIME")
this.buildOption(dd,"Integer","INTEGER")
this.buildOption(dd,"Decimal","DOUBLE")
this.buildOption(dd,"File","FILE2")
this.buildOption(dd,"True/False","BOOLEAN")
}
;this.buildOption=function(selectEl,name,value){var option=cE("option",selectEl);option.value=value;option.innerHTML=name;}
;}


;;function EditFormFieldsPopup(){this.mc=new MiniCache();this.popup;this.formId;this.tableUpdater;this.build=function(){var thisObj=this;var fx=function(){thisObj.initData();thisObj.buildElements();}
;this.loadData(fx);}
;this.buildElements=function(){var popup=new Popup();this.popup=popup;popup.title="Add Form";popup.disableBg=true;popup.width=900;popup.height=600;popup.fadeBg=false;var contentArea=popup.build();contentArea.style.padding="20px";var div=cE("div",contentArea);this.buildTableName(div);var div=cE("div",contentArea);this.addFieldButton(div);popup.center();}
;this.initData=function(){var tableUpdater=new TableUpdater(this.mc);this.tableUpdater=tableUpdater;}
;this.addFieldButton=function(parentEl){var div=cE("div",parentEl);div.style.margin="25px 0 15px";var button=cE("button",div);button.innerHTML="Add Field";var thisObj=this;var fx=function(){var popup=new AddFieldPopup(thisObj.tableUpdater);popup.build();}
;E.click(button,fx);}
;this.buildTableName=function(parentEl){var div=cE("div",parentEl);div.innerHTML="Table Name";var field=this.tableUpdater.getDisplayName();var props={style:{width:"300px"}
}
;var div=cE("div",parentEl);field.buildField(div,"edit",props);}
;this.loadData=function(afterFx){this.mc.addTemplateToLoad("form");var thisObj=this;var fx=function(){thisObj.createForm();afterFx();}
;this.mc.process(fx);}
;this.createForm=function(){var record=this.mc.createRecord("form");}
;this.initCss=function(){
}
;}


;function FormPopup(){this.mc=new MiniCache();this.popup;this.build=function(){var thisObj=this;var fx=function(){thisObj.buildElements();}
;this.loadData(fx);}
;this.buildElements=function(){var popup=new Popup();this.popup=popup;popup.title="Add Form";popup.disableBg=true;popup.width=900;popup.height=600;popup.fadeBg=false;var contentArea=popup.build();contentArea.style.padding="20px";var div=cE("div",contentArea);this.buidCreateNew(div);popup.center();}
;this.buidCreateNew=function(parentEl){var div=cE("div",parentEl);var button=cE("button",div);button.innerHTML="Create New Form";}
;this.loadData=function(afterFx){afterFx();}
;this.initCss=function(){
}
;}

var LpPopupUtil=new LpPopupUtilBase();function LpPopupUtilBase(){this.buildContentSection=function(parentEl,title){var titleHolder=cE("div",parentEl);titleHolder.className="lpp_sectionTitleHolder";var tbody=createTable(titleHolder,"100%")
var tr=cE("tr",tbody);var td=cE("td",tr);td.innerHTML=title;td.className="lpp_sectionTitle";var td=cE("td",tr);td.style.width="100%";var hr=cE("hr",td);hr.className="lpp_divider";var contentHolder=cE("div",parentEl);contentHolder.className="lpp_contentHolder";return contentHolder;}
;this.buildDivider=function(parentEl){var hr=cE("hr",parentEl);hr.className="lpp_divider";}
;this.buildButtonSection=function(parentEl,buttonLabel,buttonFx,cancelLabel,cancelFx){var tbody=createTable(parentEl,"100%");var tr=cE("tr",tbody);var td=cE("td",tr);var button=cE("button",td);button.innerHTML=buttonLabel;button.className="lp_darkButton";E.click(button,buttonFx);var td=cE("td",tr);var div=cE("div",td);div.className="lp_cancelTxt";div.innerHTML=cancelLabel;E.click(div,cancelFx);}
;}
;
;function LpPopup(){this.popup=new Popup();this.width;this.height;this.zIndex;this.title="&nbsp;";this.closeFx;
this.build=function(){var popup=this.popup;popup.closeFx=this.closeFx;popup.disableBg=true;popup.width=this.width;popup.height=this.height;popup.zIndex=this.zIndex;popup.showX=true;popup.fadeBg=false;popup.doc=window.parent.document;popup.titleDragBarClass="lpp_header";popup.useFrame=true;popup.title=this.title;popup.closeImg="/upload/custom_screens/html5/livepage/close_icon.gif";var cA=popup.build();cA.className="lpp_contentArea lp_reset";this.cA=cA;this.initCss();return cA;}
;
this.buildHeader=function(parentEl,popup){var holder=cE("div",parentEl);holder.className="lpp_header";popup.makeDraggable(holder);var div=cE("div",holder);div.style.padding="0px 0px 0px 15px";div.innerHTML=this.title||"";CssUtil.setFloat(div,"left");var img=cE("img",holder);img.src="/upload/custom_screens/html5/livepage/close_icon.gif";img.style.cursor="pointer";img.style.padding="0px 15px 0px 0px";img.style.position="relative";img.style.top="3px";CssUtil.setFloat(img,"right");var thisObj=this;var closeFx=function(){popup.close();}
;eh_attachEvent("onclick",img,closeFx);var div=cE("div",holder);div.style.clear="both";}
;this.initCss=function(){var doc=this.cA.ownerDocument;var cC=new CssClass(".lpp_header");cC.add("border-bottom","1px solid #2e2e2e")
cC.add("padding","8px 0px 8px 0px");cC.add("font","bold 14px arial");cC.add("color","white");cC.add("background","#3e3e3e");cC.add("width","100%");cC.init(this.popup.doc);var cC1=new CssClass(".lpp_contentArea");cC1.add("font-family","Arial");cC1.add("color","#333333");cC1.add("user-select","none");cC1.add("-webkit-user-select","none");cC1.add("-moz-user-select","-moz-none");cC1.add("margin","0px auto");cC1.init(doc);var cC2=new CssClass(".lpp_contentArea td");cC2.add("font-family","Arial");cC2.init(doc);var cC=new CssClass(".lp_darkButton");cC.add("display","inline-block");cC.add("vertical-align","baseline");cC.add("margin","0 2px");cC.add("outline","none");cC.add("cursor","pointer");cC.add("text-align","center");cC.add("text-decoration","none");cC.add("font","14px/100% Arial, Helvetica, sans-serif");cC.add("border-radius","5px");cC.add("padding","5px 10px 5px 10px");cC.add("color","white");cC.add("border","solid 1px #7a7a7a");cC.add("background","#8d8d8d");cC.add("background","-webkit-gradient(linear, left top, left bottom, from(#8d8d8d), to(#4f4f4f))");cC.add("background","-moz-linear-gradient(top, #8d8d8d, #4f4f4f)");cC.add("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr='#8d8d8d', endColorstr='#4f4f4f')");cC.init(doc);var cC=new CssClass(".lp_darkButton:hover");cC.add("background","#4f4f4f");cC.add("background","-webkit-gradient(linear, left top, left bottom, from(#4f4f4f), to(#8d8d8d))");cC.add("background","-moz-linear-gradient(top, #4f4f4f, #8d8d8d)");cC.add("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr='#4f4f4f', endColorstr='#8d8d8d')");cC.init(doc);var cls=new CssClass(".lp_darkButton:active");cls.add("position","relative");cls.add("top","1px");cls.init(doc);var cB=new CssClass(".lp_cancelTxt");cB.add("color","#666666");cB.add("float","right");cB.add("padding-top","10px");cB.init(doc);var cB=new CssClass(".lp_cancelTxt:hover");cB.add("cursor","pointer");cB.add("text-decoration","underline");cB.init(doc);var cC=new CssClass(".lpp_sectionTitle");cC.add("font-weight","bold")
cC.add("color","#333333");cC.add("font-size","14px");cC.add("font-family","Arial");cC.add("white-space","nowrap");cC.add("padding-right","8px");cC.init(doc);var cC=new CssClass(".lpp_divider");cC.add("width","100%")
cC.add("border-bottom","1px solid #dedede");cC.add("border-top","0px solid #dedede");cC.init(doc);var cC=new CssClass(".lpp_contentHolder");cC.add("margin","10px 0px 20px 10px")
cC.init(doc);var cC=new CssClass("select");cC.add("padding","2px");cC.init(doc);var cC=new CssClass(".tpp_contentArea");cC.add("padding","25px");cC.add("font","12px arial");cC.init(doc);}
;this.setPctWidth=function(pctWidth){var totalWidth=window.top.innerWidth;this.cA.style.width=(totalWidth*pctWidth/100)+"px";}
;this.setPctHeight=function(pctHeight){var totalHeight=window.top.innerHeight;this.cA.style.height=(totalHeight*pctHeight/100)+"px";}
;}
;
var LpCss=new LivePageCss();function LivePageCss(){this.init=function(){var cls=new CssClass(".a-meta-no-transitions *");cls.add("transition","none !important");cls.init();var cls=new CssClass(".lp_reset");cls.add("color","black");cls.init();var cls=new CssClass(".imageFrameTop");cls.add("border-bottom","1px solid black");cls.init();var cls=new CssClass(".imageFrameRight");cls.add("border-left","1px solid black");cls.init();var cls=new CssClass(".imageFrameBottom");cls.add("border-top","1px solid black");cls.init();var cls=new CssClass(".imageFrameLeft");cls.add("border-right","1px solid black");cls.init();var cssClass=new CssClass(".lp_saQuickInfoBox");cssClass.add("background","#333333");cssClass.add("border","1px solid white");cssClass.add("font-size","11px");cssClass.add("font-family","arial");cssClass.add("font-weight","bold");cssClass.add("padding","4px");cssClass.add("color","white");cssClass.add("line-height","1.2em");cssClass.add("text-align","left");cssClass.init();var cssClass=new CssClass(".lp_link");cssClass.add("font-family","arial");cssClass.add("font-size","16px");cssClass.add("cursor","pointer");cssClass.init();var cssClass=new CssClass(".lp_link:hover");cssClass.add("text-decoration","underline");cssClass.init();var cssClass=new CssClass(".lp_smallText");cssClass.add("color","black");cssClass.add("font-family","arial");cssClass.add("font-size","12px");cssClass.init();var cssClass=new CssClass(".lp_mediumText");cssClass.add("font-family","arial");cssClass.add("font-size","16px");cssClass.init();var cssClass=new CssClass(".lp_mediumBoldText");cssClass.add("font-family","arial");cssClass.add("font-size","16px");cssClass.add("font-weight","bold");cssClass.init();var cssClass=new CssClass("td");cssClass.add("outline","1px dotted #999999");cssClass.init();var cssClass=new CssClass(".a_tools td, .a_popupContainer td, .a_popupAnchor td");cssClass.add("outline","0");cssClass.init();var cssClass=new CssClass(".lp_editEl");cssClass.add("outline","1px dashed #cccccc");cssClass.init();var cssClass=new CssClass(".lp_settingText");cssClass.add("font-size","14px");cssClass.add("font-family","arial");cssClass.init();var cssClass=new CssClass(".lp_settingSmallText");cssClass.add("font-size","14px");cssClass.add("font-family","arial");cssClass.init();var cC=new CssClass(".lp_darkButton, .lp_smallDarkButton");cC.add("display","inline-block");cC.add("vertical-align","baseline");cC.add("margin","0 2px");cC.add("outline","none");cC.add("cursor","pointer");cC.add("text-align","center");cC.add("text-decoration","none");cC.add("font","14px/100% Arial, Helvetica, sans-serif");cC.add("border-radius","5px");cC.add("padding","5px 10px 5px 10px");cC.add("color","white");cC.add("border","solid 1px #7a7a7a");cC.add("background","#8d8d8d");cC.add("background","-webkit-gradient(linear, left top, left bottom, from(#8d8d8d), to(#4f4f4f))");cC.add("background","-moz-linear-gradient(top, #8d8d8d, #4f4f4f)");cC.add("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr='#8d8d8d', endColorstr='#4f4f4f')");cC.init();var cC=new CssClass(".lp_smallDarkButton");cC.add("margin","0 2px");cC.add("font","12px/100% Arial, Helvetica, sans-serif");cC.add("border-radius","5px");cC.add("padding","5px 10px 5px 10px");cC.init();var cC=new CssClass(".lp_darkButton:hover,.lp_smallDarkButton:hover");cC.add("background","#4f4f4f");cC.add("background","-webkit-gradient(linear, left top, left bottom, from(#4f4f4f), to(#8d8d8d))");cC.add("background","-moz-linear-gradient(top, #4f4f4f, #8d8d8d)");cC.add("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr='#4f4f4f', endColorstr='#8d8d8d')");cC.init();var cls=new CssClass(".lp_darkButton:active,.lp_smallDarkButton:active");cls.add("position","relative");cls.add("top","1px");cls.init();var cB=new CssClass(".lp_cancelTxt");cB.add("color","#666666");cB.add("float","right");cB.add("padding-top","10px");cB.init();var cB=new CssClass(".lp_cancelTxt:hover");cB.add("cursor","pointer");cB.add("text-decoration","underline");cB.init();var cls=new CssClass(".lp_popupTitleBar");cls.add("border-bottom","1px solid #2e2e2e")
cls.add("padding","8px 0px 8px 0px");cls.add("font","bold 14px arial");cls.add("color","white");cls.add("background","#3e3e3e");cls.add("width","100%");cls.init();var cls=new CssClass(".lp_toolbarHeader");cls.add("background-color","#f5f5f5");cls.add("height","28px");cls.add("border-bottom","1px solid #ffffff");cls.init();var cls=new CssClass(".lp_toolbarText");cls.add("color","#333333");cls.add("font","bold 12px verdana");cls.init();var cls=new CssClass(".tilePropsText");cls.add("font-family","arial");cls.add("font-size","12px");cls.add("border-bottom","1px solid black");cls.init();var cls=new CssClass(".mg-align-table");cls.add("margin","auto");cls.init();var cls=new CssClass(".mg-align-table td");cls.add("padding","2px");cls.init();}
;this.init();}
;

function createLiveCssGetter(fieldName,miniCache,moduleIds,styleSheetIds,omitStyleSheetIds){moduleIds=moduleIds||[];styleSheetIds=styleSheetIds||[];omitStyleSheetIds=omitStyleSheetIds||[];var getter=createGEToRunFirst(fieldName,miniCache,"LiveCssGetter");var params=getter.getChildField("exec_params");var mIdsField=params.addChildField("module_ids","ARRAY");for(var i=0;i<moduleIds.length;i++)
{mIdsField.addChildField(null,"INTEGER",moduleIds[i]);}

var cssIdsField=params.addChildField("style_sheet_ids","ARRAY");for(var i=0;i<styleSheetIds.length;i++)
{cssIdsField.addChildField(null,"INTEGER",styleSheetIds[i]);}

var omitIdsField=params.addChildField("omit_style_sheet_ids","ARRAY");for(var i=0;i<omitStyleSheetIds.length;i++)
{omitIdsField.addChildField(null,"INTEGER",omitStyleSheetIds[i]);}

return getter;}



function LiveStyleSheet(id,sourceCode){this.id=id;this.initialCode=sourceCode;this.realSheet;this.editor;this.cssDoc;this.editorPopup;this.classPrefix;this.isChanged=false;this.lastEditTime;this.updateTimer;this.updateDelay=250;this.update=function(element,props,rangeName){var className=this.getClassName(element);var cls=new LiveCssClass();cls.className=className;cls.rangeName=rangeName;for(var i=0;i<props.length;i++)
{var prop=props[i];cls.update(prop.name,prop.value);}

this.updateClass(cls);this.setChanged();LivePage.setElementToSave(element);this.registerChange();}
;this.setChanged=function(){this.isChanged=true;}
;this.updateClass=function(cls){var cssDoc=this.getCssDoc();if(cssDoc.hasUnknownNode){DebugPopup.log("compilation problem");return ;}

if(cssDoc.getRuleBySelector("@a_css")){DebugPopup.log("You can't currently use live css with @ rules. If this is priority, let me know.");return ;}

var info=cls.getRangeSizeInfo();if(info){var sizes=ResponsiveUtil.screenSizesByName;var startSize=sizes[info.startSize].minWidth;var endSize=sizes[info.endSize].maxWidth;if((!startSize)&&(!endSize||endSize==Infinity)){cls.rangeName=null;}

}

var code=cls.getCssText();var realSheet=this.getRealSheet();var posInfo=this.findRulePosInfo(cls);if(posInfo.instruction=="append"){cssDoc.appendClass(cls);realSheet.insertRule(code,realSheet.rules.length);}

else if(posInfo.instruction=="insertAfter"){cssDoc.insertClassAfter(cls,posInfo.rule);realSheet.insertRule(cls.getCssText(),posInfo.index+1);}

else if(posInfo.instruction=="insertBefore"){cssDoc.insertClassBefore(cls,posInfo.rule);realSheet.insertRule(cls.getCssText(),posInfo.index);}

else if(posInfo.instruction=="update"){var rule=posInfo.rule;rule.syncClass(cls);realSheet.deleteRule(posInfo.index);realSheet.insertRule(rule.getCssText(),posInfo.index);}

}
;this.deleteClass=function(className){var rules=this.getCssDoc().getRules(className);for(var i=rules.length-1;i>=0;i--)
{var rule=rules[i];if(rule.getClassName()==className){rule.removeRule();this.getRealSheet().deleteRule(i);}

}

this.setChanged();}
;this.findFonts=function(){var fonts={}
;var doc=this.getCssDoc();var attrs=doc.getDescByType(CssAttributeNode);for(var i=0;i<attrs.length;i++)
{var attr=attrs[i];if(attr.code=="font-family"){fonts[attr.getValue()]=1;}

}

return fonts;}
;this.findRulePosInfo=function(cls){var info={}
;info.instruction="append";var cssDoc=this.getCssDoc();var rules=cssDoc.getRules(cls.className);if(rules.length==0){return info;}

var isClsResp=cls.isResponsive();var index=-1;var counter=0;for(var i=0;i<rules.length;i++)
{var rule=rules[i];if(rule.getClassName()!=cls.className){continue;}

info.index=i;if(!isClsResp&&rule instanceof GenericRuleNode){info.instruction="update";info.rule=rule;return info;}

else if(!isClsResp&&rule instanceof ResponsiveRuleNode){info.instruction="insertBefore";info.rule=rule;return info;}

if(rule instanceof GenericRuleNode){info.instruction="insertAfter";info.rule=rule;}

else if(isClsResp&&(rule instanceof ResponsiveRuleNode)){var clsSizeInfo=cls.getRangeSizeInfo();if((clsSizeInfo.startSize==rule.startSize)&&(clsSizeInfo.endSize==rule.endSize)){info.instruction="update";info.rule=rule;return info;}

else if(ResponsiveUtil.isContained(rule.startSize,rule.endSize,clsSizeInfo.startSize,clsSizeInfo.endSize)){info.instruction="insertBefore";info.rule=rule;return info;}

else if(ResponsiveUtil.isLessThan(clsSizeInfo.startSize,rule.startSize)||ResponsiveUtil.isContained(clsSizeInfo.startSize,clsSizeInfo.endSize,rule.startSize,rule.endSize)){info.instruction="insertAfter";info.rule=rule;}


else if(!ResponsiveUtil.isLessThan(clsSizeInfo.startSize,rule.startSize)){info.instruction="insertBefore";info.rule=rule;return info;}

}

}

return info;}
;this.getRule=function(itemEl,rangeName){if(!rangeName){rangeName="defaultRange";}

var map=this.getCssDoc().getClassNameMap();var classes=CssUtil.getClasses(itemEl);for(var i=0;i<classes.length;i++)
{var className=classes[i];if(map[className]&&map[className][rangeName]){return map[className][rangeName];}

}

return null;}
;this.getCssDoc=function(){if(this.cssDoc){return this.cssDoc;}

var doc=new ACssDoc();doc.compile(this.initialCode);this.cssDoc=doc;return doc;}
;this.getClass=function(className,rangeName){var doc=this.getCssDoc();var rules=doc.getRulesByClassName(className);var defaultRule;if(ResponsiveUtil.isValidRangeName(rangeName)){for(var i=0;i<rules.length;i++)
{var rule=rules[i];if(rule.getClassName()==className&&rule.getRangeName()==rangeName){debugger;}

}

}

else 
{for(var i=0;i<rules.length;i++)
{var rule=rules[i];if(rule.getClassName()==className&&rule instanceof GenericRuleNode){debugger;}

}

}

cls=new LiveCssClass();cls.className=className;cls.rangeName=rangeName;return cls;}
;this.getRuleForRange=function(className,rangeName){var doc=this.getCssDoc();if(rangeName=="defaultRange"){return doc.getRuleBySelector("."+className);}

else 
{return doc.getResponsiveRule(className,rangeName);}

}
;this.getClassName=function(element){var classes=CssUtil.getClasses(element);if(0==classes.length){return this.createClassForEl(element);}

nameMap=this.getClassNameMap();for(var i=0;i<classes.length;i++)
{if(nameMap[classes[i]]){return classes[i];}

}

return this.createClassForEl(element);}
;this.getClassNameMap=function(){var doc=this.getCssDoc();return doc.getClassNameMap();}
;this.createClassForEl=function(element){var moduleId=LivePage.findContainingModuleId(element);var counter=1;var name=this.classPrefix+counter;var isTaken=this.isClassNameTaken(name);while(isTaken)
{counter++;name=this.classPrefix+counter;isTaken=this.isClassNameTaken(name);}

CssUtil.addClassToEl(element,name);return name;}
;this.isClassNameTaken=function(name){if(gE("."+name)){return true;}

var map=this.getClassNameMap();if(map[name]){return true;}

return false;}
;this.sync=function(mc){var record=mc.getRecord("style_sheets",this.id);if(!record){record=mc.createRecord("style_sheets",this.id);var fieldNames=record.getFieldNames();for(var i=0;i<fieldNames.length;i++)
{var name=fieldNames[i];if(name!="style_sheet"&&name!="file_last_written"){record.removeField(name);}

}

}

record.getField("style_sheet.text_css").setValue(this.getCssDoc().getString());record.getField("style_sheet.create_file").setValue(true);}
;
this.registerChange=function(){if(!this.editorPopup){return ;}

this.lastEditTime=new Date();this.setUpdate();}
;this.setUpdate=function(){if(this.updateTimer){return ;}

var thisObj=this;var fx=function(){thisObj.handleUpdate();}
;this.updateTimer=window.setInterval(fx,this.updateDelay);}
;this.handleUpdate=function(){var diff=new Date()-this.lastEditTime;if(diff<this.updateDelay){return ;}

window.clearInterval(this.updateTimer);this.updateTimer=null;this.updateEditor();}
;this.updateEditor=function(){this.editor.updateFromDoc();}
;this.buildEditor=function(x,y){var popup=new Popup();this.editorPopup=popup;popup.setAtCoord(x,y);popup.title="Live Styles";popup.titleDragBarClass="lp_popupTitleBar";popup.closeImg="/upload/custom_screens/html5/livepage/close_icon.gif";popup.showX=true;popup.useFrame=false;popup.closeEvents=null;popup.closeEvent=null;popup.disableBg=false;popup.fadeBg=false;popup.hideTopBar=false;popup.ensureOnTop=true;popup.width="400px";popup.height="700px";var thisObj=this;popup.closeFx=function(){thisObj.editorPopup=null;thisObj.editor=null;}
;var contentArea=popup.build();var editor=new CodeEditor();var thisObj=this;editor.onRecompile=function(){thisObj.onEditorChange();}
;this.editor=editor;editor.docClass=ACssDoc;editor.compileDoc=this.getCssDoc();editor.build(contentArea);popup.align();}
;this.onEditorChange=function(newCssDoc){this.clearRealSheet();var cssDoc=this.getCssDoc();var realSheet=this.getRealSheet();var rules=cssDoc.getRules();for(var i=0;i<rules.length;i++)
{var rule=rules[i];realSheet.insertRule(rule.getCssText(),i);}

}
;this.clearRealSheet=function(){var realSheet=this.getRealSheet();var rules=realSheet.cssRules
while(rules.length>0)
{realSheet.deleteRule(0);}

}
;this.getRealSheet=function(){return LiveCss.getRealSheet(this.id);}
;}


function LiveCssClass(){this.className;this.rangeName;this.properties=[];}
;LiveCssClass.prototype=new LiveCssClassBase();function LiveCssClassBase(){this.tab="      ";this.clearProps=function(){this.properties=[];}
;this.toString=function(){return (this.getSelector()+"\n"+this.getBlockText());}
;this.getBlockText=function(){var str="{\n";for(var i=0;i<this.properties.length;i++)
{var prop=this.properties[i];if(prop.value===""){continue;}

str+=this.tab+prop.property+": "+prop.value+";\n";}

str+="}";return str;}
;this.getCssText=function(){if(this.isResponsive()){return this.getTextForResp();}

else 
{return (this.getSelector()+"\n"+this.getBlockText());}

}
;this.getTextForResp=function(){var text="";text+="@media ";var info=this.getRangeSizeInfo();var sizes=ResponsiveUtil.screenSizesByName;var startSize=sizes[info.startSize].minWidth;var endSize=sizes[info.endSize].maxWidth;if(startSize){text+="(min-width:"+startSize+"px)"
}

if(startSize&&endSize){text+=" and ";}

if(endSize){text+="(max-width:"+endSize+"px)"
}

text+="{."+this.className+this.getBlockText()+"}";return text;}
;this.isResponsive=function(){return ResponsiveUtil.isValidRangeName(this.rangeName);}
;this.getRangeSizeInfo=function(){return ResponsiveUtil.getRangeNameInfo(this.rangeName);}
;this.getSelector=function(){var selector=".";if(ResponsiveUtil.isValidRangeName(this.rangeName)){selector+="r-"+this.rangeName+"-";}

selector+=this.className;return selector;}
;this.update=function(property,value){this.properties.push({property:property,value:value}
);}
;}
;

function LiveCssDropdown(element,dropdownHolder,propName,optionSet,width,optionsBoxWidth,optionsBoxHeight){this.element=element;this.parentEl=dropdownHolder;this.propName=propName;this.optionSet=optionSet;this.width=width||80;this.optionsBoxWidth=optionsBoxWidth||130;this.optionsBoxHeight=optionsBoxHeight||"90%";this.initialValue;this.onChangeFx;this.setValueFx;this.rangeName;}
;LiveCssDropdown.prototype=new LiveCssDropdownBase();function LiveCssDropdownBase(){this.build=function(){var element=this.element;var parentEl=this.parentEl;var propName=this.propName;var optionSet=this.optionSet;var width=this.width;var holder=cE("div",parentEl);holder.style.width=CssUtil.intToPixel(width);holder.style.border="1px solid #999999";var thisObj=this;var fx=function(value){debugger;thisObj.setCssValue(value);}
;var dd=new FlexDropDown(fx);this.widthDD=dd;dd.drawOuterBorder=false;dd.ddAlignment="belowRight";dd.height=23;dd.displayFontSize=12;dd.optionsBoxWidth=this.optionsBoxWidth;dd.optionsBoxHeight=this.optionsBoxHeight;dd.useValueInput=true;dd.doc=(g_params["utw"]=="true")?window.top.document:document;for(var i=0;i<optionSet.length;i++)
{var value=optionSet[i];this.addOption(element,propName,value,dd);}

var initial=this.initialValue||CssUtil.getStyle(element,propName);var ddEl=dd.build(holder,width-2,initial);dd.onBeforeShowOptions=function(){thisObj.realValue=null;}
;return holder;}
;this.setCssValue=function(value){if(this.setValueFx){this.setValueFx(value);}

else 
{var el=this.element;var propName=this.propName;this.setTempCssValue(el,propName,value);LiveCss.update(el,[{name:propName,value:value}
],this.rangeName);}

debugger;this.realValue=null;}
;this.addOption=function(element,propName,value,dd){var span=cE("nobr");span.style.fontFamily="helvetica";span.style.fontSize="14px";span.innerHTML=(value==="")?"--":value;span.style.color="black";var thisObj=this;var enterFx=function(){thisObj.setTempCssValue(element,propName,value);}
;var leaveFx=function(){thisObj.setTempCssValue(element,propName,thisObj.realValue);}
;dd.addOptionEl(span,value,false,enterFx,leaveFx);return span;}
;this.setTempCssValue=function(element,propName,value){if(!this.realValue){this.realValue=CssUtil.getStyle(element,propName);}

LiveCss.update(element,[{name:propName,value:value}
],this.rangeName);if(this.onChangeFx){this.onChangeFx();}

}
;}


function ANode(){}

ANode.prototype=new ANodeBase();function ANodeBase(){this.allowUnknownNodes=true;this.identifyNextNodeType=function(code,marker){while(marker.isBeforeEnd(code))
{for(var i=0;i<this.possibleChildren.length;i++)
{var aNodeClass=this.possibleChildren[i];var isThisTheType=aNodeClass.prototype.isThisThisType(this,code,marker);if(isThisTheType){return aNodeClass;}

}

marker.end++;}

return UnknownNode;}
;this.createNodeForClass=function(aClass,parent,ahtml,marker){return aClass.prototype.createNode(parent,ahtml,marker);}
;this.parseChildCode=function(code,marker){while(marker.isBeforeEnd(code))
{var aClass=this.identifyNextNodeType(code,marker);if(aClass.prototype.classId=="UnknownNode"){var allowsNewLine=false;for(var i=0;i<this.possibleChildren.length;i++)
{if(this.possibleChildren[i]==NewLineNode){hasNewLine=true;}

}

if(!allowsNewLine){marker.end=marker.start+1;return ;}

}

ANode.prototype.createNodeForClass(aClass,this,code,marker);if(aClass.prototype.classId=="UnknownNode"){return ;}

if(this.possibleClosings[aClass.prototype.classId]){return ;}

}

}
;this.compile=function(code){var marker=new Marker(0,0,1);this.parseChildCode(code,marker);}
;this.getChildNodeIndex=function(node){for(var i=0;i<this.childNodes.length;i++)
{if(this.childNodes[i]==node){return i;}

}

return -1;}
;this.allowUnknownChild=function(){return true;}
;
this.possibleClosings={}
;this.setParent=function(parent){if(!parent){return ;}

this.parent=parent;parent.childNodes.push(this);this.doc=parent.doc?parent.doc:parent;}
;this.appendChildren=function(node){for(var i=0;i<node.childNodes.length;i++)
{var toInsert=node.childNodes[i];this.childNodes.push(toInsert);toInsert.parent=this;}

}
;this.insertChild=function(node,index){this.childNodes.splice(index,null,node);node.parent=this;}
;this.insertChildren=function(node,index){for(var i=node.childNodes.length-1;i>=0;i--)
{var toInsert=node.childNodes[i];this.childNodes.splice(index,null,toInsert);toInsert.parent=this;}

}
;this.removeChildren=function(startIndex,howMany){this.childNodes.splice(startIndex,howMany);}
;this.remove=function(){var index=this.getSiblingIndex();if(index==-1){return ;}

this.parent.childNodes.splice(index,1);}
;this.getSiblingIndex=function(){var siblings=this.parent.childNodes;for(var i=0;i<siblings.length;i++)
{if(siblings[i]==this){return i;}

}

return -1;}
;this.getChildOfType=function(nodeClass){for(var i=0;i<this.childNodes.length;i++)
{var node=this.childNodes[i];if(node instanceof nodeClass){return node;}

}

return null;}
;this.getChildrenOfType=function(nodeClass){var children=[];for(var i=0;i<this.childNodes.length;i++)
{var node=this.childNodes[i];if(node instanceof nodeClass){children.push(node);}

}

return children;}
;this.getDescByType=function(nodeType){var nodes=[];this.helpDescByType(nodes,nodeType);return nodes;}
;this.helpDescByType=function(nodes,nodeType){if(this instanceof nodeType){nodes.push(this);}

if(this.childNodes){for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].helpDescByType(nodes,nodeType);}

}

}
;this.getDescendent=function(nodeTypeHierarchy){var node=this;for(var i=0;i<nodeTypeHierarchy.length;i++)
{node=node.getChildOfType(nodeTypeHierarchy[i]);if(!node){return null;}

}

return node;}
;this.getString=function(){var obj={str:""}
;this.getStringHelper(obj);return obj.str;}
;this.getStringHelper=function(obj){obj.str+=this.code;if(!this.childNodes){return ;}

for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].getStringHelper(obj);}

}
;this.write=function(codeEditor){if(this instanceof NewLineNode){var lineEl=cE("pre",codeEditor.codeEl);lineEl.className="line";return ;}

var codeEl=codeEditor.codeEl;var line=codeEl.children[codeEl.children.length-1];var span=cE("span",line);span.innerHTML=this.code;if(this.format){this.format(span);}

if(!this.childNodes){return ;}

for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].write(codeEditor);}

}
;this.advanceMarker=function(marker,code){marker.start+=this.code.length;marker.end=marker.start+1;}
;this.showCompiledNodes=function(){var popup=new Popup();popup.title="Debug View";var contentArea=popup.build();contentArea.style.padding="10px";contentArea.style.paddingLeft="30px";var div=cE("div",contentArea);div.style.width="1000px";div.style.height="600px";div.style.overflow="scroll";div.style.lineHeight="24px";this.buildCompiledNodes(div);popup.center();}
;this.buildCompiledNodes=function(parentEl){for(var i=0;i<this.childNodes.length;i++)
{this.debugHelper(parentEl,this.childNodes[i],0);}

}
;this.debugHelper=function(parentEl,node,indent){var indentPx=indent*20;var holder=cE("div",parentEl);holder.style.paddingLeft="20px";holder.style.position="relative";var codeEl=cE("pre",holder);codeEl.style.display="inline";codeEl.innerText=node.classId+" - \""+node.code+"\"";var hasChildren=node.childNodes&&(node.childNodes.length>0);if(!hasChildren){return ;}

var span=cE("span",holder);span.style.position="absolute";span.style.left="5px";span.style.cursor="pointer";span.innerHTML="-";var childHolder=cE("div",holder);var fx=function(){if(childHolder.style.display=="none"){childHolder.style.display="";span.innerHTML="-";}

else 
{childHolder.style.display="none";span.innerHTML="+";}

}
;E.click(span,fx);for(var i=0;i<node.childNodes.length;i++)
{this.debugHelper(childHolder,node.childNodes[i],indent+1);}

}
;}

function extendANode(aClass){var protoTypeObj=aClass.prototype;var nodeBase=ANode.prototype;for(var i in nodeBase)
{if(!protoTypeObj[i]){protoTypeObj[i]=nodeBase[i];}

}

}


function Marker(lineNumber,start,end){this.start=start;this.end=end;this.getFirstChar=function(code){return code.charAt(this.start);}
;this.getMarked=function(code){return code.substring(this.start,this.end);}
;this.chopFromStart=function(code,length){if(length){return code.substring(this.start,this.start+length);}

return code.substring(this.start);}
;this.isBeforeEnd=function(code){return (this.end<=code.length);}
;}


function UnknownNode(parent){this.setParent(parent);this.startIndex;this.element;this.code;}

UnknownNode.prototype=new UnknownNodeBase();extendANode(UnknownNode);function UnknownNodeBase(){this.createNode=function(parent,code,marker){var doc=parent.doc||parent;doc.hasUnknownNode=true;var node=new UnknownNode(parent);node.startIndex=marker.start;var ahtml=marker.chopFromStart(code);var rE=/([^\n]+)/;var result=rE.exec(ahtml);node.code=result[0];node.advanceMarker(marker,code);return node;}
;this.classId="UnknownNode";}


;;;

function extendClass(classToExtend,parentClass){var protoTypeObj=classToExtend.prototype;var nodeBase=parentClass.prototype;for(var i in nodeBase)
{if(!protoTypeObj[i]){protoTypeObj[i]=nodeBase[i];}

}

}


Function.prototype.extend=function(parentClass){var thisBase=this.prototype;var parentBase=parentClass;for(var i in parentBase)
{if(!thisBase[i]){thisBase[i]=parentBase[i];}

}

var parentPrototype=parentClass.prototype;for(var i in parentPrototype)
{if(!thisBase[i]){thisBase[i]=parentPrototype[i];}

}

}
;

function WhiteSpaceNode(parent){this.setParent(parent);this.startIndex;this.code;}

WhiteSpaceNode.prototype=new WhiteSpaceNodeBase();extendANode(WhiteSpaceNode);function WhiteSpaceNodeBase(){this.createNode=function(parent,code,marker){var node=new WhiteSpaceNode(parent);var end=marker.start+1;while(end<code.length&&code.charAt(end)!='\n'&&isWhiteSpace(code.charAt(end)))
{end++;}

node.code=code.substring(marker.start,end);node.advanceMarker(marker,code);return node;}
;this.codify=function(nodeEl){nodeEl.style.backgroundColor="orange";}
;this.isWhiteSpace=function(aString){var rE=/[^\s]/;return !rE.test(aString);}

this.isThisThisType=function(potentialParent,code,marker){var aChar=marker.getFirstChar(code);if(aChar=='\n'){return false
}

var rE=/[\s]/;return rE.test(aChar);}
;this.classId="WhiteSpaceNode";}


function NewLineNode(parent){this.setParent(parent);this.startIndex;this.code;}

NewLineNode.prototype=new NewLineNodeBase();extendANode(NewLineNode);function NewLineNodeBase(){this.createNode=function(parent,code,marker){var node=new NewLineNode(parent);node.code="\n";node.advanceMarker(marker,code);return node;}
;this.isThisThisType=function(potentialParent,code,marker){var aChar=marker.getFirstChar(code);return (aChar=='\n');}
;this.classId="NewLineNode";}


function AtRuleNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

AtRuleNode.prototype=new AtRuleNodeBase();extendANode(AtRuleNode);function AtRuleNodeBase(){this.possibleChildren=[RuleOpeningBracketNode,SemiColonNode];this.possibleClosings={"RuleOpeningBracketNode":1}
;this.createNode=function(parent,code,marker){var node=new AtRuleNode(parent);node.startIndex=marker.start;var ahtml=marker.chopFromStart(code);var rE=/[^{;]+/;var result=rE.exec(ahtml);node.code=result[0];node.advanceMarker(marker,code);node.parseChildCode(code,marker);return node;}
;this.getSelector=function(){var rE=/[^\s]+/;var result=rE.exec(this.code);return result[0];}
;this.format=function(nodeEl){nodeEl.className="at_rule";}
;this.isThisThisType=function(potentialParent,code,marker){return (marker.getFirstChar(code)=='@');}
;this.classId="AtRuleNode";}


function RuleOpeningBracketNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

RuleOpeningBracketNode.prototype=new RuleOpeningBracketNodeBase();extendANode(RuleOpeningBracketNode);function RuleOpeningBracketNodeBase(){this.possibleChildren=[NewLineNode,WhiteSpaceNode,SemiColonNode,CssAttributeNode,ClosingBracketNode,CommentNode];this.possibleClosings={"ClosingBracketNode":1}
;this.createNode=function(parent,code,marker){var node=new RuleOpeningBracketNode(parent);node.startIndex=marker.start;node.code="{";node.advanceMarker(marker,code);node.parseChildCode(code,marker);return node;}
;this.syncClass=function(cls){var map=this.getAttrMap();for(var i=0;i<cls.properties.length;i++)
{var prop=cls.properties[i];if(map[prop.property]){if(""===prop.value){this.removeAttr(map[prop.property]);}

else 
{map[prop.property].setValue(prop.value);}

}

else 
{this.addAttr(prop.property,prop.value);}

}

cls.clearProps();var attrs=this.getChildrenOfType(CssAttributeNode);for(var i=0;i<attrs.length;i++)
{cls.update(attrs[i].getName(),attrs[i].getValue());}

}
;this.addAttr=function(name,value){if(value===""){return ;}

var endings=this.getChildrenOfType(SemiColonNode);if(endings.length>0){var tempRule=new RuleOpeningBracketNode();var code="\n      "+name+": "+value+";";tempRule.compile(code);var lastSemi=this.getChildNodeIndex(endings[endings.length-1]);this.insertChildren(tempRule,lastSemi+1);}

else 
{var tempRule=new RuleOpeningBracketNode();var code="\n      "+name+": "+value+";";tempRule.compile(code);this.insertChildren(tempRule,0);}

}
;this.getAttrMap=function(){var map={}
;var attrs=this.getChildrenOfType(CssAttributeNode);for(var i=0;i<attrs.length;i++)
{map[attrs[i].getName()]=attrs[i];}

return map;}
;this.updateProp=function(name,value){var attr=this.getAttrByName(name);if(!attr){debugger;}

attr.setValue(value);debugger;}
;this.getAttrByName=function(name){var attrs=this.getChildrenOfType(CssAttributeNode);for(var i=0;i<attrs.length;i++)
{if(name==attrs[i].getName()){return attrs[i];}

}

return null;}
;this.getAttrsByName=function(name){var results=[];var attrs=this.getChildrenOfType(CssAttributeNode);for(var i=0;i<attrs.length;i++)
{if(name==attrs[i].getName()){results.push(attrs[i]);}

}

return results;}
;this.removeAttr=function(node){var index=-1;for(var i=0;i<this.childNodes.length;i++)
{if(this.childNodes[i]==node){index=i;break;}

}

if(i==-1){return ;}

var howMany=1;if(this.childNodes[i+1] instanceof SemiColonNode){howMany=2;if(this.childNodes[i+2] instanceof NewLineNode){howMany=3;if(this.childNodes[i+3] instanceof WhiteSpaceNode){howMany=4;}

}

}

this.childNodes.splice(i,howMany);this.fixIndent();}
;this.fixIndent=function(){var testIndex=this.childNodes.length-2;if(testIndex>0&&(this.childNodes[testIndex] instanceof WhiteSpaceNode)){this.childNodes.splice(testIndex,1);}

}
;this.format=function(nodeEl){nodeEl.className="opening_bracket";}
;this.isThisThisType=function(potentialParent,code,marker){return (marker.getFirstChar(code)=='{');}
;this.classId="RuleOpeningBracketNode";}


function VarNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;}

VarNode.prototype=new VarNodeBase();extendANode(VarNode);function VarNodeBase(){this.createNode=function(parent,code,marker){var node=new VarNode(parent);node.startIndex=marker.start;var ahtml=marker.chopFromStart(code);var rE=/[^;\s]+/;var result=rE.exec(ahtml);node.code=result[0];node.advanceMarker(marker,code);return node;}
;this.format=function(nodeEl){nodeEl.className="var";}
;this.isThisThisType=function(potentialParent,code,marker){return (marker.getFirstChar(code)=='$');}
;this.classId="VarNode";}


function CommentContentNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

CommentContentNode.prototype=new CommentContentNodeBase();extendANode(CommentContentNode);function CommentContentNodeBase(){this.createNode=function(parent,code,marker){var node=new CommentContentNode(parent);var rest=marker.chopFromStart(code);var end=0;var close=rest.indexOf("*/");var newLine=rest.indexOf("\n");if(close>0&&newLine>0){var end=Math.min(close,newLine);node.code=rest.substring(0,end);}

else if(close>0&&newLine==-1){var end=close;node.code=rest.substring(0,end);}

else if(close==-1&&newLine>0){var end=newLine;node.code=rest.substring(0,end);}

else if(-1==close&&-1==newLine){node.code=rest;}

node.advanceMarker(marker,code);return node;}
;this.format=function(nodeEl){nodeEl.className="comment";}
;this.isThisThisType=function(potentialParent,code,marker){if(marker.getFirstChar(code)=="\n"||"*/"==marker.chopFromStart(code,2)){return false;}

return true;}
;this.classId="CommentContentNode";}


function ClosingCommentNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;}

ClosingCommentNode.prototype=new ClosingCommentNodeBase();extendANode(ClosingCommentNode);function ClosingCommentNodeBase(){this.createNode=function(parent,code,marker){var node=new ClosingCommentNode(parent);node.startIndex=marker.start;node.code="*/";node.advanceMarker(marker,code);return node;}
;this.format=function(nodeEl){nodeEl.className="comment";}
;this.isThisThisType=function(potentialParent,code,marker){return (marker.chopFromStart(code,2)=="*/")
}
;this.classId="ClosingCommentNode";}


;;function CommentNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

CommentNode.prototype=new CommentNodeBase();extendANode(CommentNode);function CommentNodeBase(){this.possibleChildren=[ClosingCommentNode,NewLineNode,CommentContentNode];this.possibleClosings={"ClosingCommentNode":1}
;this.createNode=function(parent,code,marker){var node=new CommentNode(parent);node.startIndex=marker.start;node.code="/*";node.advanceMarker(marker,code);node.parseChildCode(code,marker);return node;}
;this.format=function(nodeEl){nodeEl.className="comment";}
;this.isThisThisType=function(potentialParent,code,marker){return (marker.chopFromStart(code,2)=="/*")
}
;this.classId="CommentNode";}


function CssAttributeNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

CssAttributeNode.prototype=new CssAttributeNodeBase();extendANode(CssAttributeNode);function CssAttributeNodeBase(){this.possibleChildren=[WhiteSpaceNode,CssAttrColonNode];this.possibleClosings={"CssAttrColonNode":1}
;this.createNode=function(parent,code,marker){var node=new CssAttributeNode(parent);node.startIndex=marker.start;var ahtml=marker.chopFromStart(code);var rE=/[^\s:;}]+/;var result=rE.exec(ahtml);node.code=result[0];node.advanceMarker(marker,code);node.parseChildCode(code,marker);return node;}
;this.getValueNode=function(){return this.getDescendent([CssAttrColonNode,CssAttrValueNode]);}
;this.getValue=function(){var node=this.getValueNode();if(!node){return "";}

return node.getValue();}
;this.remove=function(){this.parent.removeAttr(this);}
;this.setValue=function(value){if(value===""){this.remove();return ;}
;var node=this.getValueNode();if(!node){node=new CssAttrValueNode(this);}

node.setValue(value);}
;this.getName=function(){return this.code;}
;this.format=function(nodeEl){nodeEl.className="attribute";}
;this.isThisThisType=function(potentialParent,code,marker){var firstChar=marker.getFirstChar(code);var rE=/[^\s:;}]/;return rE.test(firstChar);}
;this.classId="CssAttributeNode";}


function CssAttrColonNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

CssAttrColonNode.prototype=new CssAttrColonNodeBase();extendANode(CssAttrColonNode);function CssAttrColonNodeBase(){this.possibleChildren=[WhiteSpaceNode,CssAttrValueNode,VarNode];this.possibleClosings={"CssAttrValueNode":1}
;this.closingStrings=[";"];this.createNode=function(parent,code,marker){var node=new CssAttrColonNode(parent);node.startIndex=marker.start;node.code=":";node.advanceMarker(marker,code);node.parseChildCode(code,marker);return node;}
;this.isThisThisType=function(potentialParent,code,marker){return (marker.getFirstChar(code)==':');}
;this.allowUnknownChild=function(){return false;}
;this.classId="CssAttrColonNode";}


function CssAttrValueNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;}

CssAttrValueNode.prototype=new CssAttrValueNodeBase();extendANode(CssAttrValueNode);function CssAttrValueNodeBase(){this.createNode=function(parent,code,marker){var node=new CssAttrValueNode(parent);var ahtml=marker.chopFromStart(code);var rE=/[^$;}]+/;var result=rE.exec(ahtml);node.code=result[0];node.advanceMarker(marker,code);return node;}
;this.setValue=function(value){this.code=value;}
;this.getValue=function(){return this.code;}
;this.format=function(nodeEl){nodeEl.className="attribute_value";}
;this.isThisThisType=function(potentialParent,code,marker){var firstChar=marker.getFirstChar(code);var rE=/[^$;}]/;return rE.test(firstChar);}
;this.classId="CssAttrValueNode";}


function SemiColonNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;}

SemiColonNode.prototype=new SemiColonNodeBase();extendANode(SemiColonNode);function SemiColonNodeBase(){this.createNode=function(parent,code,marker){var node=new SemiColonNode(parent);node.startIndex=marker.start;node.code=";";node.advanceMarker(marker,code);return node;}
;
this.isThisThisType=function(potentialParent,code,marker){return (marker.getFirstChar(code)==';');
}
;this.classId="SemiColonNode";}


function ClosingBracketNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;}

ClosingBracketNode.prototype=new ClosingBracketNodeBase();extendANode(ClosingBracketNode);function ClosingBracketNodeBase(){this.createNode=function(parent,code,marker){var node=new ClosingBracketNode(parent);node.startIndex=marker.start;node.code="}";node.advanceMarker(marker,code);return node;}
;this.format=function(nodeEl){nodeEl.className="closing_bracket";}
;
this.isThisThisType=function(potentialParent,code,marker){return (marker.getFirstChar(code)=='}');
}
;this.classId="ClosingBracketNode";}


var RuleInterface=new RuleInterfaceBase();function RuleInterfaceBase(){this.removeRule=function(){var parent=this.parent;var i=this.getSiblingIndex();var howMany=1;var next=parent.childNodes[i+1];if(next&&next instanceof NewLineNode){howMany++
next=parent.childNodes[i+2];if(next&&next instanceof NewLineNode){howMany++;}

}

parent.removeChildren(i,howMany);}
;}


function ResponsiveRuleNode(parent){this.startSize;this.endSize;this.className;this.isError=false;this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

ResponsiveRuleNode.prototype=new ResponsiveRuleNodeBase();extendANode(ResponsiveRuleNode);ResponsiveRuleNode.extend(RuleInterface);function ResponsiveRuleNodeBase(){this.possibleChildren=[NewLineNode,WhiteSpaceNode,RuleOpeningBracketNode];this.possibleClosings={"RuleOpeningBracketNode":1}
;this.createNode=function(parent,code,marker){var node=new ResponsiveRuleNode(parent);node.startIndex=marker.start;var ahtml=marker.chopFromStart(code);var rE=/^\.r-(xxs|xs|s|m|l|xl)-(xxs-|xs-|s-|m-|l-|xl-)?([^{\n]*)/;var result=rE.exec(ahtml);if(result){node.code=result[0];node.startSize=result[1];var end=result[2];if(end){node.endSize=end.substring(0,end.length-1);}

else 
{node.endSize=result[1];}

node.className=result[3];}

else 
{var rE=/[^{\n]+/;var result=rE.exec(ahtml);node.code=result[0];node.isError=true;}

node.advanceMarker(marker,code);node.parseChildCode(code,marker);return node;}
;this.getCssText=function(){var text="";text+="@media ";var sizes=ResponsiveUtil.screenSizesByName;var startSize=sizes[this.startSize].minWidth;var endSize=sizes[this.endSize].maxWidth;var isEndSize=(endSize&&endSize!=Infinity);if(startSize){text+="(min-width:"+startSize+"px)"
}

if(startSize&&isEndSize){text+=" and ";}

if(isEndSize){text+="(max-width:"+endSize+"px)"
}

var blockText="";for(var i=0;i<this.childNodes.length;i++)
{blockText+=this.childNodes[i].getString();}

text+="{."+this.className+blockText+"}";return text;}
;this.syncClass=function(cls){var node=this.getChildOfType(RuleOpeningBracketNode);node.syncClass(cls);}
;this.updateProp=function(name,value){var node=this.getChildOfType(RuleOpeningBracketNode);node.updateProp(name,value);}
;this.getMinWidth=function(){return ResponsiveUtil.screenSizesByName[this.startSize].minWidth||null;}
;this.getMaxWidth=function(){return ResponsiveUtil.screenSizesByName[this.startSize].maxWidth||null;}
;this.getRangeName=function(){if(this.isError){return null;}

var rangeName=this.startSize;if(this.endSize&&(this.endSize!=this.startSize)){rangeName+="-"+this.endSize;}

return rangeName;}
;this.getSelector=function(){return this.code.trim();}
;this.getClassName=function(){return this.className;}
;this.createErrorNode=function(node,ahtml){var rE=/[^{\n]+/;var result=rE.exec(ahtml);node.code=result[0];}

this.format=function(nodeEl){nodeEl.className=this.isError?"error":"responsive_rule";}
;this.getAttrByName=function(name){var node=this.getChildOfType(RuleOpeningBracketNode);return node.getAttrByName(name);}
;this.getAttrsByName=function(name){var node=this.getChildOfType(RuleOpeningBracketNode);return node.getAttrsByName(name);}
;this.addAttr=function(name,value){var node=this.getChildOfType(RuleOpeningBracketNode);node.addAttr(name,value);}
;this.isThisThisType=function(potentialParent,code,marker){return (".r-"==marker.chopFromStart(code,3));}
;this.classId="ResponsiveRuleNode";}


function GenericRuleNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

GenericRuleNode.prototype=new GenericRuleNodeBase();extendANode(GenericRuleNode);GenericRuleNode.extend(RuleInterface);function GenericRuleNodeBase(){this.possibleChildren=[NewLineNode,WhiteSpaceNode,RuleOpeningBracketNode];this.possibleClosings={"RuleOpeningBracketNode":1}
;this.createNode=function(parent,code,marker){var node=new GenericRuleNode(parent);node.startIndex=marker.start;var ahtml=marker.chopFromStart(code);var rE=/[^{\n]+/;var result=rE.exec(ahtml);node.code=result[0];node.advanceMarker(marker,code);node.parseChildCode(code,marker);return node;}
;this.syncClass=function(cls){var node=this.getChildOfType(RuleOpeningBracketNode);node.syncClass(cls);}
;this.getCssText=function(){return this.getString();}
;this.updateProp=function(name,value){var node=this.getChildOfType(RuleOpeningBracketNode);node.updateProp(name,value);}
;this.getSelector=function(){return this.code.trim();}
;this.getClassName=function(){var className=this.code.trim();if(className.charAt(0)=='.'){className=className.substring(1);}

return className;}
;this.getAttrByName=function(name){var node=this.getChildOfType(RuleOpeningBracketNode);return node.getAttrByName(name);}
;this.getAttrsByName=function(name){var node=this.getChildOfType(RuleOpeningBracketNode);return node.getAttrsByName(name);}
;this.addAttr=function(name,value){var node=this.getChildOfType(RuleOpeningBracketNode);node.addAttr(name,value);}
;this.isRule=true;this.format=function(nodeEl){nodeEl.className="generic_rule";}
;this.isThisThisType=function(potentialParent,code,marker){var firstChar=marker.getFirstChar(code);var rE=/[^@\s{}\/;]/;return rE.test(firstChar);}
;this.classId="GenericRuleNode";}


function MediaQueryNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

MediaQueryNode.prototype=new MediaQueryNodeBase();extendANode(MediaQueryNode);function MediaQueryNodeBase(){this.possibleChildren=[NewLineNode,WhiteSpaceNode,MediaOpeningBracketNode];this.possibleClosings={"MediaOpeningBracketNode":1}
;this.createNode=function(parent,code,marker){var node=new MediaQueryNode(parent);node.startIndex=marker.start;var ahtml=marker.chopFromStart(code);var rE=/[^{\n]+/;var result=rE.exec(ahtml);node.code=result[0];node.advanceMarker(marker,code);node.parseChildCode(code,marker);return node;}
;this.getRule=function(className){var node=this.getChildOfType(MediaOpeningBracketNode);return node.getRule(className);}
;
this.getRuleCount=function(){var node=this.getChildOfType(MediaOpeningBracketNode);return node.getRuleCount();}
;this.getMinWidth=function(){var rE=/min-width\s*:\s*(\d+)px/;var result=rE.exec(this.code);if(!result){return null;}

return result[1];}
;this.getMaxWidth=function(){var rE=/max-width\s*:\s*(\d+)px/;var result=rE.exec(this.code);if(!result){return null;}

return result[1];}
;this.isThisThisType=function(potentialParent,code,marker){var begin=marker.chopFromStart(code,6);return (begin=="@media");}
;this.classId="MediaQueryNode";}


function MediaOpeningBracketNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

MediaOpeningBracketNode.prototype=new MediaOpeningBracketNodeBase();extendANode(MediaOpeningBracketNode);function MediaOpeningBracketNodeBase(){this.possibleChildren=[NewLineNode,WhiteSpaceNode,GenericRuleNode,AtRuleNode,ClosingBracketNode,CommentNode];this.possibleClosings={"ClosingBracketNode":1}
;this.createNode=function(parent,code,marker){var node=new MediaOpeningBracketNode(parent);node.startIndex=marker.start;node.code="{";node.advanceMarker(marker,code);node.parseChildCode(code,marker);return node;}
;this.getRule=function(className){for(var i=0;i<this.childNodes.length;i++)
{var child=this.childNodes[i];if(child.getClassName&&child.getClassName()==className){return child;}

}

return null;}
;
this.getRuleCount=function(){var counter=0;for(var i=0;i<this.childNodes.length;i++)
{if(this.childNodes[i].isRule){counter++;}

}

return counter;}
;this.isThisThisType=function(potentialParent,code,marker){return (marker.getFirstChar(code)=='{');}
;this.classId="MediaOpeningBracketNode";}


function VarDeclarationNode(parent){this.setParent(parent);this.startIndex;this.code;this.element;this.childNodes=[];}

VarDeclarationNode.prototype=new VarDeclarationNodeBase();extendANode(VarDeclarationNode);function VarDeclarationNodeBase(){this.possibleChildren=[WhiteSpaceNode,CssAttrColonNode,SemiColonNode];this.possibleClosings={"SemiColonNode":1}
;this.createNode=function(parent,code,marker){var node=new VarDeclarationNode(parent);node.startIndex=marker.start;var ahtml=marker.chopFromStart(code);var rE=/[^\:\s]+/;var result=rE.exec(ahtml);node.code=result[0];node.advanceMarker(marker,code);node.parseChildCode(code,marker);return node;}
;this.getValueNode=function(){return this.getDescendent([CssAttrColonNode,CssAttrValueNode]);}
;this.setValue=function(value){if(value===""){this.remove();return ;}
;var node=this.getValueNode();if(!node){node=new CssAttrValueNode(this);}

node.setValue(value);}
;this.format=function(nodeEl){nodeEl.className="var_declaration";}
;this.isThisThisType=function(potentialParent,code,marker){return (marker.getFirstChar(code)=='$');}
;this.classId="VarDeclarationNode";}


;;;;;;;;;;;;;;;;;;;;function ACssDoc(){this.childNodes=[];this.hasUnknownNode=false;this.id=++acss_counter;}

ACssDoc.prototype=new ACssDocBase();extendANode(ACssDoc);var acss_counter=0;function ACssDocBase(){this.possibleChildren=[NewLineNode,WhiteSpaceNode,MediaQueryNode,ResponsiveRuleNode,VarDeclarationNode,GenericRuleNode,AtRuleNode,CommentNode];this.compile=function(code){var marker=new Marker(0,0,1);this.parseChildCode(code,marker);}
;this.getRuleBySelector=function(selector){for(var i=0;i<this.childNodes.length;i++)
{var node=this.childNodes[i];if(node.getSelector&&node.getSelector()==selector){return node;}

}

return null;}
;this.getRule=function(rule){if(rule instanceof ResponsiveRuleNode){return this.getRRule(rule);}

return null;}
;
this.getRRule=function(rule){for(var i=0;i<this.childNodes.length;i++)
{var child=this.childNodes[i];if(!(child instanceof MediaQueryNode)){continue;}

if(child.getMinWidth()==rule.getMinWidth()&&child.getMaxWidth()==rule.getMaxWidth()){var thisRule=child.getRule(rule.className);if(thisRule){return thisRule;}

}

}

return null;}
;this.getRules=function(){var rules=[];for(var i=0;i<this.childNodes.length;i++)
{var node=this.childNodes[i];if((node instanceof GenericRuleNode)||(node instanceof ResponsiveRuleNode)||(node instanceof AtRuleNode)){rules.push(node);}

}

return rules;}
;this.getRuleSummary=function(className){var summary={className:className}
;var rRules=summary.rRules={}
;summary.defaultRule=null;var rules=this.getRulesByClassName(className);for(var i=0;i<rules.length;i++)
{var rule=rules[i];if(rule instanceof ResponsiveRuleNode){rRules[rule.getRangeName()]=rule;}

else if(rule instanceof GenericRuleNode){summary.defaultRule=rule;}

else 
{DebugPopup.log("strange rule summary");}

}

return summary;}
;this.getRulesByClassName=function(className){var rules=[];for(var i=0;i<this.childNodes.length;i++)
{var node=this.childNodes[i];if(node.getClassName&&node.getClassName()==className){rules.push(node);}

}

return rules;}
;this.getResponsiveRule=function(className,rangeName){return this.getRuleBySelector(".r-"+rangeName+"-"+className);}
;this.appendClass=function(cls){var newDoc=new ACssDoc();newDoc.compile(cls.toString()+"\n\n");this.appendChildren(newDoc);}
;this.getVarDecl=function(varName){for(var i=0;i<this.childNodes.length;i++)
{var child=this.childNodes[i];if(!(child instanceof VarDeclarationNode)){continue;}

if(child.code==varName){return child;}

}

return null;}
;this.insertClassAfter=function(cls,node){var index=this.getChildNodeIndex(node);var nextNode=this.childNodes[index+1];if(!nextNode){this.appendClass(cls);return ;}

while((nextNode instanceof WhiteSpaceNode)&&this.childNodes[index+1])
{index++;nextNode=this.childNodes[index+1];}

if(nextNode instanceof NewLineNode){index++;}

var nextNode=this.childNodes[index+1];if(nextNode instanceof NewLineNode){index++;}

index++;var newDoc=new ACssDoc();newDoc.compile(cls.toString()+"\n\n");this.insertChildren(newDoc,index);}
;this.insertClassBefore=function(cls,node){var index=this.getChildNodeIndex(node);var prevNode=this.childNodes[index-1];if(prevNode instanceof NewLineNode){index--;}

var newDoc=new ACssDoc();newDoc.compile("\n"+cls.toString()+"\n");this.insertChildren(newDoc,index);return ;}
;this.updateClass=function(cls){var newDoc=new ACssDoc();newDoc.compile(cls.toString()+"\n\n");var index=-1;for(var i=0;i<this.childNodes.length;i++)
{var node=this.childNodes[i];if(node instanceof GenericRuleNode&&node.code.trim()==cls.selector){index=i;break;}

}

if(-1==index){this.appendChildren(newDoc);}

else 
{this.childNodes.splice(index,1,newDoc.childNodes[0]);}

}
;this.getClassNameMap=function(){
var nameMap={}
;for(var i=0;i<this.childNodes.length;i++)
{var node=this.childNodes[i];if(node.getClassName){var name=node.getClassName().trim();var ranges=nameMap[name];if(!ranges){ranges=nameMap[name]={}
;}

if(node instanceof GenericRuleNode){ranges["defaultRange"]=node;}

else if(node instanceof ResponsiveRuleNode){ranges[node.getRangeName()]=node;}

}

}

return nameMap;}
;this.write=function(codeEditor){codeEditor.codeEl.innerHTML="";var lineEl=cE("pre",codeEditor.codeEl);lineEl.className="line";for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].write(codeEditor);}

}
;this.parseChildCode=function(code,marker){this.childNodes=[];while(marker.isBeforeEnd(code))
{var aClass=this.identifyNextNodeType(code,marker);ANode.prototype.createNodeForClass(aClass,this,code,marker);}

}
;this.getString=function(){var obj={str:""}
;for(var i=0;i<this.childNodes.length;i++)
{this.childNodes[i].getStringHelper(obj);}

return obj.str;}
;this.showCompiledNodes=function(){var popup=new Popup();popup.title="Debug View";var contentArea=popup.build();contentArea.style.padding="10px";contentArea.style.paddingLeft="30px";var div=cE("div",contentArea);div.style.width="1000px";div.style.height="600px";div.style.overflow="scroll";div.style.lineHeight="24px";this.buildCompiledNodes(div);popup.center();}
;this.buildCompiledNodes=function(parentEl){for(var i=0;i<this.childNodes.length;i++)
{this.debugHelper(parentEl,this.childNodes[i],0);}

}
;this.debugHelper=function(parentEl,node,indent){var indentPx=indent*20;var holder=cE("div",parentEl);holder.style.paddingLeft="20px";holder.style.position="relative";var codeEl=cE("pre",holder);codeEl.style.display="inline";var iT=node.classId;if(!(node instanceof NewLineNode)){iT+=" - \""+node.code+"\"";}

codeEl.innerText=iT;var hasChildren=node.childNodes&&(node.childNodes.length>0);if(!hasChildren){return ;}

var span=cE("span",holder);span.style.position="absolute";span.style.left="5px";span.style.cursor="pointer";span.innerHTML="-";var childHolder=cE("div",holder);var fx=function(){if(childHolder.style.display=="none"){childHolder.style.display="";span.innerHTML="-";}

else 
{childHolder.style.display="none";span.innerHTML="+";}

}
;E.click(span,fx);for(var i=0;i<node.childNodes.length;i++)
{this.debugHelper(childHolder,node.childNodes[i],indent+1);}

}
;this.initCss=function(doc){var cls=new CssClass(".var_declaration,.var");cls.add("color","#7F0091");cls.add("font-weight","bold");cls.init(doc);var cls=new CssClass(".error");cls.add("color","red");cls.init(doc);var cls=new CssClass(".at_rule");cls.add("color","#A64D79");cls.init(doc);var cls=new CssClass(".responsive_rule");cls.add("color","#A64D79");cls.init(doc);var cls=new CssClass(".generic_rule");cls.add("color","#446FBD");cls.init(doc);var cls=new CssClass(".opening_bracket, .closing_bracket");cls.add("color","#535386");cls.init(doc);var cls=new CssClass(".attribute");cls.add("color","#535353");cls.init(doc);var cls=new CssClass(".attribute_value");cls.add("color","#738D00");cls.init(doc);var cls=new CssClass(".comment");cls.add("color","#AAAAAA");cls.init(doc);}
;this.classId="ACssDoc";}

function isLetter(aChar){var rE=/[a-z]|[A-Z]/;return rE.test(aChar);}

function isWhiteSpace(aString){var rE=/[^\s]/;return !rE.test(aString);}



function CodePasteHandler(doc,rangeUtil,editor){this.doc=doc;this.rangeUtil=rangeUtil;this.editor=editor;}
;CodePasteHandler.prototype=new CodePasteHandlerBase();function CodePasteHandlerBase(){this.init=function(){var thisObj=this;var fx=function(e){thisObj.handlePaste(e);}
;var settings={stop:false}
;E.paste(this.doc,fx,settings);}
;this.handlePaste=function(event){var range=this.rangeUtil.getSelectedRange();this.deleteRangeContents(range);var el=cE("textarea");el.style.height="1px";el.style.width="1px";el.style.fontSize="1px";el.style.outline=0;el.style.border=0;el.style.resize="none";el.style.overflow="hidden";el.style.display="inline";el.style.color="transparent";range.insertNode(el);el.focus();var thisObj=this;var fx=function(){thisObj.handleAfterPaste(el);}
;window.setTimeout(fx,0);}
;this.handleAfterPaste=function(el){var newText=el.value;var range=this.rangeUtil.createRange();range.selectNode(el);var lineEl=this.getLine(el);if(!lineEl){lineEl=cE("pre");lineEl.className="line";insertAfter(lineEl,el);el.parentElement.removeChild(el);aE(lineEl,el);range.selectNode(el);}

var eolRange=range.cloneRange();eolRange.collapse(false);eolRange.setEndAfter(lineEl);var lastLineEnd=eolRange.toString();eolRange.deleteContents();range.deleteContents();var lines=newText.split("\n");if(1==lines.length){var textNode=this.doc.createTextNode(lines[0]);range.insertNode(textNode);range.collapse(false);range.selectNode(textNode);range.collapse(false);this.rangeUtil.selectRange(range);if(lastLineEnd){var textNode=this.doc.createTextNode(lastLineEnd);aE(lineEl,textNode);}

return ;}

var textNode=this.doc.createTextNode(lines[0]);range.insertNode(textNode);range.collapse(false);var node;for(var i=1;i<lines.length-1;i++)
{var text=lines[i];node=cE("pre");node.innerText=text||"\n";node.className="line";insertAfter(node,lineEl);lineEl=node;}

var lastLineText=lines[lines.length-1];if(lastLineText){node=cE("pre");node.innerText=lastLineText||"\n";node.className="line";insertAfter(node,lineEl);lineEl=node;range.selectNode(node);range.collapse(false);this.rangeUtil.selectRange(range);if(lastLineEnd){var textNode=this.doc.createTextNode(lastLineEnd);aE(lineEl,textNode);}

}

else if(!lastLineEnd){var nextLine=lineEl.nextElementSibling;if(nextLine){range.selectNodeContents(nextLine);range.collapse(true);}

else 
{range.selectNodeContents(lineEl);range.collapse(false);}

this.rangeUtil.selectRange(range);if(lastLineEnd){var textNode=this.doc.createTextNode(lastLineEnd);aE(lineEl,textNode);}

}

else if(!lastLineText&&lastLineEnd){node=cE("pre");node.className="line";insertAfter(node,lineEl);lineEl=node;range.selectNode(lineEl);range.collapse(true);this.rangeUtil.selectRange(range);if(lastLineEnd){var textNode=this.doc.createTextNode(lastLineEnd);aE(lineEl,textNode);}

else 
{node.innerText="\n";}

}

else 
{this.rangeUtil.selectRange(range);if(lastLineEnd){var textNode=this.doc.createTextNode(lastLineEnd);aE(lineEl,textNode);}

}

this.editor.updateLineCount();}
;this.deleteRangeContents=function(range){if(range.startOffset==0&&range.startContainer.parentElement.tagName=="PRE"){var line=range.startContainer.parentElement;var endRange=range.cloneRange();endRange.collapse();var nextLine=this.getLine(endRange.startContainer);range.deleteContents();if(line!=nextLine){line.parentElement.removeChild(line);range.selectNode(nextLine);range.collapse(true);}

}

else 
{range.deleteContents();}

}
;this.getLine=function(node){if(!node){return null;}

while(node)
{if("PRE"==node.tagName){return node;}

node=node.parentNode;if(!node){return null;}

if("HTML"==node.tagName){return null;}

}

return null;}
;}


;function CodeKeyHandler(editor){this.editor=editor;this.doc=editor.doc;this.rangeUtil;this.onKeyDown;this.onKeyUp;this.pasteHandler;this.lastEditTime;this.compileTimer;this.init(editor,editor.doc);}

CodeKeyHandler.prototype=new CodeKeyHandlerBase();function CodeKeyHandlerBase(){this.tabSize=6;this.compileDelay=1000;this.tagAC;this.isCompileDisabled;this.init=function(editor,doc){this.tabSize=editor.tabSize;this.rangeUtil=new RangeHandler(this.editor.editWindow,doc);var thisObj=this;var fx=function(e){var cancel=false;if(thisObj.onKeyDown){cancel=thisObj.onKeyDown(e);}

if(!cancel){thisObj.handleKeyDown(e);}

else 
{E.stop(e);}

}
;var settings={stop:false}
;E.keydown(this.doc.body,fx,settings);var thisObj=this;var fx=function(e){var cancel=false;if(thisObj.onKeyUp){cancel=thisObj.onKeyUp(e);}

if(!cancel){thisObj.handleKeyUp(e);}

else 
{E.stop(e);}

thisObj.registerChange(e);}
;var settings={stop:false}
;E.keyup(this.doc.body,fx,settings);var pasteHandler=new CodePasteHandler(this.doc,this.rangeUtil,this.editor);pasteHandler.init();}
;this.registerChange=function(event){if(!this.editor.compileDoc){return ;}

this.lastEditTime=new Date();var code=this.getKeyCode(event);if(code>=16&&code<=45){return ;}

this.setRecompile();}
;this.setRecompile=function(){if(this.compileTimer){return ;}

var thisObj=this;var fx=function(){thisObj.handleRecompile();}
;this.compileTimer=window.setInterval(fx,this.compileDelay);}
;this.handleRecompile=function(){var diff=new Date()-this.lastEditTime;if(diff<this.compileDelay){return ;}

window.clearInterval(this.compileTimer);this.compileTimer=null;this.recompile();}
;this.recompile=function(){var range=this.rangeUtil.getSelectedRange();var cursorPos=this.editor.getRangePos(range);var props={isTrim:false}
;var code=this.editor.getCode(props);this.editor.updateCode(code,cursorPos);var fx=this.editor.onRecompile;if(fx){fx(this.editor.compileDoc);}

}
;
this.handleKeyDown=function(event){var code=this.getKeyCode(event);var overrideFx=this.editor.keyDownFxs[code];if(overrideFx){overrideFx.call(this,event);return ;}

var fxName=this.keyDownFxs[code];var fx=this[fxName];if(fx){fx.call(this,event);}

}
;this.handleKeyUp=function(event){var code=this.getKeyCode(event);var overrideFx=this.editor.keyUpFxs[code];if(overrideFx){overrideFx.call(this,event);return ;}

var fxName=this.keyUpFxs[code];var fx=this[fxName];if(fx){fx.call(this,event);}

}
;this.deleteSelection=function(event){var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();var firstEl=getNearestAncestor(range.startContainer,"pre");var lastEl=getNearestAncestor(range.endContainer,"pre");var isMulti=(firstEl!=lastEl);range.deleteContents();rangeUtil.selectRange(range);if(isMulti){this.combineEls(firstEl,lastEl);}

}
;this.combineEls=function(el,nextEl){var newStart;while(nextEl.childNodes[0])
{var node=nextEl.removeChild(nextEl.childNodes[0]);if(!newStart){newStart=node;}

aE(el,node);}

nextEl.parentNode.removeChild(nextEl);var rangeUtil=this.rangeUtil;var range=rangeUtil.createRange(this.doc);range.selectNode(newStart);range.collapse(true);rangeUtil.selectRange(range);}
;this.onLeftArrowDown=function(e){var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();if(e.ctrlKey){this.editor.ensureSelInView();return ;}

var line=this.editor.getLine(range);range.setStart(line,0);var lineStart=range.toString();if(""==lineStart||""!=lineStart.trim()){return ;}

E.stop(e);var col=lineStart.length;var newCol=(Math.ceil(col/this.tabSize)-1)*this.tabSize;this.editor.goToCol(line,newCol);this.editor.ensureSelInView();}
;this.onRightArrowDown=function(e){if(e.ctrlKey){return ;}

var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();var line=this.editor.getLine(range);range.setStart(line,0);var lineStart=range.toString();if(""!=lineStart.trim()){return ;}

var col=lineStart.length;range.setEnd(line,line.childNodes.length);var newPos=(this.tabSize-col%this.tabSize)+col;var spaces=this.getLeadSpaceCount(range.toString());if(newPos>spaces){return ;}

E.stop(e);this.editor.goToCol(line,newPos);}
;this.onUpArrowDown=function(e){var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();var line=this.editor.getLine(range);var prevLine=line.previousElementSibling;if(!prevLine||prevLine.innerText!=""){return ;}

E.stop(e);range.selectNodeContents(prevLine);rangeUtil.selectRange(range);}
;this.onDownArrowDown=function(e){var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();var line=this.editor.getLine(range);var nextLine=line.nextElementSibling;if(!nextLine||nextLine.innerHTML!=""){return ;}

E.stop(e);range.selectNodeContents(nextLine);rangeUtil.selectRange(range);}
;
this.onEnterDown=function(e){this.deleteSelection(e);E.stop(e);var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();var elToSplit=this.editor.getLine(range);if(!elToSplit){return ;}

var splitPointEl=cE("b",null,this.doc);range.insertNode(splitPointEl);var splittingEl=splitPointEl.parentNode;var parent=elToSplit.parentNode;do
{var frontEl=splittingEl.cloneNode(false);var tempEl=splittingEl.childNodes[0];while(tempEl&&tempEl!=splitPointEl)
{var nextEl=tempEl.nextSibling;splittingEl.removeChild(tempEl);aE(frontEl,tempEl);tempEl=nextEl;}

var backEl=splittingEl.cloneNode(false);backEl.removeAttribute("fN");tempEl=tempEl.nextSibling;while(tempEl)
{var nextEl=tempEl.nextSibling;splittingEl.removeChild(tempEl);aE(backEl,tempEl);tempEl=nextEl;}

var next=splittingEl.parentNode;splitPointEl.parentNode.removeChild(splitPointEl);insertAfter(backEl,splittingEl);insertAfter(splitPointEl,splittingEl);insertAfter(frontEl,splittingEl);splittingEl.parentNode.removeChild(splittingEl);splittingEl=next;}

while(splittingEl!=parent);splitPointEl.parentNode.removeChild(splitPointEl);var indentNode=this.indent(backEl);if(indentNode){range.selectNodeContents(indentNode);range.collapse(false);rangeUtil.selectRange(range);}

else 
{range.selectNodeContents(backEl);range.collapse(true);rangeUtil.selectRange(range);}

this.editor.updateLineCount();}
;this.onEnterUp=function(e){if(!this.editor.getLine(this.rangeUtil.getSelectedRange())){return ;}

this.editor.ensureSelInView();this.editor.updateLineCount();}
;this.indent=function(lineEl){var prevLine=lineEl.previousElementSibling;if(!prevLine){return ;}

var rE=/^(\s+)/;var result=rE.exec(prevLine.innerText);if(!result){return null;}

var indentNode=this.doc.createTextNode(result[0]);lineEl.insertBefore(indentNode,lineEl.childNodes[0]);return indentNode;}
;this.getLeadSpaceCount=function(str){var rE=/^\s*/;var result=rE.exec(str);var str=result[0];return ('\n'==str.charAt(str.length-1))?str.length-1:str.length;}
;this.onTabDown=function(e){E.stop(e);var range=this.rangeUtil.getSelectedRange();var startEl=getNearestAncestor(range.startContainer,"pre");var endEl=getNearestAncestor(range.endContainer,"pre");var isMultiLine=(startEl!=endEl);if(e.shiftKey){if(isMultiLine){this.onTabDownWShiftMulti(e);}

else 
{this.onTabDownWShift(e);}

}

else 
{if(isMultiLine){this.onTabDownMulti(e);}

else 
{this.onTabDownOneLine(e);}

}

}
;this.onTabDownWShift=function(e){var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();var origRange=range.cloneRange();var lineEl=getNearestAncestor(range.commonAncestorContainer,"pre");lineEl.normalize();var node=lineEl.childNodes[0];var textNode=(node.nodeType==1)?node.childNodes[0]:node;var noOfSpaces=this.getLeadSpaceCount(textNode.nodeValue);var leftOver=noOfSpaces%this.tabSize;var toDel=(leftOver==0)?this.tabSize:leftOver;if(textNode&&textNode.nodeType==3){var newNode=textNode.splitText(toDel);textNode.parentNode.removeChild(textNode);}

rangeUtil.selectRange(origRange);}
;this.getCursorLine=function(range){return getNearestAncestor(range.commonAncestorContainer,"pre");}
;this.onTabDownWShiftMulti=function(e){var range=this.rangeUtil.getSelectedRange();var startEl=getNearestAncestor(range.startContainer,"pre");var endEl=getNearestAncestor(range.endContainer,"pre");if(range.endContainer==endEl&&range.endOffset==0){endEl=endEl.previousSibling;}

var temp=startEl;while(temp!=endEl)
{this.unindentLine(temp);temp=temp.nextSibling;}

this.unindentLine(endEl);this.selectLines(startEl,endEl);}
;this.selectLines=function(startLine,endLine){var range=this.rangeUtil.createRange();range.setStartBefore(startLine.childNodes[0]);range.setEndAfter(endLine.childNodes[endLine.childNodes.length-1]);this.rangeUtil.selectRange(range);}
;this.unindentLine=function(lineEl){lineEl.normalize();var noOfSpaces=this.getLeadSpaceCount(lineEl.innerText);var leftOver=noOfSpaces%this.tabSize;var spaces=leftOver||this.tabSize;var toDel=Math.min(spaces,noOfSpaces);var node=lineEl.childNodes[0];var textNode=(node.nodeType==1)?node.childNodes[0]:node;if(!textNode||textNode.nodeType!=3){return ;}

var newNode=textNode.splitText(toDel);textNode.parentNode.removeChild(textNode);}
;this.onTabDownMulti=function(e){var range=this.rangeUtil.getSelectedRange();var startEl=getNearestAncestor(range.startContainer,"pre");var endEl=getNearestAncestor(range.endContainer,"pre");if(range.endContainer==endEl&&range.endOffset==0){endEl=endEl.previousSibling;}

var temp=startEl;while(temp!=endEl)
{this.indentLine(temp);temp=temp.nextSibling;}

this.indentLine(endEl);this.selectLines(startEl,endEl);}
;this.indentLine=function(lineEl){lineEl.normalize();var noOfSpaces=this.getLeadSpaceCount(lineEl.innerText);var leftOver=noOfSpaces%this.tabSize;var spaces=this.tabSize-leftOver;var str="";for(var i=0;i<spaces;i++)
{str+=" ";}

var pre=cE("pre",null,this.doc);pre.style.display="inline";pre.innerText=str;var rangeUtil=this.rangeUtil;var range=rangeUtil.createRange();range.selectNodeContents(lineEl);range.collapse(true);range.insertNode(pre);removeNode(pre);range.detach();}
;this.onTabDownOneLine=function(e){var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();var lineEl=getNearestAncestor(range.commonAncestorContainer,"pre");lineEl.normalize();if(lineEl.innerText=="\n"){lineEl.innerHTML="";}

lineEl.normalize();var fullLineTest=rangeUtil.createRange();fullLineTest.selectNodeContents(lineEl);if(fullLineTest.toString()==range.toString()&&""!=range.toString()){this.indentLine(lineEl);lineEl.normalize();fullLineTest.selectNodeContents(lineEl);rangeUtil.selectRange(fullLineTest);return ;}

range.setStartBefore(lineEl);var cursorPos=range.toString().length;var noOfSpaces=this.getLeadSpaceCount(lineEl.innerText);if(noOfSpaces>cursorPos){this.editor.goToCol(lineEl,noOfSpaces);}

else 
{var leftOver=range.toString().length%this.tabSize;var spaces=this.tabSize-leftOver;var str="";for(var i=0;i<spaces;i++)
{str+=" ";}

range.collapse(false);var pre=cE("pre",null,this.doc);pre.style.display="inline";pre.innerText=str;range.insertNode(pre);range.setStartAfter(pre);rangeUtil.selectRange(range);removeNode(pre);}

range.detach();}
;this.onBackSpaceUp=function(){this.editor.updateLineCount();}
;this.onBackSpaceDown=function(e){var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();if(range.toString()!=""){return ;}

if(e.ctrlKey){return ;}

var line=this.editor.getLine(range);range.setStart(line,0);var lineStart=range.toString();if(lineStart.length==0){E.stop(e);var prevLine=line.previousElementSibling;if(prevLine.lastChild&&prevLine.lastChild.nodeType==1&&prevLine.lastChild.tagName=="BR"){prevLine.removeChild(prevLine.lastChild);}

var newRange=rangeUtil.createRange(this.doc);newRange.selectNodeContents(prevLine);newRange.collapse(false);var count=line.childNodes.length;for(var i=0;i<count;i++)
{var child=line.removeChild(line.childNodes[0]);aE(prevLine,child);}

line.parentElement.removeChild(line);rangeUtil.selectRange(newRange);}


}
;this.onDeleteUp=function(){this.editor.updateLineCount();}
;this.onCtrlSDown=function(e){if(!e.ctrlKey){return ;}

E.stop(e);this.editor.saveFx();}
;
this.onShowAC=function(){this.isCompileDisabled=true;}
;this.onHideAC=function(){this.isCompileDisabled=false;}
;

this.getKeyCode=function(event){return B.isIE()?event.keyCode:event.which;}
;this.keyDownFxs={13:"onEnterDown",8:"onBackSpaceDown",9:"onTabDown",83:"onCtrlSDown",37:"onLeftArrowDown",39:"onRightArrowDown",38:"onUpArrowDown",40:"onDownArrowDown"}
;this.keyUpFxs={13:"onEnterUp",8:"onBackSpaceUp",46:"onDeleteUp",188:"onLessThanUp",39:"onRightArrowUp",37:"onLeftArrowUp"}
;}


;function RangeHandler(window,doc){this.window=window;this.doc=doc;}
;RangeHandler.prototype=new RangeHandlerBase();function RangeHandlerBase(){this.createRange=function(){return this.doc.createRange();}
;this.selectRange=function(range){if(B.isIE()){range.select();}

else 
{var selection=this.window.getSelection();selection.removeAllRanges();selection.addRange(range);}

}
;
this.getSelectedRange=function(){var doc=this.doc;if(B.isIE()){var range=this.doc.selection.createRange();if(!RangeUtil.isRangeInDoc(range,this.doc)){range=RangeUtil.createRange(this.doc);}

return range;}

else 
{var selection=this.window.getSelection();var rangeCount=selection.rangeCount;if(rangeCount==0){var range=doc.createRange();if(doc.body.childNodes.length>0){var posEl=doc.body.childNodes[doc.body.childNodes.length-1];range.setStartAfter(posEl);range.collapse(true);}

selection.addRange(range);return range;}

else if(rangeCount==1){return selection.getRangeAt(0);}

else 
{alert("multiple range selection");return null;}

}

}
;
}


;;;function CodeEditor(){this.numberCol;this.codeEl;this.editWindow;this.doc;this.mc;this.initialCode;this.docClass;this.compileDoc;this.onRecompile;this.saveFx;this.lineHeight=16;this.scrollTop=0;this.code;this.rangeUtil;this.tabSize=6;this.keyDownFxs={}
;this.keyUpFxs={}
;this.build=function(parentEl,code){if(code){this.initialCode=code;}

else if(this.doc){this.initialCode=this.doc.getString();}

this.buildStructure(parentEl);this.rangeUtil=new RangeHandler(this.editWindow,this.doc);this.buildEditor(code);this.scroll();this.updateLineCount();this.setResizeEvent();}
;this.buildEditor=function(code){cursorPos={start:{line:0,col:0}
}
;this.updateCode(code,cursorPos);this.initialHtml=this.codeEl.innerHTML;this.initKeys();}
;this.updateFromDoc=function(){this.updateCode();
}
;this.updateCode=function(code,cursorPos){if(this.compileDoc){var doc=this.compileDoc;if(code){doc.compile(code);}

doc.write(this);doc.initCss(this.doc);}

else if(this.docClass){var cls=this.docClass;var doc=new cls();doc.compile(code);doc.write(this);doc.initCss(this.doc);this.compileDoc=doc;}

else 
{var lines=code.split("\n");for(var i=0;i<lines.length;i++)
{this.createLine(lines[i],i);}

}

this.placeeCursor(cursorPos);}
;this.placeeCursor=function(cursorPos){if(!cursorPos){return ;}

var rangeUtil=this.rangeUtil;var sRange=rangeUtil.createRange();this.placeRange(sRange,cursorPos.start);var eRange;if(cursorPos.end){var eRange=rangeUtil.createRange();this.placeRange(eRange,cursorPos.end);sRange.setEnd(eRange.startContainer,eRange.startOffset);}

rangeUtil.selectRange(sRange);}
;this.placeRange=function(range,pos){var lineEl=this.codeEl.children[pos.line];this.placeAtCol(range,lineEl,pos.col);}
;this.placeAtCol=function(range,lineEl,newPos){var textNode;var diff=newPos;for(var i=0;i<lineEl.childNodes.length;i++)
{var node=lineEl.childNodes[i];var nextNode=(node.nodeType==1)?node.childNodes[0]:node;if(nextNode){textNode=nextNode;}

else 
{break;}

if(diff<=textNode.length){break;}

else 
{diff-=textNode.length;}

}

if(!textNode){range.setStart(lineEl,0);}

else 
{range.setStart(textNode,diff);}

range.collapse(true);}
;this.goToCol=function(lineEl,newPos){var rangeUtil=this.rangeUtil;range=rangeUtil.createRange();this.placeAtCol(range,lineEl,newPos);rangeUtil.selectRange(range);}
;this.getRangePos=function(range){var posInfo={}
;var start=range.cloneRange();start.collapse(true);posInfo.start=this.getRangePointPos(start);if(!posInfo.start){return null;}

if(!range.collapsed){var end=range.cloneRange();end.collapse(false);posInfo.end=this.getRangePointPos(end);}

return posInfo;}
;this.getRangePointPos=function(range){var count=0;var lineEl=getNearestAncestor(range.startContainer,"pre");if(!lineEl){return null;}

var temp=lineEl;while(temp.previousElementSibling)
{count++;temp=temp.previousElementSibling;}

var test=this.rangeUtil.createRange();test.selectNodeContents(lineEl);test.setEnd(range.startContainer,range.startOffset);var col=test.toString().length;return {line:count,col:col}
;}
;this.initKeys=function(){var handler=new CodeKeyHandler(this);}
;this.getCode=function(props){debugger;if(!props){props={isTrim:true}
;}

var code="";var count=this.codeEl.children.length;debugger;for(var i=0;i<count-1;i++)
{var line=this.codeEl.children[i];code+=this.getLineOfCode(line,props)+"\n";}

var line=this.codeEl.children[i];code+=this.getLineOfCode(line,props);return code;}
;this.getLineOfCode=function(line,props){var cleaned=line.innerText.replace(/\n/g,"");return props.isTrim?(this.trimRight(cleaned)):(cleaned);}
;this.setKeyDown=function(keyCode,fx){this.keyDownFxs[keyCode]=fx;}
;this.setKeyUp=function(keyCode,fx){this.keyUpFxs[keyCode]=fx;}
;this.updateFromDoc=function(){this.compileDoc.write(this);this.updateLineCount();}
;this.getScrollTop=function(){return this.resizeEl.scrollTop;}
;this.trimRight=function(str){var ws=/\s/;var i=str.length;while(ws.test(str.charAt(--i))){}
;return str.slice(0,i+1);}
;this.hasChanged=function(){return (this.initialHtml!=this.codeEl.innerHTML);}
;this.createLine=function(lineText){var lineEl=cE("pre",this.codeEl);lineEl.className="line";lineEl.innerText=lineText||"\n";}
;this.getLine=function(range){return getNearestAncestor(range.startContainer,"pre");}
;this.setResizeEvent=function(){var thisObj=this;var fx=function(){thisObj.resize();}
;E.resize(fx);}
;this.resize=function(){var el=this.resizeEl;el.style.display="none";el.style.width="";el.style.width=el.parentNode.offsetWidth+"px";el.style.display="";}
;this.updateLineCount=function(){var holder=this.numberCol;var children=this.codeEl.children;var count=children.length;var currentLength=holder.children.length;var lineHeight=this.lineHeight;for(var i=currentLength;i<count;i++)
{var el=cE("div",holder);el.style.right="0px";el.style.position="absolute";el.style.top=lineHeight*i+"px";var span=cE("span",el);span.style.paddingRight="15px";span.innerHTML=i+1;}

for(var i=currentLength;i>count;i--)
{holder.removeChild(holder.children[holder.children.length-1]);}

this.lineCountEl.innerHTML=count;}
;this.scroll=function(){this.resizeEl.scrollTop=this.scrollTop;}
;this.buildStructure=function(parentEl){parentEl.innerHTML="<div><iframe frameborder='0'></iframe></div>";var div=parentEl.firstChild;div.style.height="100%";div.style.overflow="hidden";var frame=parentEl.firstChild.firstChild;frame.style.padding=0;frame.style.margin=0;frame.style.width="100%";frame.style.height="100%";frame.style.overflow="hidden";this.frame=frame;this.editWindow=frame.contentWindow;var doc=frame.contentWindow.document;doc.open();this.doc=doc;doc.write("<!DOCTYPE HTML>");doc.write("<html style=\"height:100%\"><head><style type=\"text/css\"></style>");doc.write("</head><body style=\"height:100%\">");doc.write("</body></html>");doc.close();this.initCss(doc);sA(doc.body,"spellcheck","false");var tBody=createTable(doc.body,"100%","100%");var tr=cE("tr",tBody);var td=cE("td",tr);td.style.height="100%";td.style.width="100%";var div=cE("div",td);div.style.height="100%";div.style.width=td.offsetWidth+"px";div.style.overflow="auto";this.resizeEl=div;var thisObj=this;var fx=function(){thisObj.repositionNos();}
;E.on(div,"scroll",fx);var mainArea=cE("div",div);mainArea.className="ahtmlEditorMainArea";this.mainArea=mainArea;var tr=cE("tr",tBody);var td=cE("td",tr);td.className="bottomInfoBar";this.buildInfoBar(td);this.buildMainArea(mainArea);}
;this.buildInfoBar=function(parentEl){var tBody=createTable(parentEl,"100%","100%");var tr=cE("tr",tBody);var td=cE("td",tr);td.className="infoBarLeft";var td=cE("td",tr);td.className="infoBarRight";var div=cE("div",td);var span=cE("span",div);this.lineCountEl=span;var span=cE("span",div);span.innerHTML=" Lines";var td=cE("td",tr);td.style.width="80px";var pIcon=cE("progress",td);this.pIcon=pIcon;pIcon.style.visibility="hidden";pIcon.style.width="40px";pIcon.style.height="12px";}
;this.showCompiling=function(){this.pIcon.style.visibility="";}
;this.showNotCompiling=function(){this.pIcon.style.visibility="hidden";}
;this.repositionNos=function(){var col=this.numberCol;col.style.left=this.resizeEl.scrollLeft+"px";}
;this.isSelectionInView=function(range){var line=this.getLine(range);var holder=this.resizeEl;return ((line.offsetTop+line.offsetHeight-holder.scrollTop)>holder.childNodes[0].offsetHeight)?false:true;}
;this.isSelectionInHorizView=function(range){if(range.startOffset*4<this.resizeEl.scrollLeft){this.resizeEl.scrollLeft=Math.max(0,this.resizeEl.scrollLeft-30);}

}
;this.ensureSelInView=function(){var before=document.body.scrollTop;var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();if(!this.isSelectionInView(range)){var rangeUtil=this.rangeUtil;var range=rangeUtil.getSelectedRange();var line=this.getLine(range);line.scrollIntoView(line);}

if(this.isSelectionInHorizView(range)){}

document.body.scrollTop=before;}
;this.buildMainArea=function(parentEl){var tBody=createTable(parentEl,"100%","100%");var table=tBody.parentNode;table.className="ce_mainArea";var tr=cE("tr",tBody);var td=cE("td",tr);td.vAlign="top";td.style.position="relative";var div=cE("div",td);div.style.position="absolute";div.style.left=0;div.style.top=0;div.style.width="50px";div.style.height="100%";div.style.color="#aaaaaa";div.style.backgroundColor="#eeeeee";div.style.borderRight="1px solid rgb(170, 170, 170)";this.numberCol=div;var div=cE("div",td);div.style.paddingLeft="53px";div.style.height="100%";div.style.outline="0";div.contentEditable="true";this.codeEl=div;}
;this.initCss=function(doc){var cls=new CssClass("html");cls.add("height","100%");cls.init(doc);var cls=new CssClass("body");cls.add("margin","0");cls.add("padding","0");cls.add("background-color","white");cls.add("height","100%");cls.add("font-size","13px");cls.add("font-family","tahoma,geneva,sans-serif");cls.init(doc);var cls=new CssClass("pre");cls.add("font-size","13px");cls.add("font-family","tahoma,geneva,sans-serif");cls.add("margin","0");cls.add("padding","0");cls.add("outline","0");cls.add("height",this.lineHeight+"px");cls.init(doc);var cls=new CssClass(".ahtmlEditorMainArea");cls.add("height","100%");cls.add("width","100%");cls.init(doc);var cls=new CssClass(".line");cls.add("min-height","16px");cls.init(doc);var cls=new CssClass(".bottomInfoBar");cls.add("border-top","1px solid #cccccc");cls.add("background-color","#eeeeee");cls.add("color","#777777");cls.add("font-size","12px");cls.add("font-family","arial");cls.add("height","20px");cls.init(doc);var cls=new CssClass(".infoBarLeft");cls.add("vertical-align","middle");cls.add("padding-left","10px");cls.init(doc);var cls=new CssClass(".infoBarRight");cls.add("vertical-align","middle");cls.add("width","200px");cls.init(doc);}
;}


;;;;;;var LiveCss=new LiveCssBase();function LiveCssBase(){this.mc=new MiniCache();this.styleSheets={}
;this.sheetIdToWrite;this.idToRealSheet={}
;
this.update=function(element,props,rangeName){if(rangeName){var rangeInfo=ResponsiveUtil.getRangeNameInfo(rangeName);if(rangeInfo.startSize!="xxs"){var r="xxs-"+rangeInfo.endSize;this.updateClass(element,props,r);}

}

this.updateClass(element,props,rangeName);}
;
this.deleteClassesForEl=function(element){var toDelete=[];var classes=CssUtil.getClasses(element);for(var i=0;i<classes.length;i++)
{var usedBy=gL("."+classes[i]);if(usedBy.length==1&&usedBy[0]==element){toDelete.push(classes[i]);}

}

var sheet=this.getStyleSheetForEl(element);for(var i=0;i<toDelete.length;i++)
{sheet.deleteClass(toDelete[i]);}

}
;this.appendStyleSheet=function(path,afterFx){StyleSheetUtil.appendStyleSheet(path,afterFx);this.idToRealSheet=null;}
;this.removeStyleSheet=function(path){StyleSheetUtil.removeStyleSheet(path);this.idToRealSheet=null;}
;this.sync=function(mc){for(var i in this.styleSheets)
{var sheet=this.styleSheets[i];sheet.sync(mc);}

}
;this.updateClass=function(element,props,rangeName){var sheet=LiveCss.getSheetToWriteForEl(element);sheet.update(element,props,rangeName);}
;this.setSheetToWrite=function(id){this.sheetIdToWrite=id;this.loadStyleSheet(id);}
;this.clearSheetToWrite=function(){this.sheetIdToWrite=null;}
;this.buildStyleDD=function(element,parentEl,propName,optionSet,width,optionsBoxWidth,optionsBoxHeight){var dd=new LiveCssDropdown(element,parentEl,propName,optionSet,width,optionsBoxWidth,optionsBoxHeight);return dd.build();}
;this.findFonts=function(){var fonts={}
;for(var i in this.idToRealSheet)
{var sheet=this.getStyleSheetById(i);if(!sheet){continue;}

someFonts=sheet.findFonts();for(var j in someFonts)
{fonts[j]=1;}

}

var result=[];for(var i in fonts)
{result.push(i);}

return result;}
;this.getStyleSheetById=function(id){var sheet=this.styleSheets[id];if(!sheet){var record=this.mc.getRecord("style_sheets",id)
if(!record){return null;}

var cssText=record.getField("style_sheet.text_css").getValue();sheet=this.styleSheets[id]=new LiveStyleSheet(id,cssText);}

return sheet;}
;this.getStyleSheetForEl=function(element){var moduleRec=this.getModuleForEl(element);var cssId=moduleRec.getField("style_sheet.id").getValue();var sheet=this.getStyleSheetById(cssId);sheet.classPrefix="m"+moduleRec.id+"_el";return sheet;}
;this.getSheetToWriteForEl=function(element){if(this.sheetIdToWrite){var moduleId=LivePage.findContainingModuleId(element);var cssId=this.sheetIdToWrite;var sheet=this.getStyleSheetById(cssId);sheet.classPrefix="m"+moduleId+"_el";return sheet;}

else 
{return this.getStyleSheetForEl(element);}

}
;this.getClassNameForEl=function(element){var sheet=this.getStyleSheetForEl(element);return sheet.getClassName(element);}
;this.clearSheet=function(id){delete(this.styleSheets[id]);this.clearRealSheets();}
;this.loadStyleSheet=function(id){this.mc.addRecordToLoad("style_sheets",id);this.mc.process();}
;this.loadModuleRec=function(moduleId,afterLoad){var rI=this.mc.addRecordToLoad("module",moduleId);rI.addField("style_sheet.*");this.mc.process(afterLoad);}
;this.getModuleForEl=function(element){var moduleId=LivePage.findContainingModuleId(element);var mRec=this.mc.getRecord("module",moduleId);if(mRec!=null&&mRec.getField("style_sheet.id").getValue()==0){this.mc.clearRecord(mRec.type,mRec.id);mRec=null;}

return mRec;}
;this.getIdFromHref=function(sheet){var href=sheet.href;if(!href){return 0;}

var before=href.lastIndexOf('/');var after=href.indexOf(".css");if(-1==before||-1==after){return 0;}

var id=parseInt(href.substring(before+1,after));if(isNaN(id)){return 0;}

return id;}
;this.clearRealSheets=function(){this.idToRealSheet=null;}
;
this.getRealSheet=function(id){if(this.idToRealSheet&&this.idToRealSheet[id]){return this.idToRealSheet[id]
}

this.indexRealSheets();return this.idToRealSheet[id]||null;
}
;this.indexRealSheets=function(){this.idToRealSheet={}
;var ids=[];var sS=document.styleSheets;for(var i=0;i<sS.length;i++)
{var sheet=sS[i];var id=this.getIdFromHref(sheet);if(!id){continue;}

if(!this.idToRealSheet[id]){this.idToRealSheet[id]=sheet;ids.push(id);}

}

return ids;}
;
this.init=function(){var styleIds=this.indexRealSheets();var moduleIds=LivePage.getAllModuleIds();var mc=this.mc;var getter=createLiveCssGetter("getter",mc,moduleIds,styleIds,null);var fx=function(){}
;mc.process(fx);}
;this.initialize=function(element,afterFx){var moduleRec=LiveCss.getModuleForEl(element);if(null==moduleRec){var moduleId=LivePage.findContainingModuleId(element);var thisObj=this;var afterLoad=function(){thisObj.indexRealSheets()
afterFx();}
;this.loadModuleRec(moduleId,afterLoad);}

else 
{afterFx();}

}
;}



function FloatingEditToolBar(){this.popup;this.build=function(){this.initCss();var popup=new Popup();popup.setAsAnchor(document.body,"upperRight");popup.disableBg=false;popup.disableEsc=true;popup.position="fixed";popup.width=210;this.popup=popup;var cA=cE("div",popup.build());cA.id="etb_optionHolder";this.buildTopBar(cA);var div=cE("div",cA);div.style.padding="4px";this.buildIcons(div);popup.align();var reposition=function(){var posEl=CssUtil.getElementsByClassName("a_popupAnchor")[0];var top=posEl.offsetTop;var left=posEl.offsetLeft;var width=posEl.offsetWidth;var docWidth=document.body.offsetWidth;if(left+width>docWidth){left=docWidth-width;}

posEl.style.top=top+"px";posEl.style.left=left+"px";}
;E.add(window,"resize",reposition);}
;this.buildIcons=function(parentEl){var tbody=createTable(parentEl);var saveFx=function(){showProgressIcon("saving");LivePage.save(hideProgressIcon);}
;var tr=cE("tr",tbody);var saveAndCont=function(){showProgressIcon("saving");LivePage.handleClick();LivePage.save(hideProgressIcon);}
;var td=cE("td",tr);this.buildOption(td,"save.png",saveAndCont,"Save<br>(Ctrl + S)");var saveAndExit=function(){showProgressIcon("saving");LivePage.handleClick();var afterSave=function(){LivePage.goToReadOnly();}

LivePage.save(afterSave);}
;var td=cE("td",tr);this.buildOption(td,"save-exit.png",saveAndExit,"Save & Exit<br>(Ctrl + shift + S)");var exitFx=function(){LivePage.goToReadOnly();}
;var td=cE("td",tr);this.buildOption(td,"etb_exit_icon.png",exitFx,"Exit<br>(Ctrl + Shift + E)");var td=cE("td",tr);this.buildLaunchSaButton(td);}
;this.buildLaunchSaButton=function(parentEl){var saButton=cE("div",parentEl);saButton.className="etb_saLaunchButton";var img=cE("img",saButton);img.src="/upload/custom_screens/html5/livepage/etb_sa_icon.png";var span=cE("span",saButton);span.innerHTML="SITE ARCHITECT";var launchSa=function(){var url="http://"+window.location.host+"/site-architect?pageId="+getMasterCache().values.mainPage;window.open(url,"sa","");LivePage.goToReadOnly();}
;E.click(saButton,launchSa);}
;this.buildOption=function(parentEl,imgName,onClick,tip){var holder=cE("div",parentEl);holder.className="etb_button";var img=cE("img",holder);img.src="/upload/custom_screens/html5/livepage/"+imgName;E.click(holder,onClick);this.attachHelpTip(holder,tip);}
;this.buildTopBar=function(parentEl){var dragger=cE("div",parentEl);dragger.className="etb_dragBar";var popup=this.popup;popup.makeDraggable(dragger);}
;this.attachHelpTip=function(element,helpTip){var popup=new HoverPopup(element);popup.alignment="belowCenter";popup.showDelay=500;popup.position="fixed";popup.onShow=function(parentEl){var holder=cE("div",parentEl);holder.style.marginTop="4px";var div=cE("div",holder);div.className="lp_saQuickInfoBox";div.innerHTML=helpTip;}
;popup.init();}
;this.initCss=function(){var cssClass=new CssClass("#etb_optionHolder");cssClass.add("background","#e3e2e3");cssClass.add("-webkit-box-shadow","3px 3px 16px rgba(0, 0, 0, 0.5)");cssClass.add("-moz-box-shadow","3px 3px 16px rgba(0, 0, 0, 0.5)");cssClass.add("box-shadow","3px 3px 16px rgba(0, 0, 0, 0.5)");cssClass.add("font","12px arial");cssClass.add("border","1px solid #4e4e4e");cssClass.init();var cssClass=new CssClass("#etb_optionHolder *");cssClass.add("user-select","none");cssClass.add("-webkit-user-select","none");cssClass.add("-moz-user-select","-moz-none");cssClass.init();var cls=new CssClass("#etb_optionHolder td");cls.add("padding","0px 2px 0px 2px");cls.init();var cC=new CssClass(".etb_button");cC.add("background","white");cC.add("font-size","10px");cC.add("border","1px solid white");cC.add("border-radius","3px");cC.add("text-align","left");cC.add("color","black");cC.add("padding","3px");cC.add("cursor","pointer");cC.add("white-space","nowrap");cC.init();var cC=new CssClass(".etb_button img");cC.add("position","relative");cC.add("top","2px");cC.init();var cls=new CssClass(".etb_button:hover");cls.add("background","#f5f5f5");cls.add("border","1px solid #999999");cls.init();var cC=new CssClass(".etb_saLaunchButton");cC.add("font-size","10px");cC.add("text-align","center");cC.add("color","#666666");cC.add("padding","5px");cC.add("cursor","pointer");cC.add("white-space","nowrap");cC.init();var cls=new CssClass(".etb_saLaunchButton:hover");cls.add("color","black");cls.init();var cls=new CssClass(".etb_saLaunchButton span");cls.add("padding-left","4px");cls.add("position","relative");cls.add("top","-2px");cls.init();var cC=new CssClass(".etb_dragBar");cC.add("height","15px");cC.add("background","-webkit-gradient(linear, left top, left bottom, from(#7c7b7c), to(#4e4e4e))");cC.add("background","-moz-linear-gradient(top, #8d8d8d, #4f4f4f)");cC.add("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr='#8d8d8d, endColorstr='#4f4f4f)");cC.init();}
;}


var IFrameFramer=new IFrameFramerBase()
function IFrameFramerBase(){this.iframeRegistry={}
;this.init=function(){var css=new CssClass(".iframe-border");css.add("border","10px solid red");css.init();var tO;var thisObj=this;var frameFx=function(){thisObj.frameIframes();clearTimeout(tO);}
;tO=window.setTimeout(frameFx,5000);this.attachResize();}
;this.attachResize=function(){var thisObj=this;var resizeFx=function(){var iframes=thisObj.iframeRegistry;for(var frameId in iframes)
{var iframeInfo=iframes[frameId];var iFrame=iframeInfo.iframe;var cover=iframeInfo.cover;thisObj.positionCover(iFrame,cover);}

thisObj.frameIframes();}
;E.resize(resizeFx);}
;this.frameIframes=function(){var iFrames=document.getElementsByTagName("iframe");for(var i=0;i<iFrames.length;i++)
{var iFrame=iFrames[i];if(LivePage.isBeforeEOF(iFrame)){this.frameIframe(iFrame);}

}

}
;this.frameIframe=function(iFrame){var pE=iFrame.parentElement;var cover=iFrame.cover||iE("div",pE,0);cover.className="a_skip";iFrame.cover=cover;this.positionCover(iFrame,cover);var rCLick=function(e){var coordinate=getEventCoord(e);var x=coordinate.x;var y=coordinate.y;RightClickPageOptions.handleRightClick(iFrame,x,y)
}
;E.add(cover,"contextmenu",rCLick);var tempId=gA(iFrame,"a_meta_frameId");if(null==tempId){tempId=A.createTempId();sA(iFrame,"a_meta_frameId",tempId);}

this.iframeRegistry[tempId]={cover:cover,iframe:iFrame}
;}
;this.positionCover=function(iFrame,cover){cover.style.position="absolute";cover.style.top=0;cover.style.left=0;cover.style.width=iFrame.offsetWidth+"px";cover.style.height=iFrame.offsetHeight+"px";}
;}
;
;;
function LivePageInitializer(){this.init=function(){this.buildEditFloatBar();this.initKeyPressSave();this.cancelBckSpaceBrowsing();this.initUnsavedAlert();this.addTemplatesToLoad();this.initUserSettings();IFrameFramer.init();}
;this.initUserSettings=function(){UserSettingsMgr.addSettingsToLoad("lp_settings");UserSettingsMgr.loadSettings();}
;
this.addTemplatesToLoad=function(){var mc=getMasterCache();mc.addTemplateToLoad("style_sheets");mc.addTemplateToLoad("css_transition_state");}
;
this.initKeyPressSave=function(){var keyPressSave=function(e){var keyCode=KeyHandler.getKeyCode(e);if(e.ctrlKey){var isSKey=(keyCode==83||keyCode==115);if(isSKey&&null!=EditUtil.editableElement){LivePage.setElementToSave(EditUtil.editableElement);}

if(e.shiftKey&&isSKey){showProgressIcon("saving...");var afterSave=function(){LivePage.goToReadOnly();}

LivePage.save(afterSave);E.stop(e);}

else if(isSKey){showProgressIcon("saving...");LivePage.save(hideProgressIcon);E.stop(e);}

else if(keyCode==82||keyCode==114){window.location.reload();E.stop(e);}

else if(e.shiftKey&&keyCode==69){if(confirm("Are you sure you want to leave without saving your changes?")){LivePage.goToReadOnly();}

E.stop(e);}

}

}
;E.add(document.body,"keydown",keyPressSave);}
;
this.buildEditFloatBar=function(){var popup=new FloatingEditToolBar();popup.build();}
;
this.cancelBckSpaceBrowsing=function(){var backSpaceCancel=function(e){var keyCode=KeyHandler.getKeyCode(e);if(keyCode==8&&e.srcElement.tagName=="BODY"){E.stop(e);}

}
;E.add(document.body,"keydown",backSpaceCancel);}
;this.initUnsavedAlert=function(){var unloadAlert=function(event){if(LivePage.hasChanged()){return "Your page has changed, please select 'do not leave page' and save your changes."
}

}
;E.add(window,"beforeunload",unloadAlert);}
;}
;

var GridManager=new GridManagerBase();function GridManagerBase(){this.grids={}
;this.counter=0;this.disableCloseEvent=false;this.isCloseable=function(){return !this.disableCloseEvent;}
;this.disableClose=function(){this.disableCloseEvent=true;}
;this.enableClose=function(){this.disableCloseEvent=false;}
;this.closeAllGrids=function(){for(var i in this.grids)
{this.grids[i].close();}

this.grids={}
;}
;this.getInnerItemEl=function(itemEl){var el=itemEl.children[0];if(!el){return null;}

return el.children[0];}
;this.register=function(grid){var id=this.counter++;this.grids[id]=grid;return id;}
;this.hideAllGrids=function(){var grids=this.grids;for(var gridId in grids)
{grids[gridId].hideFramers();}

}
;this.reframeAllGrids=function(){var grids=this.grids;for(var gridId in grids)
{grids[gridId].reframe();}

}
;}



var GridCss=new GridCssBase();function GridCssBase(){this.initCss=function(){var borderColor="#666666";var cls=new CssClass(".lp_lrFramerColumnTop,.lp_lrFramerHiddenColumnTop");cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("background-color","#6FA8DC");cls.add("height","5px");cls.init();var cls=new CssClass(".lp_lrFramerHiddenColumnTop");cls.add("border","1px solid "+borderColor);cls.add("background-color","white");cls.init();var cls=new CssClass(".lp_lrFramerColumnBottom,.lp_lrFramerHiddenColumnBottom");cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("background-color","#6FA8DC");cls.add("height","5px");cls.add("cursor","ns-resize");cls.init();var cls=new CssClass(".lp_lrFramerHiddenColumnBottom");cls.add("border","1px solid "+borderColor);cls.add("background-color","white");cls.init();var cls=new CssClass(".lp_lrFramerColumnLeft,.lp_lrFramerHiddenColumnLeft");cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("border-bottom","0");cls.add("border-top","0");cls.add("background-color","#6FA8DC");cls.add("width","5px");cls.init();var cls=new CssClass(".lp_lrFramerHiddenColumnLeft");cls.add("border","1px solid "+borderColor);cls.add("background-color","white");cls.init();var cls=new CssClass(".lp_lrFramerColumnRight,.lp_lrFramerHiddenColumnRight");cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("border-bottom","0");cls.add("border-top","0");cls.add("background-color","#6FA8DC");cls.add("cursor","ew-resize");cls.add("width","5px");cls.init();var cls=new CssClass(".lp_lrFramerHiddenColumnRight");cls.add("border","1px solid "+borderColor);cls.add("background-color","white");cls.init();var cls=new CssClass(".mg-tile-frame-iconRow,.mg-tile-frame-hidden-iconRow");cls.add("border","1px solid "+borderColor);cls.add("border-left","0");cls.add("border-top","0");cls.add("background-color","#6FA8DC");cls.add("height","22px");cls.add("width","14px");cls.add("z-index","40");cls.add("position","relative");cls.add("left","3px");cls.add("-moz-border-bottom-right-radius","5px");cls.add("border-bottom-right-radius","5px");cls.init();var cls=new CssClass(".mg-tile-frame-hidden-iconRow");cls.add("border","1px solid "+borderColor);cls.add("background-color","white");cls.init();}
;this.initCss();}


function GridDragger(grid){this.grid=grid;this.startNSDrag=function(e,itemEl,framer){if(this.dragInfo){return ;}

this.grid.disableCloseEvent=true;this.grid.declassifyItem(itemEl);itemEl.style.zIndex=this.grid.getTopZIndex();var dragInfo={}
;this.dragInfo=dragInfo;dragInfo.startY=event.clientY;dragInfo.itemEl=itemEl;dragInfo.origHeight=this.grid.getHeightVal(itemEl.offsetHeight);dragInfo.columnCount=Math.round(dragInfo.origHeight/this.grid.getBoxHeightValue());dragInfo.elements=this.grid.getSortedEls();var boxEl=itemEl.children[0].children[0];var innerEl=boxEl.children[0];if(innerEl){dragInfo.isFullHeight=(boxEl.offsetHeight==innerEl.offsetHeight);}

document.body.style.cursor="move";this.grid.hideFramers(framer);dragInfo.resizeFramer=framer;var thisObj=this;var moveFx=function(e){thisObj.resizeHeight(e);}
;E.add(document.body,"mousemove",moveFx);dragInfo.moveFx=moveFx;var upFx=function(e){thisObj.finishDrag();}
;E.add(document.body,"mouseup",upFx);dragInfo.upFx=upFx;}
;this.startEWDrag=function(e,itemEl,framer){if(this.dragInfo){return ;}

this.grid.declassifyItem(itemEl);itemEl.style.zIndex=this.grid.getTopZIndex();var dragInfo={}
;this.dragInfo=dragInfo;dragInfo.startX=event.clientX;dragInfo.itemEl=itemEl;dragInfo.origWidth=this.grid.getWidthVal(itemEl.offsetWidth);dragInfo.columnCount=Math.round(dragInfo.origWidth/this.grid.getBoxWidthValue());dragInfo.elements=this.grid.getSortedEls();document.body.style.cursor="move";this.grid.hideFramers(framer);dragInfo.resizeFramer=framer;var thisObj=this;var moveFx=function(e){thisObj.resizeWidth(e);}
;E.add(document.body,"mousemove",moveFx);dragInfo.moveFx=moveFx;var upFx=function(e){thisObj.finishDrag();}
;E.add(document.body,"mouseup",upFx);dragInfo.upFx=upFx;}
;this.resizeWidth=function(event){var dragInfo=this.dragInfo;if(!dragInfo){this.removeEvents();return ;}

var impliedWidth=dragInfo.origWidth+this.grid.getWidthVal(event.clientX-dragInfo.startX);var columnCount=Math.round(impliedWidth/this.grid.getBoxWidthValue());if((dragInfo.columnCount==columnCount)||(0>=columnCount)){return ;}

var itemEl=dragInfo.itemEl;itemEl.style.width=this.grid.getDimValue(columnCount*this.grid.getBoxWidthValue(),this.grid.getBoxWidthUnit());dragInfo.columnCount=columnCount;dragInfo.resizeFramer.reframe();}
;this.adjustGridWidth=function(){if("px"!=this.grid.getBoxWidthUnit()){return ;}

var neededWidth=0;var gridEl=this.grid.gridEl;for(var i=0;i<gridEl.children.length;i++)
{var itemEl=gridEl.children[i];var itemRight=itemEl.offsetLeft+itemEl.offsetWidth;neededWidth=Math.max(neededWidth,itemRight);}

var r=this.grid.getCurrentRangeName();LiveCss.update(this.grid.gridEl,[{name:"width",value:neededWidth+"px"}
],r);
}
;this.adjustGridHeight=function(){if("px"!=this.grid.getBoxHeightUnit()){return ;}

var neededHeight=0;var gridEl=this.grid.gridEl;for(var i=0;i<gridEl.children.length;i++)
{var itemEl=gridEl.children[i];var itemBottom=CssUtil.pixelToInt(CssUtil.getStyle(itemEl,"top"))+CssUtil.pixelToInt(CssUtil.getStyle(itemEl,"height"));neededHeight=Math.max(neededHeight,itemBottom);}

var r=this.grid.getCurrentRangeName();LiveCss.update(this.grid.gridEl,[{name:"height",value:"100%"}
],r);var currentHeight=CssUtil.pixelToInt(CssUtil.getStyle(gridEl,"height"));if(neededHeight>currentHeight){LiveCss.update(this.grid.gridEl,[{name:"height",value:neededHeight+"px"}
],r);}

}
;this.resizeHeight=function(event){var dragInfo=this.dragInfo;var impliedHeight=dragInfo.origHeight+this.grid.getHeightVal(event.clientY-dragInfo.startY);var rowCount=Math.round(impliedHeight/this.grid.getBoxHeightValue());if((dragInfo.rowCount==rowCount)||(0>=rowCount)){return ;}

dragInfo.itemEl.style.height=this.grid.getDimValue(rowCount*this.grid.getBoxHeightValue(),this.grid.getBoxHeightUnit());dragInfo.rowCount=rowCount;dragInfo.resizeFramer.reframe();}
;this.removeEvents=function(){E.remove(document.body,"mousemove",this.dragInfo.moveFx);E.remove(document.body,"mouseup",this.dragInfo.upFx);document.body.style.cursor="";}
;this.finishDrag=function(){this.removeEvents();var itemEl=this.dragInfo.itemEl;itemEl.style.zIndex=this.grid.getTopZIndex();this.grid.redoZIndex();this.adjustGridWidth();this.adjustGridHeight();if(this.dragInfo.isFullHeight){var boxEl=itemEl.children[0].children[0];var innerEl=boxEl.children[0];if(CssUtil.elHasClass(innerEl,"a-grid")){LiveCss.update(innerEl,[{name:"height",value:boxEl.offsetHeight+"px"}
],this.grid.getCurrentRangeName());}

}

var rangeName=this.grid.getCurrentRangeName();this.grid.classifyItem(itemEl,rangeName);this.vScroll=document.body.offsetHeight<document.body.scrollHeight;this.grid.reframe(itemEl);var thisObj=this;var fx=function(){if(thisObj.vSrcoll!=(document.body.offsetHeight<document.body.scrollHeight)){thisObj.grid.reframe(itemEl);}

}
;window.setTimeout(fx,50);this.dragInfo=null;}
;this.attachMoveDrag=function(framer){var cover=framer.getCoverEl();cover.style.cursor="move";var el=framer.element;var thisObj=this;DragUtil.getYOffset=function(dragEl){return dragEl.offsetHeight/2;}
;var createDragElFx=function(){return null;}
;var onDragStart=function(e){thisObj.onStartMoveDrag(e,el);}
;var onDragEnd=function(){thisObj.finishMoveDrag();}
;var onDrag=function(e){thisObj.onMoveDrag(e);}
;var onClickNoDrag=function(e){thisObj.grid.destroy();}
;var props={}
;props.element=framer.element;props.triggerEl=cover;props.onDragStart=onDragStart;props.onDragEnd=onDragEnd;props.createDragElFx=createDragElFx;props.onDrag=onDrag;props.onClickNoDrag=onClickNoDrag;E.makeDraggable(framer.element,props);}
;this.onStartMoveDrag=function(e,itemEl){if(this.dragInfo){return ;}

var dragInfo={}
;this.dragInfo=dragInfo;dragInfo.itemEl=itemEl;var coord=this.grid.getGridCoord(e);dragInfo.prevX=coord.x;dragInfo.prevY=coord.y;this.grid.declassifyItem(itemEl);itemEl.style.zIndex=this.grid.getTopZIndex();var item=this.grid.readItem(itemEl);dragInfo.offsetLeft=coord.x-item.left;dragInfo.offsetTop=coord.y-item.top;this.grid.hideFramers();}
;this.onMoveDrag=function(e){var coord=this.grid.getGridCoord(e);var dragInfo=this.dragInfo;if(dragInfo.prevX==coord.x&&dragInfo.prevY==coord.y){return ;}

dragInfo.prevX=coord.x;dragInfo.prevY=coord.y;var itemEl=dragInfo.itemEl;var left=Math.max(0,coord.x-dragInfo.offsetLeft);var top=Math.max(0,coord.y-dragInfo.offsetTop);itemEl.style.left=this.grid.getDimValue(this.grid.getBoxWidthValue()*left,this.grid.getBoxWidthUnit());itemEl.style.top=this.grid.getDimValue(this.grid.getBoxHeightValue()*top,this.grid.getBoxHeightUnit());DragHandler.frameAsDragging(itemEl);}
;this.finishMoveDrag=function(){document.body.style.cursor="";LivePage.setElementToSave(this.dragInfo.itemEl);var itemEl=this.dragInfo.itemEl;itemEl.style.zIndex=this.grid.getTopZIndex();this.grid.redoZIndex();this.adjustGridWidth();this.adjustGridHeight();var rangeName=this.grid.getCurrentRangeName();this.grid.classifyItem(itemEl,rangeName);this.vScroll=document.body.offsetHeight<document.body.scrollHeight;this.grid.reframe(itemEl);var thisObj=this;var fx=function(){if(thisObj.vSrcoll!=(document.body.offsetHeight<document.body.scrollHeight)){thisObj.grid.reframe(itemEl);}

}
;window.setTimeout(fx,50);DragHandler.hideDragFrame();this.dragInfo=null;}
;}



function serializeToJson(myObj){if(typeof(myObj)!='object'){return "\""+myObj+"\"";}

if(myObj==null){return "null";}

var json="";if(myObj.length&&myObj[0]){json+="[";for(var i=0;i<myObj.length;i++)
{if(i!=0){json+=",";}

json+=serializeToJson(myObj[i]);}

json+="]";}

else 
{json+="{";var counter=0;for(var i in myObj)
{if(typeof(myObj[i])=='function'){continue;}

if(counter!=0){json+=",";}

json+="\""+i+"\":"+serializeToJson(myObj[i]);counter++;}

json+="}";}

return json;}

function deserializeJson(json){var command="var obj = "+json;eval(command);return obj;}

;function GridInserter(){}

GridInserter.prototype=new GridInserterBase();function GridInserterBase(){this.parentEl;this.popup;this.build=function(targetEl,x,y){var moduleRec=LiveCss.getModuleForEl(targetEl);if(null==moduleRec||moduleRec.getField("style_sheet.id").getValue()==0){var moduleId=LivePage.findContainingModuleId(targetEl);var thisObj=this;var afterLoad=function(){LiveCss.indexRealSheets();thisObj.finishBuild(targetEl,x,y);}
;LiveCss.loadModuleRec(moduleId,afterLoad);}

else 
{this.finishBuild(targetEl,x,y);}

}
;this.finishBuild=function(targetEl,x,y){var parentEl=(CssUtil.elHasClass(targetEl.parentElement,"a-grid"))?GridManager.getInnerItemEl(targetEl):targetEl;var gridEl=this.insert(parentEl);GridEditMenuPopup.setGridEl(gridEl);if(!GridEditMenuPopup.isShowing()){GridEditMenuPopup.show(x,y);}

hideProgressIcon();}
;this.insert=function(parentEl){var id=A.createTempId();var gridEl=cE("div");gridEl.className="a-grid";gridEl.style.border="1px solid transparent";gridEl.id=id;var isInner=(parentEl.tagName!="BODY");if(!isInner){var eof=LivePage.findEndOfFileNode();parentEl.insertBefore(gridEl,eof);}

else 
{aE(parentEl,gridEl);}

var height=(parentEl.tagName=="BODY")?"100%":parentEl.offsetHeight+"px";var props=[{name:"width",value:"100%"}
,{name:"height",value:height}
];if(isInner){props.push({name:"text-align",value:"left"}
);props.push({name:"vertical-align",value:"top"}
);}

var mainSheet=LiveCss.getStyleSheetForEl(gridEl);var currentSheet=LiveCss.getSheetToWriteForEl(gridEl);mainSheet.update(gridEl,props);if(currentSheet!=mainSheet){currentSheet.update(gridEl,props);}

var params={}
;params.command="MondrianEditor";params.ranges=this.getDefaultRanges();ActionHandler.addAction(gridEl,params);var fx=function(){gridEl.style.border="";}

setTimeout(fx,0);return gridEl;}
;this.getDefaultRanges=function(){return {"xl":{"squareWidth":"1.042%","squareHeight":"10px"}
,
"l":{"squareWidth":"1.042%","squareHeight":"10px"}
,
"m":{"squareWidth":"1.042%","squareHeight":"10px"}
,
"s":{"squareWidth":"1.042%","squareHeight":"10px"}
,
"xs":{"squareWidth":"1.042%","squareHeight":"10px"}
,
"xxs":{"squareWidth":"1.042%","squareHeight":"10px"}
}
;
}
;this.initCss=function(){var cls=new CssClass(".mg-settingsTabOff");cls.add("font-weight","bold");cls.add("background-color","#ffffff");cls.add("color","#666666");cls.add("font-size","14px");cls.add("padding","5px 12px");cls.add("border","1px solid #385774");cls.add("border-bottom","0");cls.init();var cls=new CssClass(".mg-settingsTabOn");cls.add("font-weight","bold");cls.add("color","#c2c4c6");cls.add("color","white");cls.add("background-color","#385774");cls.add("padding","5px 12px");cls.add("font-size","14px");cls.init();var cls=new CssClass(".mg-settingsTabSpacing");cls.add("width","2px");cls.init();}
;this.initCss();}



function GridFramer(gridEl,grid){this.gridEl=gridEl;this.grid=grid;}

GridFramer.prototype=new GridFramerBase();function GridFramerBase(){this.framer;this.resizeFx;this.depth;this.colors=[{border:"#4C1130",bg:"#D5A6BD"}
,{border:"#4C1130",bg:"#D5A6BD"}
];this.frame=function(){var depth=this.findDepth();var framer=new Framer("mg-grid-frame-top"+depth,"mg-grid-frame-right"+depth,"mg-grid-frame-bottom"+depth,"mg-grid-frame-left"+depth);framer.staggerDrawing=true;framer.paddingLeft=-5;framer.paddingRight=-5;framer.paddingTop=-5;framer.paddingBottom=-5;framer.doHideOnOut=false;framer.maxOpacity=".9";framer.frame(this.gridEl);this.framer=framer;
this.attachResize();this.initCss();
}
;this.startEWDrag=function(e,framer){if(framer.right!=e.target){return ;}

var gridEl=this.gridEl;var dragInfo={}
;this.dragInfo=dragInfo;dragInfo.startX=event.clientX;dragInfo.origWidth=gridEl.offsetWidth;document.body.style.cursor="move";dragInfo.resizeFramer=framer;var thisObj=this;var moveFx=function(e){thisObj.resizeWidth(e);}
;E.add(document.body,"mousemove",moveFx);dragInfo.moveFx=moveFx;var upFx=function(e){thisObj.finishDrag();}
;E.add(document.body,"mouseup",upFx);dragInfo.upFx=upFx;}
;this.startNSDrag=function(e,itemEl,framer){var gridEl=this.gridEl;var dragInfo={}
;this.dragInfo=dragInfo;dragInfo.startY=event.clientY;dragInfo.origHeight=this.gridEl.offsetHeight;document.body.style.cursor="move";var thisObj=this;var moveFx=function(e){thisObj.resizeHeight(e);}
;E.add(document.body,"mousemove",moveFx);dragInfo.moveFx=moveFx;var upFx=function(e){thisObj.finishDrag();}
;E.add(document.body,"mouseup",upFx);dragInfo.upFx=upFx;}
;this.finishDrag=function(){E.remove(document.body,"mousemove",this.dragInfo.moveFx);E.remove(document.body,"mouseup",this.dragInfo.upFx);document.body.style.cursor="";LiveCss.update(this.gridEl,[{name:"width",value:this.gridEl.offsetWidth+"px"}
,{name:"height",value:this.gridEl.offsetHeight+"px"}
],this.grid.getCurrentRangeName());this.gridEl.style.width="";this.gridEl.style.height="";this.grid.syncMC();LivePage.setElementToSave(this.gridEl);if(this.grid){this.grid.reframe();}

}
;this.resizeWidth=function(event){var dragInfo=this.dragInfo;var impliedWidth=dragInfo.origWidth+(event.clientX-dragInfo.startX);this.gridEl.style.width=impliedWidth+"px";this.framer.reframe();}
;this.resizeHeight=function(event){var dragInfo=this.dragInfo;var impliedHeight=dragInfo.origHeight+(event.clientY-dragInfo.startY);this.gridEl.style.height=impliedHeight+"px";this.framer.reframe();}
;this.reframe=function(){this.framer.reframe();}
;this.initCss=function(){var i=this.depth;var colors=this.colors[i];if(null==colors){colors=this.colors[0];}

this.createClasses(i,colors.border,colors.bg);}
;this.findDepth=function(){var depth=0;var gridEl=getAncesterWClass(this.gridEl.parentNode,"a-grid");while(gridEl)
{depth++;gridEl=getAncesterWClass(gridEl.parentNode,"a-grid");}

this.depth=depth;return depth;}
;this.attachResize=function(){var thisObj=this;this.resizeFx=function(){thisObj.framer.reframe(true);}
;E.resize(this.resizeFx);}
;this.launchSettingPopup=function(){showProgressIcon("Loading");this.grid.hideFramers();var thisObj=this;var afterFx=function(){hideProgressIcon();var popup=new GridSettingsPopup();popup.grid=thisObj.grid;popup.gridFramer=thisObj;popup.build(thisObj.gridEl);popup.closeFx=function(){thisObj.reframe();}
;}
;sl_loadScript('/0/le8763_0.js',afterFx);afterFx;}
;this.destroy=function(){if(this.framer){this.framer.destroy();}

this.framer=null;E.remove(window,"resize",this.resizeFx);}
;
this.createClasses=function(suffix,borderColor,frameColor){var cls=new CssClass(".mg-grid-frame-iconRow"+suffix);cls.add("border","1px solid "+borderColor);cls.add("border-right","0");cls.add("border-top","0");cls.add("background-color",frameColor);cls.add("height","22px");cls.add("width","14px");cls.add("z-index","40");cls.add("position","relative");cls.add("left","-14px");cls.add("-moz-border-bottom-left-radius","5px");cls.add("border-bottom-left-radius","5px");cls.init();var cls=new CssClass(".mg-grid-frame-top"+suffix);cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("background-color",frameColor);cls.add("height","5px");cls.init();var cls=new CssClass(".mg-grid-frame-bottom"+suffix);cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("background-color",frameColor);cls.add("height","5px");cls.init();var cls=new CssClass(".mg-grid-frame-left"+suffix);cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("border-bottom","0");cls.add("border-top","0");cls.add("background-color",frameColor);cls.add("width","5px");cls.init();var cls=new CssClass(".mg-grid-frame-right"+suffix);cls.add("-webkit-transition","opacity .2s linear 0");cls.add("transition","opacity .2s linear 0");cls.add("border","1px solid "+borderColor);cls.add("border-bottom","0");cls.add("border-top","0");cls.add("background-color",frameColor);cls.add("width","5px");cls.init();}
;}


function TileIcon(itemEl){this.itemEl=itemEl;this.grid;this.build=function(parentEl){var isHidden=LivePage.isElHidden(this.itemEl);var row=cE("div",parentEl);row.className=isHidden?"mg-tile-frame-hidden-iconRow":"mg-tile-frame-iconRow";var iIcon=cE("div",row);iIcon.style.position="absolute";iIcon.style.left="-2px";iIcon.style.height="18px";iIcon.style.width="14px";iIcon.style.display="table";iIcon.style.cursor="pointer";var thisObj=this;var sFx=function(){thisObj.launchSettingPopup();}
;E.click(iIcon,sFx);var span=cE("div",iIcon);span.style.display="table-cell";span.style.textAlign="center";span.style.verticalAlign="middle";span.style.fontSize="18px";span.style.fontFamily="georgia";span.style.color=isHidden?"#6FA8DC":"white";span.innerHTML="i";}
;this.launchSettingPopup=function(){showProgressIcon("Loading");this.grid.hideFramers();var thisObj=this;var afterFx=function(){hideProgressIcon();var popup=new TilePropertiesPopup();popup.grid=thisObj.grid;popup.build(thisObj.itemEl);popup.closeFx=function(){thisObj.grid.reframe();}
;}
;sl_loadScript('/0/le8773_0.js',afterFx);afterFx;}
;}



function HiddenTilesMenu(){this.build=function(parentEl){var div=cE("div",parentEl);div.align="center";this.buildShowHide(div);}
;this.buildShowHide=function(parentEl){var span=cE("button",parentEl);span.style.padding="4px 15px";span.className="lp_smallDarkButton";span.innerHTML="Show";}
;}


function BackgroundSettings(itemEl){this.itemEl=itemEl;this.grid;this.opacitySet=["",1,.95,.9,.85,.8,.75,.7,.6,.5,.4,.3,.2,.1,0];this.bgSizeSet=["","auto","cover","contain","10%","25%","50%","75%","90%","100%","90% 90%","80% 80%","70% 70%","60% 60%","50% 50%","200px 100px"];this.repeatSet=["","no-repeat","repeat-x","repeat-y","repeat"];this.positionSet=["","left top","left center","left bottom","right top","right center","right bottom","center top","center center","center bottom",
"10px 10px","10px 20px","20px 10px","20px 20px","10% 10%","10% 20%","20% 10%","20% 20%"];this.parentEl;this.build=function(parentEl){if(parentEl){this.parentEl=parentEl;}

else 
{parentEl=this.parentEl;}

parentEl.style.padding="6px 10px";parentEl.innerHTML="";var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);this.setBgColor(td);var td=cE("td",tr);td.style.paddingLeft="14px";this.buildOpacity(td);var div=cE("div",parentEl);div.style.padding="6px 0";this.buildImage(div);var div=cE("div",parentEl);div.style.padding="6px 0";this.buildVideo(div);}
;this.setBgColor=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="16px";td.innerHTML="Color";var td=cE("td",tr);var thisObj=this;var fx=function(color){thisObj.updateColor(color);}
;var initial=CssUtil.getStyle(this.itemEl,"background-color");buildColorInput(td,fx,initial);}
;this.updateColor=function(color){var rangeName=this.grid.getCurrentRangeName();LiveCss.update(this.itemEl,[{name:"background-color",value:color}
],rangeName);}
;
this.getBgImage=function(){var current=CssUtil.getStyle(this.itemEl,"background-image");if(current=="none"){current="";}

return current;}
;this.buildImage=function(parentEl){var div=cE("div",parentEl);div.style.marginTop="4px";this.buildImageSetButtons(div);if(this.getBgImage()){var tBody=createTable(parentEl);tBody.className="tilePropsText";var table=tBody.parentNode;table.style.marginLeft="45px";table.style.marginTop="8px";var tr=cE("tr",tBody);var td=cE("td",tr);this.buildBgSize(td);var td=cE("td",tr);td.style.paddingLeft="10px";this.buildRepeat(td);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingTop="6px";td.colSpan=2;this.buildBgPos(td);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingTop="6px";td.colSpan=2;var imgString=this.getBgImage();imgString=imgString.replace(")","");var lastBar=imgString.lastIndexOf("/")+1;imgString=(lastBar<=0)?imgString:imgString.slice(lastBar);td.innerHTML="Current: "+imgString;}

}
;this.buildBgPos=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="";td.innerHTML="Position";var tr=cE("tr",tBody);var td=cE("td",tr);var dd=new LiveCssDropdown(this.itemEl,td,"background-position",this.positionSet,120);dd.rangeName=this.grid.getCurrentRangeName();var thisObj=this;dd.setValueFx=function(value){LiveCss.update(thisObj.itemEl,[{name:"background-position",value:value}
],this.rangeName);}
;dd.build();}
;this.buildRepeat=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="";td.innerHTML="Repeat";var tr=cE("tr",tBody);var td=cE("td",tr);var dd=new LiveCssDropdown(this.itemEl,td,"background-repeat",this.repeatSet,90);dd.rangeName=this.grid.getCurrentRangeName();var thisObj=this;dd.setValueFx=function(value){LiveCss.update(thisObj.itemEl,[{name:"background-repeat",value:value}
],this.rangeName);}
;dd.build();}
;this.buildBgSize=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="";td.innerHTML="Size";var tr=cE("tr",tBody);var td=cE("td",tr);var thisObj=this;var dd=new LiveCssDropdown(this.itemEl,td,"background-size",this.bgSizeSet,70);dd.rangeName=this.grid.getCurrentRangeName();dd.setValueFx=function(value){LiveCss.update(thisObj.itemEl,[{name:"background-size",value:value}
],this.rangeName);}
;dd.build();}
;this.buildImageSetButtons=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.paddingRight="10px";td.innerHTML="Image";var td=cE("td",tr);var span=cE("button",td);span.style.padding="4px 15px";span.className="lp_smallDarkButton";var current=this.getBgImage();span.innerHTML=current?"change":"set";var thisObj=this;var fx=function(){thisObj.popupImage();}
;E.click(span,fx);if(current){var td=cE("td",tr);td.style.paddingLeft="6px";var span=cE("button",td);span.style.padding="4px 15px";span.className="lp_smallDarkButton";span.innerHTML="remove";var thisObj=this;var fx=function(){thisObj.removeBgImage();}
;E.click(span,fx);}

}
;
this.buildVideo=function(parentEl){var div=cE("div",parentEl);this.buildVideoSetButtons(div);}
;
this.buildVideoSetButtons=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tBody);td.style.paddingRight="6px";td.innerHTML="Video";var td=cE("td",tBody);td.style.paddingLeft="6px";var span=cE("button",td);span.style.padding="4px 15px";span.className="lp_smallDarkButton";var current=VideoDisplay.getVideos(this.itemEl);span.innerHTML=(current&&current.length>0)?"change":"set";var thisObj=this;var fx=function(){thisObj.popupVideo();}
;E.click(span,fx);if(current&&current.length>0){var td=cE("td",tBody);var span=cE("button",td);span.style.padding="4px 15px";span.className="lp_smallDarkButton";span.innerHTML="remove";var thisObj=this;var fx=function(){thisObj.removeBgVideo();}
;E.click(span,fx);}

}
;this.removeBgImage=function(){var rangeName=this.grid.getCurrentRangeName();LiveCss.update(this.itemEl,[{name:"background-image",value:"none"}
],rangeName);this.build();}
;this.updateImage=function(imageId,mc){var path=mc.getRecord("image_library",imageId).getField("file").getOriginalPath();var value="url("+path+")";var rangeName=this.grid.getCurrentRangeName();LiveCss.update(this.itemEl,[{name:"background-image",value:value}
],rangeName);}
;this.popupImage=function(){var color="";var thisObj=this;var libraryFx=function(){var imagePopup=new ImagePopup();imagePopup.selectImgFx=function(imageId){thisObj.updateImage(imageId,imagePopup.mc);imagePopup.popup.close();thisObj.build();}
;imagePopup.build();}
;sl_loadScript('/0/le8121_0.js',libraryFx);libraryFx;}
;
this.removeBgVideo=function(){var fragInfo=A.getFragInfo(this.itemEl.id)
if(!fragInfo){return ;}

ActionHandler.removeActions(fragInfo,"videoHandler");VideoDisplay.remove(this.itemEl);this.build(this.parentEl);}
;
this.popupVideo=function(){var thisObj=this;var videoFx=function(){var videoPopup=new VideoPopup(thisObj.itemEl);videoPopup.saveFx=function(){thisObj.build(thisObj.parentEl);}
;videoPopup.build();}
;sl_loadScript('/0/le8776_0.js',videoFx);videoFx;}
;this.buildOpacity=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tBody);td.style.paddingRight="6px";td.innerHTML="Opacity";var td=cE("td",tBody);var dd=new LiveCssDropdown(this.itemEl,td,"opacity",this.opacitySet,60,60);dd.rangeName=this.grid.getCurrentRangeName();var thisObj=this;dd.setValueFx=function(value){LiveCss.update(thisObj.itemEl,[{name:"opacity",value:value}
,{name:"filter",value:"alpha(opacity="+value*100+")"}
],this.rangeName);}
;return dd.build();}
;}



function GridDimensionSettings(element,framer,grid){this.element=element;this.framer=framer;this.grid=grid;this.widthSet=["100%","50px","100px","150px","200px","250px","300px","400px","500px","600px","700px","800px","900px","1000px","300%","200%","150%","100%","50%","33.33%","25%"];this.rangeName;this.build=function(parentEl){CssUtil.addClassToEl(this.element,"a-meta-grid-slider");var holder=cE("div",parentEl);holder.style.padding="10px";var mg=new MondrianGrid(this.element);this.rangeName=mg.getCurrentRangeName();var gridEl=this.element;if(gridEl.offsetWidth>document.body.offsetWidth){var div=cE("div",holder);div.style.margin="10px 0px";this.buildPositionSlider(div);}

var div=cE("div",holder);this.buildDimensions(div);var div=cE("div",holder);div.style.marginTop="8px";this.buildUnits(div);}
;this.buildPositionSlider=function(parentEl){var tbody=createTable(parentEl,"100%");var tr=cE("tr",tbody);var td=cE("td",tr);var span=cE("div",td);span.style.borderTop="10px solid transparent";span.style.borderBottom="10px solid transparent";span.style.borderRight="10px solid #4f4f4f";span.style.cursor="pointer";var thisObj=this;var prevClick=function(){thisObj.showHiddenArea("previous");}
;E.click(span,prevClick);var td=cE("td",tr);td.style.textAlign="center";td.innerHTML="scroll grid";var td=cE("td",tr);var span=cE("div",td);span.style.borderTop="10px solid transparent";span.style.borderBottom="10px solid transparent";span.style.borderLeft="10px solid #4f4f4f";span.style.cursor="pointer";var nextClick=function(){thisObj.showHiddenArea("next");}
;E.click(span,nextClick);}
;this.buildDimensions=function(parentEl){var holder=cE("div",parentEl);holder.style.marginBottom="10px";holder.style.overflow="hidden";var div=cE("div",holder);CssUtil.setFloat(div,"left");div.style.width="50%";this.buildWidth(div);var div=cE("div",holder);CssUtil.setFloat(div,"left");div.style.width="50%";this.buildHeight(div);var holder=cE("div",parentEl);holder.style.marginBottom="10px";holder.style.overflow="hidden";var div=cE("div",holder);CssUtil.setFloat(div,"left");div.style.width="50%";this.buildMinWidth(div);var div=cE("div",holder);CssUtil.setFloat(div,"left");div.style.width="50%";this.buildMinHeight(div);}
;this.buildUnits=function(parentEl){var tBody=createTable(parentEl);var tr=cE("tr",tBody);var td=cE("td",tr);this.buildWidthUnit(td);var td=cE("td",tr);td.style.paddingLeft="10px";this.buildHeightUnit(td);}
;this.buildWidthUnit=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.colSpan=2;td.innerHTML="Width Unit";var tr=cE("tr",tBody);var td=cE("td",tr);var thisObj=this;var fx=function(){debugger;thisObj.updateWidthUnit();}
;var props={value:this.grid.getBoxWidthValue(),onAfterChangeFx:fx}
;var input=buildNumberInput(td,props);this.widthUnitValueInput=input;input.style.width="55px";input.style.fontSize="12px";var td=cE("td",tr);var dd=this.buildUnitDD(td,this.grid.getBoxWidthUnit(),fx);this.widthUnitDD=dd;}
;this.buildHeightUnit=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.colSpan=2;td.innerHTML="Height Unit";var tr=cE("tr",tBody);var td=cE("td",tr);var thisObj=this;var fx=function(){thisObj.updateHeightUnit();}
;var props={value:this.grid.getBoxHeightValue(),onAfterChangeFx:fx}
;var input=buildNumberInput(td,props);this.heightUnitValueInput=input;input.style.width="55px";input.style.fontSize="12px";var td=cE("td",tr);var dd=this.buildUnitDD(td,this.grid.getBoxHeightUnit(),fx);this.heightUnitDD=dd;}
;this.updateHeightUnit=function(){var value=this.heightUnitValueInput.value+this.heightUnitDD.value;this.grid.action.ranges[this.grid.getCurrentRangeName()].squareHeight=value;this.grid.refreshAction();}
;this.updateWidthUnit=function(){var value=this.widthUnitValueInput.value+this.widthUnitDD.value;var current=this.grid.getCurrentRangeName();var ranges=this.grid.editRanges;var srcRanges=this.grid.action.ranges;for(var i in ranges)
{if(ResponsiveUtil.isLessThan(i,current)||i==current){srcRanges[i].squareWidth=value;}

}

this.grid.refreshAction();}
;this.buildUnitDD=function(parentEl,initial,onChangeFx){var dd=cE("select",parentEl);dd.style.fontSize="12px";var thisObj=this;var fx=function(){onChangeFx();}
;E.change(dd,fx);var option=cE("option",dd);option.value="px";option.innerHTML="px";var option=cE("option",dd);option.value="%";option.innerHTML="%";dd.value=initial;return dd;}
;this.buildWidth=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.innerHTML="Width";var tr=cE("tr",tBody);var td=cE("td",tr);var dd=new LiveCssDropdown(this.element,td,"width",this.widthSet,100);dd.initialValue=this.getWidthVal();dd.rangeName=this.rangeName;var thisObj=this;dd.onChangeFx=function(){thisObj.grid.reframe();}
;dd.build();}
;this.getWidthVal=function(){var pxVal=this.element.offsetWidth;if(this.grid.getBoxWidthUnit()!="%"){return pxVal+"px";}

return 100*pxVal/this.element.parentElement.offsetWidth+"%";}
;this.getHeightVal=function(){var pxVal=this.element.offsetHeight;if(this.grid.getBoxHeightUnit()!="%"){return pxVal+"px";}

return 100*pxVal/this.element.parentElement.offsetHeight+"%";}
;this.buildHeight=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.innerHTML="Height";var tr=cE("tr",tBody);var td=cE("td",tr);var dd=new LiveCssDropdown(this.element,td,"height",this.widthSet,100);dd.initialValue=this.getHeightVal();dd.rangeName=this.rangeName;var thisObj=this;dd.onChangeFx=function(){thisObj.grid.reframe();}
;dd.build();}
;this.buildRange=function(parentEl){var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.width="80px";td.innerHTML="Responsive Range";var tr=cE("tr",tBody);var td=cE("td",tr);td.className="lp_mediumBoldText";td.style.fontSize="20px";td.style.textTransform="uppercase";td.innerHTML=this.rangeName;}
;this.buildMinHeight=function(parentEl){this.buildDD("Min Height",parentEl);}
;this.buildMinWidth=function(parentEl){this.buildDD("Min Width",parentEl);}
;this.buildDD=function(label,parentEl){var unit;var initiVal;var property;if(label.indexOf("Height")>=0){property=(label.indexOf("Min")>=0)?"min-height":"height";unit=this.grid.getBoxHeightUnit(this.rangeName);var minHeightVal=CssUtil.getStyle(this.element,"min-height");initVal=(label.indexOf("Min")>=0&&minHeightVal)?minHeightVal:this.grid.getHeightVal(this.element.offsetHeight)+unit;}

else 
{property=(label.indexOf("Min")>=0)?"min-width":"width";unit=this.grid.getBoxWidthUnit(this.rangeName);var minWidthVal=CssUtil.getStyle(this.element,"min-width");initVal=(label.indexOf("Min")>=0&&minWidthVal)?minWidthVal:this.grid.getWidthVal(this.element.offsetWidth)+unit;}

var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.innerHTML=label;var tr=cE("tr",tBody);var td=cE("td",tr);var dd=new LiveCssDropdown(this.element,td,property,this.widthSet,100);dd.initialValue=initVal;dd.rangeName=this.rangeName;dd.build();}
;
this.showHiddenArea=function(direction){var marginStyle="marginLeft";var tileContainer=this.element;var currentMargin=(tileContainer.style[marginStyle]=="")?0:0-parseInt(tileContainer.style[marginStyle].replace("px",""));var tileSize=tileContainer.parentNode["offsetWidth"];var lastMargin=currentMargin;if(null==direction){currentMargin=0;}

else if(direction=="next"){currentMargin+=tileSize;this.currentTile++;}

else 
{currentMargin-=tileSize;this.currentTile--;}

if(currentMargin>=tileContainer["scrollWidth"]){currentMargin=tileContainer["scrollWidth"]-tileSize;this.currentTile=(currentMargin<=lastMargin)?this.currentTile-1:this.currentTile;}

else if(currentMargin<=0){currentMargin=0;this.currentTile=0;}

currentMargin=0-currentMargin;tileContainer.style[marginStyle]=currentMargin+"px";this.grid.reframe();}
;}
;

function AlignGridSettings(gridEl,grid){this.gridEl=gridEl;this.grid=grid;this.build=function(parentEl){parentEl.innerHTML="";var div=cE("div",parentEl);var tBody=createTable(div);tBody.parentElement.className="mg-align-table";var tr=cE("tr",tBody);var thisObj=this;var tr=cE("tr",tBody);var td=cE("td",tr);var mL=cE("img",td);mL.src="/upload/custom_screens/html5/livepage/layout/mondrian/mg-align-ml.gif";var mLFx=function(){thisObj.updateCss("left");}
;E.click(mL,mLFx);var td=cE("td",tr);var mM=cE("img",td);mM.src="/upload/custom_screens/html5/livepage/layout/mondrian/mg-align-mm.gif";var mMFx=function(){thisObj.updateCss("center");}
;E.click(mM,mMFx);var td=cE("td",tr);var mR=cE("img",td);mR.src="/upload/custom_screens/html5/livepage/layout/mondrian/mg-align-mr.gif";var mRFx=function(){thisObj.updateCss("right");}
;E.click(mR,mRFx);}
;this.updateCss=function(horizAlign){var props;if("left"==horizAlign){props=[{name:"margin",value:"0 auto 0 0"}
];}

else if("right"==horizAlign){props=[{name:"margin",value:"0 0 0 auto"}
];}

else 
{props=[{name:"margin",value:"0 auto"}
];}

LiveCss.update(this.gridEl,props);this.grid.reframe();}
;}



function GridOverFlowSettings(element){this.element=element;this.overflowSet=["visible","hidden","scroll","auto"];this.build=function(parentEl){parentEl.innerHTML="";var div=cE("div",parentEl);div.style.padding="6px";div.align="center";var dd=new LiveCssDropdown(this.element,div,"overflow",this.overflowSet,100,100);var thisObj=this;dd.setValueFx=function(value){}
;dd.build();}
;}


;;;;function GridSettingsPopup(){this.gridEl;this.grid;this.gridFramer;this.width=250;this.closeFx;this.popup;this.build=function(gridEl){debugger;this.gridEl=gridEl;ContainerHandler.disableFramers();this.buildPopup();this.attachResize();}
;this.buildPopup=function(){this.initCss();var popup=new Popup();this.popup=popup;popup.title="Grid Styles";popup.positionEl=this.gridEl;popup.alignment=this.chooseAlign();popup.titleDragBarClass="lp_popupTitleBar";popup.closeImg="/upload/custom_screens/html5/livepage/close_icon.gif";popup.showX=true;popup.useFrame=false;popup.closeEvents=["onclick","oncontextmenu"];popup.closeEvent=null;popup.disableBg=true;popup.fadeBg=false;popup.width=this.width;popup.ensureOnTop=true;var thisObj=this;popup.closeFx=function(){if(thisObj.closeFx){thisObj.closeFx();}

}
;var contentArea=popup.build();CssUtil.makeNotSelectable(contentArea);this.buildContent(contentArea);popup.align();}
;
this.buildGridSettings=function(contentArea,gridEl){this.gridEl=gridEl;this.buildContent(contentArea);}
;this.attachResize=function(){var thisObj=this;this.resizeFx=function(){thisObj.onResize();}
;E.resize(this.resizeFx);}
;this.onResize=function(){this.refresh();if(this.popup){this.popup.adjustForOffScreen();}

}
;this.refresh=function(){this.buildContent();}
;this.chooseAlign=function(){var coord=findElCoord(this.gridEl);return "upperRight";}
;this.buildContent=function(parentEl){if(parentEl){this.parentEl=parentEl;}

else 
{parentEl=this.parentEl;}

var toolBar=new SlidingToolBar();toolBar.persistentKey="lp_settings";toolBar.headerClass="lp_toolbarHeader";toolBar.headerTextClass="lp_toolbarText";toolBar.expandedArrow="/upload/custom_screens/moduleeditor/item_open_icon.gif";toolBar.collapsedArrow="/upload/custom_screens/moduleeditor/item_closed_icon.gif";if(this.gridEl.parentElement.tagName!="BODY"){var view=new AlignGridSettings(this.gridEl,this.grid);toolBar.addMenuItem("Alignment",view);}

var bgView=new BackgroundSettings(this.gridEl);bgView.grid=this.grid;toolBar.addMenuItem("Background",bgView);var view=new GridDimensionSettings(this.gridEl,this.gridFramer,this.grid);toolBar.addMenuItem("Dimensions",view);var view=new GridOverFlowSettings(this.gridEl);toolBar.addMenuItem("Overflow",view);toolBar.build(parentEl);}
;this.close=function(){this.popup.close();}
;this.initCss=function(){var cls=new CssClass(".mg-align-table");cls.add("margin","auto");cls.init();var cls=new CssClass(".mg-align-table td");cls.add("padding","2px");cls.init();}
;}



;;var GridEditMenuPopup=new GridEditMenuPopupBase();function GridEditMenuPopupBase(){this.gridEl;this.grid;this.width=250;this.isShown=false;this.setGridEl=function(gridEl){if(this.gridEl==gridEl){return ;}

if(this.isShowing()){this.clear();}

this.gridEl=gridEl;var grid=new MondrianGrid(gridEl);this.grid=grid;if(this.isShowing()){GridManager.disableClose();this.grid.frame();if(!this.popup){this.buildPopup(x,y);}

this.buildContent();}

}
;this.refreshGrid=function(){if(this.grid){this.grid.reframe();}

}
;this.show=function(x,y){EditUtil.disable();this.clear();GridManager.disableClose();this.grid.frame();if(!this.popup){this.buildPopup(x,y);}

this.buildContent();this.isShown=true;this.attachResize();}
;this.buildContent=function(){
var parentEl=this.popup.contentArea;parentEl.innerHTML="";var div=cE("div",parentEl);div.style.padding="10px 15px";rEl=div;this.responsiveEl=rEl;var settingsEl=cE("div",parentEl);CssUtil.makeNotSelectable(settingsEl);var gridPopup=new GridSettingsPopup();gridPopup.grid=this.grid;gridPopup.gridFramer=this.grid.gridFramer;gridPopup.buildGridSettings(settingsEl,this.gridEl);this.gridPopup=gridPopup;this.buildRange();}
;this.attachResize=function(){var thisObj=this;this.resizeFx=function(){thisObj.onResize();}
;E.resize(this.resizeFx);}
;this.onResize=function(){this.buildContent();this.popup.adjustForOffScreen();}
;this.buildRange=function(){var parentEl=this.responsiveEl;parentEl.innerHTML="";var tBody=createTable(parentEl);tBody.className="tilePropsText";var tr=cE("tr",tBody);var td=cE("td",tr);td.style.width="150px";td.innerHTML="Responsive Range";var td=cE("td",tr);td.className="lp_mediumBoldText";td.style.fontSize="20px";td.style.textTransform="uppercase";td.innerHTML=this.grid.getCurrentRangeName();}
;this.clear=function(){if(this.grid){GridManager.enableClose();this.grid.close();}

}

this.isShowing=function(){return this.popup?true:false;}
;this.close=function(){if(!this.isShowing()){return ;}

this.responsiveEl=null;this.gridPopup=null;E.remove(window,"resize",this.resizeFx);GridManager.enableClose();var grid=this.grid;grid.close();this.grid=null;this.gridEl=null;this.popup.close();this.popup=null;EditUtil.enable();}
;this.buildPopup=function(x,y){var popup=new Popup();this.popup=popup;popup.setAtCoord(x,y);popup.title="Mondrian Grid Menu";popup.titleDragBarClass="lp_popupTitleBar";popup.closeImg="/upload/custom_screens/html5/livepage/close_icon.gif";popup.showX=true;popup.useFrame=false;popup.closeEvents=null;popup.closeEvent=null;popup.disableBg=false;popup.fadeBg=false;popup.hideTopBar=false;popup.width=this.width;popup.ensureOnTop=true;var thisObj=this;popup.closeFx=function(){thisObj.close();if(thisObj.closeFx){thisObj.closeFx();}

}
;var contentArea=popup.build();contentArea.className="lp_reset";CssUtil.makeNotSelectable(contentArea);popup.align();}
;}


function pixelToNumber(pixel){if(pixel!=""){return parseInt(pixel.substr(0,pixel.length-2));}

else 
{return 0;}

}
;

;function SlidingToolBar(){this.menuItems=[];this.headerClass="";this.headerTextClass="";this.expandedArrow;this.collapsedArrow;this.persistentKey;this.settings;this.totalTime=100;this.moves=10;this.timePerNudge=this.totalTime/this.moves;this.defaultIsExpanded=false;this.onSlide;this.init=function(){if(this.persistentKey&&!window["UserSettingsMgr"]){this.settings=new UserSettings(this.persistentKey);}

}
;this.build=function(parentEl){parentEl.innerHTML="";var settingsData;if(this.settings){settingsData=this.settings.getSettings();}

var menuItems=this.menuItems;for(var i=0;i<menuItems.length;i++)
{var item=menuItems[i];this.buildMenuItem(parentEl,item,settingsData);}

}
;this.refresh=function(){var menuItems=this.menuItems;for(var i=0;i<menuItems.length;i++)
{var item=menuItems[i];if(item.isInitialized){item.content.innerHTML="";item.viewer.build(item.content);}

}

}
;this.addMenuItem=function(name,viewer,addCustomContentFx){var item={name:name,viewer:viewer,isInitialized:false,addCustomContentFx:addCustomContentFx}
;this.menuItems.push(item);}
;this.buildMenuItem=function(parentEl,item,settingsData){var isExpanded;if(window["UserSettingsMgr"]){isExpanded=UserSettingsMgr.getProperty(this.persistentKey,item.name)?true:false;}

else 
{isExpanded=(settingsData&&settingsData.getChildField(item.name))?true:false;}

var holder=cE("div",parentEl);holder.className=this.headerClass;holder.style.clear="both";var headerTBbody=createTable(holder,"100%","100%");var headerTr=cE("tr",headerTBbody);var headerTd=cE("td",headerTr);var tBody=createTable(headerTd,null,"100%");var tr=cE("tr",tBody);var td=cE("td",tr);td.align="right";td.vAlign="middle";td.style.paddingLeft="8px";td.style.cursor="pointer";var arrow=cE("img",td);if(IS_IE){arrow.style.marginTop="2px";}

arrow.src=isExpanded?this.expandedArrow:this.collapsedArrow;var td=cE("td",tr);td.style.paddingLeft="3px";td.className=this.headerTextClass;td.innerHTML=item.name;addUnderlineEvents(td);var customTd=cE("td",headerTr);customTd.align="right";if(item.addCustomContentFx){item.addCustomContentFx(customTd);}

var content=cE("div",parentEl);content.style.display=isExpanded?"":"none";item.content=content;if(isExpanded){item.viewer.build(content);item.isInitialized=true;}

var thisObj=this;var fx=function(){var isExpand=(content.style.display=="none")?true:false;if(isExpand){thisObj.showMenuItem(item);arrow.src=thisObj.expandedArrow;if(settingsData){settingsData.addChildField(item.name,"BOOLEAN",true);}

else if(thisObj.persistentKey&&window["UserSettingsMgr"]){UserSettingsMgr.setProperty(thisObj.persistentKey,item.name,true);}

}

else 
{thisObj.hideMenuItem(item);arrow.src=thisObj.collapsedArrow;if(settingsData){settingsData.removeChildField(item.name);}

else if(thisObj.persistentKey&&window["UserSettingsMgr"]){UserSettingsMgr.deleteProperty(thisObj.persistentKey,item.name);}

}

if(thisObj.settings&&!window["UserSettingsMgr"]){thisObj.settings.saveSettings();}

}
;eh_attachEvent("onclick",holder,fx);}
;this.hideMenuItem=function(item){var element=item.content;element.style.height=element.offsetHeight+"px";element.style.overflow="hidden";var thisObj=this;var fx=function(){var pixelsPerMove=Math.round(element.scrollHeight/thisObj.moves);var newHeight=pixelToNumber(element.style.height)-pixelsPerMove;if(0<newHeight){element.style.height=newHeight+"px";window.setTimeout(fx,thisObj.timePerNudge);}

else 
{element.style.display="none";element.style.height="";element.style.overflow="";if(thisObj.onSlide){thisObj.onSlide();}

if(thisObj.settings){thisObj.settings.saveSettings();}

}

}
;window.setTimeout(fx,0);}
;this.showMenuItem=function(item){var element=item.content;if(!item.isInitialized){item.viewer.build(element);}

element.style.height="1px";element.style.overflow="hidden";element.style.display="";var thisObj=this;var fx=function(){var pixelsPerMove=Math.round(element.scrollHeight/thisObj.moves);var newHeight=pixelToNumber(element.style.height)+pixelsPerMove;if(newHeight<element.scrollHeight){element.style.height=newHeight+"px";window.setTimeout(fx,thisObj.timePerNudge);}

else 
{element.style.height="";element.style.overflow="";element.style.display="";if(thisObj.onSlide){thisObj.onSlide();}

if(thisObj.settings){thisObj.settings.saveSettings();}

}

}
;window.setTimeout(fx,0);}
;}


;;;;;;;;function MondrianGrid(gridEl){this.gridEl=gridEl;this.posInfo;this.lastSortedEls;this.editRanges;this.framers;this.gridFramer;this.action;this.id;this.gridDragger=new GridDragger(this);this.init=function(){this.id=GridManager.register(this);var fragInfo=A.getFragInfo(this.gridEl.id);var action;for(var i=0;i<fragInfo.actions.length;i++)
{if(fragInfo.actions[i].command=="MondrianEditor"){action=fragInfo.actions[i];}

}

if(!action){alert("problem with mondrian grid settings");return ;}

this.action=action;this.editRanges=clone(action.ranges);}
;this.init();this.frame=function(focusItemEl){var thisObj=this;var afterFx=function(){thisObj.finishFrame(focusItemEl);}
;var moduleEl=focusItemEl||this.gridEl;LiveCss.initialize(moduleEl,afterFx);}
;this.refreshAction=function(){this.editRanges=clone(this.action.ranges);LivePage.setElementToSave(this.gridEl);}
;this.finishFrame=function(focusItemEl){this.framers=[];this.frameGrid();this.frameItems(focusItemEl);this.attachGridClick();this.attachResize();LiveCssTransitionUtil.lockTransitions("mg");}
;this.frameGrid=function(){if(!this.gridFramer){this.gridFramer=new GridFramer(this.gridEl,this)
}

this.gridFramer.frame();}
;this.frameItems=function(focusItemEl){var els=this.getLastSortedEls();if(focusItemEl){var start=0;for(var i=0;i<els.length;i++)
{if(focusItemEl==els[i]){start=i;break;}

}

var el=els[start];if(CssUtil.elHasClass(el,"a-meta-no-tile")){this.frameItem(el);}

for(var i=1;i<els.length;i++)
{if(els[start+i]){var el=els[start+i];if(CssUtil.elHasClass(el,"a-meta-no-tile")){continue;}

this.frameItem(el);}

if(els[start-i]){var el=els[start-i];if(CssUtil.elHasClass(el,"a-meta-no-tile")){continue;}

this.frameItem(el);}

}

}

else 
{for(var i=0;i<els.length;i++)
{var el=els[i];if(CssUtil.elHasClass(el,"a-meta-no-tile")){continue;}

this.frameItem(el);}

}

}
;this.attachGridClick=function(){var thisObj=this;this.exitFx=function(){thisObj.destroy();}
;var doc=getParentDocument(this.gridEl);E.add(doc.body,"click",this.exitFx);E.add(doc.body,"rightclick",this.exitFx);}
;this.getSizeToRange=function(){if(this.sizeToRange){return this.sizeToRange;}

var sR=this.sizeToRange={}
;var names=[];for(var i in this.editRanges)
{var sizes=ResponsiveUtil.getRangeSizes(i);if(!sizes){sR["defaultRange"]=i;continue;}

for(var j=0;j<sizes.length;j++)
{sR[sizes[j]]=i;}

}

return sR;}
;this.getCurrentRangeName=function(){var map=this.getSizeToRange();if(!map){alert("lacking input data for mondrian grid");}

var rangeName=map[ResponsiveUtil.getCurrentSize()];if(!rangeName){rangeName=map["defaultRange"];}

return rangeName;}
;this.getCurrentRange=function(){return this.editRanges[this.getCurrentRangeName()];}
;this.getBoxWidthValue=function(rangeName){var range=this.editRanges[rangeName]||this.getCurrentRange();if(!range.sqWidthValue){range.sqWidthValue=CssUtil.getNumberVal(range.squareWidth);}

return range.sqWidthValue;}
;this.getBoxWidthPxValue=function(rangeName){if("%"==this.getBoxWidthUnit(rangeName)){var pctValue=this.getBoxWidthValue(rangeName);return (pctValue*this.gridEl.offsetWidth)/100;}

else 
{return this.getBoxWidthValue(rangeName);}

}
;this.getBoxWidthUnit=function(rangeName){var range=this.editRanges[rangeName]||this.getCurrentRange();if(!range.sqWidthUnit){range.sqWidthUnit=CssUtil.getNumberUnit(range.squareWidth);}

return range.sqWidthUnit;}
;this.getBoxHeightValue=function(rangeName){var range=this.editRanges[rangeName]||this.getCurrentRange();if(!range.sqHeightValue){range.sqHeightValue=CssUtil.getNumberVal(range.squareHeight);}

return range.sqHeightValue;}
;this.getBoxHeightPxValue=function(rangeName){if("%"==this.getBoxHeightUnit(rangeName)){var pctValue=this.getBoxHeightValue(rangeName);return (pctValue*this.gridEl.offsetHeight)/100;}

else 
{return this.getBoxHeightValue(rangeName);}

}
;this.getBoxHeightUnit=function(rangeName){var range=this.editRanges[rangeName]||this.getCurrentRange();if(!range.sqHeightUnit){range.sqHeightUnit=CssUtil.getNumberUnit(range.squareHeight);}

return range.sqHeightUnit;}
;this.pixelToWidthUnit=function(pxVal){return Math.round(pxVal/this.getBoxWidthPxValue());}
;this.getWidthVal=function(pxVal){if(this.getBoxWidthUnit()!="%"){return pxVal;}

return JsUtil.round((100*pxVal/this.gridEl.offsetWidth),3);}
;this.pixelToHeightUnit=function(pxVal){return Math.round(pxVal/this.getBoxHeightPxValue());}
;this.getHeightVal=function(pxVal){if(this.getBoxHeightUnit()!="%"){return pxVal;}

return JsUtil.round((100*pxVal/this.gridEl.offsetHeight),3);}
;this.attachResize=function(){var thisObj=this;this.resizeFx=function(){thisObj.reframe();}
;E.resize(this.resizeFx);}
;this.classifyItem=function(itemEl,rangeName){if(CssUtil.elHasClass(itemEl,"a-meta-no-tile")){return ;}

var sheet=this.getStyleSheet();var className=LiveCss.getClassNameForEl(itemEl);var rangeInfo=ResponsiveUtil.getRangeNameInfo(rangeName);
if(rangeInfo.startSize!="xxs"){var defaultRangeName="xxs-"+rangeInfo.endSize;this.updateClass(sheet,itemEl,className,defaultRangeName);}

this.updateClass(sheet,itemEl,className,rangeName);itemEl.style.width="";itemEl.style.height="";itemEl.style.left="";itemEl.style.top="";itemEl.style.zIndex="";}
;this.updateClass=function(sheet,itemEl,className,rangeName){var cls=new LiveCssClass();cls.className=className;cls.rangeName=rangeName;cls.update("width",this.getDimValue(CssUtil.getNumberVal(itemEl.style.width),CssUtil.getNumberUnit(itemEl.style.width)));cls.update("height",this.getDimValue(CssUtil.getNumberVal(itemEl.style.height),CssUtil.getNumberUnit(itemEl.style.height)));cls.update("left",this.getDimValue(CssUtil.getNumberVal(itemEl.style.left),CssUtil.getNumberUnit(itemEl.style.left)));cls.update("top",this.getDimValue(CssUtil.getNumberVal(itemEl.style.top),CssUtil.getNumberUnit(itemEl.style.top)));if(itemEl.style.zIndex){cls.update("z-index",itemEl.style.zIndex);}

sheet.updateClass(cls);}
;this.isResetDefaultClass=function(sheet,className){var rules=sheet.getCssDoc().getRulesByClassName(className);var count=0;for(var i=0;i<rules.length;i++)
{var rule=rules[i];if(rule instanceof ResponsiveRuleNode){count++
if(count>=2){return false;}

else if(this.getCurrentRangeName()!=rule.getRangeName()){return false;}

}

}

return true;}
;this.createTileProps=function(x,y){var coord=findElCoord(this.gridEl,true);var boxX=this.pixelToWidthUnit(x-coord.x);var boxY=this.pixelToHeightUnit(y-coord.y);var totalWidth=this.gridEl.offsetWidth;var totalHeight=Math.min(document.body.clientHeight,this.gridEl.offsetHeight);var k=(totalWidth>=1000)?.25:.5;var width=this.pixelToWidthUnit(totalWidth*k);var height=this.pixelToHeightUnit(totalHeight*.25);return {x:boxX,y:boxY,width:width,height:height}
;}
;this.createItem=function(x,y){var itemEl=cE("div",this.gridEl);LivePage.setElementToSave(itemEl);var holder=cE("div",itemEl);var div=cE("section",holder);div.innerHTML="";var loc=this.createTileProps(x,y);this.createItemCss(itemEl,loc,loc.width,loc.height);if(this.isFramed()){this.frameItem(itemEl);}

this.lastSortedEls=null;return itemEl;}
;this.createItemCss=function(itemEl,coord,boxWidth,boxHeight){var rangeName=this.getCurrentRangeName();var className=LiveCss.getClassNameForEl(itemEl);var sheet=this.getStyleSheet();this.createPosCls(coord,boxWidth,boxHeight,sheet,className,rangeName);this.createPosCls(coord,boxWidth,boxHeight,sheet,className);var defaultSheet=LiveCss.getStyleSheetForEl(itemEl);if(defaultSheet!=sheet){this.createPosCls(coord,boxWidth,boxHeight,defaultSheet,className,rangeName);this.createPosCls(coord,boxWidth,boxHeight,defaultSheet,className);}

}
;this.createPosCls=function(coord,boxWidth,boxHeight,sheet,className,rangeName){var cls=new LiveCssClass();cls.className=className;cls.rangeName=rangeName;cls.update("width",this.getDimValue(this.getBoxWidthValue(rangeName)*boxWidth,this.getBoxWidthUnit(rangeName)));cls.update("height",this.getDimValue(this.getBoxHeightValue(rangeName)*boxHeight,this.getBoxHeightUnit(rangeName)));cls.update("left",this.getDimValue(this.getBoxWidthValue(rangeName)*coord.x,this.getBoxWidthUnit(rangeName)));cls.update("top",this.getDimValue(this.getBoxHeightValue(rangeName)*coord.y,this.getBoxHeightUnit(rangeName)));cls.update("z-index",this.getTopZIndex());sheet.updateClass(cls);}
;this.getDimValue=function(value,unit){if(unit=="%"){value=Math.round(value*1000)/1000;}

return value+unit;}
;this.reframe=function(focusItemEl){if(!this.framers){return ;}

for(var i=0;i<this.framers.length;i++)
{this.framers[i].reframe(true);}

this.gridFramer.framer.reframe(true);}
;this.destroy=function(){this.close();}
;this.close=function(){if(!GridManager.isCloseable()){return ;}

var doc=getParentDocument(this.gridEl);E.remove(doc.body,"click",this.exitFx);E.remove(doc.body,"contextmenu",this.exitFx);this.clearFramers();LiveCssTransitionUtil.unlockTransitions("mg");}
;this.isFramed=function(){return this.framers?true:false;}
;this.clearFramers=function(){if(this.gridFramer){this.gridFramer.destroy();this.gridFramer=null;}

if(this.framers){for(var i=0;i<this.framers.length;i++)
{var framer=this.framers[i];framer.destroy();}

this.framers=null;}

E.remove(window,"resize",this.resizeFx);}
;this.hideFramers=function(keepFramer){if(this.gridFramer){this.gridFramer.framer.tempHide();}

if(!this.framers){return ;}

for(var i=0;i<this.framers.length;i++)
{var framer=this.framers[i];if(keepFramer&&keepFramer.element==framer.element){continue;}

framer.tempHide();}

}
;this.frameItem=function(itemEl){var isHidden=LivePage.isElHidden(itemEl);var framer=isHidden?new Framer("lp_lrFramerHiddenColumnTop","lp_lrFramerHiddenColumnRight","lp_lrFramerHiddenColumnBottom","lp_lrFramerHiddenColumnLeft"):
new Framer("lp_lrFramerColumnTop","lp_lrFramerColumnRight","lp_lrFramerColumnBottom","lp_lrFramerColumnLeft");framer.staggerDrawing=true;framer.paddingLeft=-5;framer.paddingRight=-5;framer.paddingTop=-5;framer.paddingBottom=-5;framer.doHideOnOut=false;framer.cover=true;framer.maxOpacity=".9";framer.frame(itemEl);this.framers.push(framer);var thisObj=this;var ewFx=function(e){thisObj.gridDragger.startEWDrag(e,itemEl,framer);}
;E.mousedown(framer.right,ewFx);var nsFx=function(e){thisObj.gridDragger.startNSDrag(e,itemEl,framer);}
;E.mousedown(framer.bottom,nsFx);this.gridDragger.attachMoveDrag(framer);var onRightClick=function(e){var el=itemEl;var innerEl=GridManager.getInnerItemEl(itemEl);if(innerEl){if(innerEl.children[0]){el=innerEl.children[0];}

}

var coordinate=getEventCoord(e);var x=coordinate.x;var y=coordinate.y;RightClickPageOptions.handleRightClick(el,x,y)
}
;E.rightclick(framer.getCoverEl(),onRightClick);var tile=new TileIcon(itemEl);tile.grid=this;tile.build(framer.left);}
;this.redoZIndex=function(){var tiles=[];for(var i=0;i<this.gridEl.children.length;i++)
{var tileEl=this.gridEl.children[i];var z=parseInt(CssUtil.getStyle(tileEl,"z-index"));if(isNaN(z)){z=0;}

tiles.push({tileEl:tileEl,z:z}
);}

sorter_sortAscending("z",tiles);}
;this.getTopZIndex=function(){var z=0;for(var i=0;i<this.gridEl.children.length;i++)
{var thisZ=CssUtil.getStyle(this.gridEl.children[i],"z-index");if(isNaN(thisZ)){continue;}

z=Math.max(z,thisZ);}

return z+1;}
;this.readItem=function(itemEl){var width=this.getWidthVal(CssUtil.getNumberVal(CssUtil.getStyle(itemEl,"width")));width=Math.ceil(width/this.getBoxWidthValue());var left=this.getWidthVal(CssUtil.getNumberVal(CssUtil.getStyle(itemEl,"left")));left=Math.ceil(left/this.getBoxWidthValue());var height=this.getHeightVal(CssUtil.getNumberVal(CssUtil.getStyle(itemEl,"height")));height=Math.ceil(height/this.getBoxHeightValue());var top=this.getHeightVal(CssUtil.getNumberVal(CssUtil.getStyle(itemEl,"top")));top=Math.ceil(top/this.getBoxHeightValue());return {left:left,top:top,width:width,height:height}
;}
;this.getGridCoord=function(e){var coord=findElCoord(this.gridEl,true);var left=e.clientX-coord.x;var top=e.clientY-coord.y;var x=Math.floor(this.getWidthVal(left)/this.getBoxWidthValue());x=Math.max(0,x);var y=Math.floor(this.getHeightVal(top)/this.getBoxHeightValue());y=Math.max(0,y);return {x:x,y:y}
;}
;this.declassifyItem=function(itemEl){var item=this.readItem(itemEl);itemEl.style.width=this.getBoxWidthValue()*item.width+this.getBoxWidthUnit();itemEl.style.height=this.getBoxHeightValue()*item.height+this.getBoxHeightUnit();itemEl.style.left=this.getBoxWidthValue()*item.left+this.getBoxWidthUnit();itemEl.style.top=this.getBoxHeightValue()*item.top+this.getBoxHeightUnit();}
;this.getStyleSheet=function(){return LiveCss.getSheetToWriteForEl(this.gridEl);}
;this.getLastSortedEls=function(){if(this.lastSortedEls){return this.lastSortedEls;}

return this.getSortedEls();}
;this.getSortedEls=function(rangeName){var els=[];for(var i=0;i<this.gridEl.children.length;i++)
{els.push(this.gridEl.children[i]);}

this.sortElsByPos(els,rangeName);this.lastSortedEls=els;return els;}
;this.sortElsByPos=function(els,rangeName){var toSort=[];for(var i=0;i<els.length;i++)
{var itemEl=els[i];if(rangeName){var sheet=this.getStyleSheet();var rule=sheet.getRule(itemEl,rangeName);if(!rule){var left=0;var top=0;}

else 
{var left=CssUtil.getNumberVal(rule.getAttrByName("left").getValue())*1000000;var top=CssUtil.getNumberVal(rule.getAttrByName("top").getValue());}

}

else 
{var left=CssUtil.getNumberVal(CssUtil.getStyle(itemEl,"left"))*1000000;var top=CssUtil.getNumberVal(CssUtil.getStyle(itemEl,"top"));}

toSort.push({el:itemEl,sortVal:left+top}
);}

sorter_sortAscending("sortVal",toSort);while(els.length>0)
{els.pop();}

for(var i=0;i<toSort.length;i++)
{els.push(toSort[i].el);}

return els;}
;}



var CssTransitionUtil=new CssTransitionUtilBase();function CssTransitionUtilBase(){this.map={}
;this.getTransition=function(id){if(!id){return null;}

var t=this.map[id];if(!t){t=new Transition();t.id=id;this.map[id]=t;}

return t;}
;this.getTestClassName=function(stateId,stepIndex){var stepCount=stepIndex+1;return "testCssTransId"+stateId+"_"+stepCount;}
;this.runOnload=function(){if(A.isEditMode()){return ;}

var transitions=getMasterCache().getRecordsByType("css_transition_state");for(var i=0;i<transitions.length;i++)
{var record=transitions[i];var t=CssTransitionUtil.getTransition(record.getId());if(record.getField("do_onload").getValue()){t.status="on";}

t.undoTransition();}

}
;{var thisObj=this;var fx=function(){thisObj.runOnload();}
;BodyOnloader.addFxForBeforeLoad(fx);}

}
;

function TransitionInstruction(){this.build=function(parentEl){parentEl.innerHTML="";var holder=cE("div",parentEl);holder.style.fontSize="14px";holder.style.padding="7px";var div=cE("div",holder);div.innerHTML="Changes to tiles style properties, like sizes, colors, positions, will apply to the transitional state, not to the page.";}
;}



function TransitionSteps(id,mc,state){this.id=id;this.mc=mc;this.state=state;this.parentEl;this.options=["all 0.5s ease","all 0.5s linear","all 0.5s ease-in","all 0.5s ease-in-out","all 0.5s cubic-bezier(.5,.1,.5,.1)"];this.build=function(parentEl){if(parentEl){this.parentEl=parentEl;}

this.parentEl.innerHTML="";var holder=cE("div",this.parentEl);holder.style.padding="8px 15px";this.buildSteps(holder);this.addStepButton(holder);}
;this.buildSteps=function(parentEl){var div=cE("div",parentEl);div.className="lp_settingText";this.stepHolder=div;var record=this.mc.getRecord("css_transition_state",this.id);var steps=record.getField("intermediate_steps");var childNames=steps.getChildFieldNames();if(0==childNames.length){div.innerHTML="No steps have been created";return ;}

for(var i=0;i<childNames.length;i++)
{var step=steps.getChildField(childNames[i]);this.buildStep(step,i);}

}
;this.buildStep=function(stepField,index){var isEditing=(this.state.currentStep==index);var div=cE("div",this.stepHolder);sA(div,"index",index);var tBody=createTable(div,"100%");tBody.style.fontSize="14px";var tr=cE("tr",tBody);var thisObj=this;var fx=function(){if(!thisObj.isDragging){return ;}

var draggingEl=thisObj.draggingEl;if(draggingEl==div){return ;}

var isBefore=isBeforeSibling(div,draggingEl);draggingEl.parentNode.removeChild(draggingEl);if(isBefore){div.parentNode.insertBefore(draggingEl,div);}

else 
{insertAfter(draggingEl,div);}

}
;E.mouseenter(div,fx);var td=cE("td",tr);var span=cE("span",td);var label=isEditing?"Editing ":"";label+="Step "+(index+1);span.innerHTML=label;span.style.fontWeight="bold";addUnderlineEvents(span);var thisObj=this;var editFx=function(){thisObj.editStep(index);}
;E.click(span,editFx);if(isEditing){this.buildEditInfo(div,stepField,index);}

var td=cE("td",tr);td.align="right";td.className="lp_link";td.style.fontSize="12px";td.style.cursor="move";td.innerHTML="re-order";this.addDragEvents(td,div);}
;this.addDragEvents=function(grip,stepRow){var thisObj=this;DragUtil.getXOffset=function(dragEl){return 50;}
;DragUtil.getYOffset=function(dragEl){return 0;}
;var createDragElFx=function(){var dragEl=stepRow.cloneNode(true);dragEl.className="a_tools";dragEl.style.border="3px dashed #d6e0f5";dragEl.style.width=grip.parentNode.offsetWidth+"px";return dragEl;}
;var onDragStart=function(){fade_setOpacity(stepRow,50);thisObj.isDragging=true;thisObj.draggingEl=stepRow;}
;var onDragEnd=function(){thisObj.isDragging=false;fade_resetOpacity(stepRow);thisObj.syncStepOrder();thisObj.state.clearSteps();}
;DragUtil.makeDraggable(grip,null,onDragStart,onDragEnd,createDragElFx);}
;this.syncStepOrder=function(){var record=this.mc.getRecord("css_transition_state",this.id);var steps=record.getField("intermediate_steps");var newOrder=[];var children=this.stepHolder.children;for(var i=0;i<children.length;i++)
{var child=children[i];var newField=steps.getChildField(gA(child,"index")).cloneField();newOrder.push(newField);}

steps.clear();for(var i=0;i<newOrder.length;i++)
{steps.insertChildField(null,"COLLECTION",newOrder[i],null,i+1);}

}
;this.buildEditInfo=function(parentEl,stepField,index){var holder=cE("div",parentEl);holder.style.border="1px solid #999999";holder.style.backgroundColor="#F3F3F3";holder.style.padding="6px";var div=cE("div",holder);this.buildPropDD(div,stepField);var div=cE("div",holder);div.style.padding="4px 0 0 6px";var span=cE("span",div);span.style.fontSize="12px";span.innerHTML="delete step";addUnderlineEvents(span);var thisObj=this;var deleteFx=function(){thisObj.deleteStep(index);}
;E.click(span,deleteFx);}
;this.buildPropDD=function(parentEl,stepField){var thisObj=this;var fx=function(value){stepField.getChildField("transition_property").setValue(value);}
;var dd=new FlexDropDown(fx);dd.drawOuterBorder=true;dd.ddAlignment="belowRight";dd.height=25;dd.displayFontSize=12;dd.optionsBoxWidth=this.optionsBoxWidth;dd.optionsBoxHeight=this.optionsBoxHeight;dd.useValueInput=true;dd.doc=(g_params["utw"]=="true")?window.top.document:document;for(var i=0;i<this.options.length;i++)
{var value=this.options[i];this.addOption(value,dd);}

var initial=stepField.getChildField("transition_property").getValue();var ddEl=dd.build(parentEl,this.width-2,initial);}
;this.addOption=function(value,dd){var span=cE("nobr");span.style.fontFamily="helvetica";span.style.fontSize="12px";span.innerHTML=(value==="")?"--":value;span.style.color="black";dd.addOptionEl(span,value,false);return span;}
;this.getRecord=function(){return this.mc.getRecord("css_transition_state",this.id);}
;this.deleteStep=function(index){if(!confirm("Are you sure you want to delete this step?")){return ;}

var record=this.getRecord();record.getField("intermediate_steps").removeChildField(index);this.build();this.state.goToLastStep();}
;this.editStep=function(index){this.state.goToStep(index);this.build();}
;this.addStepButton=function(parentEl){var div=cE("div",parentEl);div.style.paddingTop="6px";var span=cE("span",div);span.className="lp_smallText";span.innerHTML="+ add step";addUnderlineEvents(span);var thisObj=this;var fx=function(){var afterFx=function(){thisObj.build();}
;thisObj.addStep(afterFx);}
;E.click(span,fx);}
;this.addStep=function(){var thisObj=this;var fx=function(stepField){thisObj.state.refreshView();thisObj.build();}
;LiveCssTransitionUtil.addTransitionStep(this.id,this.mc,fx);}
;}



function TransitionRunInfo(id,mc,state){this.id=id;this.mc=mc;this.state=state;this.build=function(parentEl){var record=state.getRecord();var holder=cE("div",parentEl);holder.style.paddingLeft="3px";var div=cE("div",holder);div.style.padding="3px";this.buildOnLoad(div,record);var div=cE("div",holder);div.style.padding="3px";this.buildLoop(div,record);}
;this.buildOnLoad=function(parentEl,record){var tBody=createTable(parentEl);tBody.className="lp_settingSmallText";var tr=cE("tr",tBody);var td=cE("td",tr);record.getField("do_onload").buildField(td,"edit");var td=cE("td",tr);td.innerHTML="Run Onload";}
;this.buildLoop=function(parentEl,record){var tBody=createTable(parentEl);tBody.className="lp_settingSmallText";var tr=cE("tr",tBody);var td=cE("td",tr);record.getField("do_loop").buildField(td,"edit");var td=cE("td",tr);td.innerHTML="Loop when finished";}
;}
;

function TransitionPreview(id,mc,state){this.id=id;this.mc=mc;this.state=state;this.build=function(parentEl){var div=cE("div",parentEl);div.align="center";var tBody=createTable(div);var tr=cE("tr",tBody);var td=cE("td",tr);td.style.padding="4px";var thisObj=this;var backwardFx=function(){thisObj.goBackwards();}
;E.click(td,backwardFx);var span=cE("div",td);span.style.width="0px";span.style.height="0px";span.style.borderTop="10px solid transparent";span.style.borderBottom="10px solid transparent";span.style.borderRight="15px solid black";var td=cE("td",tr);td.style.padding="4px";var forwardFx=function(){thisObj.goForward();}
;E.click(td,forwardFx);var span=cE("div",td);span.style.width="0px";span.style.height="0px";span.style.borderTop="10px solid transparent";span.style.borderBottom="10px solid transparent";span.style.borderLeft="15px solid black";var td=cE("td",tr);td.style.padding="4px";var stopFx=function(){alert("need to implement");}
;E.click(td,stopFx);var span=cE("div",td);span.style.width="20px";span.style.height="20px";span.style.backgroundColor="black";}
;this.getTransition=function(){CssTransitionUtil.getTransition();var t=new Transition();t.id=this.id;t.mc=this.mc;return t;}
;this.goForward=function(){LiveCssTransitionUtil.lockTransitions("transition_preview");this.state.clearSteps();var thisObj=this;var fx=function(){LiveCssTransitionUtil.unlockTransitions("transition_preview");var t=thisObj.getTransition();t.doTransition();}
;window.setTimeout(fx,0);}
;this.goBackwards=function(){LiveCssTransitionUtil.lockTransitions("transition_preview");var thisObj=this;var fx=function(){LiveCssTransitionUtil.unlockTransitions("transition_preview");var t=thisObj.getTransition();t.status="on";t.undoTransition();}
;this.state.goToLastStep(fx);}
;}
;

function TransitionFinish(id,mc,state){this.id=id;this.mc=mc;this.state=state;this.build=function(parentEl){parentEl.innerHTML="";var div=cE("div",parentEl);this.listHolder=div;div.style.padding="6px 15px";this.buildList();this.buildAdd(parentEl);}
;this.buildAdd=function(parentEl){var div=cE("div",parentEl);div.style.padding="6px 15px";var span=cE("span",div);span.className="lp_link";span.style.fontSize="12px";span.style.fontWeight="bold";span.innerHTML="+ add";var thisObj=this;var fx=function(){thisObj.create();thisObj.buildList();}
;E.click(span,fx);}
;this.buildList=function(){var holder=this.listHolder;holder.innerHTML="";var record=this.getRecord();var info=record.getField("finish_info");var tBody=createTable(holder);var fieldNames=info.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var finisher=info.getChildField(fieldNames[i]);var tr=cE("tr",tBody);this.buildFinisher(tr,finisher);}

}
;this.buildFinisher=function(parentTr,finisher){var td=cE("td",parentTr);this.buildTransitionDD(td,finisher);var td=cE("td",parentTr);td.style.paddingLeft="10px";this.buildDelete(td,finisher);}
;this.buildDelete=function(parentEl,finisher){var span=cE("span",parentEl);span.className="lp_link lp_smallText";span.innerHTML="delete";var thisObj=this;var fx=function(){thisObj.deleteFinisher(finisher);}
;E.click(span,fx);}
;this.deleteFinisher=function(finisher){var record=this.getRecord();var info=record.getField("finish_info");info.removeChildField(finisher.name);this.buildList();}
;this.create=function(){var record=this.getRecord();var info=record.getField("finish_info");var finishField=info.addChildField(null,"COLLECTION");finishField.addChildField("type","COLLECTION","transition");var transLink=finishField.addChildField("transition","RECORD_TYPE");transLink.getChildField("type").setValue("css_transition_state");}
;this.buildTransitionDD=function(parentEl,finisher){var holder=cE("div",parentEl);var dd=cE("select",parentEl);dd.style.width="120px";dd.style.fontSize="12px";var thisObj=this;var fx=function(){var value=dd.value||0;var field=finisher.getChildField("transition.id").setValue(value);}
;E.change(dd,fx);var option=cE("option",dd);option.value="";option.innerHTML="--";var itemBuilderFx=function(record){var id=record.getId();if(id==thisObj.id){return ;}

var option=cE("option",dd);option.value=id;option.innerHTML=record.getField("name").getValue();}
;var afterFx=function(){dd.value=finisher.getChildField("transition.id").getValue();}
;LiveCssTransitionUtil.processTransitions(itemBuilderFx,null,afterFx);}
;this.getRecord=function(){return this.mc.getRecord("css_transition_state",this.id);}
;}
;

;;;;;function CssTransitionState(id){this.mc=LiveCss.mc;this.id=id;this.popup;this.width="200px";this.currentStep=-1;this.stepsView;this.build=function(x,y){LiveCssTransitionUtil.lockTransitions("transition_state_view");this.load(x,y);}
;this.load=function(x,y){var mc=this.mc;var input=mc.addRecordToLoad("css_transition_state",this.id);input.addField("intermediate_steps.*.style_sheet.style_sheet");input.addField("*");var thisObj=this;var fx=function(){thisObj.buildPopup(x,y);}
;mc.process(fx);}
;this.getRecord=function(){return this.mc.getRecord("css_transition_state",this.id);}
;this.buildPopup=function(x,y){var popup=new Popup();this.popup=popup;popup.setAtCoord(x,y);popup.title="Edit Transition";popup.titleDragBarClass="lp_popupTitleBar";popup.closeImg="/upload/custom_screens/html5/livepage/close_icon.gif";popup.showX=true;popup.useFrame=false;popup.closeEvents=null;popup.closeEvent=null;popup.disableBg=false;popup.fadeBg=false;popup.hideTopBar=false;popup.width=this.width;popup.ensureOnTop=true;var thisObj=this;popup.closeFx=function(){thisObj.clearSteps();if(thisObj.closeFx){thisObj.closeFx();}

}
;var contentArea=popup.build();contentArea.className="lp_reset";CssUtil.makeNotSelectable(contentArea);this.buildContent(contentArea);popup.align();}
;this.buildContent=function(parentEl){this.goToLastStep();var div=cE("div",parentEl);div.style.padding="8px";this.buildName(div);var div=cE("div",parentEl);div.style.padding="0px 8px 8px 8px";this.buildButtons(div);var div=cE("div",parentEl);this.buildToolBar(div);}
;this.buildToolBar=function(parentEl){var toolBar=new SlidingToolBar();toolBar.persistentKey="lp_settings";toolBar.headerClass="lp_toolbarHeader";toolBar.headerTextClass="lp_toolbarText";toolBar.expandedArrow="/upload/custom_screens/moduleeditor/item_open_icon.gif";toolBar.collapsedArrow="/upload/custom_screens/moduleeditor/item_closed_icon.gif";var view=new TransitionInstruction();toolBar.addMenuItem("Info",view);var view=new TransitionSteps(this.id,this.mc,this);this.stepsView=view;toolBar.addMenuItem("Steps",view);
var view=new TransitionRunInfo(this.id,this.mc,this);toolBar.addMenuItem("Run",view);var view=new TransitionFinish(this.id,this.mc,this);toolBar.addMenuItem("On Finish",view);toolBar.build(parentEl);}
;this.refreshView=function(){this.goToStep(this.currentStep);}
;this.goToLastStep=function(afterFx){var count=this.getRecord().getField("intermediate_steps").getChildFieldCount();this.goToStep((count-1),afterFx);}
;this.goToStep=function(index,afterFx){var finishFx=function(){if(afterFx){afterFx();}

}
;if(index==this.currentStep){finishFx();return ;}

else if(index>this.currentStep){var fx=function(){GridEditMenuPopup.refreshGrid();finishFx();}
;var thisObj=this;var steps=this.getRecord().getField("intermediate_steps");var fieldNames=steps.getChildFieldNames();var cssId;var lastI=Math.min(fieldNames.length,index);var startI=this.currentStep+1;for(var i=startI;i<=lastI;i++)
{var step=steps.getChildField(fieldNames[i]);cssId=step.getChildField("style_sheet.id").getValue();if(i==lastI){StyleSheetUtil.enableSheetById(cssId,fx);}

else 
{StyleSheetUtil.enableSheetById(cssId);}

}

LiveCss.setSheetToWrite(cssId);}

else if(index<this.currentStep){var fx=function(){GridEditMenuPopup.refreshGrid();finishFx();}
;var thisObj=this;var steps=this.getRecord().getField("intermediate_steps");var fieldNames=steps.getChildFieldNames();var cssId;for(var i=this.currentStep;i>index;i--)
{var step=steps.getChildField(fieldNames[i]);cssId=step.getChildField("style_sheet.id").getValue();StyleSheetUtil.disableSheetById(cssId);}

var step=steps.getChildField(index);cssId=step.getChildField("style_sheet.id").getValue();LiveCss.setSheetToWrite(cssId);GridEditMenuPopup.refreshGrid();finishFx();}

this.currentStep=index;}
;this.clearSteps=function(){var record=this.getRecord();if(!record){return ;}

var steps=record.getField("intermediate_steps");var fieldNames=steps.getChildFieldNames();var cssId;for(var i=0;i<fieldNames.length;i++)
{var step=steps.getChildField(fieldNames[i]);cssId=step.getChildField("style_sheet.id").getValue();StyleSheetUtil.removeSheetById(cssId);}

this.currentStep=-1;LiveCss.clearSheetToWrite();this.stepsView.build();}
;this.buildButtons=function(parentEl){var div=cE("div",parentEl);var button=cE("button",div);button.className="lp_smallDarkButton";button.innerHTML="Save";var thisObj=this;var fx=function(){thisObj.saveAndExit();}
;E.click(button,fx);var button=cE("button",div);button.className="lp_smallDarkButton";button.innerHTML="Cancel";var thisObj=this;var fx=function(){thisObj.cancelAndExit();}
;E.click(button,fx);var span=cE("span",div);span.className="lp_smallText lp_link";CssUtil.setFloat(span,"right");span.style.position="relative";span.style.top="12px";span.innerHTML="delete";var fx=function(){thisObj.deleteRecord();}
;E.click(span,fx);}
;this.cancelAndExit=function(){this.clearSteps();var cssIds=this.getCssIds();for(var i=0;i<cssIds.length;i++)
{LiveCss.clearSheet(cssIds[i]);}

this.exit();}
;this.exit=function(){var coord=this.popup.getPosition();this.popup.close();LiveCssTransitionUtil.unlockTransitions("transition_state_view");var popup=new CssTransitionsPopup();popup.build(coord.x,coord.y);GridEditMenuPopup.refreshGrid();}
;this.saveAndExit=function(){var thisObj=this;var fx=function(){thisObj.clearSteps();thisObj.exit();}
;this.save(fx);}
;this.refactor=function(){var cssIds=this.getCssIds();for(var i=0;i<cssIds.length;i++)
{var sheet=LiveCss.getStyleSheetById(cssIds[i]);if(!sheet){continue;}

var cls=new LiveCssClass();cls.className=CssTransitionUtil.getTestClassName(this.id,i);cls.update("z-index",i+1);sheet.updateClass(cls);}

}
;this.indexSels=function(){var selectors={}
;var record=this.getRecord();var steps=record.getField("intermediate_steps");var fieldNames=steps.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var step=steps.getChildField(fieldNames[i]);var stepId=step.getChildField("style_sheet.id").getValue();var sheet=LiveCss.getStyleSheetById(stepId);if(!sheet){continue;}

var map=sheet.getClassNameMap();for(var j in map)
{selectors[j]=true;}

}

var sField=record.getField("selectors");sField.clear();for(var i in selectors)
{sField.addChildField(null,"TEXT",i);}

}
;this.save=function(afterFx){this.indexSels();var thisObj=this;var fx=function(){thisObj.finishSave(afterFx);}
;this.goToLastStep(fx);}
;this.finishSave=function(afterFx){this.refactor();LiveCss.sync(LivePage.mc);var mc=new MiniCache();var testRecord=this.getRecord();var test2=testRecord.cloneRecord(mc);var record=this.getRecord().cloneRecord(mc);record.getField("name").setValue(this.nameInput.value);var steps=record.getField("intermediate_steps");var fieldNames=steps.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var step=steps.getChildField(fieldNames[i]);var stepId=step.getChildField("style_sheet.id").getValue();var sheet=LiveCss.getStyleSheetById(stepId);sheet.sync(mc);}

var thisObj=this;var fx=function(){LiveCss.clearRealSheets();if(afterFx){afterFx();}

}
;mc.process(fx);}
;this.getCssIds=function(){var cssIds=[];var record=this.getRecord();var steps=record.getField("intermediate_steps");var fieldNames=steps.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var step=steps.getChildField(fieldNames[i]);cssIds.push(step.getChildField("style_sheet.id").getValue());}

return cssIds;}
;this.deleteRecord=function(){var cssIds=this.getCssIds();for(var i=0;i<cssIds.length;i++)
{this.mc.deleteRecord("style_sheets",cssIds[i]);LiveCss.mc.clearRecord("style_sheets",cssIds[i]);}

this.mc.deleteRecord("css_transition_state",this.id);LiveCss.mc.clearRecord("css_transition_state",this.id);this.clearSteps();this.mc.process();this.exit();}
;this.buildName=function(parentEl){var record=this.getRecord();var div=cE("div",parentEl);div.className="lp_smallText";div.style.fontWeight="bold";div.innerHTML="State Name";var div=cE("div",parentEl);div.style.marginTop="3px";var props={value:record.getField("name").getValue()}
;var input=buildTextInput(div,props);input.placeholder="Enter Name";this.nameInput=input;}
;}


function CssTransitionsPopup(){this.listHolder;this.mc=new MiniCache();this.maxListHeight="500px";this.popup;this.build=function(x,y){var popup=new Popup();this.popup=popup;popup.setAtCoord(x,y);popup.title="CSS Transitions";popup.titleDragBarClass="lp_popupTitleBar";popup.closeImg="/upload/custom_screens/html5/livepage/close_icon.gif";popup.showX=true;popup.useFrame=false;popup.closeEvents=["onclick","oncontextmenu"];popup.closeEvent=null;popup.disableBg=true;popup.fadeBg=false;popup.hideTopBar=false;popup.width=this.width;popup.ensureOnTop=true;var thisObj=this;popup.closeFx=function(){if(thisObj.closeFx){thisObj.closeFx();}

}
;var contentArea=popup.build();contentArea.className="lp_reset";CssUtil.makeNotSelectable(contentArea);this.buildContent(contentArea);popup.align();}
;this.load=function(afterFx){var mc=this.mc;var moduleIds=LivePage.getAllModuleIds();var listInput=mc.addListToLoad("css_transition_state","transitions",null,null,"name","asc");for(var i=0;i<moduleIds.length;i++)
{listInput.addOrSearchTerm("module",moduleIds[i],SEARCHTERM_EXACT_MATCH,"");}

var thisObj=this;var fx=function(){afterFx();}
;mc.process(fx);}
;this.buildContent=function(parentEl){var div=cE("div",parentEl);div.style.overflow="auto";div.style.maxHeight=this.maxListHeight;this.listHolder=div;this.refreshList();}
;this.buildList=function(){var list=this.mc.getListByName("transitions");var holder=this.listHolder;var ids=list.ids;if(ids.length==0){var div=cE("div",holder);div.align="center";div.style.width="175px";div.style.padding="15px";div.innerHTML="No transitions have been created";}

else 
{for(var i=0;i<ids.length;i++)
{this.drawListItem(ids[i]);}

}

this.popup.align();}
;this.drawListItem=function(recordId){var record=this.mc.getRecord("css_transition_state",recordId);var holder=this.listHolder;var div=cE("div",holder);div.className="lp_link";div.style.fontWeight="bold";div.style.padding="6px 15px 6px 15px";div.style.borderBottom="1px solid #999999";div.innerHTML=record.getField("name").getValue()||"Untitled";var thisObj=this;var fx=function(){thisObj.loadATransition(recordId);}
;E.click(div,fx);}
;this.loadATransition=function(id){var coord=this.popup.getPosition();this.popup.close();var t=new CssTransitionState(id);t.build(coord.x,coord.y);}
;this.refreshList=function(){var thisObj=this;var fx=function(){thisObj.buildList();}
;this.load(fx);}
;this.close=function(){this.popup.close();}
;}



;;;var LiveCssTransitionUtil=new LiveCssTransitionUtilBase();function LiveCssTransitionUtilBase(){this.mc=LiveCss.mc;this.lockNames={}
;this.lockTransitions=function(lockName){if(this.areTransitionsOn()){var doc=getParentDocument(this.gridEl);CssUtil.addClassToEl(document.body,"a-meta-no-transitions");}

if(!this.lockNames[lockName]){this.lockNames[lockName]=0;}

this.lockNames[lockName]++;}
;this.unlockTransitions=function(lockName){if(!this.lockNames[lockName]){this.lockNames[lockName]--;if(0==this.lockNames[lockName]){delete(this.lockNames[lockName]);}

}

if(JsUtil.isEmpty(this.lockNames)){var doc=getParentDocument(this.gridEl);CssUtil.removeClassFromEl(document.body,"a-meta-no-transitions");}

}
;this.areTransitionsOn=function(){return !CssUtil.elHasClass(document.body,"a-meta-no-transitions");}
;this.create=function(moduleId,afterFx){var template=this.mc.getTemplate("css_transition_state");if(template){this.createRecord(moduleId,afterFx);}

else 
{var thisObj=this;var fx=function(){thisObj.createRecord(moduleId,afterFx);}
;this.loadTemplate(fx);}

}
;this.createRecord=function(moduleId,afterFx){var mc=this.mc;var record=mc.createRecord("css_transition_state");record.getField("module.id").setValue(moduleId);var thisObj=this;var fx=function(){var finishFx=function(){afterFx(record.getId());}
;thisObj.addTransitionStep(record.getId(),mc,finishFx);}
;mc.process(fx)
}
;this.addTransitionStep=function(stateId,mc,afterFx){var record=mc.createRecord("style_sheets");var thisObj=this;var fx=function(){thisObj.afterAddStep(record,stateId,mc,afterFx);}
;mc.process(fx);}
;this.afterAddStep=function(cssRecord,stateId,mc,afterFx){var record=mc.getRecord("css_transition_state",stateId);var steps=record.getField("intermediate_steps");var step=steps.addChildField(null,"COLLECTION");var cssField=step.addChildField("style_sheet","RECORD_TYPE");cssField.getChildField("type").setValue("style_sheets");cssField.getChildField("id").setValue(cssRecord.getId());step.addChildField("transition_property","TEXT","all 0.5s ease-in");if(afterFx){afterFx(step);}

}
;this.processTransitions=function(itemBuilderFx,noResultsFx,afterFx){var list=this.mc.getListByName("transition_list");if(list){this.afterListLoad(itemBuilderFx,noResultsFx,afterFx);}

else 
{this.load(itemBuilderFx,noResultsFx,afterFx);}

}
;this.load=function(itemBuilderFx,noResultsFx,afterFx){var mc=this.mc;var moduleIds=LivePage.getAllModuleIds();var listInput=mc.addListToLoad("css_transition_state","transition_list",null,null,"name","asc");for(var i=0;i<moduleIds.length;i++)
{listInput.addOrSearchTerm("module",moduleIds[i],SEARCHTERM_EXACT_MATCH,"");}

var thisObj=this;var fx=function(){thisObj.afterListLoad(itemBuilderFx,noResultsFx,afterFx);}
;mc.process(fx);}
;this.afterListLoad=function(builderFx,noResultsFx,afterFx){var list=this.mc.getListByName("transition_list");var ids=list.ids;if(ids.length==0){if(noResultsFx){noResultsFx();}

}

else 
{for(var i=0;i<ids.length;i++)
{var record=this.mc.getRecord("css_transition_state",ids[i]);builderFx(record);}

}

if(afterFx){afterFx();}

}
;this.loadTemplate=function(afterFx){this.mc.addTemplateToLoad("css_transition_state");this.mc.process(afterFx);}
;}
;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;var LivePage=new LivePageBase();function LivePageBase(){this.mc=window.parent["mc"]||new MiniCache();this.moduleIdsToSync={}
;this.fieldsToSync={}
;this.cyclesToSync={}
;
this.fragsByType={}
;
this.moduleFrags=[];
this.moduleIds=[];this.fragInfo=g_moduleInfo.fragInfo;this.pageId;this.pageModuleId;this.templateModuleId;this.resizer;this.iconBar;this.onClick;
this.isChanged=false;this.init=function(){this.registerFragsByType();this.initTagHandlers();this.scroll();this.resizer=new ElementResizer();this.disableLinks();this.setClick();this.setMouseDown();KeyHandler.init();ContainerHandler.init();RightClickPageOptions.init();}
;
this.disableLinks=function(){var hrefEls=gL("a");for(var i=0;i<hrefEls.length;i++)
{var linkEl=hrefEls[i];this.disableLink(linkEl);}

}
;
this.disableLink=function(linkEl){var hrefValue=gA(linkEl,"href");if(!hrefValue){return ;}

var noHref=window.location.href+"#";sA(linkEl,"a_href",hrefValue);sA(linkEl,"href","#");var parentNode=linkEl.parentNode;if(null!=parentNode&&parentNode.className.indexOf("page")<0){this.attachHref(linkEl);}

var thisObj=this;var cancelClick=function(){return false;}
;E.click(linkEl,cancelClick);}
;this.setOnClick=function(fx){this.onClick=fx;}
;
this.attachHref=function(linkEl){var popup=new HoverPopup(linkEl);popup.alignment="aboveLeft";popup.showDelay=500;popup.hideDelay=0;popup.onShow=function(parentEl){var div=cE("div",parentEl);div.className="lp_saQuickInfoBox";var span=cE("span",div);span.style.cursor="pointer";span.innerHTML="Open Link";var openFx=function(){popup.isOverEl=false;popup.isOverPopup=false;popup.forceClose();var params={}
;var newUrl=gA(linkEl,"a_href");if(newUrl.indexOf("http")<0){params.mode="visual_edit";}

var url=UrlUtil.addParamsToUrl(newUrl,params);window.open(url);}
;E.click(span,openFx);var span=cE("span",div);span.innerHTML="|";span.style.padding="0px 5px";var span=cE("span",div);span.style.cursor="pointer";span.innerHTML="Edit Link";var editFx=function(){new LinkPopup(linkEl).build();}
;E.click(span,editFx);}
;popup.init();}
;this.initTagHandlers=function(){LiveFieldHandler.initHandler(this.mc);LiveCycleHandler.initHandler();LiveNavHandler.initHandler();LiveComponentHandler.initHandler();}
;this.exec=function(cmd){var range=RangeUtil.getSelectedRange();var editEl=range.commonAncestorContainer;var origValue=editEl.contentEditable;var wasEditable=("true"==origValue);if(!wasEditable){editEl.contentEditable="true";}

document.execCommand(cmd,false,null);if(!wasEditable){editEl.contentEditable=origValue;}

window.focus();}
;this.setClick=function(){var thisObj=this;var fx=function(e){thisObj.handleClick(e);}
;var settings={stop:false}
;E.click(document.body,fx,settings);var fx=function(e){thisObj.handleMouseUp(e);}
;var settings={stop:false}
;E.mouseup(document.body,fx,settings);}
;this.cancelClick=false;this.handleMouseUp=function(e){this.cancelClick=false;if(this.onClick){return ;}

if(!e){return ;}

if(!LivePage.isBeforeEOF(e.srcElement)&&e.srcElement.tagName!="BODY"){return ;}

if(e.button!=0){return ;}

var yPos=document.body.scrollTop;var xPos=document.body.scrollLeft;var isEditing=EditUtil.handleMouseUp(e);if(isEditing){this.cancelClick=true;}

window.scrollTo(xPos,yPos);}
;this.handleClick=function(e){if(this.cancelClick){this.cancelClick=false;return ;}

if(this.onClick){if(!this.onClick(e)){this.onClick=null;}

return ;}

if(!e){return ;}

if(!LivePage.isBeforeEOF(e.srcElement)&&e.srcElement.tagName!="BODY"){return ;}

var element=e.srcElement;if("IMG"==element.tagName){this.frameImage(element);}

}
;
this.setMouseDown=function(){var thisObj=this;var fx=function(e){thisObj.handleMouseDown(e);}
;var settings={stop:false}
;E.mousedown(document.body,fx,settings);}
;this.handleMouseDown=function(e){if(!LivePage.isBeforeEOF(e.srcElement)){return ;}

EditUtil.handleMouseDown(e);}
;this.scroll=function(){if('undefined'==typeof(g_params)||null==g_params){return ;}

var scrollTop=parseInt(g_params.scrollTop);if(!scrollTop){return ;}

var windowHeight=window.innerHeight||document.body.clientHeight;var div=cE("div",document.body);div.style.position="absolute";div.style.top=(windowHeight+scrollTop)+"px";div.scrollIntoView(false);div.parentNode.removeChild(div);}
;this.save=function(afterFx){var thisObj=this;var fx=function(){var livePage=new LivePageSaver(thisObj);var saveFx=function(){EditUtil.reset();afterFx();}
;livePage.save(saveFx);thisObj.isChanged=false;}
;sl_loadScript('/0/le8501_0.js',fx);fx;}
;
this.findEndOfFileNode=function(){var marker=document.getElementById("sa_eof");var temp=marker.previousSibling;while(temp&&temp.nodeType!=1)
{temp=temp.previousSibling;}

if(!temp){return marker;}

var eof;if(temp.tagName.toLowerCase()=="script"){eof=temp;}

else 
{eof=marker;}

return eof;}
;this.isBeforeEOF=function(element){if(element.tagName=="BODY"){return false;}

var ancestor=element;if(!ancestor.parentNode){return false;}

while(ancestor.parentNode.tagName!="BODY")
{ancestor=ancestor.parentNode;if(!ancestor){return false;}

}

return isBeforeSibling(ancestor,this.findEndOfFileNode());}
;this.isMetaEl=function(element){while(element&&element.parentNode&&element.parentNode.tagName!="BODY")
{element=element.parentNode;}

if(!element.parentNode){return false;}

var eof=this.findEndOfFileNode();return !isBeforeSibling(element,eof)
}
;this.isElHidden=function(element){return (element.offsetWidth==0||element.offsetHeight==0);}
;this.createImageFramer=function(){this.resizer=new ElementResizer();}
;this.frameImage=function(image){this.resizer.frame(image);}
;this.goToReadOnly=function(){var params={"mode":"normal"}
;window.location.href=UrlUtil.addParamsToUrl(window.location.href,params)
}

this.getModuleHolderEl=function(moduleId){if(moduleId==this.templateModuleId||moduleId==this.pageModuleId){return document.body;}

var moduleFrag=this.moduleFrags[moduleId];if(null!=moduleFrag){return gE("#"+moduleFrag.elId);}

for(var i in this.fragInfo)
{var aFrag=this.fragInfo[i];if(aFrag.dbId==moduleId&&aFrag.fragType=="module"){return document.getElementById(aFrag.elId);}

}

}
;this.setFragToSave=function(fragInfo){var fragType=(fragInfo.fieldType&&fragInfo.fieldType=="MODULE")?"module":fragInfo.fragType;var thisObj=this;var fx=thisObj[this.fragSetSaveFxs[fragType]];if(fx){var args=[fragInfo];return fx.apply(this,args);}

}
;this.fragSetSaveFxs={"cycle":"setCycleToSave","module":"setModuleToSave","field":"setFieldToSave"}
;this.setFieldToSave=function(fieldFragInfo){var recordIndex=fieldFragInfo.recordType+fieldFragInfo.dbId;var recordFields=this.fieldsToSync[recordIndex];if(!recordFields){var recordFields={}
;this.fieldsToSync[recordIndex]=recordFields;recordFields.type=fieldFragInfo.recordType;recordFields.id=fieldFragInfo.dbId;recordFields.fields={}
;}

recordFields.fields[fieldFragInfo.params.name]=fieldFragInfo;}
;
this.setModuleToSave=function(fragInfo){var moduleId=(fragInfo.fragType=="field")?fragInfo.moduleId:fragInfo.dbId;this.moduleIdsToSync[moduleId]=true;}
;this.setCycleToSave=function(fragInfo){fragInfo.liveCycleObj.setToSave();}
;this.setElementToSave=function(element){this.isChanged=true;var fragInfo=this.findFragToSave(element);if(!fragInfo){var baseModuleId=this.getBaseModuleId();this.moduleIdsToSync[baseModuleId]=true;}

else 
{this.setFragToSave(fragInfo);if(element.id==fragInfo.elId){this.setElementToSave(element.parentElement);}

}

}
;this.getBaseModuleId=function(){return this.templateModuleId||this.pageModuleId;}
;this.findFragToSave=function(element){while(element.tagName!="BODY")
{var fragInfo=A.getFragInfo(element.id);if(fragInfo&&this.fragSetSaveFxs[fragInfo.fragType]){return fragInfo;}

element=element.parentNode;}

return null;}
;this.findContainingModuleId=function(element){while(element&&element.tagName!="BODY")
{var fragInfo=A.getFragInfo(element.id);if(fragInfo&&(fragInfo.fragType=="module"||(fragInfo.fragType=="field"&&fragInfo.fieldType=="MODULE"))){return (fragInfo.fragType=="module")?fragInfo.dbId:fragInfo.moduleId;}

element=element.parentNode;}

return this.pageModuleId;}
;this.loadData=function(afterFx){this.pageId=getMasterCache().values.mainPage;this.mc.addTemplateToLoad("module");this.mc.addTemplateToLoad("page");this.mc.addTemplateToLoad("style_sheets");var recordInput=this.mc.addRecordToLoad("page",this.pageId);recordInput.addField("*");recordInput.addField("screen_module.*");recordInput.addField("template.module");var thisObj=this;var fx=function(){var pageRecord=thisObj.mc.getRecord("page",thisObj.pageId);if(pageRecord){var templateMIdField=pageRecord.getField("template.module.id");if(null!=templateMIdField){thisObj.templateModuleId=templateMIdField.getValue();}

thisObj.pageModuleId=pageRecord.getField("screen_module.module.id").getValue();}

else 
{thisObj.pageModuleId=g_params.module_id;}

afterFx();}
;this.mc.process(fx);}
;
this.insertATag=function(parentEl,html){showProgressIcon("inserting html");var aHtmlGetter=new AHtmlGetter(html);var thisObj=this;var afterExecute=function(data){thisObj.processATagInsert(parentEl,data);}
;aHtmlGetter.execute(afterExecute);}
;
this.processATagInsert=function(parentEl,data){var fragInfo=this.fragInfo;var html=data.html;eval("var jsData= "+data.json);var mFragInfo=jsData.fragInfo;for(var fragId in mFragInfo)
{fragInfo[fragId]=mFragInfo[fragId];}

var styles=data.styles;var scripts=data.scripts;if(styles.length==0&&scripts.length==0){this.insertHtml(parentEl,html,mFragInfo);}

else 
{this.injectResources(styles,scripts,mFragInfo,parentEl,html);}

}
;
this.injectResources=function(styles,scripts,fragInfo,parentEl,html){var headEl=document.getElementsByTagName('head')[0];for(var i=0;i<styles.length;i++)
{var cssEl=document.createElement("link");cssEl.rel="stylesheet"
cssEl.href=styles[i];cssEl.type="text/css";aE(headEl,cssEl);}

this.triggerScriptLoad(scripts,0,fragInfo,parentEl,html);}
;
this.triggerScriptLoad=function(scripts,index,fragInfo,parentEl,html){if(scripts.length==0){this.insertHtml(parentEl,html,fragInfo);return ;}

var scriptEl=document.createElement("script");scriptEl.src=scripts[index];scriptEl.type="text/javascript";var thisObj=this;var onLoad=function(){if(index==[scripts.length-1]){thisObj.insertHtml(parentEl,html,fragInfo);}

else 
{thisObj.triggerScriptLoad(scripts,index+1,fragInfo,parentEl,html);}

}
;aE(document.body,scriptEl);E.add(scriptEl,"load",onLoad);}
;
this.insertHtml=function(parentEl,html,fragInfo){var placeHolder=iE("span",parentEl,0);replaceNodeWithHtml(html,placeHolder);ATagInitializer.initFromJsData(fragInfo);for(var fragId in fragInfo)
{var newEl=gE("#"+fragId);this.setElementToSave(newEl);if(CssUtil.elHasClass(parentEl,"a_container")){BlockHandler.initBlock(newEl);}

}

hideProgressIcon();}
;
this.hasChanged=function(){return this.isChanged;}
;
this.getRegistryItems=function(registryName){return A.registryByName[registryName];}
;
this.removeFragInfo=function(elId){delete(g_moduleInfo.fragInfo[elId]);}
;
this.registerFragsByType=function(){var frags=this.fragInfo;for(var fragId in frags)
{this.registerFragByType(frags[fragId]);}

}
;
this.getAllModuleIds=function(){this.moduleIds.push(this.pageModuleId);return this.moduleIds;}
;
this.registerFragByType=function(fragInfo){var fragType=(fragInfo.fragType=="module"||(fragInfo.fieldType&&fragInfo.fieldType=="MODULE"))?"module":fragInfo.fragType;if(fragType=="module"){var moduleId=fragInfo.moduleId||fragInfo.dbId;this.moduleFrags[moduleId]=fragInfo;this.moduleIds.push(moduleId);}

var fragsByType=this.fragsByType[fragType]
if(null==fragsByType){fragsByType=[];this.fragsByType[fragType]=fragsByType;}

fragsByType.push(fragInfo);}
;this.init();}
;;{var sl_onAfterFx=sl_onAfterLoadFx['/0/le8498_0.js'];if(sl_onAfterFx){sl_onAfterFx();}}