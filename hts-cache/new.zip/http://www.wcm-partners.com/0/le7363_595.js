
function ajax_ProcessCache(cache,requestHandler){var isAsync=(requestHandler!=null)?true:false;var xmlRequest=ajax_getXMLHttpRequest();var url="ProcessCache.ajax";xmlRequest.open("POST",url,isAsync);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("cache="+cache);if(!isAsync){do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_addToCache(xmlRequest.responseText);}

}

}

while(xmlRequest.readyState!=4)}

else 
{xmlRequest.onreadystatechange=function(){if(xmlRequest.readyState==4){if(xmlRequest.status==200){var success=ajax_addToCache(xmlRequest.responseText);if(success){requestHandler();}

}

}

}

}

}

function ajax_addToCache(obj){var errorOccured="error_"+"ocurred"
var sessionExpired="session_"+"expired";if(obj==sessionExpired){alert("Your session has expired and you will be re-directed to the home page.");location.reload("");return false;}

else if(obj.indexOf(errorOccured)!=-1){if(errorOccured==obj){alert("A problem has occured and we have been notified. Please try again later");}

else 
{alert(obj);}

}

else 
{var temp=eval(obj);ajax_updateCache(cache);}

return true;}

function ajax_updateCache(cache){var recordsById=cache.recordsById;for(var recordId in recordsById)
{recordsById[recordId].ownerCache=g_cache;recordsById[recordId].init();g_cache.recordsById[recordId]=recordsById[recordId];}

var recordsByName=cache.recordsByName;for(var recordName in recordsByName)
{g_cache.recordsByName[recordName]=recordsByName[recordName];}

var templates=cache.templates;for(var type in templates)
{templates[type].ownerCache=g_cache;g_cache.templates[type]=templates[type];}

var dynTables=cache.dynTables;for(var type in dynTables)
{dynTables[type].ownerCache=g_cache;dynTables[type].init();g_cache.dynTables[type]=dynTables[type];}

var listsByName=cache.listsByName;for(var name in listsByName)
{listsByName[name].ownerCache=g_cache;listsByName[name].init();g_cache.listsByName[name]=listsByName[name];}

var listsByType=cache.listsByType;for(var type in listsByType)
{listsByType[type].ownerCache=g_cache;listsByType[type].init();g_cache.listsByType[type]=listsByType[type];}

g_cache.lastUpdate=new Date().getTime();cache=null;}

function ajax_doNothing(){}


function ajax_getXMLHttpRequest(){var xmlreq=null;if(window.XMLHttpRequest){xmlreq=new XMLHttpRequest();}

else if(window.ActiveXObject){try
{xmlreq=new ActiveXObject("Msxml2.XMLHTTP");}

catch(e)
{xmlreq=new ActiveXObject("Microsoft.XMLHTTP");}

}

else 
{alert("This browser does not support this feature");}

return xmlreq;}

function ajax_getReadyStateHandler(xmlRequest,responseXmlHandler){var requestHandler=function(){if(xmlRequest.readyState==4){if(xmlRequest.status==200){responseXmlHandler(xmlRequest.responseText);}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

return requestHandler;}


var constants_CUSTOM_SCREEN_TABLE_NAME="custom_screens";var constants_JAVASCRIPT_GLOBALS_TABLE_NAME="js_globals";var constants_EDITOR_PATH="editor";var constants_JS_EDITOR_PATH="jseditor";var constants_CACHE_NODE_NAME="cache";var constants_TO_LOAD_NOAD_NAME="to_load";var constants_TO_SAVE_NODE_NAME="to_save";var constants_TO_DELETE_NODE_NAME="to_delete"
var constants_TO_ADD_NODE_NAME="to_add";var constans_TO_UPDATE_NODE_NAME="to_update";var constants_PRIMARY_TYPE_ATTRIBUTE="primary_type";var constants_PRIMARY_ID_ATTRIBUTE="id";var constants_DYNTABLES_NODE_NAME="dyntables";var constants_RECORDS_NODE_NAME="records";var constants_LISTS_NODE_NAME="lists";var constants_TABLE_NODE_NAME="table";var constants_NAME_ATTRIBUTE="name";var constants_DISPLAY_NAME_ATTRIBUTE="displayName";var constants_RECORD_NODE_NAME="records";var constans_TYPE_ATTRIBUTE="type"
var constants_ID_ATTRIBUTE="id";var contants_FIELD_NODE_NAME="f";var contants_FIELD_TYPE_ATTRIBUTE="type";var contants_NAME_ATTRIBUTE="name";var contants_DISPLAY_NAME_ATTRIBUTE="dn";var contants_DISPLAY_ORDER_ATTRIBUTE="do";var contants_IS_MULTIPLE_ATTRIBUTE="multiple";var contants_VALUE_ATTRIBUTE="value";var contants_NEXT_UNNAMED_CHILD_COUNT_ATTRIBUTE="nucc";var contants_IS_STATIC_ATTRIBUTE="is_static";var constants_LESS_THAN_CHAR="!#"+"lessthanForXml!";var constants_GREATER_THAN_CHAR="!#"+"greaterthanForXml!";var constants_PERCENTAGE_SIGN="!#"+"percentagesing!";var constants_AND_SIGN="!#"+"andsign!";var constants_PLUS_SIGN="!#"+"plussign!";var constants_SPECIFIC_CAT_DEF="specific_category_definition";
function util_isInDom(element){if(!element.parentNode){return false;}

else if(element.parentNode.tagName){return true;}

else 
{return false;}

}

function util_getLength(aList){var counter=0;for(var i in aList)
{counter++;}

return counter;}

function util_replaceAllString(aString,stringValue,replaceString){var re=eval("/"+stringValue+"/g");return aString.replace(re,replaceString);}

function util_addUnderlineEvent(element){element.onmouseover=function(){element.style.textDecoration="underline"}
;element.onmouseout=function(){element.style.textDecoration=""}
;}

var g_processedHtmlForXml=null;function util_formatForXml(value){alert("this function should be used. Please notify Evan");var strForXml=g_processedHtmlForXml;var htmlString=value;htmlString=util_replaceAll(htmlString,"%",constants_PERCENTAGE_SIGN);htmlString=util_replaceAll(htmlString,"&",constants_AND_SIGN);htmlString=util_replaceAll(htmlString,"+",constants_PLUS_SIGN);ajax_getStringForXml(htmlString);var maxTimeTrying=2000;var startTime=new Date();while(null==strForXml&&((new Date()-startTime)<maxTimeTrying))
{strForXml=g_processedHtmlForXml;}

g_processedHtmlForXml=null;return strForXml;}

var util_mswordchars=[]
util_mswordchars[String.fromCharCode(8220)]='"';util_mswordchars[String.fromCharCode(8221)]='"';util_mswordchars[String.fromCharCode(8216)]="'";util_mswordchars[String.fromCharCode(8217)]="'";util_mswordchars[String.fromCharCode(8211)]="-";util_mswordchars[String.fromCharCode(8212)]="--";util_mswordchars[String.fromCharCode(189)]="1/2";util_mswordchars[String.fromCharCode(188)]="1/4";util_mswordchars[String.fromCharCode(190)]="3/4";util_mswordchars[String.fromCharCode(169)]="(C)";util_mswordchars[String.fromCharCode(174)]="(R)";util_mswordchars[String.fromCharCode(8230)]="...";function util_removeMsCharacters(value){for(var msChar in util_mswordchars)
{value=util_replaceAll(value,msChar,util_mswordchars[msChar])
}

return value;}

function util_removeEmbededScripts(html){var scriptStart=html.indexOf("<SCRIPT");var scriptEnd=html.indexOf("<"+"/SCRIPT>");while(scriptStart!=-1&&scriptEnd!=-1)
{var scriptString=html.substring(scriptStart,(scriptEnd+9));html=html.replace(scriptString,"");scriptStart=html.indexOf("<SCRIPT");scriptEnd=html.indexOf("<"+"/SCRIPT>");}

var scriptStart=html.indexOf("<script");var scriptEnd=html.indexOf("<"+"/script>");while(scriptStart!=-1&&scriptEnd!=-1)
{var scriptString=html.substring(scriptStart,(scriptEnd+9));html=html.replace(scriptString,"");scriptStart=html.indexOf("<script");scriptEnd=html.indexOf("<"+"/script>");}

return html;}

function util_addHiddenInput(name,value,container){var input=document.createElement("input")
input.type="hidden";input.value=value;input.name=name;container.appendChild(input);}

function util_clearElement(element){for(var i=element.childNodes.length-1;i>=0;i--)
{element.removeChild(element.childNodes[i]);}

}

function util_openFieldXmlTag(field){var xml=constants_LESS_THAN_CHAR+"f ";xml+="name='"+field.name+"' ";xml+=" dn='"+util_formatForXmlValue(field.displayName);xml+="' type='"+field.TYPE;xml+="' do='"+field.displayOrder+"'";var valueStr=(field.value==null)?">":" value='"+util_formatForXmlValue(field.value)+"'>";xml+=valueStr;return xml;}

function util_closeFieldXmlTag(){return constants_LESS_THAN_CHAR+"/f>";}

var util_reservedXmlChars=new Array();util_reservedXmlChars["'"]='!#'+'singlequote!';util_reservedXmlChars['<']='!#'+'lessthan!';util_reservedXmlChars['>']='!#'+'greaterthan!';util_reservedXmlChars['"']='!#'+'doublequote!';util_reservedXmlChars['&']='!#'+'andsign!';util_reservedXmlChars['%']='!#'+'percentagesing!';util_reservedXmlChars['+']='!#'+'plussign!';util_reservedXmlChars['&nbsp;']=' ';function util_formatValueForHtml(value){if(value==true||value==false){return value;}

else if(value==undefined||value==null||value==""){return "";}

for(var i in util_reservedXmlChars)
{if(i=='&nbsp;'){continue;}

value=util_replaceAll(value,util_reservedXmlChars[i],i);}

return value;}

function util_formatForXmlValue(value){if(value==true||value==false){return value;}

else if(value==undefined||value==null||value==""){return "";}

value=util_newReplaceAll(value,"'","!#"+"singlequote!");value=util_newReplaceAll(value,"<","!#"+"lessthan!");value=util_newReplaceAll(value,">","!#"+"greaterthan!");value=util_newReplaceAll(value,"\"","!#"+"doublequote!");value=util_newReplaceAll(value,"&","!#"+"andsign!");value=util_newReplaceAll(value,"%","!#"+"percentagesing!");value=util_newReplaceAll(value,"\n","!#"+"breakline!");value=util_newReplaceAll(value,"\\+","!#"+"plussign!");value=util_newReplaceAll(value,"&nbsp;"," ");
return value;}

function util_newReplaceAll(aString,replaceStr,replaceValue){if("string"!=typeof(aString)){return aString;}

var rE=new RegExp(replaceStr,"g");return aString.replace(rE,replaceValue);}


function util_replaceAll(aString,replaceStr,replaceValue){try
{var index=aString.indexOf(replaceStr);}

catch(e)
{return aString;}

while(index>-1)
{aString=aString.replace(replaceStr,replaceValue);index=aString.indexOf(replaceStr,index+replaceValue.length);}

return aString;}

;;;;var g_types;var g_cache;if(window["globals_webappPath"]==undefined){var globals_webappPath="";}

if(!g_currentDateTime){var g_currentDateTime=new cache_CurrentDateTime();}

function core_Cache(primaryType,primaryId,screenType,userHandle,userId,year,month,date,time){if(year){g_currentDateTime.month=month;g_currentDateTime.year=year;g_currentDateTime.date=date;g_currentDateTime.time=time;}

this.lastUpdate=new Date().getTime();this.isUpdated=false;this.primaryType=primaryType;this.primaryId=primaryId;this.screenType=screenType;this.userHandle=userHandle;this.userId=userId;this.isUpdated=false;this.typeList=null;this.fieldTypes=null;this.mainDynTable=null;this.mainRecord=null;this.mainList=null;this.recordsById=new Array();this.recordsByName=new Array();this.recordsByKey=new Array();this.dynTables=new Array();this.listsByType=new Array();this.listsByName=new Array();this.templates=new Array();this.dyntablesToDelete=new Array();this.dyntablesToLoad=new Array();this.dyntablesToSave=new Array();this.listsToLoad=new Array();this.recordsByType=new Array();this.recordsToSave=new Array();if(window.pop_Popup){this.popup=(g_cache==null)?new pop_Popup():g_cache.popup;}

this.init=function(){cache_init(this);}
;this.toXml=function(){return cache_toXml(this);}
;this.loadList=function(type){cache_loadList(type)}
;this.rebuildScreen=function(){cache_rebuildScreen(this)}
;this.addListToLoad=function(nameOrType,list){this.listsToLoad[nameOrType]=list;}
;this.getListByName=function(name){return this.listsByName[name.toLowerCase()];}
;this.getListByType=function(type){return this.listsByType[type];}
;this.getRecordToSave=function(type,id){return this.recordsToSave[type+id]}
;this.getRecordsToSaveOfAType=function(typeName){return cache_getRecordsToSaveOfAType(typeName,this)}
;this.getChildRecord=function(fieldName,parentRecord){return cache_getChildRecord(fieldName,parentRecord)}
;this.getRecordById=function(id){var record=(this.recordsById[id]==undefined)?null:this.recordsById[id];return record;}

this.getRecordByUniqueId=function(type,id){var record=(this.recordsById[type+id]==undefined)?null:this.recordsById[type+id];return record;}

this.getRecordByName=function(name){var recordId=this.recordsByName[name.toLowerCase()];return (recordId!=undefined)?this.getRecordById(recordId):this.getRecordById(name);}

this.addRecord=function(record){cache_addRecord(record,this);}
;this.addRecordToLoad=function(type,id,name){cache_addRecordToLoad(type,id,name,this);}
;this.addRecordToDelete=function(type,id){cache_addRecordToDelete(type,id,this);}
;this.addDynTableToDelete=function(type){this.dyntablesToDelete.push(type);}
;this.addDynTableToSave=function(table){this.dyntablesToSave.push(table);}
;this.addDynTableToLoad=function(type,loadFull,loadTemplate){if((this.dyntablesToLoad[type]==null||this.dyntablesToLoad[type]==undefined)&&type!=""){this.dyntablesToLoad[type]=new cache_DynTableRequest(type,loadFull,loadTemplate)
}

}

this.getRecordByKey=function(type,fieldName,keyword,name){return cache_getRecordByKey(type,fieldName,keyword,name,this)}
;this.getTemplate=function(type){return cache_getTemplate(type,this);}
;this.getRecord=function(type,recordId){return cache_getRecord(type,recordId,this)}
;this.getList=function(type){return cache_getList(type,this)}
;this.process=function(requestHandler){cache_process(this,requestHandler)}
;this.submitCache=function(path,isToSave){cache_submit(path,this)}
;this.submitCacheNoRefresh=function(){return cache_submitNoRefresh(this)}
;this.createList=function(type,name,doSave){return cache_createList(this,type,name,doSave)}

this.createRecord=function(type){return cache_createRecord(this,type)}
;this.createMessageSenderRecord=function(){return cache_createMessageSenderRecord(this)}
;this.clearRecord=function(recordName){cache_clearRecord(recordName)}
;this.createRecordToProcess=function(recordName){return cache_createRecordToProcess(this,recordName)}
;this.enableTransaction=function(){cache_EnableTransaction(this);return this;}
;g_types=this.typeList;return this;}

function cache_createRecordToProcess(cache,recordName){var record=new core_Record(recordName,0);record.addName(recordName);record.doProcess=true;cache.addRecord(record);return record;}

function cache_clearRecord(recordName){var uniqueId=g_cache.recordsByName[recordName];delete(g_cache.recordsById[uniqueId]);delete(g_cache.recordsByName[recordName]);}

var cache_nextMessageId=0;function cache_createMessageSenderRecord(thisObj){cache_nextMessageId--;var record=new core_Record("messageSender",cache_nextMessageId);record.fields.messageSender=new messagesender_MessageSender();record.fields.messageSender.buildChildFields();record.doProcess=true;record.ownerCache=thisObj;record.init();thisObj.addRecord(record);return record;}

function cache_getRecordsToSaveOfAType(typeName,thisObj){var recordsToSave=new Array();var recordsOfAType=thisObj.recordsByType[typeName];if(recordsOfAType!=null){for(var recordId in recordsOfAType)
{var aRecord=recordsOfAType[recordId];if(aRecord.toSave){recordsToSave.push(aRecord);}

}

}

return recordsToSave;}

function cache_getChildRecord(fieldName,parentRecord){var type=parentRecord.getFieldByName(fieldName).selectedType;var id=parentRecord.getFieldByName(fieldName).selectedId;return g_cache.getRecord(type,id);}

function cache_loadPresentationRecord(type,id){var path=(type==constants_CUSTOM_SCREEN_TABLE_NAME)?constants_EDITOR_PATH:constants_JS_EDITOR_PATH;var cache=new core_Cache(type,id,path);cache.addRecordToLoad(type,id)
cache.primaryId=id;cache.primaryType=path;cache.submitCache(path);}

function cache_submitNoRefresh(thisCache){var theForm=document.getElementById("upload_form");theForm.action=globals_webappPath+"/go";util_addHiddenInput("cache",thisCache.toXml(),theForm);try
{theForm.submit();return true;}

catch(e)
{alert("Some files you are trying to submit are not valid. Please select a valid file");return false;}

}

function cache_submit(path,thisCache){var theForm=document.forms[0];if(null==theForm){theForm=document.createElement("form");theForm.enctype="multipart/form-data";theForm.method="post";}

if(window["globals_webappPath"]){theForm.action=globals_webappPath+"/"+path;}

else 
{theForm.action="/"+path;}

util_addHiddenInput("cache",thisCache.toXml(),theForm);theForm.submit();thisCache=null;}

function cache_init(thisCache){for(var recordId in thisCache.recordsById)
{var record=thisCache.recordsById[recordId];record.ownerCache=thisCache;record.init();}

for(var type in thisCache.templates)
{thisCache.templates[type].ownerCache=thisCache;}

for(var type in thisCache.dynTables)
{thisCache.dynTables[type].ownerCache=thisCache;thisCache.dynTables[type].init();}

for(var name in thisCache.listsByName)
{thisCache.listsByName[name].ownerCache=thisCache;thisCache.listsByName[name].init();}

for(var name in thisCache.lists)
{thisCache.lists[name].ownerCache=thisCache;thisCache.lists[name].init();}

thisCache.mainDynTable=thisCache.dynTables[thisCache.primaryType];thisCache.mainRecord=thisCache.getRecordById(thisCache.primaryType+thisCache.primaryId);thisCache.mainList=thisCache.listsByType[thisCache.primaryType];}

function cache_addRecordToDelete(type,id,thisCache){var record=new core_Record(type,id);record.toDelete=true;cache_addRecord(record,thisCache);}

function cache_addRecord(record,thisCache){var records;if(thisCache.recordsByType[record.type]==undefined){records=new Array();thisCache.recordsByType[record.type]=records;}

else 
{records=thisCache.recordsByType[record.type];}

var existingRecord=records[record.type+record.id];if(existingRecord==null){records[record.type+record.id]=record;}

else 
{existingRecord.addNames(record.names);}

}

function cache_addRecordToLoad(type,id,name,thisCache){var record=new core_Record(type,id);record.toLoad=true;record.addName(name);var isAdded=false;if(thisCache.recordsByType[type]){isAdded=cache_isRecordOnList(record,thisCache.recordsByType[type])
}

if(!isAdded){cache_addRecord(record,thisCache);}

}

function cache_isRecordOnList(record,addedRecords){var isAdded=false;if(addedRecords[record.type+record.id]){var names=addedRecords[record.type+record.id].names;names=names.concat(record.names);addedRecords[record.type+record.id].toLoad=true;isAdded=true;}

return isAdded
}

function cache_toXml(thisCache){var xml=constants_LESS_THAN_CHAR+"cache primary_type='"+thisCache.primaryType+"' id='"+thisCache.primaryId+"' screen_type='"+thisCache.screenType+"'>";xml+=cache_dynTablesToXml(thisCache);xml+=cache_recordsToToXml(thisCache);xml+=cache_listsToXlm(thisCache);xml+=constants_LESS_THAN_CHAR+"/cache>";return xml;}

function cache_dynTablesToXml(thisCache){var xml=constants_LESS_THAN_CHAR+"dyntables>";xml+=constants_LESS_THAN_CHAR+"to_save>";xml+=cache_dyntableToSaveToXml(thisCache);xml+=constants_LESS_THAN_CHAR+"/to_save>";xml+=constants_LESS_THAN_CHAR+"to_load>";xml+=cache_dyntableToLoadToXml(thisCache);xml+=constants_LESS_THAN_CHAR+"/to_load>";xml+=constants_LESS_THAN_CHAR+"to_delete>";xml+=cache_dyntableToDeleteToXml(thisCache);xml+=constants_LESS_THAN_CHAR+"/to_delete>";xml+=constants_LESS_THAN_CHAR+"/dyntables>";return xml;}

function cache_dyntableToSaveToXml(thisCache){var xml="";for(tableName in thisCache.dyntablesToSave)
{xml+=thisCache.dyntablesToSave[tableName].toXml();}

return xml;}

function cache_dyntableToLoadToXml(thisCache){var xml="";for(i in thisCache.dyntablesToLoad)
{var table=thisCache.dyntablesToLoad[i]
xml+=constants_LESS_THAN_CHAR
xml+="table name='";xml+=table.name;xml+="' load_full='";xml+=table.loadFull
xml+="' load_template='"
xml+=table.loadTemplate
xml+="'/>";}

return xml;}

function cache_dyntableToDeleteToXml(thisCache){var xml="";for(var i=0;i<thisCache.dyntablesToDelete.length;i++)
{xml+=constants_LESS_THAN_CHAR+"table name='"+thisCache.dyntablesToDelete[i]+"'/>";}

return xml;}

function cache_recordsToToXml(thisCache){var xml=constants_LESS_THAN_CHAR+"records>";for(var type in thisCache.recordsByType)
{var records=thisCache.recordsByType[type];if(null==records){continue
}

for(var recordId in records)
{xml+=records[recordId].toXml();}

}

xml+=constants_LESS_THAN_CHAR+"/records>";thisCache.recordsByType=new Array();return xml;}

function cache_listsToXlm(thisCache){var xml=constants_LESS_THAN_CHAR+"lists>";xml+=constants_LESS_THAN_CHAR+"to_load>";for(var nameOrType in thisCache.listsToLoad)
{xml+=thisCache.listsToLoad[nameOrType].toXml();}

xml+=constants_LESS_THAN_CHAR+"/to_load>";xml+=constants_LESS_THAN_CHAR+"/lists>";return xml;}

function cache_process(thisCache,requestHandler){if(null!=g_cache){thisCache.primaryType=g_cache.primaryType;thisCache.primaryId=g_cache.primaryId;thisCache.screenType=g_cache.screenType;}

var cacheXml=thisCache.toXml();ajax_ProcessCache(cacheXml,requestHandler);thisCache=null;}

function cache_createList(thisCache,type,name,doSave){var list=new core_List(type,[],name);list.createRequiredChildren(doSave);thisCache.addListToLoad(name,list);return list;}

function cache_createRecord(thisCache,type){var record=thisCache.getTemplate(type).clone()
record.toSave=true;record.ownerCache=thisCache;thisCache.addRecord(record);thisCache.recordsToSave[type+record.id]=record;return record;}

function cache_getRecordByKey(type,fieldName,keyword,name,thisCache){var record=g_cache.getRecordByName(name);if(null==record){var cache=new core_Cache('',-1)
cache.addRecordToLoadByKey(fieldName,keyword,type,name);cache.process();var maxTimeTrying=2000;var startTime=new Date();while(null==record&&((new Date()-startTime)<maxTimeTrying))
{record=g_cache.getRecordByName(name);}

cache=null;}

return record;}

function cache_getTemplate(type,thisCache){var template=g_cache.templates[type];if(null==template){var cache=new core_Cache('',-1);cache.addDynTableToLoad(type,false,true);cache.process();var maxTimeTrying=2000;var startTime=new Date();while(null==template&&((new Date()-startTime)<maxTimeTrying))
{template=g_cache.templates[type];}

cache=null;}

return template;}

function cache_getRecord(type,recordId,thisCache){var record=null
if(recordId==0){record=g_cache.getTemplate(type).clone();return record;}

record=g_cache.getRecordById(type+recordId);if(null==record){var cache=new core_Cache('',-1)
cache.addRecordToLoad(type,recordId);cache.process();cache=null;record=g_cache.getRecordById(type+recordId);
cache=null;}

return record;}

function cache_getList(type,thisCache){var list=g_cache.getListByType(type);if(null==list){var cache=new core_Cache('',-1)
cache.createList(type,type,false);cache.process();var maxTimeTrying=2000;var startTime=new Date();while(null==list&&((new Date()-startTime)<maxTimeTrying))
{list=g_cache.getListByType(type);}

cache=null;}

if(null==list){alert("failed to load list with ajax");}

return list;}

function cache_DynTableRequest(name,loadFull,loadTemplate){this.name=name;this.loadFull=loadFull
this.loadTemplate=loadTemplate;}

function cache_CurrentDateTime(){this.year;this.date;this.month;this.timeInSeconds;}

function cache_EnableTransaction(thisCache){thisCache.bTransactionMode=true;}


function objectToField(object,name,typeName,extraInfo){return oft_populateField(object,null,name,typeName,extraInfo);}

if(!otf_objectToFieldFxByType){var otf_objectToFieldFxByType=[];}

function registerConverter(fieldTypeName,conversionFx){if(!otf_objectToFieldFxByType){otf_objectToFieldFxByType=[];}

otf_objectToFieldFxByType[fieldTypeName]=conversionFx;}

function oft_populateField(object,parentField,name,typeName,extraInfo){var objectType=typeof(object);if("function"==objectType){return ;}

var isObject=object&&(objectType=='object');if(typeName){var converterFx=otf_objectToFieldFxByType[typeName];return converterFx(object,name,extraInfo);}

if(isObject){var field=object.length?new array_ArrayType(name,"",0):new collectionfield_Collection(name,"",0);var dO=1;for(var i in object)
{var typeIndicatorName=i+"_ft";var extraInfoName=typeIndicatorName+"i";var childField=oft_populateField(object[i],field,i,object[typeIndicatorName],object[extraInfoName]);if(childField){childField.displayOrder=dO;field.addChildField(childField);dO++;}

}

return field;}

else 
{return new field_String(name,"",0,object,false);}

}

function oft_isTypeIndicator(fieldName){var nameLength=fieldName.length;if(nameLength<=3){return false;}

var suffix=fieldName.substring(nameLength-3,nameLength);return ("_ft"==suffix)
}

;var IS_MOZILLA=document.getElementById&&!document.all;var IS_IE=document.all;var IS_CHROME=navigator.userAgent.toLowerCase().indexOf('chrome')>-1;var crossbrowser_browserName;var crossbrowser_wc3MouseButtons=[];crossbrowser_wc3MouseButtons.left=1;crossbrowser_wc3MouseButtons.middle=4;crossbrowser_wc3MouseButtons.right=2;var crossbrowser_ieMouseButtons=[];crossbrowser_ieMouseButtons.left=1;crossbrowser_ieMouseButtons.middle=4;crossbrowser_ieMouseButtons.right=2;function crossbrowser_findMouseButtonStatus(event,buttonPosition){var buttonNumber=(event)?crossbrowser_wc3MouseButtons[buttonPosition]:crossbrowser_ieMouseButtons[buttonPosition];var isPressed=false;if(!event){event=window.event;}

if(event.which){isPressed=(event.which==buttonNumber);}

else if(event.button){isPressed=(event.button==buttonNumber);}

return isPressed;}
;function crossbrowser_dispatchEvent(element,eventObject){
if(IS_IE){element.fireEvent("on"+eventObject.type,eventObject);}

else if(IS_MOZILLA){element.dispatchEvent(eventObject);}

}

function crossbrowser_isInDom(element){if(!element.parentNode){return false;}

else if(element.parentNode.tagName){return true;}

else 
{return false;}

}

function crossbrowser_getBrowserName(){if(crossbrowser_browserName){return crossbrowser_browserName;}

var userAgent=navigator.userAgent;if(userAgent){if(userAgent.indexOf("MSIE")!=-1){crossbrowser_browserName="Internet Explorer";return crossbrowser_browserName;}

else if(userAgent.indexOf("Firefox")!=-1){crossbrowser_browserName="Firefox";return crossbrowser_browserName;}

else if(userAgent.toLowerCase().indexOf('chrome')>-1){crossbrowser_browserName="Chrome";return crossbrowser_browserName;}

}

var vendor=navigator.vendor;if(vendor){if(userAgent.indexOf("Apple")!=-1){crossbrowser_browserName="Safari";return crossbrowser_browserName;}

}

else if(window.opera){crossbrowser_browserName="Opera";return crossbrowser_browserName;}

crossbrowser_browserName="Unknown";return crossbrowser_browserName;}

function crossbrowser_attachEvent(object,eventName,eventFunction){if(IS_MOZILLA){eventName=eventName.substring(2,eventName.length);object.addEventListener(eventName,eventFunction,false);}

else if(IS_IE){object.attachEvent(eventName,eventFunction);}

}

function crossbrowser_stopEvent(event){if(IS_MOZILLA){event.stopPropagation();event.preventDefault();}

else if(IS_IE){if(!event){event=window.event;}

event.returnValue=false;event.cancelBubble=true;}

}

function crossbrowser_handleEvent(event){if(IS_MOZILLA){event.stopPropagation();event.preventDefault();}

else if(IS_IE){window.event.returnValue=false;window.event.cancelBubble=true;}

}

function crossbrowser_cancelBubble(event){if(IS_MOZILLA){event.stopPropagation();}

else if(IS_IE&&event){event.cancelBubble=true;}

else if(IS_IE&&window.event){window.event.cancelBubble=true;}

}

function crossbrowser_getKeyCode(event){var key;if(IS_MOZILLA){key=(null!=event?event.which:window.event.keyCode);}

else if(IS_IE){key=window.event.keyCode;}

return key;}

function crossbrowser_getAttribute(anObject,attributeName){var value=(anObject[attributeName])?anObject[attributeName]:anObject.getAttribute(attributeName);return value;}

function crossbrowser_removeEvent(element,eventType,eventFunction){if(!eventFunction){return ;}

if(IS_MOZILLA){eventType=eventType.substring(2,eventType.length);element.removeEventListener(eventType,eventFunction,false);}

else if(IS_IE){element.detachEvent(eventType,eventFunction);}

}

function crossbrowser_checkBrowser(messageHandler){var isValidBrowser=true;if(navigator.userAgent.indexOf("Firefox")!=-1){var versionindex=navigator.userAgent.indexOf("Firefox")+8
if(parseInt(navigator.userAgent.charAt(versionindex))<2){crossbrowser_buildBrowserAlert("Firefox",messageHandler);isValidBrowser=false;}

}

else if(navigator.userAgent.indexOf("MSIE")!=-1){var temp=navigator.appVersion.split("MSIE")
var version=parseFloat(temp[1])
if(version<6){crossbrowser_buildBrowserAlert("MSIE",messageHandler);isValidBrowser=false;}

}

else if(navigator.userAgent.indexOf("Safari")!=-1){if(version<3){crossbrowser_buildBrowserAlert("Safari",messageHandler);isValidBrowser=false;}

}

return isValidBrowser;}

function crossbrowser_buildBrowserAlert(browserType,messageHandler){var table=document.createElement("table");table.width="100%";table.cellPadding=0;table.cellSpacing=0;g_cache.popup.editableDiv.appendChild(table);var tbody=document.createElement("tbody");table.appendChild(tbody);var tr=document.createElement("tr");tbody.appendChild(tr);var td=document.createElement("td");td.width=(document.documentElement.clientWidth)?document.documentElement.clientWidth:document.body.clientWidth;td.height=1000;td.style.position="absolute";td.style.backgroundColor="#eeeeee";td.vAlign="middle";td.align="center";tr.appendChild(td);if(browserType=="Firefox"){var element=messageHandler("Firefox","http://www.mozilla.com/en-US/firefox/upgrade");element.style.marginTop=200;td.appendChild(element);}

else if(browserType=="MSIE"){var element=messageHandler("Internet Explorer","http://www.microsoft.com/windows/downloads/ie/getitnow.mspx");td.appendChild(element);}

else if(browserType=="Safari"){var element=messageHandler("Safari","http://www.apple.com/safari/download");td.appendChild(element);}

}

function scrambleString(aString){return aString;}

function util_isInDom(element){if(!element.parentNode){return false;}

else if(element.parentNode.tagName){return true;}

else 
{return false;}

}

function crossbrowser_getIEVersion(){if(navigator.appName=='Microsoft Internet Explorer'){var rv=-1;var ua=navigator.userAgent;var re=new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");var ver=re.exec(ua)[1];if(ver!=null){rv=ver.charAt(0);}

}

return rv;}




function cE(tagName,parentEl,doc){if(!doc){doc=getParentDocument(parentEl);}

var element=doc.createElement(tagName);if(parentEl){parentEl.appendChild(element);}

return element;}


function gL(selectors){return document.querySelectorAll(selectors);}


function gE(selector,doc){if(!doc){doc=document;}

return doc.querySelector(selector);}


function sA(element,name,value){element.setAttribute(name,value);}


function rA(element,name){element.removeAttribute(name);}


function gA(element,name){if(element.nodeType!=1){return null;}

return element.getAttribute(name);}


function cC(tBody){var tr=cE("tr",tBody);var td=cE("td",tr);return td;}


function iE(tagName,parentEl,insertIndex){var doc=getParentDocument(parentEl);var element=doc.createElement(tagName);try
{parentEl.insertBefore(element,parentEl.childNodes[insertIndex]);}

catch(e)
{parentEl.appendChild(element);}

return element;}


function aE(parentEl,element){parentEl.appendChild(element);}


function createTable(parentEl,width,height){var doc=getParentDocument(parentEl);var table=doc.createElement("table");table.cellPadding=0;table.cellSpacing=0;if(width){table.style.width=(!isNaN(width))?width+"px":width;}

if(height){table.style.height=(!isNaN(height))?height+"px":height;}

parentEl.appendChild(table);var tBody=doc.createElement("tbody");table.appendChild(tBody);return tBody;}


function getPlainText(element){var linesArray=new Array();var fx=function(element,linesArray){var displayType=CssUtil.getStyle(element,"display");if(!(displayType=="inline"||displayType=="inline-block")&&linesArray[linesArray.length-1]!=""){linesArray.push("");}

if(element.nodeType==3){linesArray[linesArray.length-1]=linesArray[linesArray.length-1]+element.data;}

else if(element.firstChild){fx(element.firstChild,linesArray);}

if(element.nextSibling){fx(element.nextSibling,linesArray);}

}
;fx(element,linesArray);return linesArray;}
;
function getParentDocument(element){var doc=null;if(element==null||element.ownerDocument==null){doc=document;}

else 
{doc=element.ownerDocument;}

return doc;}

function cls(parentEl,label,onclickFx,eventGroupName){var s=cE("span",parentEl);s.className="text linkColor";s.innerHTML=label;addUnderlineEvents(s,"main");var clickFx=(onclickFx)?onclickFx:function(){}
;eh_attachEvent("onclick",s,clickFx,eventGroupName);return s;}

function cli(parentEl,src,onclickFx,eventGroupName){var i=cE("img",parentEl);i.src=src;i.style.cursor="pointer";eh_attachEvent("onclick",i,onclickFx,eventGroupName);return i;}

function cb(parentEl,label,onclickFx,eventGroupName){var b=cE("button",parentEl);b.className="text";b.innerHTML=label;b.setAttribute('type',"button");eh_attachEvent("onclick",b,onclickFx,eventGroupName);return b;}
;function docGetEl(id){return document.getElementById(id);}

function addUnderlineEvents(element,eventGroupName){var mouseOverFx=function(){element.style.textDecoration='underline'}
;eh_attachEvent("onmouseover",element,mouseOverFx,eventGroupName,false,null,null,null,true);var mouseOutFx=function(){element.style.textDecoration=''}
;eh_attachEvent("onmouseout",element,mouseOutFx,eventGroupName,false,null,null,null,true);element.style.cursor="pointer";}
;

function isInDom(element){var parentNode=element.parentNode;if(!parentNode){return false;}

else if(!parentNode.tagName){return false;}

else if(parentNode.tagName.toLowerCase()=="body"){return true;}

else if(parentNode){return isInDom(parentNode);}

else 
{return true;}

}



;var eh_events=[];
function eh_attachEvent(eventType,element,eventFx,eventGroupName,stopEvent,ownerWindow,doReturn,returnValue,allowBubbling){element[eventType]=function(event){ownerWindow=(!ownerWindow)?window:ownerWindow;event=(!event)?ownerWindow.event:event;if(eventFx){eventFx(event);}

if(stopEvent){crossbrowser_stopEvent(event);}

else if(!allowBubbling){crossbrowser_cancelBubble(event);}

if(doReturn){return returnValue;}

}
;eh_registerEvent(element,eventType,eventGroupName);}
;function eh_attachOnMouseEnter(element,fx,ownerWindow){if(BrowserUtil.isIE()||BrowserUtil.isFF()){eh_attachEvent("onmouseenter",element,fx,null,null,ownerWindow);}

else 
{element.onmouseover=function(event){if(!event){ownerWindow=(!ownerWindow)?window:ownerWindow;event=ownerWindow.event;}

if(!isDescendent(event.fromElement,event.currentTarget)&&isDescendent(event.toElement,event.currentTarget)){fx(event);}

}
;eh_registerEvent(element,"onmouseover");}

}

function eh_attachOnMouseLeave(element,fx,ownerWindow){if(BrowserUtil.isIE()||BrowserUtil.isFF()){eh_attachEvent("onmouseleave",element,fx,null,null,ownerWindow);}

else 
{var outFx=function(){if(!isInDom(element)){document.body.removeEventListener("mouseout",outFx,false);}

if(isDescendent(event.srcElement,element)&&!isDescendent(event.toElement,element)){fx(event);}

}

eh_addEvent("onmouseout",document.body,outFx);}

}


function eh_removeEventHandler(element,eventType,eventFx){if(!eventFx){return ;}

if(element.removeEventListener){var evType=eventType.substring(2,eventType.length);element.removeEventListener(evType,eventFx,false);}

else if(element.detachEvent){element.detachEvent(eventType,eventFx);}

}
;
function eh_attachBeforeUnload(onBeforeUnloadFx){var isAlreadyRun=false;var fx=function(){if(!isAlreadyRun){isAlreadyRun=true;onBeforeUnloadFx();}

}

eh_addEvent("onbeforeunload",window,fx);}

function eh_addEvent(eventName,object,eventFunction){if(document.getElementById&&!document.all){eventName=eventName.substring(2,eventName.length);object.addEventListener(eventName,eventFunction,false);}

else if(document.all){object.attachEvent(eventName,eventFunction);}

}

function eh_getSource(event){return event.target||event.srcElement;}


function eh_attachEventNoRegister(eventType,element,eventFx,eventGroupName,stopEvent,ownerWindow,doReturn,returnValue,allowBubbling){element[eventType]=function(event){ownerWindow=(!ownerWindow)?window:ownerWindow;event=(!event)?ownerWindow.event:event;if(eventFx){eventFx(event);}

if(stopEvent){crossbrowser_stopEvent(event);}

else if(!allowBubbling){crossbrowser_cancelBubble(event);}

if(doReturn){return returnValue;}

}
;}

function eh_registerEvent(element,eventType,eventGroupName){if(!IS_IE){return ;}

if(!eventGroupName){eventGroupName="default";}

var eventGroup=eh_events[eventGroupName];if(!eventGroup){eventGroup=[];eh_events[eventGroupName]=eventGroup;}

var eventsByType=eventGroup[eventType];if(!eventsByType){eventsByType=[];eventGroup[eventType]=eventsByType;}

eventsByType.push(element);}


function eh_clearEventGroup(eventGroupName,omitGC){eh_clearEventsNotInDom();}

function eh_clearEventsNotInDom(){for(var groupName in eh_events)
{eh_clearUnusedEvents(eh_events[groupName]);}

if(IS_IE){CollectGarbage();}

}

function eh_clearUnusedEvents(eventGroup){for(var eventType in eventGroup)
{var eventsByType=eventGroup[eventType];var count=eventsByType.length;for(var i=0;i<count;i++)
{try
{if(!isInDom(eventsByType[i])){eventsByType[i][eventType]=null;}

}

catch(e)
{}

}

}

}


function eh_clearAllEvents(){for(var groupName in eh_events)
{eh_clearEventGroup(groupName,true);}

document.body.onunload=null;if(IS_IE){CollectGarbage();}

}

function eh_initalizeGC(){document.body.onunload=eh_clearAllEvents;}


if(window["sl_loadedScript"]==undefined){var sl_loadedScript=[];}
;if(window["sl_onAfterLoadFx"]==undefined){var sl_onAfterLoadFx=[];}
;function sl_loadScript(scriptPath,onAfterLoadFx){if(sl_loadedScript[scriptPath]){if(onAfterLoadFx){onAfterLoadFx();}

return ;}

sl_onAfterLoadFx[scriptPath]=onAfterLoadFx;var scriptToLoad=document.createElement("script");scriptToLoad.src=scriptPath;scriptToLoad.type="text/javascript";document.body.appendChild(scriptToLoad);sl_loadedScript[scriptPath]=true;}

function field_Boolean(name,displayName,displayOrder,value,isStatic){this.buildCheckbox=function(){return bl_buildCheckBox(this)}
;this.buildRadioButtons=function(){return bl_buildRadioButtons(this)}
;this.TYPE="BOOLEAN";this.TYPE_DISPLAY_NAME="Boolean";this.ownerRecord;this.ownerCache;this.parentField;this.name=name;this.displayName=displayName;this.displayOrder=displayOrder
this.value=value;this.isStatic=isStatic;this.isEditable=false;this.fieldContainer=null;this.init=function(){}
;this.buildHTML=function(){return bl_buildHTML(this)}
;this.buildSettingsHTML=function(){return bl_buildSettingsHTML(this)}
;this.toXml=function(){return bl_toXml(this)}
;this.clone=function(){return new field_Boolean(this.name,this.displayName,this.displayOrder,this.value,this.isStatic)}
;this.getValue=function(){return this.value;}
;this.setValue=function(value){this.value=value;}

this.checkbox=null;this.onclickHandler=null;this.onselectHandler=null
}

function boolean_objectToField(object,name){var field=new field_Boolean(name,"",0,object,false);return field;}

if(window.registerConverter){registerConverter("BOOLEAN",boolean_objectToField);}

function bl_buildRadioButtons(thisObj,isVertical){var container=document.createElement("span");var tagName=(thisObj.isVertical)?"div":"span";var isYes=(thisObj.value)?true:false;var yesIcon=bl_buildOption("Yes",tagName,thisObj,isYes);container.appendChild(yesIcon);var isNo=(thisObj.value)?false:true;var noIcon=bl_buildOption("No",tagName,thisObj,isNo);container.appendChild(noIcon);return container;}

function bl_buildOption(displayName,tagName,thisObj,isChecked){var container=document.createElement(tagName);var input=document.createElement("input");input.type="radio";input.defaultChecked=isChecked;input.value=displayName;bl_addOnclick(input,thisObj,isChecked);container.appendChild(input);var span=document.createElement("span");span.innerHTML=displayName;span.style.marginLeft=5;container.appendChild(span);return container;}

function bl_addOnclick(input,thisObj){if(input.defaultChecked){thisObj.selectedDefaultInput=input;}

input.onclick=function(){if(thisObj.selectedDefaultInput!=null){thisObj.selectedDefaultInput.checked=false;}

input.checked=true;thisObj.value=(input.value=="Yes")?true:false;thisObj.selectedDefaultInput=this;if(thisObj.onselectHandler!=null){thisObj.onselectHandler(thisObj);}

}
;}

function bl_buildCheckBox(thisObj){var checkbox=document.createElement("input");checkbox.type="checkbox";checkbox.value=thisObj.value;checkbox.defaultChecked=(thisObj.value)?true:false;checkbox.onclick=function(){thisObj.value=(this.checked)?true:false
if(thisObj.onclickHandler!=null){thisObj.onclickHandler();}

}
;thisObj.checkbox=checkbox;return checkbox;}

function bl_buildSettingsHTML(thisObj){var container=document.createElement("div")
var table=document.createElement("table");container.appendChild(table);var tbody=document.createElement("tbody");table.appendChild(tbody);var tr=document.createElement("tr");tbody.appendChild(tr);var td=document.createElement("td");td.vAlign="top";tr.appendChild(td);var doUpdate=document.createElement("input");doUpdate.type="checkbox";doUpdate.defaultChecked=(thisObj.value)?true:false;doUpdate.onclick=function(){thisObj.value=(this.checked)?true:false}
;td.appendChild(doUpdate);var td=document.createElement("td");td.className="architectReadOnly";tr.appendChild(td);var div=document.createElement("div");div.innerHTML="Default to  true?"
td.appendChild(div);return container;}

function bl_buildHTML(thisObj){thisObj.fieldContainer=document.createElement("span");if(thisObj.isEditable){bl_buildEditableHTML(thisObj)
}

else 
{bl_buildReadOnlyHTML(thisObj)
}

return thisObj.fieldContainer;}

function bl_buildEditableHTML(thisObj){var checkbox=document.createElement("input");checkbox.type="checkbox";checkbox.value=thisObj.value;checkbox.defaultChecked=(thisObj.value)?true:false;checkbox.onclick=function(){thisObj.value=(this.checked)?true:false
if(thisObj.onclickHandler!=null){thisObj.onclickHandler();}

}
;thisObj.fieldContainer.appendChild(checkbox);thisObj.checkbox=checkbox;}

function bl_buildReadOnlyHTML(thisObj){var span=thisObj.fieldContainer;span.innerHTML=(thisObj.value)?"yes":"no";}

function bl_toXml(thisObj){var xml=constants_LESS_THAN_CHAR+"f ";xml+="name='"+thisObj.name;xml+="' dn='"+util_formatForXmlValue(thisObj.displayName);xml+="' type='"+thisObj.TYPE;xml+="' do='"+thisObj.displayOrder;xml+="' value='"+thisObj.value;xml+="' is_static='"+thisObj.isStatic+"'/>";return xml;}

function draganddrop_attachDrag(draggableElement,dragTrigger){var dg=new draganddrop_DragAndDrop(draggableElement,dragTrigger);}

function draganddrop_DragAndDrop(draggableElement,dragTrigger){this.draggableElement=draggableElement;this.dragTrigger=dragTrigger;this.initialX;this.initialY;this.initialMouseX;this.initialMouseY;draganddrop_init(this);}

function draganddrop_init(dragObj){if(!dragObj.dragTrigger){return ;}

dragObj.dragTrigger.style.cursor="move";dragObj.dragTrigger.onmousedown=function(event){draganddrop_startDrag(dragObj,event);crossbrowser_stopEvent(event);}
;dragObj.dragTrigger.onmouseup=function(event){draganddrop_cancelDocumentEvents();crossbrowser_stopEvent(event);}
;}

function draganddrop_startDrag(dragObj,event){dragObj.initialX=dragObj.draggableElement.offsetLeft;dragObj.initialY=dragObj.draggableElement.offsetTop;dragObj.initialMouseX=(event)?event.clientX:window.event.clientX;dragObj.initialMouseY=(event)?event.clientY:window.event.clientY;document.onmousemove=function(event){draganddrop_startMove(dragObj,event);crossbrowser_stopEvent(event);}
;}

function draganddrop_startMove(dragObj,event){var newX=(event)?event.clientX:window.event.clientX;var newY=(event)?event.clientY:window.event.clientY;var xMove=newX-dragObj.initialMouseX;var yMove=newY-dragObj.initialMouseY;var posTop=dragObj.initialY+yMove;var posLeft=dragObj.initialX+xMove;dragObj.draggableElement.style.top=posTop+"px";dragObj.draggableElement.style.left=posLeft+"px";crossbrowser_stopEvent(event);}

function draganddrop_cancelDocumentEvents(){document.onmousemove=null;}

var B=BrowserUtil=new BrowserUtilBase();function BrowserUtilBase(){this.name;this.version;this.OS;this.isFF=function(){return ("Firefox"==this.name);}
;this.isIE=function(){return ("Explorer"==this.name);}
;this.isChrome=function(){return ("Chrome"==this.name);}
;this.isSafari=function(){return ("Safari"==this.name);}
;this.isOpera=function(){return ("Opera"==this.name);}
;this.getName=function(){return this.name;}
;this.getVersion=function(){return this.version;}
;this.isIOS=function(){return (this.OS=="IOS");}
;this.isAndroid=function(){var ua=navigator.userAgent.toLowerCase();return ua.indexOf("android")>-1;}
;this.getOS=function(){return this.OS;}
;this.init=function(){this.name=this.searchString(this.dataBrowser)||"An unknown browser";this.version=this.searchVersion(navigator.userAgent)||this.searchVersion(navigator.appVersion)||"an unknown version";this.OS=this.searchString(this.dataOS)||"an unknown OS";}
;this.searchString=function(data){for(var i=0;i<data.length;i++)
{var dataString=data[i].string;var dataProp=data[i].prop;this.versionSearchString=data[i].versionSearch||data[i].identity;if(dataString){if(dataString.indexOf(data[i].subString)!=-1){return data[i].identity;}

else if(dataProp){return data[i].identity;}

}

}

}
;this.searchVersion=function(dataString){var index=dataString.indexOf(this.versionSearchString);if(index==-1){return ;}

return parseFloat(dataString.substring(index+this.versionSearchString.length+1));}
;this.dataBrowser=[];var obj={string:navigator.userAgent,subString:"Chrome",identity:"Chrome"}
;this.dataBrowser.push(obj)
var obj={string:navigator.userAgent,subString:"OmniWeb",versionSearch:"OmniWeb/",identity:"OmniWeb"}
;this.dataBrowser.push(obj)
var obj={string:navigator.vendor,subString:"Apple",identity:"Safari",versionSearch:"Version"}
;this.dataBrowser.push(obj)
var obj={prop:window.opera,identity:"Opera"}
;this.dataBrowser.push(obj)
var obj={string:navigator.vendor,subString:"iCab",identity:"iCab"}
;this.dataBrowser.push(obj);var obj={string:navigator.vendor,subString:"KDE",identity:"Konqueror"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Firefox",identity:"Firefox"}
;this.dataBrowser.push(obj);var obj={string:navigator.vendor,subString:"Camino",identity:"Camino"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Netscape",identity:"Netscape"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"MSIE",identity:"Explorer",versionSearch:"MSIE"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Gecko",identity:"Mozilla",versionSearch:"rv"}
;this.dataBrowser.push(obj);var obj={string:navigator.userAgent,subString:"Mozilla",identity:"Netscape",versionSearch:"Mozilla"}

this.dataBrowser.push(obj);this.dataOS=[];var obj={string:navigator.platform,subString:"Win",identity:"Windows"}

this.dataOS.push(obj);var obj={string:navigator.platform,subString:"Mac",identity:"Mac"}
;this.dataOS.push(obj);var obj={string:navigator.platform,subString:"iPad",identity:"IOS"}
;this.dataOS.push(obj);var obj={string:navigator.userAgent,subString:"iPhone",identity:"IOS"}
;this.dataOS.push(obj);var obj={string:navigator.platform,subString:"Linux",identity:"Linux"}
;this.dataOS.push(obj);this.init();}
;
;;if(!global_popup){var global_popup=null;}

function npop_Popup(){this.popupSpace=null;this.editableDiv=null;this.popupArea=null;this.contentArea=null;this.resizableArea=null;this.closeFx=null;this.dragTrigger=null;this.flashElement=null;this.parentPopup=null;this.childPopup=null;this.showPopup=function(){npop_showPopup(this)}
;this.centerPopup=function(){npop_centerPopup(this)}
;this.showPopupAtLocation=function(xCoord,yCoord){npop_showPopupAtLocation(this,xCoord,yCoord)}
;this.closePopup=function(){npop_closePopup(this)}
;this.getChildPopup=function(){return npop_getChildPopup(this)}
;this.drawTitleBar=false;this.buildCloseButton=true;this.sizeBasedOnRes=false;this.disableBackground=true;this.popupTitle="";this.fontColor="";this.bgImage=null;this.bgColor="#F0F5F5";this.titleBackgroundColor;
this.zIndex=1000;this.resizePopup=function(){npop_resize(this)}
;this.popupAligner=null;npop_init(this);npop_buildShadowCell(this);this.build=function(){npop_createContentArea(this);}
;}

function npop_resize(popupObj){popupObj.resizableArea.style.height=popupObj.contentArea.childNodes[0].offsetHeight;}

function npop_getChildPopup(popupObj){var childPopup=popupObj.childPopup;if(popupObj.childPopup==null){childPopup=new npop_Popup();popupObj.childPopup=childPopup;childPopup.parentPopup=popupObj;}

return childPopup;}

function npop_init(popupObj){var popupSpace=document.createElement("div");popupSpace.style.display="none";popupSpace.style.zIndex=(null!=popupObj.zIndex?popupObj.zIndex:1000);popupSpace.style.position="absolute";popupSpace.style.top="0px";popupSpace.style.left="0px";popupSpace.align="center";var width=(document.documentElement.clientWidth)?document.documentElement.clientWidth:document.body.clientWidth;popupSpace.style.width=width+"px";popupSpace.style.height="100%";if(document.body.childNodes.length==0){document.body.appendChild(popupSpace);}

else 
{document.body.insertBefore(popupSpace,document.body.childNodes[0]);}

popupObj.popupSpace=popupSpace;var popupAligner=document.createElement("div");popupAligner.style.position="absolute";popupSpace.appendChild(popupAligner);popupObj.popupAligner=popupAligner;var editableDiv=document.createElement("div");if(IS_IE){editableDiv.style.width="100px";editableDiv.style.height="100px";}

popupAligner.appendChild(editableDiv);popupObj.editableDiv=editableDiv;}

function npop_showPopup(popupObj){if(popupObj.parentPopup==null){popupObj.popupSpace.style.zIndex=(null!=popupObj.zIndex?popupObj.zIndex:1000);popupObj.popupSpace.style.display="";if(popupObj.disableBackground){popupObj.popupSpace.style.backgroundImage="url(/upload/empty_image.gif)";popupObj.popupSpace.style.height=document.body.scrollHeight;}

else 
{popupObj.popupSpace.style.backgroundImage="";popupObj.popupSpace.style.height="";}

var totalHeight=(window.innerHeight)?window.innerHeight:document.body.clientHeight;var totalWidth=(window.innerWidth)?window.innerWidth:document.body.clientWidth;if(popupObj.isBasedOnRes){totalHeight=screen.height;totalWidth=screen.width;}

var contentHeight=popupObj.popupAligner.offsetHeight;var isBiggerThanWindow=(contentHeight>totalHeight)?true:false;if(isBiggerThanWindow){var newContentDiv=popupObj.contentArea;newContentDiv.style.height=totalHeight-100+"px";newContentDiv.style.overflowY="auto";}

var popupHeight=(popupObj.popupAligner.innerHeight)?popupObj.popupAligner.innerHeight:popupObj.popupAligner.clientHeight;var popupWidth=(popupObj.popupAligner.innerWidth)?popupObj.popupAligner.innerWidth:popupObj.popupAligner.clientWidth;var height=totalHeight-popupHeight;var width=totalWidth-popupWidth;var topPosition=height/3;var leftPosition=width/2;var initialHeight=popupObj.popupAligner.offsetHeight;var initialWidth=popupObj.popupAligner.offsetWidth;var posTop="";var posLeft="";if(initialHeight>totalHeight){posTop=(!isBiggerThanWindow)?topPosition+document.body.scrollTop+popupHeight/3:"";if(initialWidth>totalWidth){posLeft=leftPosition+document.body.scrollLeft+popupWidth/3;}

else 
{posLeft=leftPosition+document.body.scrollLeft;}

}

else 
{posTop=topPosition+document.body.scrollTop;posLeft=leftPosition+document.body.scrollLeft;}

popupObj.popupAligner.style.top=posTop+"px";popupObj.popupAligner.style.left=posLeft+"px"
new draganddrop_DragAndDrop(popupObj.popupAligner,popupObj.dragTrigger);}

else 
{var parentPopup=popupObj.parentPopup.editableDiv;var childPopup=popupObj.popupAligner;var zIndex=popupObj.parentPopup.popupSpace.style.zIndex;popupObj.popupSpace.style.zIndex=zIndex+500;popupObj.popupSpace.style.display="";popupObj.popupSpace.style.backgroundImage="url(/upload/empty_image.gif)";var parentPopHeight=(parentPopup.innerHeight)?parentPopup.innerHeight:parentPopup.clientHeight;var parentPopWidth=(parentPopup.innerWidth)?parentPopup.innerWidth:parentPopup.clientWidth;var childPopHeight=(childPopup.innerHeight)?childPopup.innerHeight:childPopup.clientHeight;var childPopWidth=(childPopup.innerWidth)?childPopup.innerWidth:childPopup.clientWidth;var height=parentPopHeight-childPopHeight;var width=parentPopWidth-childPopWidth;var topPosition=height/3;var leftPosition=width/2;var parentCoords=position_findXYCoordinates(parentPopup)
popupObj.popupAligner.style.top=topPosition+parentPopup.scrollTop+parentCoords.y+"px";popupObj.popupAligner.style.left=leftPosition+parentPopup.scrollLeft+parentCoords.x+"px";new draganddrop_DragAndDrop(popupObj.popupAligner,popupObj.dragTrigger);}

}
;function npop_centerPopup(popupObj){var totalHeight=(window.innerHeight)?window.innerHeight:document.body.clientHeight;var totalWidth=(window.innerWidth)?window.innerWidth:document.body.clientWidth;var clientHeight=(popupObj.popupAligner.innerHeight)?popupObj.popupAligner.innerHeight:popupObj.popupAligner.clientHeight;var clientWidth=(popupObj.popupAligner.innerWidth)?popupObj.popupAligner.innerWidth:popupObj.popupAligner.clientWidth;var height=totalHeight-clientHeight;var width=totalWidth-clientWidth;var topPosition=height/3;var leftPosition=width/2;popupObj.popupAligner.style.top=topPosition+document.body.scrollTop+"px";popupObj.popupAligner.style.left=leftPosition+document.body.scrollLeft+"px";new draganddrop_DragAndDrop(popupObj.popupAligner,popupObj.dragTrigger);}

function npop_showPopupAtLocation(popupObj,xCoord,yCoord){popupObj.popupAligner.style.left=xCoord+document.body.scrollLeft;popupObj.popupAligner.style.top=yCoord+document.body.scrollTop;popupObj.popupSpace.style.display="";draganddrop_DragAndDrop(popupObj.popupAligner,popupObj.dragTrigger);}

function npop_clearPopup(popupObj){popupObj.closeFx=null;popupObj.contentArea.innerHTML="";}

function npop_getPopup(){if(!global_popup){global_popup=new npop_Popup();}

return global_popup;}

function npop_closePopup(popupObj){popupObj.dragTrigger=null;popupObj.contentArea.innerHTML="";popupObj.popupSpace.style.zIndex=-100;popupObj.popupSpace.style.display="none";draganddrop_cancelDocumentEvents();if(null!=popupObj.parentPopup){popupObj.parentPopup.childPopup=null;popupObj.parentPopup=null;document.body.removeChild(popupObj.popupSpace);}

if(popupObj.closeFx){popupObj.closeFx();popupObj.closeFx=null;}

}
;function npop_buildShadowCell(popupObj){var table=document.createElement("table");table.cellPadding=0;table.cellSpacing=0;table.style.width=popupObj.editableDiv.style.width;popupObj.editableDiv.appendChild(table);popupObj.flashElement=table;var tBody=document.createElement("tbody");table.appendChild(tBody);var tr=document.createElement("tr");tBody.appendChild(tr);var td=document.createElement("td");td.style.height="8px";td.style.width="8px";td.style.backgroundImage="url(/upload/js_globals/background_images/ulc.png)";tr.appendChild(td);var td=document.createElement("td");td.style.height="8px";td.style.backgroundImage="url(/upload/js_globals/background_images/t.png)";tr.appendChild(td);var td=document.createElement("td");td.style.height="8px";td.style.width="8px";td.style.backgroundImage="url(/upload/js_globals/background_images/urc.png)";tr.appendChild(td);var tr=document.createElement("tr");tBody.appendChild(tr);var td=document.createElement("td");td.style.width="8px";td.innerHTML="&nbsp;&nbsp;";td.style.backgroundImage="url(/upload/js_globals/background_images/l.png)";tr.appendChild(td);var popupArea=document.createElement("td");popupArea.align="center";popupArea.style.backgroundColor="white";tr.appendChild(popupArea);popupObj.popupArea=popupArea;var td=document.createElement("td");td.style.width="8px";td.innerHTML="&nbsp;&nbsp;";td.style.backgroundImage="url(/upload/js_globals/background_images/r.png)";tr.appendChild(td);var tr=document.createElement("tr");tBody.appendChild(tr);var td=document.createElement("td");td.style.height="8px";td.style.width="8px";td.style.backgroundImage="url(/upload/js_globals/background_images/llc.png)";tr.appendChild(td);var td=document.createElement("td");td.style.backgroundImage="url(/upload/js_globals/background_images/b.png)";td.style.width="8px";tr.appendChild(td);var td=document.createElement("td");td.style.height="8px";td.style.width="8px";td.style.backgroundImage="url(/upload/js_globals/background_images/lrc.png)";tr.appendChild(td);}

function npop_createContentArea(popupObj){popupObj.popupArea.innerHTML="";var tbody=createTable(popupObj.popupArea);var table=tbody.parentNode;if(popupObj.buildCloseButton){var tr=cE("tr",tbody);npop_buildTitleRow(popupObj,tr);}

var tr=cE("tr",tbody);var td=cE("td",tr);td.vAlign="top";popupObj.resizableArea=td;var contentArea=cE("div",td);contentArea.style.backgroundColor="white";if(IS_IE&&BrowserUtil.getVersion()<10){contentArea.style.width="0px";contentArea.style.height="0px";}

else 
{contentArea.style.width="100%";contentArea.style.height="100%";contentArea.style.paddingBottom="1px";}

popupObj.contentArea=contentArea;}

function npop_buildTitleRow(popupObj,titleRow){if(popupObj.drawTitleBar){var td=document.createElement("td");titleRow.appendChild(td);npop_buildTitleRowTable(popupObj,td);}

else 
{var close=document.createElement("td");close.style.padding="7px";close.align="right";close.style.backgroundColor=(popupObj.titleBackgroundColor)?popupObj.titleBackgroundColor:"white";titleRow.appendChild(close);popupObj.dragTrigger=close;var img=document.createElement("img");img.src="/upload/js_globals/generic_images/popup_close.gif";img.onclick=function(){popupObj.closePopup()}
;img.style.cursor="pointer";close.appendChild(img);}

}

function npop_buildTitleRowTable(popupObj,container){var table=document.createElement("table");table.cellPadding=0;table.cellSpacing=0;table.style.width="100%";container.appendChild(table);popupObj.dragTrigger=table;var tbody=document.createElement("tbody");table.appendChild(tbody);var tr=document.createElement("tr")
tbody.appendChild(tr)
var td=document.createElement("td");if(popupObj.popupTitle==""){td.innerHTML="&nbsp";}

else 
{td.innerHTML=popupObj.popupTitle;}

td.className="mediumText";td.style.color=popupObj.fontColor;td.style.fontWeight="bold";td.style.padding="4px";td.style.paddingLeft="8px";td.style.borderBottom="1px solid  #B6B6B6";td.style.height="30px";if(popupObj.bgImage==null){td.style.backgroundColor=popupObj.bgColor;}

else 
{td.style.backgroundImage="url(/"+popupObj.bgImage+")";}

tr.appendChild(td);var close=document.createElement("td");close.style.padding="7px";close.align="right";close.style.borderBottom="1px solid  #b6b6b6"
if(popupObj.bgImage==null){close.style.backgroundColor=popupObj.bgColor;}

else 
{close.style.backgroundImage="url(/"+popupObj.bgImage+")";}

tr.appendChild(close);var img=document.createElement("img");img.src="/upload/js_globals/generic_images/popup_close.gif";img.onclick=function(){popupObj.closePopup()}
;img.style.cursor="pointer";close.appendChild(img);}

function field_Pw(name,displayName,displayOrder){this.doSave=false;this.sendWelcomeEmail=true;this.input=null;this.adjustInput=function(width,height,maxLength,validationType){password_adjustInput(this,width,height,maxLength,validationType);}
;this.buildPasswordInput=function(){return pw_buildPasswordInput(this)}
;this.TYPE="PASSWORD";this.TYPE_DISPLAY_NAME="Password";this.ownerRecord;this.ownerCache;this.parentField;this.name=name;this.displayName=displayName;this.displayOrder=displayOrder
this.value=null;this.isEditable=false;this.isVisible=true;this.children=new Array();this.fieldContainer=null;this.init=function(){}

this.buildChildFields=function(){pw_buildChildFields(this);}

this.buildHTML=function(){return pw_buildHTML(this);}

this.buildSettingsHTML=function(){return pw_buildSettingsHTML(this);}

this.toXml=function(){return pw_toXml(this);}

this.clone=function(){return pw_clone(this);}

}

function pw_objectToField(object,name){var field=new field_Pw(name,"",0);field.value=object.value;field.doSave=true;field.sendWelcomeEmail=object.sendWelcomeEmail;return field;}

if(window.registerConverter){registerConverter("PASSWORD",pw_objectToField);}

function pw_buildPasswordInput(thisObj){var input=document.createElement("input");input.type="password";thisObj.input=input;input.displayName=thisObj.displayName;input.onchange=function(){thisObj.value=this.value;}

if(thisObj.doSubmit){input.thisObj=thisObj;var eventFx=function(){pw_submit(input,thisObj)}

keypressevent_onEnterHandler(input,eventFx);}

return input;}

function password_adjustInput(thisObj,width,height,maxLength,validationType){if(width!=null){thisObj.input.style.width=width;}

if(height!=null){thisObj.input.style.height=height;}

if(validationType!=null){if(thisObj.input.validationType){thisObj.input.validationType+=","+validationType;}

else 
{thisObj.input.validationType=validationType;}

validation_attachValidationToElement(thisObj.input);}

if(maxLength!=null){thisObj.input.maxLength=maxLength;}

}

function pw_buildChildFields(thisObj){thisObj.children=new Array();thisObj.children.value=new field_String("value","Value",1.0,thisObj.value,false);thisObj.children.doSave=new field_Boolean("doSave","Value",1.0,thisObj.doSave,false);thisObj.children.send_welcome_email=new field_Boolean("send_welcome_email","Value",1.0,thisObj.sendWelcomeEmail,false);}

function pw_buildHTML(thisObj){if(thisObj.fieldContainer==null){thisObj.fieldContainer=document.createElement("span");}

if(thisObj.isEditable){pw_buildEditableHTML(thisObj);}

else 
{pw_buildReadOnlyHTML(thisObj);}

return thisObj.fieldContainer;}

function pw_buildEditableHTML(thisObj){var input=document.createElement("input");input.type="password";input.style.width=150;input.field=thisObj;thisObj.input=input;input.displayName=thisObj.displayName;input.onchange=function(){thisObj.value=this.value;}

thisObj.fieldContainer.appendChild(input);if(thisObj.doSubmit){var eventFx=function(){pw_submit(input,thisObj)}

keypressevent_onEnterHandler(input,eventFx);}

}

function pw_submit(input,thisObj){thisObj.value=util_formatForXmlValue(input.value);thisObj.ownerCache.submitCache("go")
}

function pw_buildReadOnlyHTML(thisObj){var dataSpan=document.createElement("span");dataSpan.innerHTML="***************";dataSpan.className=thisObj.readOnlyClassName;thisObj.fieldContainer.appendChild(dataSpan);}

function pw_buildSettingsHTML(thisObj){var container=document.createElement("div")
return container;}

function pw_toXml(thisObj){if(!thisObj.doSave){return "";}

thisObj.buildChildFields();var xml=util_openFieldXmlTag(thisObj);for(var name in thisObj.children)
{xml+=thisObj.children[name].toXml();}

xml+=util_closeFieldXmlTag();thisObj.children=null;return xml;}

function pw_clone(thisObj){return new field_Pw(thisObj.name,thisObj.displayName,thisObj.displayOrder);}



validation_displayFieldError=display_displayAlert;var validation_displayErrors=display_displayAlert;function display_displayAlert(errorList,successList){var errorString="";if(0<errorList.length){for(var i=0;i<errorList.length;i++)
{errorString+=errorList[i].errorMessage+"\n";}

alert(errorString);}

}


var key_keyCodeTranslater=new Array();key_keyCodeTranslater[48]="0";key_keyCodeTranslater[49]="1";key_keyCodeTranslater[50]="2";key_keyCodeTranslater[51]="3";key_keyCodeTranslater[52]="4";key_keyCodeTranslater[53]="5";key_keyCodeTranslater[54]="6";key_keyCodeTranslater[55]="7";key_keyCodeTranslater[56]="8";key_keyCodeTranslater[57]="9";key_keyCodeTranslater[65]="A";key_keyCodeTranslater[66]="B";key_keyCodeTranslater[67]="C";key_keyCodeTranslater[68]="D";key_keyCodeTranslater[69]="E";key_keyCodeTranslater[70]="F";key_keyCodeTranslater[71]="G";key_keyCodeTranslater[72]="H";key_keyCodeTranslater[73]="I";key_keyCodeTranslater[74]="J";key_keyCodeTranslater[75]="K";key_keyCodeTranslater[76]="L";key_keyCodeTranslater[77]="M";key_keyCodeTranslater[78]="N";key_keyCodeTranslater[79]="O";key_keyCodeTranslater[80]="P";key_keyCodeTranslater[81]="Q";key_keyCodeTranslater[82]="R";key_keyCodeTranslater[83]="S";key_keyCodeTranslater[84]="T";key_keyCodeTranslater[85]="U";key_keyCodeTranslater[86]="V";key_keyCodeTranslater[87]="W";key_keyCodeTranslater[88]="X";key_keyCodeTranslater[89]="Y";key_keyCodeTranslater[90]="Z";key_keyCodeTranslater[96]="0";key_keyCodeTranslater[97]="1";key_keyCodeTranslater[98]="2";key_keyCodeTranslater[99]="3";key_keyCodeTranslater[100]="4";key_keyCodeTranslater[101]="5";key_keyCodeTranslater[102]="6";key_keyCodeTranslater[103]="7";key_keyCodeTranslater[104]="8";key_keyCodeTranslater[105]="9";

var year_requiredMsgStr1="The number '";var year_requiredMsgStr2="' is not a valid email year. It has to be a number between 1000 and 2500.";var email_requiredMsgStr1="The address '";var email_requiredMsgStr2="' is not a valid email address.";var dynfield_requiredMsgStr1="Field '";var dynfield_requiredMsgStr2="' is not defined for type '";
var time_timeMsgStr1="The field '";var time_timeMsgStr2="' is not a valid time.";var time_afterTimeMsgStr1="The field '";var time_afterTimeMsgStr2="' should be later than the field '";var time_afterTimeMsgStr3="'.";var time_beforeTimeMsgStr1="The field '";var time_beforeTimeMsgStr2="' should be earlier than the field '";var time_beforeTimeMsgStr3="'.";var time_use24HourFormat=false;var numeric_minMsgStr1="The field '";var numeric_minMsgStr2="' should be greater than ";var numeric_minMsgStr3=".";var numeric_maxMsgStr1="The field '";var numeric_maxMsgStr2="' should be less than ";var numeric_maxMsgStr3=".";var numeric_lessThanMsgStr1="The field '";var numeric_lessThanMsgStr2="' should be less than the field '";var numeric_lessThanMsgStr3="'.";var numeric_lessThanEqualMsgStr1="The field '";var numeric_lessThanEqualMsgStr2="' should be less than or equal to the field '";var numeric_lessThanEqualMsgStr3="'.";var numeric_greaterThanMsgStr1="The field '";var numeric_greaterThanMsgStr2="' should be greater than the field '";var numeric_greaterThanMsgStr3="'.";var numeric_greaterThanEqualMsgStr1="The field '";var numeric_greaterThanEqualMsgStr2="' should be greater than or equal to the field '";var numeric_greaterThanEqualMsgStr3="'.";var numeric_decimalMsgStr1="The field '";var numeric_decimalMsgStr2="' is not a valid decimal.";var required_requiredMsgStr1="The field '";var required_requiredMsgStr2="' is required.";var select_reqSelMsgStr1=" The field '";var select_reqSelMsgStr2="' must have exactly ";var select_reqSelMsgStr3=" options selected.";var select_minSelMsgStr1=" The field '";var select_minSelMsgStr2="' must have a minimum of ";var select_minSelMsgStr3=" options selected.";var select_maxSelMsgStr1=" The field '";var select_maxSelMsgStr2="' must have not have more than ";var select_maxSelMsgStr3=" options selected.";var length_lengthMsgStr1="The field '";var length_lengthMsgStr2="' should be ";var length_lengthMsgStr3=" characters long.";var phone_phoneMsgStr1="The field '";var phone_phoneMsgStr2="' is not a valid phone number.";

var PERIOD_KEYCODE=46;var COMMA_KEYCODE=44;var MINUS_KEYCODE=45;var ZERO_KEYCODE=48;var NINE_KEYCODE=57;var BACKSPACE_KEYCODE=8;var DEFAULT_KEYCODE=0;
var valutility_currentEvent;
function valutility_cancelKeyPress(){crossbrowser_handleEvent(valutility_currentEvent);return null;}


function valutility_isNumeric(){var keyCode=crossbrowser_getKeyCode(valutility_currentEvent);if(keyCode>=ZERO_KEYCODE&&keyCode<=NINE_KEYCODE){return true;}

return false;}


function valutility_isAlphabetic(){var keyCode=crossbrowser_getKeyCode(valutility_currentEvent);if((keyCode>=65&&keyCode<=90)||(keyCode>=97&&keyCode<=122)){return true;}

return false;}


function valutility_isCharacter(keyCode){var keyCodePressed=crossbrowser_getKeyCode(valutility_currentEvent);if(keyCodePressed==keyCode){return true;}

return false;}

;;;;
var validation_ValidationTypes=new Array();
crossbrowser_attachEvent(window,"onload",validation_init);var validation_displayErrors;var validation_displayFieldError;var validation_elTypesToValidate=new Array("input","select","textarea","span","div","nobr","a");function validation_init(){validation_attachValidation();}



function validation_EventFunction(eventName,functionPointer){this.eventName=eventName;this.functionPointer=functionPointer;}


function validation_Error(element,errorMessage){this.element=element;this.errorMessage=errorMessage;}


function validation_ValidationType(name,defaultFunction){this.defaultFunction=defaultFunction;this.eventValidationList=new Array();this.addEventFunction=function(eventName,functionPointer){this.eventValidationList[eventName]=functionPointer;}

validation_ValidationTypes[name.toLowerCase()]=this;}


function validation_getFunctionForValType(valType,eventType){return valType.eventValidationList[eventType];}


function validation_validate(container){if(null==container){container=document.body;}

var errorList=new Array();var successList=new Array();for(var i=0;i<validation_elTypesToValidate.length;i++)
{var elementList=container.getElementsByTagName(validation_elTypesToValidate[i]);validaton_validateCollection(elementList,errorList,successList);}

validation_displayErrors(errorList,successList);return (errorList.length==0)?true:false;}

function validation_validateElement(element){var errorList=new Array();var successList=new Array();var someErrors=validation_validateField(element);for(var j=0;j<someErrors.length;j++)
{errorList.push(someErrors[j]);}

validation_displayErrors(errorList,successList);return (errorList.length==0)?true:false;}

function validation_validateLinks(container){var errorList=new Array();var successList=new Array();validaton_validateCollection(container.getElementsByTagName("a"),errorList,successList);validation_displayErrors(errorList,successList);return (errorList.length==0)?true:false;}

function validation_validateInputs(container){var errorList=new Array();var successList=new Array();validaton_validateCollection(container.getElementsByTagName("input"),errorList,successList);validation_displayErrors(errorList,successList);return (errorList.length==0)?true:false;}


function validaton_validateCollection(aCollection,errorList,successList){for(var i=0;i<aCollection.length;i++)
{var someErrors=validation_validateField(aCollection[i]);for(var j=0;j<someErrors.length;j++)
{errorList.push(someErrors[j]);}

if(0==someErrors.length){successList.push(aCollection[i]);}

}

}


function validation_validateField(anInput){var errorList=new Array();var validationType=validation_getAttribute(anInput,"validationType");if(null!=validationType&&validationType!=""){var valTypeArray=validation_removeSpaces(validationType).split(",");for(var j=0;j<valTypeArray.length;j++)
{var valType=validation_ValidationTypes[valTypeArray[j]];if((undefined!=valType)&&(null!=valType.defaultFunction)){aPossibleError=valType.defaultFunction(anInput);if(null!=aPossibleError){errorList.push(aPossibleError);}

}

}

}

return errorList;}


function validation_ValidateFieldOnEvent(object,eventType,customEventHandler,event){valutility_currentEvent=event;var errorList=new Array();var validationType=validation_getAttribute(object,"validationType");if(null!=validationType){var valTypeArray=validation_removeSpaces(validationType).split(",");for(var j=0;j<valTypeArray.length;j++)
{var valType=validation_ValidationTypes[valTypeArray[j]];var valFunc=validation_getFunctionForValType(valType,eventType);if(null!=valFunc){aPossibleError=valFunc(object);if(null!=aPossibleError){errorList.push(aPossibleError);}

}

}

}

var successList=new Array();if(errorList.length==0){successList.push(object);}

if(window.validation_displayFieldError){validation_displayFieldError(errorList,successList);}

if((errorList.length==0)&&(customEventHandler!=null)){customEventHandler();}

}


function validation_attachValidation(container){if(null==container){container=document.body;}

for(var i=0;i<validation_elTypesToValidate.length;i++)
{var elementList=container.getElementsByTagName(validation_elTypesToValidate[i]);validation_attachValidationToCollection(elementList);}

}


function validation_attachValidationToCollection(aCollection){for(var i=0;i<aCollection.length;i++)
{validation_attachValidationToElement(aCollection[i]);}

}


function validation_attachValidationToElement(anObject){var validationType=validation_getAttribute(anObject,"validationType");if(validationType==null){return ;}

var eventsAdded=new Array();var valTypeArray=validation_removeSpaces(validationType).split(",");for(var j=0;j<valTypeArray.length;j++)
{var validationObject=validation_ValidationTypes[valTypeArray[j].toLowerCase()];if(null!=validationObject){var eventList=validationObject.eventValidationList;for(var k in eventList)
{if(!eventsAdded[k]){var customEventHandler=anObject[k];var temp=k;validation_attachEventToElement(k,anObject,customEventHandler)
if(k=="onload"){validation_ValidateFieldOnEvent(anObject,k,customEventHandler);}

eventsAdded[k]=true;}

}

}

}

}


function validation_attachEventToElement(eventType,anObject,customEventHandler){anObject[eventType]=function(event){validation_ValidateFieldOnEvent(anObject,eventType,customEventHandler,event);}


}


function validation_getAttribute(anObject,attributeName){var value=(anObject[attributeName])?anObject[attributeName]:anObject.getAttribute(attributeName);return value;}


function validation_removeSpaces(aString){return aString.replace(/ /g,"");}



function login_Login(name,displayName,displayOrder){this.buildUsername=function(width){var userNameField=this.children.username;userNameField.isEditable=true;var storedUserName=readCookie("userName");if(storedUserName){userNameField.value=storedUserName;}

var userNameEl=userNameField.buildInputElement();userNameEl.style.width=(width!=null)?width:200;return userNameEl;}
;this.buildPassword=function(width){var passwordField=this.children.password;passwordField.isEditable=true;passwordField.doSubmit=true;var passwordEl=passwordField.buildPasswordInput();passwordEl.style.width=(width!=null)?width:200;return passwordEl;}
;this.rememberMe=false;this.buildButton=function(){return login_buildButton(this)}
;this.setUserName=function(userName){this.children.username.value=userName}
;this.setPassword=function(password){this.children.password.value=password}
;this.TYPE="LOGIN";this.TYPE_DISPLAY_NAME="Login";this.ownerRecord;this.ownerCache;this.parentField;this.name=name;this.displayName=displayName;this.displayOrder=displayOrder
this.isVisible=true;this.isEditable=false;this.children=new Array();this.children.username=new field_String("username","username",0,"",false);this.children.password=new field_Pw("password","password",0);this.children.password.doSave=true;this.fieldContainer=null;this.init=function(){login_init(this)}
;this.buildHTML=function(){return login_buildHTML(this)}
;this.buildChildFields=function(){}
;this.buildSettingsHTML=function(){}
;this.clone=function(){return null}
;this.toXml=function(){return login_toXml(this)}
;}

function login_init(thisObj){for(var i in thisObj.children)
{thisObj.children[i].ownerCache=thisObj.ownerCache;thisObj.children[i].ownerRecord=thisObj.ownerRecord;thisObj.children[i].parentField=thisObj;thisObj.children[i].init();}

}

function login_buildHTML(thisObj){if(thisObj.fieldContainer==null){thisObj.fieldContainer=document.createElement("span");}

var div=document.createElement("div");thisObj.fieldContainer.appendChild(div);var span=document.createElement("span");span.innerHTML="Username: ";div.appendChild(span);var userName=thisObj.children.username;userName.isEditable=true;var userNameEl=userName.buildHTML();div.appendChild(userNameEl);var div=document.createElement("div");thisObj.fieldContainer.appendChild(div);var span=document.createElement("span");span.innerHTML="Password: ";div.appendChild(span);var password=thisObj.children.password;password.isEditable=true;div.appendChild(password.buildHTML());var button=login_buildButton(thisObj);thisObj.fieldContainer.appendChild(button);return thisObj.fieldContainer;}

function login_buildButton(thisObj){var button=document.createElement("button");button.innerHTML="Login";button.onclick=function(){var logInFx=function(){thisObj.ownerCache.submitCache("go")
}

if(thisObj.rememberMe){var un=thisObj.children.username.value;var pw=thisObj.children.password.value;var cH=new CredentialHandler();cH.encrypt(un,pw,logInFx);}

else 
{logInFx();}

}
;return button;}

function login_toXml(thisObj){thisObj.buildChildFields();var xml=util_openFieldXmlTag(thisObj);for(var name in thisObj.children)
{xml+=thisObj.children[name].toXml();}

xml+=util_closeFieldXmlTag();return xml;}

function core_Record(type,id){this.type=type;this.id=id;this.names=new Array();this.indexedNames=new Array();this.fields=new Array();this.isOwned=false;this.toSave=false;this.toLoad=false;this.toDelete=false;this.doProcess=false;this.fieldsToLoad="";this.isKeyed=false;this.includeMissingFields=false;this.ownerCache;this.init=function(){record_init(this)}
;this.toXml=function(){return record_toXml(this)}
;this.getFieldByName=function(name){return this.fields[name]}
;this.addName=function(name){record_addName(name,this)}
;this.addNames=function(names){record_addNames(names,this)}
;this.addKey=function(fieldName,keyWord,createIfMissing){record_addKey(this,fieldName,keyWord,createIfMissing)}
;this.addRecordTypeToLoad=function(fieldName){record_addRecordTypeToLoad(this,fieldName)}
;this.addRecordIdListToLoad=function(fieldName){record_addRecordIdListToLoad(this,fieldName);}
;this.addPhotoInput=function(name,fieldName,jsName,maxWidth,maxHeight,width,height){record_addPhotoInput(name,fieldName,jsName,maxWidth,maxHeight,width,height,this)
}
;this.getFieldByName=function(fieldName){return record_getFieldByName(fieldName,this)}
;this.addFieldToLoad=function(fieldName){record_addFieldToLoad(this,fieldName)}
;this.addField=function(field){this.fields[field.name]=field}
;this.replaceField=function(field,name){record_replaceField(name,field,this)}
;this.clearNames=function(){record_clearNames(this)}
;this.removeField=function(name){this.fields[name]=null}
;this.clone=function(){return record_clone(this)}
;}

function record_clone(thisObj){var clonedRecord=new core_Record(thisObj.type,-100);for(var fieldName in thisObj.fields)
{clonedRecord.fields[fieldName]=thisObj.fields[fieldName].clone();}

clonedRecord.init();return clonedRecord;}

function record_clearNames(thisObj){thisObj.indexedNames=[];thisObj.names=[];}

function record_replaceField(name,field,thisObj){thisObj.fields[name]=field;field.name=name;}

function record_getFieldByName(fieldName,thisObj){var field=thisObj.fields[fieldName];return field;}

function record_addPhotoInput(name,fieldName,jsName,maxWidth,maxHeight,width,height,thisObj){thisObj.fields[name]=new photoInput_PhotoInput(name,fieldName,jsName,maxWidth,maxHeight,width,height)
}

function record_addRecordTypeToLoad(thisObj,fieldName){if(!thisObj.fields.recordTypeFields){thisObj.fields.recordTypeFields=new rti_RecordTypeInput("input_key");}

thisObj.fields.recordTypeFields.addFieldNameToLoad(fieldName);}

function record_addRecordIdListToLoad(thisObj,fieldName){if(!thisObj.fields.recordIdListFields){thisObj.fields.recordIdListFields=new recordidlistinput_RecordIdListInput();}

thisObj.fields.recordIdListFields.addFieldNameToLoad(fieldName);}

function record_addKey(thisObj,fieldName,keyWord,createIfMissing){thisObj.fields.input_key=new keyinput_RecordKeyInput(keyWord,fieldName);thisObj.isKeyed=true;}

function record_addNames(names,thisObj){for(var i=0;i<names.length;i++)
{if(thisObj.indexedNames[names[i]]){continue;}

record_addName(names[i],thisObj);}

}

function record_addName(name,thisObj){if(name==null||name==undefined||name==""){return ;}

thisObj.indexedNames[name]=true;thisObj.names.push(name);}

function record_addFieldToLoad(recordObj,fieldName){if(!fieldName||fieldName==""){return ;}

recordObj.fieldsToLoad+=fieldName+",";}

function record_init(thisObj){for(var name in thisObj.fields)
{if(thisObj.fields[name]==null||thisObj.fields[name]==undefined){continue;}

thisObj.fields[name].ownerRecord=thisObj;thisObj.fields[name].ownerCache=thisObj.ownerCache;if(thisObj.fields[name].init){thisObj.fields[name].init();}

}

}

function record_toXml(thisObj){var xml=record_createRecordTag(thisObj);for(var i in thisObj.fields)
{if(thisObj.fields[i]==null){continue;}

xml+=thisObj.fields[i].toXml();}

return xml+=constants_LESS_THAN_CHAR+"/record>"
}

function record_createRecordTag(thisObj){var name=record_createNameStr(thisObj);var xml=constants_LESS_THAN_CHAR+"record type='"+thisObj.type+"' do_save='"+
thisObj.toSave+"' do_load='"+thisObj.toLoad+"'   do_delete='"+thisObj.toDelete+"' fields_to_load='"+
thisObj.fieldsToLoad+"' include_missing_fields='"+thisObj.includeMissingFields+"'";if(name!=""){xml+="  name='"+name+"'";}

if(thisObj.doProcess){xml+="  do_process='true'";}

if(thisObj.isKeyed){xml+="  is_load_by_key='true'";}

else 
{xml+=" id='"+thisObj.id+"'";}

xml+=">";return xml
}

function record_createNameStr(thisObj){var name="";for(var i=0;i<thisObj.names.length;i++)
{name+=thisObj.names[i];if((i+1)<thisObj.names.length){name+=",";}

}

return name;}


function clone(myObj){if(typeof(myObj)!='object'){return myObj;}

if(myObj==null){return myObj;}

var myNewObj=[];if(myObj.length&&myObj[0]!=undefined&&!myObj["0_ft"]){for(var i=0;i<myObj.length;i++)
{myNewObj.push(clone(myObj[i]));}

}

else 
{for(var i in myObj)
{myNewObj[i]=clone(myObj[i]);}

}

return myNewObj;}



if(!mc_fieldTypeExtenders){var mc_fieldTypeExtenders={}
;}


mc_fieldTypeExtenders["RIL2"]=function(dynField){dynField.superGetChildField=dynField.getChildField;extendField(dynField,ril_recordIdListBase);}

var ril_recordIdListBase=new RecordIdListBase();function RecordIdListBase(){this.getIds=function(){if(!this.data.idArray){var idsField=this.getChildField("ids");var idList=idsField.getValue();this.data.idArray=(""==idList)?[]:idList.split("|");for(var i=0;i<this.data.idArray.length;i++)
{var id=this.data.idArray[i];if(id==""){this.data.idArray.splice(i,1);}

}

idsField.setValue("refer to id array",true);}

return this.data.idArray;}
;this.getChildField=function(fieldName){if(fieldName=="ids"){var ids=this.superGetChildField(fieldName);ids.setValue=function(value,isDontSetSave){var liveField=this.getLiveField();this.setFieldValue(this,value,isDontSetSave);if(liveField){this.setFieldValue(liveField,value,isDontSetSave);}

return this;}
;return ids;}

else 
{return this.superGetChildField(fieldName);}

}
;this.clearIds=function(){var liveField=this.getLiveField();this.getChildField("ids").setValue("refer to id array",true);var idArray=[];this.data.idArray=idArray;if(liveField){liveField.data.idArray=idArray;}

this.setDoSave();}
;this.addId=function(id){if(this.contains(id)){return this;}

this.setDoSave();var idsList=this.getIds();idsList.push(id);return this;}
;this.contains=function(id){var ids=this.getIds();for(var i=0;i<ids.length;i++)
{if(ids[i]==id){return true;}

}

return false;}
;this.removeId=function(id){this.setDoSave();var idsList=this.getIds();for(var i=0;i<idsList.length;i++)
{if(idsList[i]==id){idsList.splice(i,1);break;}

}

return this;}
;}



var ADateUtil=new ADateUtilBase();function ADateUtilBase(){
this.MONTH_ABBR="m_abbr";
this.MONTH_STR="m_full";
this.DAY_ABBR="d_abbr";
this.DAY_STR="d_full";
this.DAY_LETTER="day_letter";
this.DATE_ABBR="dt_abbr";
this.DATE="date";
this.MONTH="month";
this.YEAR="year";
this.adjustMonth=function(dateObj,interval){var month=dateObj.month+interval;var year=dateObj.year;if(1>month){month+=12;year--;}

else if(12<month){month-=12;year++;}

var newMonthDayCount=this.getMonthDayCount(month,year);var date=Math.min(dateObj.date,newMonthDayCount);return new ADate(date,month,year);}
;
this.getCurrentDate=function(){var currentDate=g_sessionInformation.current_datetime;return new ADate(currentDate.date,currentDate.month,currentDate.year);}


this.stringToDate=function(dateString,dateObj){var re=new RegExp("\\D*(\\d*)\\D*(\\d*)\\D*(\\d*)\\D*");var result=re.exec(dateString);if(null==result){return null;}

var date=this.parseDatePart(result[this.DATE_POS]);var month=this.parseDatePart(result[this.MONTH_POS]);var year=this.parseDatePart(result[this.YEAR_POS])
if(year<30){year+=2000;}

else if(year>30&&year<100){year+=1900;}

if(this.isValidDate(date,month,year)){if(dateObj!=null){dateObj.date=date;dateObj.month=month;dateObj.year=year;}

else 
{dateObj=new ADate(date,month,year);}

return dateObj;}

else 
{return null;}

}


this.dbFormatToDate=function(str){var dateObj=str.split("-");return new ADate(dateObj[2],dateObj[1],dateObj[0]);}


this.getLabel=function(labelKey,index){var labels=this.getLabels(labelKey);if(null==labels){return null;}

if(labelKey==this.MONTH_ABBR||labelKey==this.MONTH_STR){index--;}

return labels[index];}
;
this.getLabels=function(labelKey){var labels=this.LABEL_KEYS[labelKey];if(null==labels){return null;}

return labels;}


this.getMonthDayCount=function(month,year){var dayCounts=[31,-1,31,30,31,30,31,31,30,31,30,31];var dayCount;if(month==2){dayCount=this.isLeapYear(year)?29:28;}

else 
{dayCount=dayCounts[month-1];}

return dayCount;}


this.getInterval=function(dateObj1,dateObj2){var interval=0;var date1DbFormat=dateObj1.toDbFormat();var date2DbFormat=dateObj2.toDbFormat();var dateA;var dateB;if(date1DbFormat<date2DbFormat){dateA=dateObj1.clone();dateB=dateObj2.clone();}

else if(date1DbFormat>date2DbFormat){dateA=dateObj2.clone();dateB=dateObj1.clone();}

else 
{return 0;}

while(!dateA.equals(dateB))
{interval++;dateA.changeDate(1);}

return interval;}
;
this.TYPE="DATE";
this.EMPTY_DATE="MM/dd/yyyy";
this.SEPARATOR="/";
this.MONTH_POS=1;
this.DATE_POS=2;
this.YEAR_POS=3;
this.NULL_DATE="0000-00-00";
this.LABEL_KEYS=[];{var mAbbr=[];mAbbr.push("Jan");mAbbr.push("Feb");mAbbr.push("Mar");mAbbr.push("Apr");mAbbr.push("May");mAbbr.push("Jun");mAbbr.push("Jul");mAbbr.push("Aug");mAbbr.push("Sep");mAbbr.push("Oct");mAbbr.push("Nov");mAbbr.push("Dec");this.LABEL_KEYS[this.MONTH_ABBR]=mAbbr;}

{var months=[];months.push("January");months.push("February");months.push("March");months.push("April");months.push("May");months.push("June");months.push("July");months.push("August");months.push("September");months.push("October");months.push("November");months.push("December");this.LABEL_KEYS[this.MONTH_STR]=months;}

{var dAbbrv=[];dAbbrv.push("Sun");dAbbrv.push("Mon");dAbbrv.push("Tue");dAbbrv.push("Wed");dAbbrv.push("Thu");dAbbrv.push("Fri");dAbbrv.push("Sat");this.LABEL_KEYS[this.DAY_ABBR]=dAbbrv;}

{var days=[];days.push("Sunday");days.push("Monday");days.push("Tuesday");days.push("Wednesday");days.push("Thursday");days.push("Friday");days.push("Saturday");this.LABEL_KEYS[this.DAY_STR]=days;}

{var days=[];days.push("S");days.push("M");days.push("T");days.push("W");days.push("T");days.push("F");days.push("S");this.LABEL_KEYS[this.DAY_LETTER]=days;}

this.selectDatePart=function(partNumber,date,month,year){if(partNumber==this.DATE_POS){return this.formatDatePart(date);}

else if(partNumber==this.MONTH_POS){return this.formatDatePart(month);}

else if(partNumber==this.YEAR_POS){return year;}

}
;this.formatDatePart=function(number){if(number<10){return "0"+number;}

return parseInt(number,10);}
;this.parseDatePart=function(datePart){var i=0;while(datePart.charAt(i)=='0')
{i++;}

var datePart=datePart.substring(i,datePart.length);return parseInt(datePart,10);}
;
this.isValidDate=function(date,month,year){if(isNaN(date)||isNaN(month)||isNaN(year)){return false;}

if(month<1||month>12){return false;}

var daysInMonth=this.getMonthDayCount(month,year);if(date>daysInMonth){return false;}

if(year<1000){return false;}

return true;}
;
this.isLeapYear=function(year){if(((year%4)==0)&&((year%100)!=0)||((year%400)==0)){return true;}

else 
{return false;}

}
;this.initDateFormat=function(){try
{var dateFormat=g_sessionInformation.settings.date_format;this.EMPTY_DATE=dateFormat.empty_date;this.SEPARATOR=dateFormat.separator;this.DATE_POS=dateFormat.date_pos;this.MONTH_POS=dateFormat.month_pos;this.YEAR_POS=dateFormat.year_pos;}

catch(e)
{}

}
;this.initDateFormat();}
;
String.prototype.trim=function(){return trim(this)}
;String.prototype.safeGetValue=function(val,defVal){return safeGetValue(val,defVal)}
;String.prototype.escapeStrForSave=function(){return escapeStrForSave(this)}
;String.prototype.unescapeStrFromLoad=function(){return unescapeStrFromLoad(this)}
;String.prototype.escapeStrForXml=function(){return escapeStrForXml(this)}
;String.prototype.unescapeStrFromXml=function(){return unescapeStrFromXml(this)}
;String.prototype.sc={"\\":"\\\\","(":"\\(","^":"\\^","$":"\\$",".":"\\.","|":"\\|","?":"\\?","*":"\\*","+":"\\+",")":"\\)"}
;String.prototype.equals=function(value){return value==this;}
;String.prototype.replaceAll=function(replaceVal,replaceWith){try
{var sc=this.sc
for(var aChar in this.sc)
{var rChar=sc[aChar];replaceVal=replaceVal.replace(aChar,rChar);}

return this.replace(new RegExp(replaceVal,"g"),replaceWith);}

catch(e)
{return this.replace(new RegExp(replaceVal,"g"),replaceWith);}

}

function trim(str){var str=str.replace(/^\s\s*/,'');var ws=/\s/;var i=str.length;while(ws.test(str.charAt(--i))){}
;return str.slice(0,i+1);}

function safeGetValue(val,defVal){if(null!=val){return val;}

return defVal;}

function escapeStrForSave(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("[+]","g"),"!@!plus!@!");strRet=strRet.replace(new RegExp("[\n]","g"),"!@!newline!@!");return strRet;}

function unescapeStrFromLoad(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("!@!plus!@!","g"),"+");strRet=strRet.replace(new RegExp("!@!newline!@!","g"),"\n");return strRet;}

function escapeStrForXml(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("[&]","g"),"&amp;");strRet=strRet.replace(new RegExp("[']","g"),"&apos;");strRet=strRet.replace(new RegExp("[\"]","g"),"&quot;");strRet=strRet.replace(new RegExp("[<]","g"),"&lt;");strRet=strRet.replace(new RegExp("[>]","g"),"&gt;");return strRet;}

function unescapeStrFromXml(strSrc){if(null==strSrc){return null;}

var strRet=strSrc;strRet=strRet.replace(new RegExp("&amp;","g"),"&");strRet=strRet.replace(new RegExp("&apos;","g"),"'");strRet=strRet.replace(new RegExp("&quot;","g"),"\"");strRet=strRet.replace(new RegExp("&lt;","g"),"<");strRet=strRet.replace(new RegExp("&gt;","g"),">");return strRet;}

;;function ADate(date,month,year){try
{this.date=parseInt(date,10);this.month=parseInt(month,10);this.year=parseInt(year,10);}

catch(e)
{this.date=date;this.month=month;this.year=year;}

}
;ADate.prototype=new ADateBase();function ADateBase(){
this.getDayIndex=function(){var aDate=new Date(this.year,this.month-1,this.date);return aDate.getDay();}
;
this.toDbFormat=function(){if(!ADateUtil.isValidDate(this.date,this.month,this.year)){return ADateUtil.NULL_DATE;}

return this.year+"-"+ADateUtil.formatDatePart(this.month)+"-"+ADateUtil.formatDatePart(this.date);}
;
this.update=function(dateStr){return ADateUtil.stringToDate(dateStr,this);}
;
this.getString=function(params){if(null==params||params.length<1){return this.toDefaultString();}

var monthStr="";var monthPos=-1;var dateStr="";var datePos=-1;var fullStr="";for(var i=0;i<params.length;i++)
{switch(params[i]){
case'm_abbr':
monthStr=ADateUtil.getLabel('m_abbr',this.month);fullStr+="!monthStr!";monthPos=i;break;case'm_full':
monthStr=ADateUtil.getLabel('m_full',this.month);fullStr+="!monthStr!";monthPos=i;break;case'd_abbr':
fullStr+=ADateUtil.getLabel('d_abbr',this.getDayIndex());break;case'd_full':
fullStr+=ADateUtil.getLabel('d_full',this.getDayIndex());break;case'dt_abbr':

alert("do we need to abbreviate dates???");break;case'date':
fullStr+="!dateStr!";dateStr=this.date;datePos=i;break;case'month':
fullStr+="!monthStr!";monthStr=this.month;monthPos=i;break;case'year':
fullStr+=this.year;break;default:
fullStr+=params[i];}

}

var usDateFormat="!monthStr!/!dateStr!/"+this.year;if(fullStr.indexOf(usDateFormat)>-1){fullStr=fullStr.replace(usDateFormat,this.toDefaultString());}

else 
{var isDefaultMonthFirst=(ADateUtil.MONTH_POS<ADateUtil.DATE_POS);var isMonthFirst=(monthPos<datePos);if(isDefaultMonthFirst!=isMonthFirst){if(fullStr.indexOf("!dateStr")>0&&fullStr.indexOf("!monthStr")>0){fullStr=fullStr.replaceAll("!dateStr!",monthStr);fullStr=fullStr.replaceAll("!monthStr!",dateStr);}

else 
{fullStr=fullStr.replaceAll("!monthStr!",monthStr);fullStr=fullStr.replaceAll("!dateStr!",dateStr);}

}

else 
{fullStr=fullStr.replaceAll("!dateStr!",dateStr);fullStr=fullStr.replaceAll("!monthStr!",monthStr);}

}

return fullStr;}
;
this.changeDate=function(numberOfDays){numberOfDays=parseInt(numberOfDays,10);if(0==numberOfDays){return this;}
;var dayOfYear=numberOfDays;var isLeapYear=ADateUtil.isLeapYear(this.year);var daysInYear=(isLeapYear)?366:365;var daysInFebruary=(isLeapYear)?29:28;var dayCounts=[0,31,daysInFebruary,31,30,31,30,31,31,30,31,30,31];for(var i=1;i<this.month+1;i++)
{if(i==this.month){dayOfYear+=this.date;break;}

dayOfYear+=dayCounts[i];}

while(dayOfYear>daysInYear)
{dayOfYear=dayOfYear-daysInYear;this.year=this.year+1;isLeapYear=ADateUtil.isLeapYear(this.year);daysInYear=(isLeapYear)?366:365;}

while(dayOfYear<=0)
{isLeapYear=ADateUtil.isLeapYear(this.year-1);daysInYear=(isLeapYear)?366:365;dayOfYear=daysInYear+dayOfYear;this.year=this.year-1;}

daysInFebruary=(isLeapYear)?29:28;dayCounts=[0,31,daysInFebruary,31,30,31,30,31,31,30,31,30,31];for(var i=1;i<dayCounts.length;i++)
{var dayCount=dayCounts[i];if(dayCount>=dayOfYear){this.month=i;this.date=dayOfYear;break;}

dayOfYear-=dayCount;}

return this;}
;
this.clone=function(){return new ADate(this.date,this.month,this.year);}
;
this.getNextDate=function(){var nextDate=this.clone();nextDate.changeDate(1);return nextDate;}
;
this.getPreviousDate=function(){var nextDate=this.clone();nextDate.changeDate(-1);return nextDate;}
;
this.equals=function(otherDate){return ((this.year==otherDate.year)&&(this.month==otherDate.month)&&(this.date==otherDate.date));}
;
this.isLessThan=function(otherDate){return ((this.year<otherDate.year)||
((this.year==otherDate.year)&&(this.month<otherDate.month))||
((this.year==otherDate.year)&&(this.month==otherDate.month)&&(this.date<otherDate.date)));}
;
this.isLessThanEqual=function(otherDate){var isLessThan=((this.year<otherDate.year)||((this.year==otherDate.year)&&(this.month<otherDate.month))||
((this.year==otherDate.year)&&(this.month==otherDate.month)&&(this.date<otherDate.date)));var isEqual=this.equals(otherDate)
return (isLessThan||isEqual);}
;
this.isBeforeOtherDate=function(otherDate){return this.isLessThan(otherDate);
}
;
this.toDefaultString=function(){if(!ADateUtil.isValidDate(this.date,this.month,this.year)){return ADateUtil.EMPTY_DATE;}

var dateString="";dateString+=ADateUtil.selectDatePart(1,this.date,this.month,this.year)+ADateUtil.SEPARATOR;dateString+=ADateUtil.selectDatePart(2,this.date,this.month,this.year)+ADateUtil.SEPARATOR;dateString+=ADateUtil.selectDatePart(3,this.date,this.month,this.year);return dateString;}
;
this.getDateString=function(){return this.toDefaultString();}
;}



var ATimeUtil=new ATimeUtilBase();function ATimeUtilBase(){this.TYPE="TIME";this.TIME_FORMAT=12;
this.getCurrentTime=function(){return new ATime(g_sessionInformation.current_datetime.minute_offset);}
;
this.timeToString=function(minuteOffset){if(this.TIME_FORMAT==24){timeStr=this.offsetTo24Hr(minuteOffset);}

else 
{timeStr=this.offsetTo12Hr(minuteOffset);}

return timeStr;}
;
this.stringToTime=function(timeStr,timeObj){var offset=this.stringToOffset(timeStr);if(offset<0){return null;}

if(null!=timeObj){timeObj.minuteOffset=offset;}

else 
{timeObj=new ATime(offset)
}

return timeObj;}
;
this.stringToOffset=function(timeString){var re=new RegExp("(\\d\\d*)(:?)(\\d*)\\s*([ap]?)","g");var result=re.exec(timeString.toLowerCase());if(null==result){return -1;}

var hour;var minute;var isPM;if(""==result[2]){if(result[1].length==3){hour=parseInt(result[1].charAt(0),10);minute=parseInt(result[1].charAt(1)+result[1].charAt(2),10);}

else if(result[1].length==4){hour=parseInt(result[1].charAt(0)+result[1].charAt(1),10);minute=parseInt(result[1].charAt(2)+result[1].charAt(3),10);}

else 
{return -1;}

}

else 
{hour=parseInt(result[1],10);var mStr=result[3];if("0"==mStr.charAt(0)){mStr=mStr.charAt(1)
}

minute=parseInt(mStr,10);}

if(minute<0||minute>59||isNaN(minute)||isNaN(hour)){return -1;}

var timeOffset;if(this.TIME_FORMAT==24){if(hour<0||hour>23){return -1;}

timeOffset=this.to24HrToOffset(hour,minute);}

else 
{if(hour<1||hour>12){return -1;}

isPM=("p"==result[4])?true:false;timeOffset=this.to12HrToOffset(hour,minute,isPM);}

return timeOffset;}
;
this.offsetTo12Hr=function(offset){if(offset>=0&&offset<60){return "12:"+this.ensureTwoDigits(offset)+"AM";}

else if(offset>=60&&offset<720){var hour=Math.floor(offset/60);var minute=offset%60;return hour+":"+this.ensureTwoDigits(minute)+"AM";}

else if(offset>=720&&offset<780){var minute=offset%60;return "12:"+this.ensureTwoDigits(minute)+"PM";}

else if(offset>=780&&offset<1440){offset-=12*60;var hour=Math.floor(offset/60);var minute=offset%60;return hour+":"+this.ensureTwoDigits(minute)+"PM";}

}


this.offsetTo24Hr=function(offset){var hour=Math.floor(offset/60);var minute=offset%60;return this.ensureTwoDigits(hour)+":"+this.ensureTwoDigits(minute);}


this.ensureTwoDigits=function(number){var numberStr=number.toString()
var dot=numberStr.indexOf(".");if(dot!=-1){number=parseInt(numberStr.substring(0,dot),10);}

if(number<10){return "0"+number;}

return number;}
;this.to12HrToOffset=function(hour,minute,isPM){var minuteOffset=hour*60+minute;if(isPM){minuteOffset+=60*12;}

if(hour==12){minuteOffset-=60*12;}

return minuteOffset;}
;this.to24HrToOffset=function(hour,minute){return hour*60+minute;}
;this.initTimeFormat=function(){try
{this.TIME_FORMAT=g_sessionInformation.settings.time_format;}

catch(e)
{}

}
;this.isValidValue=function(value){return (this.validValues[value.toLowerCase()])
}
;this.initTimeFormat();this.validValues={closed:true}
;}

;function ATime(minuteOffset){this.minuteOffset=minuteOffset;}

ATime.prototype=new ATimeBase();function ATimeBase(){
this.getString=function(){var timeStr=ATimeUtil.timeToString(this.minuteOffset);return timeStr;}
;
this.toDbString=function(){return ATimeUtil.ensureTwoDigits(this.getHour())+":"+ATimeUtil.ensureTwoDigits(this.getMinute())+":00";}
;
this.clone=function(){return new ATime(this.minuteOffset);}
;
this.getHour=function(){return Math.floor(this.minuteOffset/60);}
;
this.getMinute=function(){return this.minuteOffset%60;}
;
this.changeTime=function(noOfMinutes){this.minuteOffset+=noOfMinutes;if(this.minuteOffset>=1440){this.minuteOffset=1439;}

else if(this.minuteOffset<0){this.minuteOffset=0;}

return this;}
;
this.equals=function(time){return this.minuteOffset==time.minuteOffset;}
;
this.isLessThan=function(time){return this.minuteOffset<time.minuteOffset;}
;
this.isLessThanEqual=function(time){return this.minuteOffset<=time.minuteOffset;}
;
this.isGreaterThan=function(time){return this.minuteOffset>time.minuteOffset;}
;
this.isGreaterThanEqual=function(time){return this.minuteOffset>=time.minuteOffset;}
;
this.update=function(timeStr){return ATimeUtil.stringToTime(timeStr,this);}
;
this.timeToString=function(){var timeStr=ATimeUtil.timeToString(this.minuteOffset);return timeStr;}
;}
;

;;mc_fieldTypeExtenders["TIMESTAMP"]=function(dynField){var timeObj=dynField.getValue().date_time.time;if(null!=timeObj){for(var i in ATime.prototype)
{timeObj[i]=ATime.prototype[i];}
;}
;var dateObj=dynField.getValue().date_time.date;if(null!=dateObj){for(var i in ADate.prototype)
{dateObj[i]=ADate.prototype[i];}

}
;dynField.forceSave=true;dynField.getDate=function(){return this.getValue().date_time.date;}
;dynField.getTime=function(){return this.getValue().date_time.time;}
;}
;

mc_fieldTypeExtenders["FILE2"]=function(dynField){extendField(dynField,f2_file2Base);}

var f2_file2Base=new File2Base();function File2Base(){this.getImagePath=function(width,height,allowSizingUp,fitType){var path=this.data.full_path
var params=ImageUtil.parseQueryString(path);if(width){params["w"]=width;}

if(height){params["h"]=height;}

if(allowSizingUp){params["u"]=allowSizingUp;}

if(fitType){params["f"]=fitType;}

var cleanSrc=ImageUtil.getUrlWithNoParams(path);var newPath=cleanSrc+"?"+ImageUtil.createQueryString(params);return newPath;}


this.setImageRotation=function(rotateCount){var path=this.getOriginalPath()+"?r="+rotateCount;this.getChildField("full_path").setValue(path);}
;
this.incrementRotation=function(rotateCount){var path=this.getChildField("full_path").getValue();var index=path.indexOf("?r=");var newRotation;if(-1==index){newRotation=rotateCount;}

else 
{var current=parseInt(path.charAt(index+3));newRotation=(current+rotateCount)%4;}

this.setImageRotation(newRotation);return newRotation;}


this.getOriginalPath=function(){var fullPath=this.getChildField("full_path").getValue();var end=fullPath.indexOf("?");if(-1==end){return fullPath;}

else 
{return fullPath.substring(0,end);}

}
;}

mc_fieldTypeExtenders["DATETIME"]=function(dynField){extendField(dynField,mc_dateTimeBase);var timeObj=dynField.getValue().time;if(null!=timeObj){for(var i in ATime.prototype)
{timeObj[i]=ATime.prototype[i];}
;}

var dateObj=dynField.getValue().date;if(null!=dateObj){for(var i in ADate.prototype)
{dateObj[i]=ADate.prototype[i];}

}

}

var mc_dateTimeBase=new DateTimeBase();function DateTimeBase(){this.setDate=function(date){this.data.date=date;this.setDoSave();}
;this.setTime=function(time){this.data.time=time;this.setDoSave();}
;this.getString=function(){var dateTime=this.getValue();return dateTime.date.getString()+" "+dateTime.time.getString();}
;}


mc_fieldTypeExtenders["NAME"]=function(dynField){extendField(dynField,name_nameBase);}

var name_nameBase=new NameBase();function NameBase(){this.getFirstMiddleLast=function(){return this.data.first_name+" "+this.data.middle_name+" "+this.data.last_name;}
;this.toString=function(lastNameFirst){var nameObj=this.getValue();if(lastNameFirst){return nameObj.last_name+", "+nameObj.first_name
}

else 
{return nameObj.first_name+" "+nameObj.last_name
}

}
;}


mc_fieldTypeExtenders["MODULE"]=function(dynField){extendField(dynField,mc_moduleBase);}

var mc_moduleBase=new ModuleBase();function ModuleBase(){this.setValueFromEl=function(element,lpSaver){var ahtml=lpSaver.getAhtml(element);this.getChildField("ahtml").setValue(ahtml);}
;this.getBgImageInfo=function(){var bgImageInfo={bgType:null,path:null}
;var record=this.getOwnerRecord();var fullScreenBgImage=record.getField("properties.body_attrs.full_screen_bg_image");var cssValue=record.getField("style_sheet.style_sheet").getAttrValue("body","background-image");if(fullScreenBgImage){bgImageInfo.bgType="full";bgImageInfo.path=fullScreenBgImage.getValue();}

else if(cssValue){bgImageInfo.bgType="tile";var start=cssValue.indexOf("(")+1;var end=cssValue.indexOf(")");bgImageInfo.path=cssValue.substring(start,end);}

return bgImageInfo;}
;this.setBgImageInfo=function(bgType,path,rte){path=path.replaceAll(" ","%20");var record=this.getOwnerRecord();this.clearBgImage(rte);if("full"==bgType){var bodyAttrs=record.getField("properties.body_attrs");bodyAttrs.addChildField("full_screen_bg_image","TEXT",path);BgImageUtil.setRteFullScreenBgImage(path,rte,true);}

else 
{var value="url("+path+")";record.getField("style_sheet.style_sheet").setAttribute("body","background-image",value,rte.doc);}

}
;this.clearBgImage=function(rte){var record=this.getOwnerRecord();record.getField("style_sheet.style_sheet").removeAttribute("body","background-image",rte.doc);record.getField("properties.body_attrs").removeChildField("full_screen_bg_image");BgImageUtil.removeFullScreenBgImage(rte.doc);}
;}


mc_fieldTypeExtenders["TEXT"]=function(dynField){extendField(dynField,mc_shortTextBase);}
;mc_fieldTypeExtenders["LONG_TEXT"]=function(dynField){extendField(dynField,mc_shortTextBase);}
;var mc_shortTextBase=new ShortTextBase();function ShortTextBase(){this.setValueFromEl=function(element,lpSaver){this.setValue(element.innerText);}
;}
;

;;;;;;;mc_fieldTypeExtenders["USERSTAMP"]=function(dynField){dynField.forceSave=true;}

mc_fieldTypeExtenders["C3"]=function(dynField){dynField.setDisplayValue=function(displayValue){var optionValue=null;var options=this.getChildField("category_definition.category_definition.options").data;for(var i in options)
{if(displayValue==options[i]){optionValue=i;break;}

}

if(optionValue){this.getChildField("value").setValue(optionValue);}

}

}

mc_fieldTypeExtenders["RECORD_TYPE"]=function(dynField){dynField.getRecord=function(){var mc=this.ownerRecord.ownerCache;return mc.getRecord(this.getChildField("type").getValue(),this.getChildField("id").getValue());}

dynField.createNewRecord=function(){var mc=this.ownerRecord.ownerCache;var record=mc.createRecord(this.getChildField("type").getValue());this.getChildField("id").setValue(record.id);return record;}
;}

mc_fieldTypeExtenders["RECORD_NAME"]=function(dynField){dynField.setValue=function(value){this.getChildField("recordName").setValue(value);}
;dynField.getValue=function(){return this.getChildField("recordName").getValue();}
;}

mc_fieldTypeExtenders["ARRAY"]=function(dynField){dynField.clear=function(){var length=this.getChildFieldNames().length;for(var i=length-1;i>=0;i--)
{this.removeChildField(i);}

}

}

mc_fieldTypeExtenders["DATE"]=function(dynField){var dateObj=dynField.getValue();if(null==dateObj){return ;}

if(window["ADate"]==undefined){return 
}

for(var i in ADate.prototype)
{dateObj[i]=ADate.prototype[i];}

}
;mc_fieldTypeExtenders["TIME_TYPE_NAME"]=function(dynField){var timeObj=dynField.getValue();if(null==timeObj){return ;}

if(window["ATime"]==undefined){return 
}

for(var i in ATime.prototype)
{timeObj[i]=ATime.prototype[i];}

}
;
;;function DynField(name,data,metaData,parentField,ownerRecord){this.name=name
this.data=data;this.metaData=metaData;this.parentField=parentField;this.ownerRecord=ownerRecord;addExentsions(this);}
;DynField.prototype=new DynFieldBase();function DynFieldBase(){
this.buildField=function(parentEl,converterName,properties){var uiType=this.getUiType()||this.getFieldType();var conversionFx=mc_objectToHtmlFxByType[converterName][uiType];if(!conversionFx){var doc=(properties&&properties.doc)?properties.doc:document;var div=cE("div",parentEl,doc);div.innerHTML="no for drawing type: "+uiType+" with converter '"+converterName+"'";return ;}

return conversionFx(parentEl,this,properties);}
;this.getChildField=function(fieldName){fieldName+="";var ownerRecord=this.ownerRecord;var dotIndex=fieldName.indexOf(".");if(this.data[fieldName]||-1==dotIndex){if("RECORD_TYPE"==this.getFieldType()&&fieldName!="id"&&fieldName!="type"&&fieldName!="createRecord"&&fieldName!="deleteRecord"){if(ownerRecord.isTemplate){var template=ownerRecord.ownerCache.getTemplate(this.data.type);if(null==template){alert("The template for "+this.data.type+" is not loaded. Please add it to load");return null;}

return ownerRecord.ownerCache.getTemplate(this.data.type).getField(fieldName);}

else 
{var record=ownerRecord.ownerCache.getRecord(this.data.type,this.data.id);if(null==record){return null;}

return record.getField(fieldName);}

}

else 
{if(!this.metaData[fieldName+"_ft"]){return null;}

return new DynField(fieldName,this.data[fieldName],this.metaData[fieldName],this,ownerRecord);}

}

else 
{var field=this.getChildField(fieldName.substring(0,dotIndex));if(null==field){return null;}

return field.getChildField(fieldName.substring(dotIndex+1,fieldName.length));}

}
;
this.getChildFields=function(){var childFields=[];var fieldNames=this.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var childField=this.getChildField(fieldNames[i]);if(null!=childField){childFields.push(childField);}

}

return childFields;}
;this.addChildField=function(fieldName,fieldType,value,displayName,displayOrder){var newField=this.addChildFieldData(fieldName,fieldType,value,displayName,displayOrder);var liveField=this.getLiveField();if(liveField){newField=liveField.addChildFieldData(fieldName,fieldType,value,displayName,displayOrder);}

return newField;}
;this.addChildFieldData=function(fieldName,fieldType,value,displayName,displayOrder){var metaValue;if(!value){var defaultData=mc_typeToDefaultValue[fieldType]();value=defaultData.data;metaValue=defaultData.metaData;}

else 
{metaValue=value;}

if("ARRAY"==this.getFieldType()){fieldName=this.data.length;this.data.push(clone(value));var metaData=this.metaData;metaData[fieldName]=clone(metaValue);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName;metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;}

else 
{this.data[fieldName]=clone(value);var metaData=this.metaData;metaData[fieldName]=clone(metaValue);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;}

var childField=this.getChildField(fieldName);childField.setDoSave();return childField;}
;this.getFullFieldName=function(){var fieldName=this.name;var aField=this.parentField;while(aField)
{fieldName=aField.name+"."+fieldName;aField=aField.parentField;}

return fieldName;}

this.insertChildField=function(fieldName,fieldType,field,displayName,displayOrder){field.parentField=this;field.ownerRecord=this.ownerRecord;if("ARRAY"==this.getFieldType()){fieldName=this.data.length;this.data.push(field.data);var metaData=this.metaData;metaData[fieldName]=field.metaData;metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName;metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;metaData[fieldName+"_uit"]=""
}

else 
{field.name=fieldName;this.data[fieldName]=field.data;var metaData=this.metaData;metaData[fieldName]=field.metaData;metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;metaData[fieldName+"_uit"]=""
}

var childField=this.getChildField(fieldName);childField.setDoSave();return childField;}
;this.renameChild=function(newName,previousName){var oldField=this.getChildField(previousName);var fieldType=oldField.getFieldType();var displayName=oldField.getDisplayName();var displayOrder=oldField.getDisplayOrder();var newChild=oldField.cloneField();this.removeChildField(previousName);return this.insertChildField(newName,fieldType,newChild,displayName,displayOrder);}
;this.cloneField=function(){var data=clone(this.data);var metaData=clone(this.metaData);return new DynField(this.name,data,metaData,null,null);}

this.removeChildField=function(fieldName){this.removeChildFieldData(fieldName);var liveField=this.getLiveField();if(liveField){liveField.removeChildFieldData(fieldName);}

}
;this.removeChildFieldData=function(fieldName){if("ARRAY"==this.getFieldType()){var index=parseInt(fieldName);var originalLength=this.data.length;this.data.splice(index,1);var metaData=this.metaData;delete(metaData[index]);delete(metaData[index+"_ft"]);delete(metaData[index+"_dn"]);delete(metaData[index+"_do"]);delete(metaData[index+"_ds"]);delete(metaData[index+"_uit"]);for(var i=index;i<originalLength-1;i++)
{var oldIndex=i+1;metaData[i]=metaData[oldIndex];metaData[i+"_ft"]=metaData[oldIndex+"_ft"];metaData[i+"_dn"]=metaData[oldIndex+"_dn"];metaData[i+"_do"]=metaData[oldIndex+"_do"];metaData[i+"_ds"]=metaData[oldIndex+"_ds"];metaData[i+"_uit"]=metaData[oldIndex+"_uit"];}

delete(metaData[i]);delete(metaData[i+"_ft"]);delete(metaData[i+"_dn"]);delete(metaData[i+"_do"]);delete(metaData[i+"_ds"]);delete(metaData[i+"_uit"]);}

else 
{delete(this.data[fieldName]);var metaData=this.metaData;delete(metaData[fieldName]);delete(metaData[fieldName+"_ft"]);delete(metaData[fieldName+"_dn"]);delete(metaData[fieldName+"_do"]);delete(metaData[fieldName+"_ds"]);delete(metaData[fieldName+"_uit"]);}

this.setDoSave();}
;this.getChildFieldNames=function(){if("ARRAY"==this.getFieldType()){var indexNames=[];for(var i=0;i<this.data.length;i++)
{indexNames[i]=i;}

return indexNames;}

return mc_getFieldNames(this.metaData);}
;this.getChildFieldCount=function(){return this.getChildFieldNames().length;}
;this.getFieldType=function(){var thisMetaData=this.getThisMetaData();return thisMetaData?thisMetaData[this.name+"_ft"]:null;}
;this.getOwnerRecord=function(){var testField=this;while(!testField.ownerRecord&&testField.parentField)
{testField=testField.parentField;}

return testField.ownerRecord;}
;this.getOwnerCache=function(){return this.getOwnerRecord().ownerCache;}
;this.isSetDoSave=function(){return this.getMetaInfo("ds");}
;this.setDoSave=function(){var record=this.getOwnerRecord();if(null==record){return ;}

var metaData=this.getThisMetaData();if(metaData[this.name+"_ds"]){return ;}

metaData[this.name+"_ds"]=true;var parentField=this.parentField;if(!parentField){record.setDoSave();}

else 
{parentField.setDoSave();}

}
;this.setDontSave=function(){this.setMetaInfo(false,"ds");}
;this.resetMetaInfo=function(value,suffix){
var metaData=this.getThisMetaData();metaData[this.name+"_"+suffix]=value;var fieldNames=this.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var childField=this.getChildField(fieldNames[i]);childField.resetMetaInfo(value,suffix);}

}
;this.getThisMetaData=function(){if(this.parentField){return this.parentField.metaData;}

else if(this.ownerRecord){return this.ownerRecord.metaData;}

else 
{return null;}

}
;this.getMetaInfo=function(suffix){return this.getThisMetaData()[this.name+"_"+suffix];}
;this.setMetaInfo=function(value,suffix){var metaData=this.getThisMetaData();metaData[this.name+"_"+suffix]=value;if(!value&&suffix=="ds"){return ;}

this.setDoSave();}
;this.getDisplayOrder=function(){return this.getMetaInfo("do");}
;this.setDisplayOrder=function(displayOrder){this.setMetaInfo(displayOrder,"do");}
;this.getUiType=function(){if(null==this.getMetaInfo("uit")){return "";}

return this.getMetaInfo("uit");}
;this.setUiType=function(uiType){this.setMetaInfo(uiType,"uit");}
;this.getDisplayName=function(){return this.getMetaInfo("dn");}
;this.setDisplayName=function(displayName){this.setMetaInfo(displayName,"dn");}
;
this.getValue=function(){return this.data;}
;
this.getLiveField=function(){var fullFieldName=this.getFullFieldName();var ownerRecord=this.getOwnerRecord();if(null==ownerRecord){return null;}

var liveField=null;try
{liveField=ownerRecord.getRefreshed().getField(fullFieldName);}

catch(e)
{}

return (liveField&&liveField.data!=this.data)?liveField:null;}
;this.setValue=function(value,isDontSetSave){this.setFieldValue(this,value,isDontSetSave);var liveField=this.getLiveField();if(liveField){this.setFieldValue(liveField,value,isDontSetSave);}

return this;}
;this.setValueFromEl=function(element,lpSaver){}
;this.setFieldValue=function(dynField,value,isDontSetSave){if(null==dynField){return ;}

dynField.data=value;if(dynField.parentField){dynField.parentField.data[dynField.name]=value;}

else 
{dynField.ownerRecord.data[dynField.name]=value;}

if(!isDontSetSave){dynField.setDoSave();}

}

}

function addExentsions(dynField){var fieldType=dynField.getFieldType();var extender=mc_fieldTypeExtenders[fieldType];if(extender){extender(dynField);}

}

function extendField(dynField,objectDef){for(var i in objectDef)
{dynField[i]=objectDef[i];}

}
;

;function Record(type,id,data,metaData,ownerCache){this.type=type;this.id=id;this.ownerCache=ownerCache;delete(data.type);delete(data.id);this.data=data;this.metaData=metaData;this.recordCount=++mc_recordCounter;}

Record.prototype=new RecordBase();function RecordBase(type,id,data,metaData,ownerCache){this.getId=function(){if(0>=this.id){var ids=mc_tempToRealId[this.type];if(ids){return ids[this.id]||this.id;}

else 
{return this.id;}

}

return this.id;}

this.getField=function(fieldName){var dotIndex=fieldName.indexOf(".");if(-1==dotIndex){if( typeof (this.metaData[fieldName])!="undefined"){return new DynField(fieldName,this.data[fieldName],this.metaData[fieldName],null,this);}

else 
{return null;}

}

else 
{var field=this.getField(fieldName.substring(0,dotIndex));if(!field){return null;}

return field.getChildField(fieldName.substring(dotIndex+1,fieldName.length));}

}
;this.addField=function(fieldName,fieldType,displayName,displayOrder){var defaultData=mc_typeToDefaultValue[fieldType]();this.data[fieldName]=clone(defaultData.data);var metaData=this.metaData;metaData[fieldName]=clone(defaultData.metaData);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;return this.getField(fieldName);}
;this.cloneRecord=function(mc){var newRecord=mc.createRecord(this.type,this.getId());
var fieldNames=this.getFieldNames();for(var i=0;i<fieldNames.length;i++)
{var field=this.getField(fieldNames[i]);var newField=field.cloneField();newField=newRecord.insertField(field.name,field.getFieldType(),newField,field.getDisplayName(),field.getDisplayOrder());if(field.isSetDoSave()){newField.setDoSave();}

}

return newRecord;}
;this.addName=function(name){this.ownerCache.addRecordName(this,name);}
;this.insertField=function(fieldName,fieldType,field,displayName,displayOrder){field.ownerRecord=this;this.data[fieldName]=field.data;var metaData=this.metaData;metaData[fieldName]=field.metaData;metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName?displayName:'';metaData[fieldName+"_do"]=displayOrder?displayOrder:-1;return this.getField(fieldName);}
;this.replaceField=function(fieldName,dynField){var replacedField=this.insertField(fieldName,dynField.getFieldType(),dynField,dynField.getDisplayName(),dynField.getDisplayOrder());replacedField.setDoSave();return replacedField;}

this.setDoSave=function(){if(this.metaData.doProcess){return ;}

this.metaData.doSave=true;this.setDoLoad();}
;this.isSetDoSave=function(){return this.metaData.doSave;}
;this.cancelSave=function(){this.ownerCache.cancelRecordToLoad(this.type,this.id);this.metaData.doSave=false;}
;this.setDoLoad=function(){this.ownerCache.addRecordToLoad(this.type,this.id);}
;this.getFieldNames=function(){return mc_getFieldNames(this.metaData);}
;this.getRefreshed=function(){return this.ownerCache.getRecord(this.type,this.id);}
;this.resetMetaInfo=function(value,suffix){var fieldNames=this.getFieldNames();for(var i=0;i<fieldNames.length;i++)
{var childField=this.getField(fieldNames[i]);childField.resetMetaInfo(value,suffix);}

}
;this.removeUnchangedFields=function(){var names=this.getFieldNames();for(var i=0;i<names.length;i++)
{var field=this.getField(names[i]);if(!field.isSetDoSave()){this.removeField(names[i]);}

}

}
;
this.removeField=function(fieldName){delete(this.data[fieldName]);var metaData=this.metaData;delete(metaData[fieldName]);delete(metaData[fieldName+"_ft"]);delete(metaData[fieldName+"_dn"]);delete(metaData[fieldName+"_do"]);delete(metaData[fieldName+"_ds"]);delete(metaData[fieldName+"_uit"]);}
;
}

var mc_recordCounter=0;

function DynTable(type,data,metaData,settings,ownerCache){this.type=type;this.ownerCache=ownerCache;this.data=data;this.metaData=metaData;this.settings=settings;this.getField=function(fieldName){return new DynField(fieldName,this.data[fieldName],this.metaData[fieldName],null,this);}
;this.setDoSave=function(){this.settings.doSave=true;}
;this.addField=function(fieldName,fieldType,displayName,displayOrder){this.setDoSave();var defaultData=mc_typeToDefaultValue[fieldType]();this.data[fieldName]=clone(defaultData.data);var metaData=this.metaData;metaData[fieldName]=clone(defaultData.metaData);metaData[fieldName+"_ft"]=fieldType;metaData[fieldName+"_dn"]=displayName;metaData[fieldName+"_do"]=displayOrder;metaData[fieldName+"_ds"]=true;metaData[fieldName+"_uit"]="";return this.getField(fieldName);}
;this.getFieldNames=function(){return mc_getFieldNames(this.metaData);}
;}

if(!mc_typeToDefaultValue){var mc_typeToDefaultValue={}
;}

function mc_insertMetaData(object,fieldName,fieldType,displayName,displayOrder,value){object[fieldName]=value;object[fieldName+"_ft"]=fieldType;object[fieldName+"_dn"]=displayName;object[fieldName+"_do"]=displayOrder;}

mc_typeToDefaultValue["COLLECTION"]=function(){return {data:{}
,metaData:{}
}
;}
;mc_typeToDefaultValue["ARRAY"]=function(){return {data:[],metaData:[]}
;}
;mc_typeToDefaultValue["INTEGER"]=function(){return {data:0,metaData:0}
;}
;mc_typeToDefaultValue["DOUBLE"]=function(){return {data:0.0,metaData:0.0}
;}
;mc_typeToDefaultValue["TIME_TYPE_NAME"]=function(){return {data:null,metaData:null}
;}
;mc_typeToDefaultValue["BOOLEAN"]=function(){return {data:false,metaData:false}
;}
;mc_typeToDefaultValue["RECORD_TYPE"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("type","TEXT");field.addChildField("id","INTEGER");field.addChildField("createRecord","BOOLEAN");field.addChildField("deleteRecord","BOOLEAN");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["RIL2"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("type","TEXT");field.addChildField("ids","LONG_TEXT");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["MODULE"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("ahtml","LONG_TEXT");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["TEXT"]=function(){return {data:"",metaData:""}
;}
;mc_typeToDefaultValue["TREE"]=function(){return {data:"",metaData:""}
;}
;mc_typeToDefaultValue["PASSWORD"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("value","TEXT");field.addChildField("doSave","BOOLEAN",true);return {data:field.data,metaData:field.metaData}
;}
;mc_typeToDefaultValue["DATE"]=function(){return {data:null,metaData:null}
;}
;mc_typeToDefaultValue["DATETIME"]=function(){var field=new DynField(null,{date:null,time:null}
,{}
,null,null);field.addChildField("isGMT","BOOLEAN");return {data:field.data,metaData:field.metaData}
;}
;mc_typeToDefaultValue["LONG_TEXT"]=function(){return {data:"",metaData:""}
;}
;mc_typeToDefaultValue["MS3"]=function(){var data={selected_options:"",category_definition:{type:"cat_def3",id:0,deleteRecord:false,createRecord:false}
}
;var metaData={}
;mc_insertMetaData(metaData,"selected_options","LONG_TEXT","",0,"");mc_insertMetaData(metaData,"category_definition","RECORD_TYPE","",0,{}
);var definitionMeta=metaData.category_definition;mc_insertMetaData(definitionMeta,"type","TEXT","",0,"cat_def3");mc_insertMetaData(definitionMeta,"id","INTEGER","",0,0);mc_insertMetaData(definitionMeta,"createRecord","BOOLEAN","",0,false);mc_insertMetaData(definitionMeta,"deleteRecord","BOOLEAN","",0,false);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["C3"]=function(){var data={default_value:"",value:"",category_definition:{type:"cat_def3",id:0,deleteRecord:false,createRecord:false}
}
;var metaData={}
;mc_insertMetaData(metaData,"default_value","TEXT","",0,"");mc_insertMetaData(metaData,"value","TEXT","",0,"");mc_insertMetaData(metaData,"category_definition","RECORD_TYPE","",0,{}
);var definitionMeta=metaData.category_definition;mc_insertMetaData(definitionMeta,"type","TEXT","",0,"cat_def3");mc_insertMetaData(definitionMeta,"id","INTEGER","",0,0);mc_insertMetaData(definitionMeta,"createRecord","BOOLEAN","",0,false);mc_insertMetaData(definitionMeta,"deleteRecord","BOOLEAN","",0,false);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["TIMESTAMP"]=function(){var data={str_format:"simple",do_update:false,date_time:{date:{date:1,month:1,year:1}
,time:{minuteOffset:0}
}
}
;var metaData={}
;mc_insertMetaData(metaData,"str_format","TEXT","",0,"simple");mc_insertMetaData(metaData,"do_update","BOOLEAN","",0,false);mc_insertMetaData(metaData,"date_time","DATETIME","",0,{}
);var dateTimeMeta=metaData.date_time;mc_insertMetaData(dateTimeMeta,"isGMT","BOOLEAN","",0,true);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["USERSTAMP"]=function(){var data={do_update:false,user_name:'',user_id:0}
;var metaData={}
;mc_insertMetaData(metaData,"user_name","TEXT","",0,"");mc_insertMetaData(metaData,"do_update","BOOLEAN","",0,false);mc_insertMetaData(metaData,"user_id","INTEGER","",0,0);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["RECORD_NAME"]=function(){var data={recordName:'',updateOnImport:true}
;var metaData={}
;mc_insertMetaData(metaData,"recordName","TEXT","",0,"");mc_insertMetaData(metaData,"updateOnImport","BOOLEAN","",0,true);return {data:data,metaData:metaData}
;}
;mc_typeToDefaultValue["TIME_ALLOCATION_TYPE"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("time_allocation_record","RECORD_TYPE");field.addChildField("finder","RECORD_TYPE");field.addChildField("physical_resource","RECORD_TYPE");field.addChildField("event_title","TEXT");field.addChildField("event_status","COLLECTION");field.addChildField("is_double_allowed","BOOLEAN",false);field.addChildField("start_date","DATE");field.addChildField("start_time","TIME_TYPE_NAME");field.addChildField("end_date","DATE");field.addChildField("end_time","TIME_TYPE_NAME");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["RTA2"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("time_allocation_record","RECORD_TYPE");field.addChildField("physical_resource","RECORD_TYPE");field.addChildField("event_title","TEXT");field.addChildField("is_double_allowed","BOOLEAN",false);field.addChildField("start_date","DATE");field.addChildField("start_time","TIME_TYPE_NAME");field.addChildField("end_date","DATE");field.addChildField("end_time","TIME_TYPE_NAME");var recurInfo=field.addChildField("recur_info","COLLECTION");recurInfo.addChildField("recur_type","TEXT","weekly","",1);recurInfo.addChildField("every_nth_week","INTEGER",1,"",2);recurInfo.addChildField("is_monday","BOOLEAN",true,"",3);recurInfo.addChildField("is_tuesday","BOOLEAN",true,"",4);recurInfo.addChildField("is_wednesday","BOOLEAN",true,"",5);recurInfo.addChildField("is_thursday","BOOLEAN",true,"",6);recurInfo.addChildField("is_friday","BOOLEAN",true,"",7);recurInfo.addChildField("is_saturday","BOOLEAN",true,"",8);recurInfo.addChildField("is_sunday","BOOLEAN",true,"",9);recurInfo.addChildField("every_nth_month","INTEGER",1,"",10);recurInfo.addChildField("day_or_date","TEXT","day","",11);field.addChildField("cancelled_dates","COLLECTION");return {data:field.data,metaData:field.metaData}
;}

mc_typeToDefaultValue["NAME"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("prefix","TEXT");field.addChildField("first_name","TEXT");field.addChildField("middle_name","TEXT");field.addChildField("last_name","TEXT");field.addChildField("suffix","TEXT");return field;}
;mc_typeToDefaultValue["FILE2"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("file_name","TEXT");field.addChildField("folder_name","TEXT");field.addChildField("full_path","TEXT");field.addChildField("rename_on_upload","BOOLEAN");return field;}
;mc_typeToDefaultValue["PATH"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("real_path","TEXT");field.addChildField("friendly_path","TEXT");return field;}
;mc_typeToDefaultValue["URL"]=function(){var field=new DynField(null,{}
,{}
,null,null);var fUrl=field.addChildField("friendly_url","TEXT");fUrl.setUiType("FURL");field.addChildField("action_path","TEXT");field.addChildField("params","COLLECTION");field.addChildField("update_on_import","BOOLEAN");field.addChildField("url","RECORD_TYPE");field.addChildField("is_clash","BOOLEAN");field.addChildField("is_public","BOOLEAN",true);field.addChildField("clash_url","RECORD_TYPE");var fUrl=field.addChildField("forward_url","RECORD_TYPE");fUrl.getChildField("type").setValue("url");field.addChildField("screen_title","TEXT");field.addChildField("minicache_input","MCL");return field;}
;mc_typeToDefaultValue["RR"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("range_name","TEXT");field.addChildField("min","TEXT");field.addChildField("max","TEXT");return field;}
;mc_typeToDefaultValue["INPUT"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("value","TEXT");field.addChildField("validationType","TEXT","false");field.addChildField("autoComplete","BOOLEAN",false);return {data:field.data,metaData:field.metaData}
;}
;
function ajax_getStringForXml(string){var xmlRequest=ajax_getXMLHttpRequest();var url="GetHtmlForXml.ajax";xmlRequest.open("POST",url,false);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("html="+string);do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_setFormatedXmlString(xmlRequest.responseText);}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

while(xmlRequest.readyState!=4)}

function ajax_setFormatedXmlString(str){g_processedHtmlForXml=str;}

function ajax_getStringForEditor(string){var xmlRequest=ajax_getXMLHttpRequest();var handlerFunction=ajax_getReadyStateHandler(xmlRequest,ajax_setEditorString);xmlRequest.onreadystatechange=handlerFunction;var url="GetHtmlForEditor.ajax";xmlRequest.open("POST",url,false);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("html="+string);do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_setEditorString(xmlRequest.responseText)
}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

while(xmlRequest.readyState!=4)}

function ajax_setEditorString(str){editor_processedHtmlForEditor=str;}

function ajax_getStringForHtml(string){var xmlRequest=ajax_getXMLHttpRequest();var handlerFunction=ajax_getReadyStateHandler(xmlRequest,ajax_setHtmlString);xmlRequest.onreadystatechange=handlerFunction;var url="GetHtml.ajax";xmlRequest.open("POST",url,false);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send("html="+string);do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){ajax_setHtmlString(xmlRequest.responseText)
}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

while(xmlRequest.readyState!=4)}

function ajax_setHtmlString(str){editor_processedHtmlForHtml=str;}


;if(!vfc_converters){var vfc_converters={}
;}

function vfc_getValue(dynField){var fieldType=dynField.getFieldType();var converter=vfc_converters[fieldType];if(!converter){return "";}

return converter(dynField);}

function vfc_registerConverter(fieldType,converterFx){vfc_converters[fieldType]=converterFx;}

vfc_converters["DATETIME"]=function(dynField){var dateTimeObj=dynField.data;var value;if(dateTimeObj&&dateTimeObj.date!=null&&dateTimeObj.time!=null){var dateObj=dateTimeObj.date;value=dateObj.toDbFormat()
value+=" "+dateTimeObj.time.toDbString();}

else 
{value="";}

return value;}

vfc_converters["RECORD_TYPE"]=function(dynField){return dynField.data.id;}

vfc_converters["RIL2"]=function(dynField){if(dynField.data.idArray){var idsStr="";var idArray=dynField.data.idArray;for(var i=0;i<idArray.length;i++)
{if(i!=0){idsStr+="|"+idArray[i];}

else 
{idsStr+=idArray[i];}

}

dynField.data.ids=idsStr;delete(dynField.data.idArray);}

return dynField.data.ids;}

function vfc_getCategory3Value(dynField){var definition=dynField.data.category_definition;var miniCache=dynField.ownerRecord.ownerCache;var c3Records=miniCache.records[definition.type];if(!c3Records){return "";}

var definitionRecord=c3Records[definition.id];if(!definitionRecord){return "";}

var value=dynField.data.value;return util_formatForXmlValue(definitionRecord.category_definition.options[value]);}

vfc_registerConverter("C3",vfc_getCategory3Value);function vfc_getRecordTypeValue(dynField){return dynField.data.id;}

vfc_registerConverter("RECORD_TYPE",vfc_getRecordTypeValue);function vfc_getLongTextValue(dynField){return util_formatForXmlValue(dynField.data);}

vfc_registerConverter("LONG_TEXT",vfc_getLongTextValue);function vfc_getDateValue(dynField){if(!dynField.data){return "";}

return dynField.data.toDbFormat();}

vfc_registerConverter("DATE",vfc_getDateValue);function vfc_getGenericValue(dynField){return dynField.getValue();}

vfc_registerConverter("BOOLEAN",vfc_getGenericValue);vfc_registerConverter("INTEGER",vfc_getGenericValue);vfc_registerConverter("DOUBLE",vfc_getGenericValue);function vfc_getTimeValue(dynField){var timeStr="";var timeObj=dynField.data;if(timeObj!=null){timeStr=timeObj.toDbString();}

return timeStr;}

vfc_registerConverter("TIME_TYPE_NAME",vfc_getTimeValue);function vfc_getRecordNameValue(dynField){return dynField.data.recordName;}

vfc_registerConverter("RECORD_NAME",vfc_getRecordNameValue);function vfc_returnNoValue(){return "";}

vfc_registerConverter("COLLECTION",vfc_returnNoValue);vfc_registerConverter("SST",vfc_returnNoValue);vfc_registerConverter("ARRAY",vfc_returnNoValue);vfc_registerConverter("TIMESTAMP",vfc_returnNoValue);vfc_registerConverter("USERSTAMP",vfc_returnNoValue);vfc_registerConverter("CD3",vfc_returnNoValue);vfc_registerConverter("DBI",vfc_returnNoValue);vfc_registerConverter("TIME_ALLOCATION_TYPE",vfc_returnNoValue);vfc_registerConverter("RTA2",vfc_returnNoValue);vfc_registerConverter("NAME",vfc_returnNoValue);vfc_registerConverter("MODULE",vfc_returnNoValue);function vfc_getShortTextValue(dynField){return util_formatForXmlValue(dynField.getValue());}

vfc_registerConverter("TEXT",vfc_getShortTextValue);vfc_registerConverter("TREE",vfc_getShortTextValue);function vfc_getInputValue(dynField){return util_formatForXmlValue(dynField.getChildField("value").getValue());}

vfc_registerConverter("INPUT",vfc_getInputValue);vfc_registerConverter("TEXT_AREA",vfc_getInputValue);vfc_registerConverter("PASSWORD",vfc_getInputValue);function vfc_getNewCategoryValue(dynField){return util_formatForXmlValue(dynField.getChildField("value").getValue());}

vfc_registerConverter("NEW_CATEGORY",vfc_getNewCategoryValue);function vfc_getMs3Value(dynField){return util_formatForXmlValue(dynField.getChildField("selected_options").getValue());}

vfc_registerConverter("MS3",vfc_getMs3Value);function vfc_getRecordNameValue(dynField){return dynField.data.recordName;}

vfc_registerConverter("RECORD_NAME",vfc_getRecordNameValue);function vfc_getUrlValue(dynField){return dynField.getChildField("friendly_url").getValue();}

vfc_registerConverter("URL",vfc_getUrlValue);function vfc_getNamelValue(dynField){try
{dynField.ownerRecord.getField(dynField.name+"_ln").setValue("");}

catch(e){}

return ""
}

vfc_registerConverter("NAME",vfc_getNamelValue);vfc_converters["PATH"]=function(dynField){return dynField.data.real_path;}

vfc_converters["FILE2"]=function(dynField){if(!dynField.data.file_name){return ;}

dynField.getOwnerCache().useFrame=true;return "";}

function photoConverter(dynField){dynField.getChildField("originalImagePath").setValue("");if(!dynField.data.originalImage.image_file.file_name){return ;}

dynField.getOwnerCache().useFrame=true;return "";}

vfc_converters["PHOTO"]=photoConverter;vfc_converters["FILE"]=vfc_returnNoValue;vfc_converters["IMAGE"]=vfc_returnNoValue;vfc_converters["VIDEO"]=vfc_returnNoValue;
;
function mcs_process(miniCache,onAfterProcess,onErrorFx){miniCache.runBeforeProcesses();miniCache.useFrame=false;var xml=mcs_createCacheXml(miniCache);mc_processCache(xml,miniCache,onAfterProcess,onErrorFx);}

function mc_processCache(xml,miniCache,onAfterProcessFx,onErrorFx){if(miniCache.useFrame){mc_processUploadCache(xml,miniCache,onAfterProcessFx);return ;}

var isAsync=(onAfterProcessFx!=null)?true:false;var xmlRequest=ajax_getXMLHttpRequest();var url="ProcessMiniCache.ajax";xmlRequest.open("POST",url,isAsync);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");var requestUrl="cache="+xml;requestUrl+="&screenId="+g_sessionInformation.screen_id;xmlRequest.send(requestUrl);if(isAsync){xmlRequest.onreadystatechange=function(){if(xmlRequest.readyState==4){if(xmlRequest.status==200){if(!mc_isResponseValid(xmlRequest.responseText)){if(onErrorFx){onErrorFx();}

return ;}

mc_setXmlResponseInto(miniCache,xmlRequest.responseText);if(onAfterProcessFx){onAfterProcessFx();}

}

}

}

}

else {do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){mc_setXmlResponseInto(miniCache,xmlRequest.responseText);}

}

}

while(xmlRequest.readyState!=4)return ;}

}

function mc_processUploadCache(xml,miniCache,onAfterProcessFx){var thisWindow=miniCache.ownerWindow||window;var doc=thisWindow.document||document;var body=doc.body;var html="<form id='uploadForm' method='post' action='IFrameCommunicator.do' enctype='multipart/form-data' target='uploadTarget'></form>";html+="<iframe style='display:none' id='uploadTarget' name='uploadTarget'></iframe>";var formHolder=cE("div",body);formHolder.id="uploadElements";formHolder.innerHTML=html;var form=doc.getElementById("uploadForm");var inputs=doc.getElementsByTagName("input");for(var i=inputs.length-1;i>=0;i--)
{var input=inputs[i];if(input.type.toLowerCase()!="file"){continue;}

var removed=input.parentNode.removeChild(input);aE(form,removed);}

var input=doc.createElement("input")
input.type="hidden";input.name="cache";input.id="mc_cache";form.appendChild(input);input.value=xml;thisWindow.mc_onAfterProcessIFrameFx=function(responseText){var uploadElements=doc.getElementById("uploadElements");uploadElements.parentNode.removeChild(uploadElements);if(!mc_isResponseValid(responseText)){return ;}

mc_setXmlResponseInto(miniCache,responseText,"from upload cache");if(onAfterProcessFx){onAfterProcessFx();}

}
;form.submit();}
;

var mc_onAfterProcessIFrameFx;function mc_setXmlResponseInto(miniCache,responseText,errorInfo){try
{eval(responseText);}

catch(e)
{if(!errorInfo){errorInfo="";}

alert("error receiving data: "+errorInfo);return ;}

mc_updateData(miniCache,miniCacheData);if(miniCache.doSyncToMaster){mc_updateData(getMasterCache(),miniCacheData);}

}

function mc_isResponseValid(obj){var errorOccured="error_"+"ocurred";var sessionExpired="session_"+"expired";if(obj==sessionExpired){alert("Your session has expired and you will be re-directed to the home page.");location.reload("");return false;}

if(obj.indexOf(errorOccured)==0){if(errorOccured==obj){alert("A problem has occured and we have been notified. Please try again later");}

else 
{alert(obj);}

return false;}

return true;}

function mc_updateData(miniCache,miniCacheData){mc_updateIds(miniCache,miniCacheData);copyData(miniCacheData.records_by_key,miniCache.records_by_key);var recordTypes=miniCacheData.records;var mcRecordTypes=miniCache.records;for(var i in recordTypes)
{if(!mcRecordTypes[i]){mcRecordTypes[i]=clone(recordTypes[i]);}

else 
{copyData(recordTypes[i],mcRecordTypes[i]);}

}

var recordTypes=miniCacheData.record_meta_data;var mcRecordTypes=miniCache.record_meta_data;for(var i in recordTypes)
{if(!mcRecordTypes[i]){mcRecordTypes[i]=clone(recordTypes[i]);}

else 
{copyData(recordTypes[i],mcRecordTypes[i]);}

}

copyData(miniCacheData.lists,miniCache.lists);copyData(miniCacheData.templates,miniCache.templates);copyData(miniCacheData.template_meta_data,miniCache.template_meta_data);copyData(miniCacheData.dyn_tables,miniCache.dyn_tables);copyData(miniCacheData.temp_to_real_id,mc_tempToRealId);copyData(miniCacheData.values,miniCache.values);}

function mc_updateIds(miniCache,miniCacheData){var records=miniCache.records;var recordMetaData=miniCache.record_meta_data;for(var i in miniCacheData.temp_to_real_id)
{if(!records[i]){continue;}

var idMap=miniCacheData.temp_to_real_id[i];for(var j in idMap)
{var recordsOfType=records[i];var recordMetaDataOfType=recordMetaData[i];if(recordsOfType[j]){var newId=idMap[j];recordsOfType[newId]=recordsOfType[j];recordMetaDataOfType[newId]=recordMetaDataOfType[j];delete(recordMetaDataOfType[j]);delete(recordsOfType[j]);}

}

}

}

function copyData(dataHolder,destinationHolder){for(var i in dataHolder)
{destinationHolder[i]=clone(dataHolder[i]);}

}

function mcs_createCacheXml(miniCache){var xml=constants_LESS_THAN_CHAR+"cache>";xml+=mcs_appendRecordsXml(miniCache);xml+=mcs_appendDynTablesXml(miniCache);xml+=constants_LESS_THAN_CHAR+"/cache>";return xml;}

function mcs_appendDynTablesXml(miniCache){var xml=constants_LESS_THAN_CHAR+"dyntables>";xml+=constants_LESS_THAN_CHAR+"to_save>";var dynTables=miniCache.dyn_tables;for(var i in dynTables)
{var dynTable=miniCache.getDynTable(i);if(dynTable.settings.doSave){xml+=mcs_appendDynTableXml(dynTable);}

}

xml+=constants_LESS_THAN_CHAR+"/to_save>";xml+=mcs_appendTablesToDeleteXml(miniCache);xml+=constants_LESS_THAN_CHAR+"/dyntables>";return xml;}

function mcs_appendTablesToDeleteXml(miniCache){var tablesToDelete=miniCache.tables_to_delete;if(tablesToDelete.length==0){return "";}

var xml=constants_LESS_THAN_CHAR+"to_delete>";for(var i=0;i<tablesToDelete.length;i++)
{xml+=constants_LESS_THAN_CHAR+"f name='"+tablesToDelete[i]+"'/>";}

xml+=constants_LESS_THAN_CHAR+"/to_delete>";return xml;}

function mcs_appendDynTableXml(dynTable){var xml=constants_LESS_THAN_CHAR+"table";xml+=" name='"+dynTable.type;xml+="' dn='"+dynTable.settings.singularName+"'>";xml+=mcs_appendTableFieldsToDelete(dynTable);xml+=mcs_appendTableFieldsToSave(dynTable);xml+=mcs_appendTableSettings(dynTable);xml+=constants_LESS_THAN_CHAR+"/table>";return xml;}

function mcs_appendTableFieldsToDelete(dynTable){var deleteXml="";var fieldsToDelete=dynTable.settings.fieldsToDelete;for(var i in fieldsToDelete)
{deleteXml+=constants_LESS_THAN_CHAR+"f name='"+fieldsToDelete[i]+"'/>";}

delete(dynTable.settings.fieldsToDelete);if(""==deleteXml){return "";}

var xml=constants_LESS_THAN_CHAR+"to_delete>";xml+=deleteXml;xml+=constants_LESS_THAN_CHAR+"/to_delete>";return xml;}

function mcs_appendTableSettings(dynTable){var xml=constants_LESS_THAN_CHAR+"settings>";xml+=constants_LESS_THAN_CHAR+"f ";xml+=" type='"+"DYNTABLE_SETTINGS"+"'>";var settings=dynTable.settings;delete(settings.doSave);for(var i in settings)
{xml+=constants_LESS_THAN_CHAR+"f ";xml+="name='"+i;xml+="' type='"+"TEXT";xml+="' value='"+util_formatForXmlValue(settings[i])+"'/>";}

xml+=constants_LESS_THAN_CHAR+"/f>";xml+=constants_LESS_THAN_CHAR+"/settings>";return xml;}

function mcs_appendTableFieldsToSave(dynTable){var xml="";var fieldNames=mc_getFieldNames(dynTable.metaData);for(var i in fieldNames)
{var field=dynTable.getField(fieldNames[i]);if(field.getMetaInfo("ds")){xml+=mcs_appendFieldXml(field);}

}

if(""==xml){return "";}

return constants_LESS_THAN_CHAR+"to_save>"+xml+constants_LESS_THAN_CHAR+"/to_save>";}

function mcs_appendRecordsXml(miniCache){var xml=constants_LESS_THAN_CHAR+"records>";var recordsMetaData=miniCache.record_meta_data;for(var type in recordsMetaData)
{var records=recordsMetaData[type];for(var id in records)
{var record=miniCache.getRecord(type,id);xml+=mcs_appendRecordXml(record);}

}

xml+=constants_LESS_THAN_CHAR+"/records>";return xml;}

function mcs_appendRecordXml(record){var xml="";if(!record.metaData.doSave&&!record.metaData.doProcess){return xml;}

xml+=constants_LESS_THAN_CHAR+"record type='"+record.type+"'";if(record.metaData.doSave){xml+=" do_save='true' ";}

if(record.metaData.doProcess){xml+=" do_process='true' ";}

xml+="id='"+record.id+"'>";var fieldNames=record.getFieldNames();var fieldXml="";for(var i=0;i<fieldNames.length;i++)
{var dynField=record.getField(fieldNames[i]);if(record.metaData.doSave&&!dynField.getMetaInfo("ds")&&!dynField.forceSave){continue;}

fieldXml+=mcs_appendFieldXml(dynField);}

if(fieldXml==""&&record.id>0){return "";}

xml+=fieldXml+constants_LESS_THAN_CHAR+"/record>"
record.metaData.doSave=false;return xml;}

function mcs_appendFieldXml(dynField){var fieldType=dynField.getFieldType();var xml=constants_LESS_THAN_CHAR+"f ";xml+="name='"+dynField.name;xml+="' dn='"+util_formatForXmlValue(dynField.getMetaInfo("dn"));xml+="' type='"+fieldType;xml+="' do='"+dynField.getMetaInfo("do");xml+="' uit='"+dynField.getUiType();xml+="' value='"+vfc_getValue(dynField)+"'";var childFieldNames=mc_getFieldNames(dynField.metaData);var chidFieldCount=childFieldNames.length;if(0==chidFieldCount){xml+="/>";return xml;}

else 
{xml+=">";for(var i=0;i<chidFieldCount;i++)
{var childFieldName=childFieldNames[i];xml+=mcs_appendFieldXml(dynField.getChildField(childFieldName));}

xml+=constants_LESS_THAN_CHAR+"/f>";return xml;}

}


function createListInput(type,name,startRecord,max,sortField,sortDirection){startRecord=startRecord||0;max=max||-1;sortDirection=sortDirection||"asc";name=name||"temp";var listInput=new DynField(null,{}
,{}
,null,null);listInput.addChildField("record_type","TEXT",type);listInput.addChildField("name","TEXT",name);listInput.addChildField("start_record","INTEGER",startRecord);listInput.addChildField("max_record_count","INTEGER",max);listInput.addChildField("fields_to_load","TEXT","");listInput.addChildField("sort_field","TEXT",sortField);listInput.addChildField("sort_direction","TEXT",sortDirection);listInput.addChildField("search_criteria","ARRAY");extendField(listInput,g_listInputBase);return listInput;}

function turnIntoListInput(field){extendField(field,g_listInputBase);return field;}

var g_listInputBase=new ListInputBase();function ListInputBase(){this.addField=function(fieldName){var fieldsToLoad=this.getChildField("fields_to_load");fieldsToLoad.setValue(fieldsToLoad.getValue()+fieldName+",");return this;}
;this.setMax=function(max){this.getChildField("max_record_count").setValue(max);}
;this.setSortField=function(sortField){this.getChildField("sort_field").setValue(sortField);}
;this.setStartRecord=function(startRecord){this.getChildField("start_record").setValue(startRecord);}
;this.setSortDirection=function(sortDirection){this.getChildField("sort_direction").setValue(sortDirection);}
;this.addSearchTerm=function(fieldName,value,searchType,groupName){var searchCriteria=this.getChildField("search_criteria");var criteria=searchCriteria.addChildField(null,"COLLECTION");criteria.addChildField("criteria_type","TEXT","search_term");criteria.addChildField("field_name","TEXT",fieldName);criteria.addChildField("value","TEXT",value);criteria.addChildField("search_type","INTEGER",searchType);var position=this.getChildField("search_criteria").getChildFieldNames().length;criteria.addChildField("position","INTEGER",position);if(null==groupName){groupName="";}

criteria.addChildField("group","TEXT",groupName);return criteria;}
;this.addOrSearchTerm=function(fieldName,value,searchType,groupName){var criteria=this.addSearchTerm(fieldName,value,searchType);if(null==groupName){groupName="";}

criteria.addChildField("group","TEXT",groupName);var position=this.getChildField("search_criteria").getChildFieldNames().length;criteria.addChildField("position","INTEGER",position);criteria.addChildField("is_or","BOOLEAN",true);}
;this.addConditional=function(fieldName,value,conditionalType){var searchCriteria=this.getChildField("search_criteria");var criteria=searchCriteria.addChildField(null,"COLLECTION");criteria.addChildField("criteria_type","TEXT","conditional");criteria.addChildField("field_name","TEXT",fieldName);criteria.addChildField("value","TEXT",value);criteria.addChildField("conditional_type","INTEGER",conditionalType);}
;this.addDateConditional=function(fieldName,value,conditionalType){alert("need to implement");}
;this.cloneField=function(){var newListInput=createListInput();newListInput.data=clone(this.data);newListInput.metaData=clone(this.metaData);return newListInput;}
;this.getSortFieldName=function(){return this.getChildField("sort_field").getValue();}
;this.getSearchCriteria=function(fieldName){var criteria=[];var searchCriteria=this.getChildField("search_criteria");var childNames=searchCriteria.getChildFieldNames();for(var i=0;i<childNames.length;i++)
{var aCriteria=searchCriteria.getChildField(childNames[i]);if(fieldName==aCriteria.getChildField("field_name").getValue()){criteria.push(aCriteria);}

}

return criteria;}
;this.removeSearchCriteria=function(fieldName){var searchCriteria=this.getChildField("search_criteria");var childNames=searchCriteria.getChildFieldNames();for(var i=0;i<childNames.length;i++)
{var aCriteria=searchCriteria.getChildField(childNames[i]);if(fieldName==aCriteria.getChildField("field_name").getValue()){searchCriteria.removeChildField(childNames[i]);break;}

}

}
;this.getConditionals=function(){var conditionals=[];var criteria=this.getChildField("search_criteria");var fieldNames=criteria.getChildFieldNames();for(var i=0;i<fieldNames.length;i++)
{var field=criteria.getChildField(fieldNames[i]);if("conditional"==field.getChildField("criteria_type").getValue()){conditionals.push(field);}

}

return conditionals;}
;}

var CONDITIONAL_EQUALS=0;var CONDITIONAL_GREATER_THAN=1;var CONDITIONAL_GREATER_THAN_EQUAL=2;var CONDITIONAL_LESS_THAN=3;var CONDITIONAL_LESS_THAN_EQUAL=4;var CONDITIONAL_NOT_EQUAL=5;var SEARCHTERM_CONTAINS=0;var SEARCHTERM_EXACT_MATCH=1;var SEARCHTERM_BEGINS_WITH=2;var SEARCHTERM_ENDS_WITH=3;var SEARCHTERM_NOT_CONTAINS=4;
function li_getSearchCriteria(listInput,fieldName){var criteria=[];var searchCriteria=listInput.getChildField("search_criteria");var childNames=searchCriteria.getChildFieldNames();for(var i in childNames)
{var aCriteria=searchCriteria.getChildField(childNames[i]);if(fieldName==aCriteria.getChildField("field_name").getValue()){criteria.push(aCriteria);}

}

return criteria;}

function li_setFieldsToLoad(listInput,fieldsToLoad){listInput.getChildField("fields_to_load").setValue(fieldsToLoad);}

function li_addSearchTerm(listInput,fieldName,value,searchType,isOr){var searchCriteria=listInput.getChildField("search_criteria");var criteria=searchCriteria.addChildField(null,"COLLECTION");criteria.addChildField("criteria_type","TEXT","search_term");criteria.addChildField("field_name","TEXT",fieldName);criteria.addChildField("value","TEXT",value);criteria.addChildField("search_type","INTEGER",searchType);if(null==isOr){isOr=false;}

criteria.addChildField("is_or","BOOLEAN",isOr);}

function li_removeCriteria(listInput,fieldName){var criteria=listInput.getChildField("search_criteria");var childNames=criteria.getChildFieldNames();for(var i in childNames)
{if(criteria.getChildField(childNames[i]).getChildField("field_name").getValue()==fieldName){criteria.removeChildField(i);break;}

}

}


function createRecordInput(type,id){var recordInput=new DynField(null,{}
,{}
,null,null);recordInput.usedAddField=false;recordInput.addChildField("type","TEXT",type);recordInput.addChildField("id","INTEGER",id);recordInput.addChildField("fields_to_load","TEXT","*");recordInput.addChildField("record_names","TEXT","");
extendField(recordInput,g_recordInputBase);return recordInput;}

function turnIntoRecordInput(field){if(!field){return null;}

extendField(field,g_recordInputBase);return field;}

var g_recordInputBase=new RecordInputBase();function RecordInputBase(){this.clearFieldsToLoad=function(){this.getChildField("fields_to_load").setValue("");}
;this.addField=function(fieldName){var fieldsToLoad=this.getChildField("fields_to_load");var value=fieldsToLoad.getValue();if(!this.usedAddField){this.usedAddField=true;value=fieldName;}

else 
{value+=","+fieldName;}

fieldsToLoad.setValue(value);return this;}
;this.addName=function(recordName){var recordNames=this.getChildField("record_names");var value=recordNames.getValue();if(value){value+=","+recordName;}

else 
{value=recordName;}

recordNames.setValue(value);return this;}
;}


mc_typeToDefaultValue["MCL"]=function(){var field=new DynField(null,{}
,{}
,null,null);field.addChildField("name","TEXT");field.addChildField("records_to_load","COLLECTION");field.addChildField("records_by_key","COLLECTION");field.addChildField("record_names","COLLECTION");field.addChildField("fields_to_process","COLLECTION");field.addChildField("fields_to_process_first","COLLECTION");field.addChildField("fields_to_process_last","COLLECTION");field.addChildField("lists","ARRAY");field.addChildField("templates","COLLECTION");field.addChildField("dyn_tables","COLLECTION");field.addChildField("values","COLLECTION");return {data:field.data,metaData:field.metaData}
;}

vfc_registerConverter("MCL",vfc_returnNoValue);

function extendList(aList){aList.copyToListInput=function(){if(aList.listInput){return aList.listInput;}

var listInput=createListInput(this.record_type,this.name,this.start_record,this.max_record_count,this.sort_field,this.sort_direction);aList.listInput=listInput;var fields=aList.fields_to_load;for(var i in fields)
{listInput.addField(fields[i]);}

var searchCriteria=aList.search_criteria;for(var i in searchCriteria)
{var criteria=searchCriteria[i];if("search_term"==criteria.criteria_type){if(criteria.is_or){listInput.addOrSearchTerm(criteria.field_name,criteria.value,criteria.search_type,criteria.group);}

else 
{listInput.addSearchTerm(criteria.field_name,criteria.value,criteria.search_type);}

}

else if("conditional"==criteria.criteria_type){listInput.addConditional(criteria.field_name,criteria.value,criteria.conditional_type);}

}

return listInput;}
;aList.getFirstRecord=function(){return this.ownerCache.getRecord(this.record_type,this.ids[0]);}
;return aList;}

function createGeneralExecuter(name,miniCache,instruction,basePackage){var gE=miniCache.createAction(name,"GXT");prepareGE(gE,instruction,basePackage);return gE;}

function createGEToRunFirst(name,miniCache,instruction,basePackage){var gE=miniCache.createFirstAction(name,"GXT");prepareGE(gE,instruction,basePackage);return gE;}

function createGEToRunLast(name,miniCache,instruction,basePackage){var gE=miniCache.createLastAction(name,"GXT");prepareGE(gE,instruction,basePackage);return gE;}

function prepareGE(gE,instruction,basePackage){var instructions=gE.getChildField("instructions");instructions.addChildField(instruction,"TEXT",instruction);gE.getChildField("base_package").setValue(basePackage);}

mc_typeToDefaultValue["GXT"]=function(){var gE=new DynField(null,{}
,{}
,null,null);gE.addChildField("instructions","COLLECTION");gE.addChildField("base_package","TEXT");gE.addChildField("exec_params","COLLECTION");return gE;}

vfc_registerConverter("GXT",vfc_returnNoValue);
mc_fieldTypeExtenders["GXT"]=function(dynField){dynField.getResults=function(){return this.getChildField("exec_res");}

dynField.getResultByName=function(resName){return this.getChildField("exec_res").getChildField(resName)
}

dynField.addExecParamDynField=function(fieldType,dynField,name){if(null==name){name=dynField.name;}

return this.getChildField("exec_params").insertChildField(name,fieldType,dynField);}

dynField.addExecParamObj=function(name,fieldType,value){return this.getChildField("exec_params").addChildField(name,fieldType,value);}

dynField.getExecParam=function(paramName){return this.getChildField("exec_params").getChildField(paramName);}

}

;var rd_counter=0;function createRecordDeleter(miniCache){rd_counter++;var name="deleter"+rd_counter;var deleter=createGeneralExecuter(name,miniCache,"RecordDeleter");addRecordDeleterExtensions(deleter);return deleter;}

function createRecordDeleterToRunFirst(miniCache){rd_counter++;var name="deleter"+rd_counter;var deleter=createGEToRunFirst(name,miniCache,"RecordDeleter");addRecordDeleterExtensions(deleter);return deleter;}

function addRecordDeleterExtensions(deleter){var params=deleter.getChildField("exec_params");params.addChildField("type","TEXT");params.addChildField("ids","TEXT");params.addChildField("is_delete_tas","BOOLEAN",false);deleter.setType=function(type){this.getChildField("exec_params").getChildField("type").setValue(type);}
;deleter.addId=function(id){var ids=this.getChildField("exec_params").getChildField("ids");var value=ids.getValue();value+=id+",";ids.setValue(value);}
;deleter.setIsDeleteTas=function(isDeleteTas){this.getChildField("exec_params").getChildField("is_delete_tas").setValue(isDeleteTas);}
;}


function sorter_sortAscending(sortProperty,arrayToSort){sorter_sortProperty=sortProperty;arrayToSort.sort(sorter_generalCompare);sorter_sortProperty=null;}
;function sorter_sortDescending(sortProperty,arrayToSort){sorter_sortProperty=sortProperty;arrayToSort.sort(sorter_reverseCompare);sorter_sortProperty=null;}
;var sorter_sortProperty;function sorter_generalCompare(arg1,arg2){if(!sorter_sortProperty){alert("You must set the sort property");}

eval("var value1 = arg1."+sorter_sortProperty);eval("var value2 = arg2."+sorter_sortProperty);if(value1>value2){return 1;}

else if(value1<value2){return -1;}

else 
{return 0;}

}
;function sorter_reverseCompare(arg1,arg2){return sorter_generalCompare(arg2,arg1);}

;function ValidationHandler(){this.valTypes={}
;this.valObjects={}
;this.errors=[];this.errorDisplayFx;this.types={}
;this.valObjectsByType={}

this.errorList={}
;this.errorHandlerByType={}
;}

ValidationHandler.prototype=new ValidationBase();function ValidationBase(){
this.addVal=function(type,valFx){this.valTypes[type]=valFx;}
;
this.addObjectToVal=function(type,object){var objsByType=this.valObjectsByType[type];if(null==objsByType){objsByType=[];this.valObjectsByType[type]=objsByType;}

objsByType.push(object);}
;this.addValidationObject=function(type,valObject){this.valObjects[type]=valObject;}

this.getValObject=function(type){return this.valObjects[type];}


this.setErroDisplayFx=function(errorDisplayFx){this.errorDisplayFx=errorDisplayFx;}


this.validate=function(){this.resetErrors();var objsByType=this.valObjectsByType;for(var type in objsByType)
{var valFx=this.types[type]
if(null==valFx){valFx=this.valTypes[type];}

if(valFx==null){alert("There is not  a validation function registered for the type "+type);return ;}

var objList=objsByType[type];for(var i=0;i<objList.length;i++)
{var element=objList[i];if(null==element){continue;}

if(!isInDom(element)&&element.tagName!=undefined){objList[i]=null;continue;}

var result=valFx(objList[i]);var objectType=typeof(result);if(objectType=="object"){for(var j=0;j<result.length;j++)
{var error=result[j];this.errors.push(error);this.hasErrors=true;}

break}

else if(objectType=="boolean"){if(!result){this.addToErrorList(type,element);}

}

}

}

if(this.hasErrors){this.showErrors();return false;}

return true;}
;this.registerTypeValFx=function(type,valFx){this.types[type]=valFx;}
;this.registerErrorMsgFx=function(type,errorFx){this.errorHandlerByType[type]=errorFx;}
;this.registerValidation=function(type,valFx,error){this.types[type]=valFx;this.errorHandlerByType[type]=error;}
;this.showErrors=function(){var errMsg="";var errorsByType=this.errorList;for(var type in errorsByType)
{var errorFx=this.errorHandlerByType[type]
if(null==errorFx){alert("There is no error handling function registered for the type "+type);return ;}

var errorElList=errorsByType[type];for(var i=0;i<errorElList.length;i++)
{if(typeof(errorFx)=="string"){errMsg+=errorFx+"\n";}

else 
{var aMsg=errorFx(errorElList[i]);if(aMsg.trim()!=""){errMsg+=aMsg+"\n";}

}

}

}

var errors=this.errors;for(var i=0;i<errors.length;i++)
{errMsg+=errors[i]+"\n";}

if(null!=this.errorDisplayFx){this.errorDisplayFx(errMsg.replaceAll("\n","<br>"));}

else if(window.showMessage){showMessage(errMsg.replaceAll("\n","<br>"));}

else 
{alert(errMsg);}

}
;this.resetErrors=function(){this.hasErrors=false;this.errorList={}
;this.errors=[];}
;this.addToErrorList=function(type,element){this.hasErrors=true;var errorListByType=this.errorList[type];if(null==errorListByType){errorListByType=[];this.errorList[type]=errorListByType;}

errorListByType.push(element);}
;}
;if(null==ValidationUtil){var ValidationUtil=new ValidationHandler();}


var KeyCodeUtil=new KeyCodeUtilBase();function KeyCodeUtilBase(){this.getTranslation=function(keyCode){var trans=this.KEY_CODE_TRANSLATOR[keyCode];return trans;}
;this.cancelPressKey=function(event){if(null!=event.stopPropagation){event.stopPropagation();event.preventDefault();}

else 
{window.event.returnValue=false;window.event.cancelBubble=true;}

return null;}
;this.isNumeric=function(event){var keyCode=this.getKeyCode(event);if(keyCode>=48&&keyCode<=57){return true;}

return false;}
;this.isAlphabetic=function(event){var keyCode=this.getKeyCode(event);if((keyCode>=65&&keyCode<=90)||(keyCode>=97&&keyCode<=122)){return true;}

return false;}
;this.getKeyCode=function(event){var key;if(null!=event&&null!=event.which){key=event.which;}

else if(null!=window.event){key=window.event.keyCode;}

return key;}
;this.isNumber=function(keyCode){return ((keyCode>=48&&keyCode<=57)||(keyCode>=96&&keyCode<=105));}
;this.isCharacter=function(event,keyCode){var keyCodePressed=this.getKeyCode(event);if(keyCodePressed==keyCode){return true;}

return false;}

this.isValidCharForNumber=function(event){if(this.isNumeric(event)){return true;}

var isValidCharacter=(this.isCharacter(event,46)||
this.isCharacter(event,44)||
this.isCharacter(event,45)||
this.isCharacter(event,8)||
this.isCharacter(event,0));return isValidCharacter;}

var kc=[];kc[48]="0";kc[49]="1";kc[50]="2";kc[51]="3";kc[52]="4";kc[53]="5";kc[54]="6";kc[55]="7";kc[56]="8";kc[57]="9";kc[65]="A";kc[66]="B";kc[67]="C";kc[68]="D";kc[69]="E";kc[70]="F";kc[71]="G";kc[72]="H";kc[73]="I";kc[74]="J";kc[75]="K";kc[76]="L";kc[77]="M";kc[78]="N";kc[79]="O";kc[80]="P";kc[81]="Q";kc[82]="R";kc[83]="S";kc[84]="T";kc[85]="U";kc[86]="V";kc[87]="W";kc[88]="X";kc[89]="Y";kc[90]="Z";kc[96]="0";kc[97]="1";kc[98]="2";kc[99]="3";kc[100]="4";kc[101]="5";kc[102]="6";kc[103]="7";kc[104]="8";kc[105]="9";this.KEY_CODE_TRANSLATOR=kc;}
;

function getProperty(properties,name,defaultValue){if(properties==null||properties[name]==null){return defaultValue;}

return properties[name];}
;

function RequiredValidation(validationHandler){this.reqElCount=0;this.validationHandler=validationHandler;validationHandler.addValidationObject(this.TYPE,this);validationHandler.registerValidation(this.TYPE,this.validateFx,this.errorFx);}

RequiredValidation.prototype=new RequiredValidationBase();function RequiredValidationBase(){this.TYPE="REQUIRED";var eV={}
;eV[g_sessionInformation.settings.date_format.empty_date]=true;this.emptyValues=eV;this.attachValidation=function(element){if(element.name.trim()==""){element.name="Unnamed element "+this.reqElCount;}

this.validationHandler.addObjectToVal(this.TYPE,element);this.reqElCount++;}
;this.validateFx=function(element){var value=element.value.trim();if(value==""||RequiredUtil.emptyValues[value]){return false;}

return true;}

this.errorFx=function(element){return element.name+" "+"is required.";}
;this.registerEmptyValue=function(val){this.emptyValues[val]=true;}
;}

var RequiredUtil=new RequiredValidation(ValidationUtil);
;;;;
;;;;;;;;;;;;;;;
function MiniCache(){
this.ownerWindow;
this.records_by_key={}
;
this.records={}
;
this.lists={}
;
this.values={}
;
this.record_meta_data={}
;
this.templates={}
;
this.template_meta_data={}
;
this.dyn_tables={}
;
this.tables_to_delete=[];
this.record_names={}
;
this.validationHandler=new ValidationHandler();
this.onBeforeProcessFxs={}
;
this.addBeforeProcessFx=function(fx,name){var count=++mc_processFxCounter;if(!name){name="fx"+count;}

this.onBeforeProcessFxs[name]=fx;}
;
this.removeBeforeProcessFx=function(name){delete(this.onBeforeProcessFxs[name]);}
;
this.runBeforeProcesses=function(){for(var i in this.onBeforeProcessFxs)
{var fx=this.onBeforeProcessFxs[i];fx();}

}
;
this.addRecordName=function(record,name){this.record_names[name]={type:record.type,id:record.getId()}
;}
;
this.getRecordByName=function(name){var info=this.record_names[name];if(!info){return null;}

return this.getRecord(info.type,info.id);}
;this.getValue=function(name){return this.values[name];}
;
this.getDynTable=function(type){var data=this.templates[type];var metaData=this.template_meta_data[type];var settings=this.dyn_tables[type];return new DynTable(type,data,metaData,settings,this);}
;
this.getRecord=function(type,id){id=parseInt(id);if(0>id&&mc_tempToRealId[type]&&mc_tempToRealId[type][id]){id=mc_tempToRealId[type][id];}

var recordsOfType=this.records[type];if(!recordsOfType){if(mc_masterCache&&mc_masterCache.records[type]){this.records[type]=clone(mc_masterCache.records[type]);this.record_meta_data[type]=clone(mc_masterCache.record_meta_data[type]);recordsOfType=this.records[type];}

else 
{return null;}

}

var data=recordsOfType[id];if(!data){if(mc_masterCache&&mc_masterCache.records[type]&&mc_masterCache.records[type][id]){this.records[type][id]=clone(mc_masterCache.records[type][id]);this.record_meta_data[type][id]=clone(mc_masterCache.record_meta_data[type][id]);data=recordsOfType[id];}

else 
{return null;}

}

var metaData=this.record_meta_data[type][id];return new Record(type,id,data,metaData,this);}
;
this.getListByName=function(name){var aList=this.lists[name];if(!aList){if(!mc_masterCache){return null;}

var masterList=mc_masterCache.lists[name];if(null==masterList){return null;}

var masterCache=masterList.ownerCache;masterList.ownerCache=null;aList=clone(masterList);masterList.ownerCache=masterCache;}

if(!aList){return null;}

aList.ownerCache=this;return extendList(aList);}
;
this.getRecordByKey=function(type,fieldName,key){if(mc_masterCache&&mc_masterCache.records_by_key[type+"|"+fieldName+"|"+key]){var recordInfo=clone(mc_masterCache.records_by_key[type+"|"+fieldName+"|"+key]);}

else 
{var recordInfo=this.records_by_key[type+"|"+fieldName+"|"+key];}

var record=null;if(null!=recordInfo){record=this.getRecord(recordInfo.type,recordInfo.id);}

return record;}
;
this.deleteRecord=function(type,id){var deleter=createRecordDeleter(this);deleter.setType(type);deleter.addId(id);this.clearRecord(type,id);}
;
this.clearRecord=function(type,id){var mData=this.record_meta_data[type];if(!mData){return ;}

delete(mData[id]);var recordData=this.records[type];delete(recordData[id]);var isEmpty=true;for(var rId in recordData)
{isEmpty=false;break;}

if(isEmpty){delete(this.record_meta_data[type]);delete(this.records[type]);}

this.cancelRecordToLoad(type,id);}
;
this.clearAllRecords=function(){this.records_by_key={}
;this.records={}
;this.lists={}
;this.record_meta_data={}
;}
;
this.getTemplate=function(type){if(!this.templates[type]&&mc_masterCache.templates[type]){this.templates[type]=clone(mc_masterCache.templates[type]);this.template_meta_data[type]=clone(mc_masterCache.template_meta_data[type]);}

if(this.templates[type]){var template=new Record(type,0,this.templates[type],this.template_meta_data[type],this);template.isTemplate=true;return template;}

return null;}
;
this.createRecord=function(type,id){if(!id){mc_newIdCounter--;id=mc_newIdCounter;}

var templateData=this.getTemplate(type);var record=clone(templateData.data);record.type=type;record.id=id;var recordsOfType=this.records[type];if(!recordsOfType){this.records[type]={}
;recordsOfType=this.records[type];}

recordsOfType[id]=record;var recordMetaData=clone(templateData.metaData);recordMetaData.type=type;recordMetaData.id=id;var metaDataForType=this.record_meta_data[type];if(!metaDataForType){this.record_meta_data[type]={}
;metaDataForType=this.record_meta_data[type];}

metaDataForType[id]=recordMetaData;var record=this.getRecord(type,id);record.setDoSave();return record;}
;this.createTable=function(name,displayName,pluralName,packageName){this.dyn_tables[name]={singularName:displayName,pluralName:pluralName,packageName:packageName,cachingSetting:"",doSave:true}
;this.templates[name]={}
;this.template_meta_data[name]={}
;}
;this.initializeProcessor=function(){this.records["processor"]={}
;this.records["processor"][0]={}
;this.record_meta_data["processor"]={}
;this.record_meta_data["processor"][0]={}
;this.record_meta_data["processor"][0].doProcess=true;var recordToProcess=this.getRecord("processor",0);return recordToProcess.addField("processor","MCL","",0);}
;this.processor=this.initializeProcessor();this.process=function(onAfterProcessFx,onErrorFx){this.syncToMaster();var thisCache=this;var finishFx=function(){thisCache.processor=thisCache.initializeProcessor();if(onAfterProcessFx){onAfterProcessFx();}

}

mcs_process(thisCache,finishFx,onErrorFx);}
;
this.syncProcess=function(){this.syncToMaster();var thisCache=this;mcs_process(thisCache);thisCache.processor=thisCache.initializeProcessor();}
;this.createAction=function(name,fieldType){return this.processor.getChildField("fields_to_process").addChildField(name,fieldType);}
;this.createFirstAction=function(name,fieldType){return this.processor.getChildField("fields_to_process_first").addChildField(name,fieldType);}
;this.createLastAction=function(name,fieldType){return this.processor.getChildField("fields_to_process_last").addChildField(name,fieldType);}
;this.removeActionField=function(name){this.processor.getChildField("fields_to_process_last").removeChildField(name);this.processor.getChildField("fields_to_process_first").removeChildField(name);this.processor.getChildField("fields_to_process").removeChildField(name);}
;this.getActionField=function(name){return this.getRecord(name,0).getField(name);}

this.addKeyedRecordToLoad=function(type,fieldName,key,fieldsToLoad){if(!fieldsToLoad){fieldsToLoad="*";}

var recordsByKey=this.processor.getChildField("records_by_key");var requestId=type+fieldName+key;var recordToLoad=recordsByKey.addChildField(requestId,"COLLECTION",null,null,null);recordToLoad.addChildField("type","TEXT",type,null,null);recordToLoad.addChildField("field_name","TEXT",fieldName,null,null);recordToLoad.addChildField("key","TEXT",key,null,null);recordToLoad.addChildField("fields_to_load","TEXT",fieldsToLoad,null,null);return recordToLoad;}
;this.addRecordToLoad=function(type,id){var recordInput=createRecordInput(type,id);this.addRecordInput(recordInput);return recordInput;}
;this.addRecordInput=function(recordInput){var requestId=recordInput.data.type+recordInput.data.id;this.processor.getChildField("records_to_load").insertChildField(requestId,"COLLECTION",recordInput);}
;this.cancelRecordToLoad=function(type,id){var requestId=type+id;this.processor.getChildField("records_to_load").removeChildField(requestId);}

this.addListToLoad=function(type,name,startRecord,max,sortField,sortDirection){var listInput=createListInput(type,name,startRecord,max,sortField,sortDirection);this.addListInput(listInput);return listInput;}
;this.addListInput=function(listInput){this.processor.getChildField("lists").insertChildField(null,"COLLECTION",listInput);}
;this.addTableToLoad=function(tableName){var tablesToLoad=this.processor.getChildField("dyn_tables");tablesToLoad.addChildField(tableName,"TEXT",tableName);}
;this.addTemplateToLoad=function(tableName){var templates=this.processor.getChildField("templates");templates.addChildField(tableName,"TEXT",tableName);}
;this.syncToMaster=function(){if(this.isMaster||!mc_masterCache){return ;}

var recordsToSave=this.getRecordsToSave();for(var i in recordsToSave)
{var newRecord=recordsToSave[i];var masterRecord=mc_masterCache.getRecord(newRecord.type,newRecord.id);if(!masterRecord){continue;}

mc_cloneContent(newRecord.data,masterRecord.data);mc_cloneContent(newRecord.metaData,masterRecord.metaData);masterRecord.resetMetaInfo(null,"bs");}

}
;this.getRecordsToSave=function(){var recordsToSave=[];var recordsMetaData=this.record_meta_data;for(var type in recordsMetaData)
{var records=recordsMetaData[type];for(var id in records)
{var record=this.getRecord(type,id);if(record.metaData.doSave){recordsToSave.push(record);}

}

}

return recordsToSave;}
;this.getRecordsToSaveOfAType=function(type){var recordsToSave=[];var records=this.record_meta_data[type];for(var id in records)
{var record=this.getRecord(type,id);if(record.metaData.doSave){recordsToSave.push(record);}

}

return recordsToSave;}
;this.getRecordsByType=function(type,sortField,sortDirection){var recordsByType=[];var records=this.record_meta_data[type];for(var id in records)
{var record=this.getRecord(type,id);recordsByType.push(record);}

if(sortField){if(sortDirection=="asc"||!sortDirection){sorter_sortAscending("data."+sortField,recordsByType);}

else 
{sorter_sortDescending("data."+sortField,recordsByType);}

}

return recordsByType;}
;this.syncToMasterOnProcess=function(){this.doSyncToMaster=true;}

this.clearRecordsOfAType=function(type){var records=this.record_meta_data[type];for(var id in records)
{this.clearRecord(type,id);}

}

this.copyTemplate=function(recordType,fromMiniCache){var data=fromMiniCache.templates[recordType];var metaData=fromMiniCache.template_meta_data[recordType]
if(data&&metaData){this.templates[recordType]=clone(data);this.template_meta_data[recordType]=clone(metaData);}

}
;
this.addValType=function(valType,valFx){this.validationHandler.addVal(valType,valFx);return this;}
;
this.addValToObj=function(valType,valObj){this.validationHandler.addObjectToVal(valType,valObj);return this;}
;
this.validate=function(){return this.validationHandler.validate();}
;
this.id=++mc_newCacheIdCounter;
this.setOwnerWindow=function(ownerWindow){this.ownerWindow=ownerWindow;}
;
this.isDataToLoad=function(){var p=this.processor.data;return (this.isEmpty(p.records_by_key)||this.isEmpty(p.records_to_load)||this.isEmpty(p.lists));}
;this.isEmpty=function(object){for(var i in object)
{var notEmpty=object[i];return false;}

return true;}
;}
;function getMasterCache(){if(null==mc_masterCache){mc_masterCache=new MiniCache();mc_masterCache.isMaster=true;mc_masterCache.id="master";}

return mc_masterCache;}

var mc_newIdCounter=0;var mc_newCacheIdCounter=0;var mc_processFxCounter=0;var mc_tempToRealId={}
;if(!mc_masterCache){var mc_masterCache=null;}

if(!mc_objectToHtmlFxByType){var mc_objectToHtmlFxByType={}
;}

function mc_getFieldNames(metaData){var fieldNames=[];for(var i in metaData)
{var nameLength=i.length;if(nameLength<=3){continue;}

var suffix=i.substring(nameLength-3,nameLength);if("_do"==suffix){var fieldName=i.substring(0,nameLength-3);fieldNames.push({name:fieldName,order:metaData[i]}
);}

}

sorter_sortAscending("order",fieldNames);for(var i in fieldNames)
{fieldNames[i]=fieldNames[i].name;}

return fieldNames;}

function mc_clearObject(anObject){for(var i in anObject)
{delete(anObject[i]);}

}


function mc_cloneContent(source,destination){mc_clearObject(destination);for(var i in source)
{destination[i]=clone(source[i]);}

return destination;}

;;
function CredentialHandler(){this.mc=new MiniCache();
this.encrypt=function(val1,val2,afterProcess){var thisObj=this;var onProcess=function(){var encryptedVal=thisObj.mc.getActionField("crd_handler").getResultByName("result_val").getValue();createCookie("crdhdlr",encryptedVal,30);createCookie("remember_me",true,30);afterProcess();}
;var srcVal=val1+"$"+val2;this.processGe(srcVal,"encrypt",onProcess);}
;
this.decrypt=function(afterProcess){var thisObj=this;var onProcess=function(){var decryptedVal=thisObj.mc.getActionField("crd_handler").getResultByName("result_val").getValue();var val=decryptedVal.split("$");afterProcess(val[0],val[1]);}
;var srcVal=readCookie("crdhdlr");this.processGe(srcVal,"decrypt",onProcess);}
;this.processGe=function(srcVal,action,onProcess){var mc=this.mc;var gE=createGeneralExecuter("crd_handler",mc,"EncryptionHandler");gE.addExecParamObj("source_val","TEXT",srcVal);gE.addExecParamObj("action","TEXT",action);mc.process(onProcess)
}

}


;function login_LoginUtil(){this.idHolder;this.passwordHolder;this.buttonHolder;this.passwordRecoveryHolder;this.registrationHolder;this.loginEl;this.inputWidth="223px";this.buildRegisterArea=false;this.buildPassRecovery=true;this.loginCache;this.loginRecord;this.buildHTML=function(){loginutil_buildLoginForm(this)}
;this.logUser=function(){loginutil_logUser(this)}
;loginutil_createLoginRecord(this);}

function loginutil_createLoginRecord(loginObj){var cache=new core_Cache();loginObj.loginCache=cache;var record=new core_Record("login",-1);record.doProcess=true;record.ownerCache=cache;loginObj.loginRecord=record;cache.addRecord(record);var loginField=new login_Login("login","",0);record.addField(loginField);record.init();}

function loginutil_logUser(loginObj){var loginField=loginObj.loginRecord.fields.login;showLoginIcon();var loginFx=function(){var onLoginFx=function(un,pw){loginField.setUserName(un);loginField.setPassword(pw);loginObj.loginCache.submitCache("go");}
;var un=readCookie("userName");var pw=readCookie("password");var srcVal=readCookie("crdhdlr");if(un!=null&&pw!=null){onLoginFx(un,pw);}

else if(srcVal!=null&&""!=srcVal){var crd=new CredentialHandler();crd.decrypt(onLoginFx);}

else 
{eraseCookie("remember_me");eraseCookie("password");eraseCookie("userName");eraseCookie("crdhdlr");onLoginFx("","");}

}

window.setTimeout(loginFx,1000);}
;function loginutil_buildLoginForm(loginObj){var loginField=loginObj.loginRecord.fields.login;var username=loginField.buildUsername(loginObj.inputWidth);loginObj.idHolder.appendChild(username);var password=loginField.buildPassword(loginObj.inputWidth);loginObj.passwordHolder.appendChild(password);loginutil_buildRememberMe(loginField,loginObj.passwordHolder);if(loginObj.buttonHolder){var button=loginField.buildButton();button.className="text";button.style.color="#006699";button.style.paddingLeft=10;button.style.paddingRight=10;loginObj.buttonHolder.appendChild(button);}

else if(loginObj.loginEl){var onclick=function(){var logInFx=function(){loginField.ownerCache.submitCache("go")
}

if(loginField.rememberMe){var un=loginField.children.username.value;var pw=loginField.children.password.value;var cH=new CredentialHandler();cH.encrypt(un,pw,logInFx);}

else 
{logInFx();}

}
;eh_attachEvent("onclick",loginObj.loginEl,onclick);}

if(loginObj.buildPassRecovery){loginutil_buildPasswordRecovery(loginObj);}

if(loginObj.buildRegisterArea){loginutil_buildAccountRequest(loginObj);}

}

function loginutil_buildRememberMe(loginField,parentEl){var isPublic=readCookie("is_public_computer");if(isPublic){loginField.rememberMe=false;eraseCookie("remember_me");eraseCookie("password");eraseCookie("userName");eraseCookie("crdhdlr");}

var div=document.createElement("div");div.style.margin="4px 0px 4px 0px";div.style.textAlign="left";parentEl.appendChild(div);var input1=document.createElement("input");input1.type="checkbox";input1.onclick=function(){if(input1.checked){input2.checked=false;}

loginField.rememberMe=true;eraseCookie("is_public_computer");}
;div.appendChild(input1);var span=document.createElement("span");span.className="smallText";span.style.marginLeft="3px";span.innerHTML="Remember me on this computer";div.appendChild(span);var div=document.createElement("div");div.style.margin="4px 0px 4px 0px";div.style.textAlign="left";parentEl.appendChild(div);var input2=document.createElement("input");input2.type="checkbox";input2.onclick=function(){if(input2.checked){input1.checked=false;loginField.rememberMe=false;createCookie("is_public_computer",true,7);eraseCookie("remember_me");eraseCookie("password");eraseCookie("userName");}

else 
{eraseCookie("is_public_computer");}

}
;div.appendChild(input2);var span=document.createElement("span");span.className="smallText";span.style.marginLeft="3px";span.innerHTML="This is a public computer";div.appendChild(span);}

function loginutil_buildPasswordRecovery(loginObj){var span=document.createElement("span");span.style.color="#006699";span.innerHTML="Forgot Password?";span.style.cursor="pointer";span.onmouseover=function(){span.style.textDecoration="underline"}
;span.onmouseout=function(){span.style.textDecoration=""}
;span.style.cursor="pointer";span.onclick=function(event){var passwordUtil=new loginutil_PasswordRecovery();passwordUtil.buildHTML();crossbrowser_stopEvent(event);}
;loginObj.passwordRecoveryHolder.appendChild(span);}

function loginutil_PasswordRecovery(){this.recoveryCache;this.recoveryRecord;this.userId;this.buildHTML=function(){loginutil_buildPasswordRecoverArea(this)}
;loginutil_createRecoveryRecord(this);}

function loginutil_createRecoveryRecord(passwordRecoveryObj){var cache=new core_Cache();passwordRecoveryObj.recoveryCache=cache;var record=new core_Record();record.doProcess=true;var passwordRecoverField=new changepassword_ChangePassword();passwordRecoverField.name="password_recovery";record.addField(passwordRecoverField);record.init();cache.addRecord(record);passwordRecoveryObj.recoveryRecord=record;}

function loginutil_buildPasswordRecoverArea(passwordRecoveryObj){var popup=npop_getPopup();popup.drawTitleBar=true;popup.popupTitle="Reset Password";popup.buildCloseButton=true;popup.fontColor="#9BB681";popup.bgImage=null;popup.bgColor="#F2F9E0";popup.build();npop_getPopup().showPopup();var contentarea=popup.contentArea;contentarea.style.padding="10px";contentarea.style.width="260px";contentarea.style.height="100px";contentarea.style.backgroundColor="white";var table=document.createElement("table");table.cellSpacing=0;table.cellPadding=0;contentarea.appendChild(table);var tbody=document.createElement("tbody");table.appendChild(tbody);var tr=document.createElement("tr");tbody.appendChild(tr);var tr=document.createElement("tr");tbody.appendChild(tr);var td=document.createElement("td");tr.appendChild(td);var div=document.createElement("div");td.appendChild(div);var div=document.createElement("div");div.innerHTML="Enter your user name.";div.style.fontSize="12px";div.style.fontFamily="arial";div.style.marginBottom="5px";td.appendChild(div);var record=passwordRecoveryObj.recoveryRecord;var idInput=record.getFieldByName('password_recovery').buildUsernameInput();idInput.validationType="required";idInput.displayName="User Id";idInput.style.width="255px";td.appendChild(idInput);var tr=document.createElement("tr");tbody.appendChild(tr);var td=document.createElement("td");td.colSpan=2;td.align="center";td.style.paddingTop="10px";tr.appendChild(td);var button=document.createElement("button");button.innerHTML="Submit";button.onclick=function(event){passwordRecoveryObj.userId=record.getFieldByName('password_recovery').children.userName.value;loginutil_validateUserId(passwordRecoveryObj,contentarea);crossbrowser_stopEvent(event);}

button.className="text";button.style.marginRight=8;button.style.color="#006699";td.appendChild(button);var button=document.createElement("button");button.innerHTML="Cancel";button.onclick=function(){npop_getPopup().closePopup();}
;button.className="text";button.style.color="#006699";td.appendChild(button);npop_getPopup().showPopup();}

function loginutil_validateUserId(passwordRecoveryObj,container){if(!validation_validate(container)){return ;}
;var validationFx=function(isNotaValidUser){submitPasswordReset(isNotaValidUser,passwordRecoveryObj);}

validateusername_Validate(validationFx,passwordRecoveryObj.userId);}

function submitPasswordReset(isNonExistingUser,passwordRecoveryObj){var popup=npop_getPopup();popup.drawTitleBar=true;popup.popupTitle="Reset Password";popup.buildCloseButton=true;popup.fontColor="#9BB681";popup.bgImage=null;popup.bgColor="#F2F9E0";popup.build();var contentarea=popup.contentArea;contentarea.style.padding="10px";contentarea.style.width="300px";contentarea.align="center";contentarea.style.backgroundColor="white";var container=document.createElement("div");container.style.width="300px";container.style.padding="10px";container.style.paddingBottom="15px";container.style.fontFamily="arial";container.style.fontSize="14px";container.align="left";contentarea.appendChild(container);if(isNonExistingUser){var div=document.createElement("div");div.innerHTML="We are sorry but the user id <b>"+passwordRecoveryObj.userId+
" </b>does not match our  records. Please re-enter your user id or request to become a member."
container.appendChild(div);}

else 
{var div=document.createElement("div");div.innerHTML="Your password has been reset."
div.align="center";div.style.marginBottom="10px";div.style.fontWeight="bold";container.appendChild(div);var div=document.createElement("div");div.innerHTML="You will receive an email with your new login information shortly."
div.style.marginBottom="10px";container.appendChild(div);passwordRecoveryObj.recoveryCache.process(ajax_doNothing);}

var button=document.createElement("button");button.innerHTML="Done";button.onclick=function(){npop_getPopup().closePopup();}
;button.className="text";button.style.color="#006699";contentarea.appendChild(button);passwordRecoveryObj=null;popup.showPopup();}
;function showLoginIcon(){var popup=npop_getPopup();popup.buildCloseButton=false;popup.build();var contentArea=popup.contentArea;contentArea.style.width="150px";contentArea.style.height="80px";contentArea.innerHTML="";var div=document.createElement("div");div.style.width="150px";div.style.backgroundColor="white";div.align="center";contentArea.appendChild(div);var imgContainer=document.createElement("div");div.appendChild(imgContainer);var img=document.createElement("img");img.src="/upload/js_globals/generic_images/golfball_animation.gif";imgContainer.appendChild(img);var innerDiv=document.createElement("span");innerDiv.className="text";innerDiv.innerHTML="remembering login...";div.appendChild(innerDiv);npop_getPopup().showPopup();}

function field_String(name,displayName,displayOrder,value,isStatic){this.input=null;this.buildInputElement=function(){return str_buildInputElement(this)}
;this.TYPE="TEXT";this.TYPE_DISPLAY_NAME="Short Text";this.ownerRecord;this.ownerCache;this.parentField;this.name=name;this.displayName=displayName;this.displayOrder=displayOrder
this.value=(value==undefined)?"":value;this.isStatic=isStatic;this.isEditable=false;this.isVisible=true;this.fieldContainer=null;this.init=function(){}
;this.buildHTML=function(){return str_buildHTML(this)}

this.buildSettingsHTML=function(){return document.createElement("span");}
;this.toXml=function(){return str_toXml(this)}
;this.clone=function(){return new field_String(this.name,this.displayName,this.displayOrder,this.value,this.isStatic)}
;this.getValue=function(){return this.value;}
;this.setValue=function(value){this.value=value;}

}

function str_objectToField(object,name){return new field_String(name,"",0,object,false);}

if(window.registerConverter){registerConverter("TEXT",str_objectToField);}

function str_buildInputElement(thisObj){var input=document.createElement("input");input.type="text";input.value=thisObj.value;input.style.width=200;input.maxLength=200;input.onchange=function(){this.value=util_removeEmbededScripts(this.value);thisObj.value=this.value;}

return input;}

function str_createMultipleTextField(stringArray,fieldName,fieldDisplayName){var stringHolder=new field_Multiple(fieldName,fieldDisplayName,1,"TEXT","Short Text",1);for(var i=0;i<stringArray.length;i++)
{stringHolder.addChildField(new field_String("","",1,stringArray[i],false));}

return stringHolder;}

function str_toXml(thisObj){var xml=constants_LESS_THAN_CHAR+"f ";xml+="name='"+thisObj.name;xml+="' dn='"+util_formatForXmlValue(thisObj.displayName);xml+="' type='"+thisObj.TYPE;xml+="' do='"+thisObj.displayOrder;xml+="' value='"+util_formatForXmlValue(thisObj.value);xml+="' is_static='"+thisObj.isStatic+"'/>";return xml;}

function str_buildHTML(thisObj){if(thisObj.fieldContainer==null){thisObj.fieldContainer=document.createElement("span");}

if(thisObj.isEditable){str_buildEditableHTML(thisObj);}

else 
{str_buildReadOnlyHTML(thisObj);}

return thisObj.fieldContainer;}

function str_buildEditableHTML(thisObj){var input=document.createElement("input");input.type="text";input.value=thisObj.value;input.style.width=200;input.maxLength=200;input.onchange=function(){thisObj.value=this.value;}

thisObj.input=input;thisObj.fieldContainer.appendChild(input);}

function str_buildReadOnlyHTML(thisObj){var span=document.createElement("span");span.innerHTML=thisObj.value;span.className="architectReadOnly";thisObj.fieldContainer.appendChild(span);}

function createCookie(name,value,days){if(days){var date=new Date();date.setTime(date.getTime()+(days*24*60*60*1000));var expires="; expires="+date.toGMTString();}

else 
{var expires="";}

document.cookie=name+"="+value+expires+";  path=/";}

function readCookie(name){var nameEQ=name+"=";var ca=document.cookie.split(';');for(var i=0;i<ca.length;i++)
{var c=ca[i];while(c.charAt(0)==' ')
{c=c.substring(1,c.length);}

if(c.indexOf(nameEQ)==0){return c.substring(nameEQ.length,c.length);}

}

return null;}

function eraseCookie(name){createCookie(name,"",-1);}

function keypressevent_onEnterHandler(element,handler){element.onkeyup=function(event){var key=crossbrowser_getKeyCode(event);if(key==13){handler()
}

}
;}

function ts_TimeStamp(name,displayName,displayOrder,dateTimeObj,doUpdate,strFormat){this.dateTimeObj=ts_validateDateTime(dateTimeObj);this.getTSFull=function(){return this.dateTimeObj.getDateFullString()}

this.getTSSimple=function(){return this.dateTimeObj.getDateSimpleString()}

this.doUpdate=doUpdate
this.strFormat=strFormat;this.getDateStr=function(){return this.dateTimeObj.getDateStr()}
;this.getTimeStr=function(){return this.dateTimeObj.getTime()}
;this.TYPE="TIMESTAMP";this.TYPE_DISPLAY_NAME="Time Stamp";this.ownerRecord;this.ownerCache;this.parentField;this.name=name;this.displayName=displayName;this.displayOrder=displayOrder
this.isVisible=true;this.isEditable=false;this.children=null;this.fieldContainer=null;this.init=function(){}

this.buildChildFields=function(){ts_buildChildFields(this);}

this.buildHTML=function(){return ts_buildHTML(this);}

this.buildSettingsHTML=function(){return ts_buildSettingsHTML(this);}

this.toXml=function(){return ts_toXml(this);}

this.clone=function(){return ts_clone(this);}

this.buildSearchTerm=function(searchType){return ts_buildSearchterm(searchType)}
;}

function ts_objectToField(object,name){var field=new ts_TimeStamp(name,"",0,object,false,"");return field;}

if(window.registerConverter){registerConverter("TIMESTAMP",ts_objectToField);}

function ts_validateDateTime(dateTimeObj){var currentDate=new Date();var hour=currentDate.getHours();var minute=currentDate.getMinutes();var second=currentDate.getSeconds();var secondOffset=(hour*3600)+(minute*60)+second;if(dateTimeObj==null){dateTimeObj=new field_DateTime("date_time","Date/Time",1.0,"","","","");}

else 
{if(null==dateTimeObj.dateObj){dateTimeObj=new field_DateTime("date_time","Date/Time",1.0,"","","","");}

else 
{var date=dateTimeObj.dateObj;var time=dateTimeObj.timeObj.minuteOffset;dateTimeObj=new field_DateTime("date_time","Date/Time",1.0,date.year,date.month,date.date,time);}

}

return dateTimeObj;}

function ts_getFullDateTimeString(thisObj){var dateStr=date_toElegantString(thisObj.dateObj);dateStr+=" "+ts_getTimeValueString(thisObj)
return dateStr;}

function ts_buildSearchterm(searchType){if(searchType=="interval"){alert("build interval search type");}

else 
{alert("build search by date conditional");}

return "";}

function ts_buildChildFields(thisObj){thisObj.children=new Array();thisObj.children['date_time']=thisObj.dateTimeObj;thisObj.children['do_update']=new field_Boolean("do_update","Update?",2.0,thisObj.doUpdate,false);thisObj.children["str_format"]=new field_String("str_format","Date Format",2.0,thisObj.strFormat,true);}

function ts_buildHTML(thisObj){if(thisObj.fieldContainer==null){thisObj.fieldContainer=document.createElement("span");}

var dataSpan=document.createElement("span");var value=(thisObj.strFormat=="long")?thisObj.dateTimeObj.getDateFullString():thisObj.dateTimeObj.getDateSimpleString();dataSpan.innerHTML=(value=="undefined")?"":value;dataSpan.className=thisObj.readOnlyClass;thisObj.fieldContainer.appendChild(dataSpan);return thisObj.fieldContainer;}

function ts_buildSettingsHTML(thisObj){var container=document.createElement("div")
var table=document.createElement("table");container.appendChild(table);var tbody=document.createElement("tbody");table.appendChild(tbody);var tr=document.createElement("tr");tbody.appendChild(tr);var td=document.createElement("td");td.vAlign="top";tr.appendChild(td);var simple=document.createElement("input");simple.type="radio";simple.value="simple";simple.defaultChecked=(thisObj.strFormat=="simple")?true:false;simple.onclick=function(){if(thisObj.selectedDefaultInput!=null){thisObj.selectedDefaultInput.checked=false;}

this.checked=true;thisObj.strFormat=this.value;thisObj.selectedDefaultInput=this;}
;td.appendChild(simple);var td=document.createElement("td");td.className="architectReadOnly";tr.appendChild(td);var div=document.createElement("div");div.innerHTML="Simple Format"
td.appendChild(div);var div=document.createElement("div");div.innerHTML="(MM/DD/YYYY HH:MM)";div.style.fontStyle="italic";td.appendChild(div);var td=document.createElement("td");td.vAlign="top";tr.appendChild(td);var longStr=document.createElement("input");longStr.type="radio";longStr.value="long";longStr.defaultChecked=(thisObj.strFormat=="long")?true:false;longStr.onclick=function(){if(thisObj.selectedDefaultInput!=null){thisObj.selectedDefaultInput.checked=false;}

this.checked=true;thisObj.strFormat=this.value;thisObj.selectedDefaultInput=this;}
;td.appendChild(longStr);var td=document.createElement("td");td.className="architectReadOnly";tr.appendChild(td);var div=document.createElement("div");div.innerHTML="Elegant Format"
td.appendChild(div);var div=document.createElement("div");div.innerHTML="(Day, Date Month, Year HH:MM)";div.style.fontStyle="italic";td.appendChild(div);if(thisObj.strFormat=="simple"){thisObj.selectedDefaultInput=simple;}

else 
{thisObj.selectedDefaultInput=longStr;}

var td=document.createElement("td");td.vAlign="top";tr.appendChild(td);var doUpdate=document.createElement("input");doUpdate.type="checkbox";doUpdate.defaultChecked=(thisObj.doUpdate)?true:false;doUpdate.onclick=function(){thisObj.doUpdate=(this.checked)?true:false}
;td.appendChild(doUpdate);var td=document.createElement("td");td.className="architectReadOnly";tr.appendChild(td);var div=document.createElement("div");div.innerHTML="Update On Save?"
td.appendChild(div);return container;}

function ts_toXml(thisObj){ts_buildChildFields(thisObj);var xml=util_openFieldXmlTag(thisObj);for(var i in thisObj.children)
{xml+=thisObj.children[i].toXml();}

xml+=util_closeFieldXmlTag();return xml;}

function ts_clone(thisObj){return new ts_TimeStamp(thisObj.name,thisObj.displayName,thisObj.displayOrder,null,thisObj.doUpdate,thisObj.strFormat);}

;
var date_separator;var date_datePos;var date_monthPos;var date_yearPos;var date_formatGuide;function date_initDateFormat(){try
{var dateFormat=g_sessionInformation.settings.date_format;date_separator=dateFormat.separator;date_datePos=dateFormat.date_pos;date_monthPos=dateFormat.month_pos;date_yearPos=dateFormat.year_pos;date_formatGuide=dateFormat.empty_date;}

catch(e)
{date_separator="/";date_datePos=2;date_monthPos=1;date_yearPos=3;date_formatGuide="MM/dd/yyyy";}

}

date_initDateFormat();var date_dateMsgStr1="The field '";var date_dateMsgStr2="' is not a valid date.";var date_beforeDateMsgStr1="The field '";var date_beforeDateMsgStr2="' should be earlier than the field '";var date_beforeDateMsgStr3="'.";var date_afterDateMsgStr1="The field '";var date_afterDateMsgStr2="' should be later than the field '";var date_afterDateMsgStr3="'.";{var date_date=new validation_ValidationType("date",date_isDate);date_date.addEventFunction("onkeypress",date_filterKeyPress);date_date.addEventFunction("onchange",date_isDate);date_date.addEventFunction("onload",date_formatEmptyDate);date_date.addEventFunction("onfocus",formatDateForEntry);var date_beforeDate=new validation_ValidationType("beforedate",date_isBeforeDate);var date_afterDate=new validation_ValidationType("afterdate",date_isAfterDate);}


function date_ValDate(date,month,year){try
{this.date=parseInt(date,10);this.month=parseInt(month,10);this.year=parseInt(year,10);}

catch(e)
{this.date=date;this.month=month;this.year=year;}

}

function date_ValDateBase(){this.getDayStr=function(index,format){return (format==null||format=="full")?date_days[index]:date_days_short[index]}
;this.getMonthStr=function(index,format){return (format==null||format=="full")?date_months[index]:date_months_short[index]}
;this.getDateString=function(){return date_formatDate(this.date,this.month,this.year)}
;this.getElegantString=function(){return date_toElegantString(this)}
;this.toStdFormat=function(){return date_formatDate(this.date,this.month,this.year);}

this.createDateBeforeThisDate=function(daysToSubstract){return date_createDateBeforeThisDate(this,daysToSubstract)
}
;this.toDbFormat=function(){return date_toDbFormat(this.year,this.month,this.date);}
;this.dateToString=function(format){return date_getFormatedStr(this,format)
}
;this.isSameThanOtherDate=function(otherDate){return date_isSameThanOtherDate(this,otherDate);}
;this.getIntervaDateInterval=function(otherDate){return date_getIntervalBetweenDates(this,otherDate);}
;this.getNextDay=function(){return date_getNextDay(this)
}
;this.getPreviousDay=function(){return date_getPreviousDay(this);}
;this.addDaysToDate=function(numberOfDays){date_change(this,numberOfDays);return this;}

this.clone=function(){return new date_ValDate(this.date,this.month,this.year);}

}

date_ValDate.prototype=new date_ValDateBase();function date_clone(dateObj){return new date_ValDate(dateObj.date,dateObj.month,dateObj.year);}

function date_getPreviousDayOfWeek(dateObj,dayIndex){var newDateObj=new date_ValDate(dateObj.date,dateObj.month,dateObj.year);var thisDayIndex=date_getDayIndex(dateObj);var difference=dayIndex-thisDayIndex;if(difference>0){difference-=7;}

date_change(newDateObj,difference);return newDateObj;}

function date_getMax(date1,date2){return (date_isBeforeOtherDate(date1,date2))?date2:date1;}

function date_getMin(date1,date2){return (date_isBeforeOtherDate(date1,date2))?date1:date2;}

function date_getCurrentDate(){return new date_ValDate(g_currentDateTime.date,g_currentDateTime.month,g_currentDateTime.year);}

function date_createDateBeforeThisDate(thisObj,daysToSubstract){var newDateObj=null;var newDate=thisObj.date-daysToSubstract;if(newDate<=0){var previousMonth=thisObj.month-1;var year=thisObj.year;if(previousMonth<1){previousMonth=12;year--;}

var previousMonthDayCount=date_getDaysInMonth(previousMonth,year);newDateObj=new date_ValDate(previousMonthDayCount+newDate,previousMonth,year);}

else 
{newDateObj=new date_ValDate(newDate,thisObj.month,thisObj.year)
}

return newDateObj;}


function date_isBeforeDate(object){var otherField=document.getElementById(object.dateBefore);if(null==otherField){return ;}

var thisDate=date_toStdFormat(object.value);var otherDate=date_toStdFormat(otherField.value);if((null==thisDate)||(null==otherDate)){return ;}

if(!date_isBeforeOtherDate(thisDate,otherDate)){var errorMessage=date_beforeDateMsgStr1+object.displayName+date_beforeDateMsgStr2+
otherField.displayName+date_beforeDateMsgStr3;return (new validation_Error(object,errorMessage));}

}


function date_isAfterDate(object){var otherField=document.getElementById(object.dateAfter);if(null==otherField){return ;}

var thisDate=date_toStdFormat(object.value);var otherDate=date_toStdFormat(otherField.value);if((null==thisDate)||(null==otherDate)){return ;}

if(!date_isBeforeOtherDate(otherDate,thisDate)){var errorMessage=date_afterDateMsgStr1+object.displayName+date_afterDateMsgStr2+
otherField.displayName+date_afterDateMsgStr3;return (new validation_Error(object,errorMessage));}

}


function date_isSameThanOtherDate(date,otherDate){return ((date.year==otherDate.year)&&(date.month==otherDate.month)&&(date.date==otherDate.date));}


function date_isBeforeOtherDate(date,otherDate){return ((date.year<otherDate.year)||
((date.year==otherDate.year)&&(date.month<otherDate.month))||
((date.year==otherDate.year)&&(date.month==otherDate.month)&&(date.date<otherDate.date)));}


function date_toStdFormat(dateString){re=/\D*(\d*)\D*(\d*)\D*(\d*)\D*/;var result=re.exec(dateString);if(null==result){return null;}

var date=date_parseDatePart(result[date_datePos]);var month=date_parseDatePart(result[date_monthPos]);var year=date_parseYearPart(result[date_yearPos]);if(date_isDateValid(date,month,year)){return (new date_ValDate(date,month,year));}

else 
{return null;}

}

function date_getDayIndex(dateObj){if(dateObj==null){return ;}

var aDate=new Date(dateObj.year,dateObj.month-1,dateObj.date);return aDate.getDay();}

function date_jsFormat(dateObj){var year=dateObj.year;var month=dateObj.month;var date=dateObj.date;if(date>=0&&date<=9){date="0"+date;}

if(month>=0&&month<=9){month="0"+month;}

var jsFormat=""+year+month+date;return parseInt(jsFormat);}

function date_jsMonthFormat(dateObj){var year=dateObj.year;var month=dateObj.month;if(month>=0&&month<=9){month="0"+month;}

var jsFormat=""+year+month;return parseInt(jsFormat);}
;function date_jsFormatToDateObj(jsFormatStr){var jsFormatStr=jsFormatStr+' ';var year=jsFormatStr.substr(0,4);var month=jsFormatStr.substr(4,2);var firstMonthDigit=month.substr(0,1);var secondMonthDigit=month.substr(1,1);var date=jsFormatStr.substr(6,2);var firstDateDigit=date.substr(0,1);var secondDateDigit=date.substr(1,1);if(firstMonthDigit=="0"){month=secondMonthDigit;}

if(firstDateDigit=="0"){date=secondDateDigit;}

return (new date_ValDate(date,month,year))
}
;function date_toString(dateObj){if(null==dateObj||null==dateObj.date){return "";}

return date_formatDate(dateObj.date,dateObj.month,dateObj.year);}
;function date_parseDBFormat(dateDBFormat){var dateObj=dateDBFormat.split("-");return new date_ValDate(dateObj[2],dateObj[1],dateObj[0]);}

function date_toDbString(dateObj){return date_toDbFormat(dateObj.year,dateObj.month,dateObj.date);}

function date_parseDateString(dateStr){var month=dateStr.substr(0,2);var date=dateStr.substr(3,2);var year=dateStr.substr(6,4);if(month.substr(0,1)==0){month=month.substr(1,1);}

if(date.substr(0,1)==0){date=date.substr(1,1);}

var dateObj=new date_ValDate(date,month,year);return dateObj;}
;function date_getNextDay(dateObj){var date=dateObj.date+1;var month=dateObj.month;var year=dateObj.year;var monthDayCount=date_getMonthDayCount(dateObj);if(date>monthDayCount){date=1;month=month+1;}

if(month>12){month=1;year++;}

return (new date_ValDate(date,month,year));}
;
function date_change(dateObj,numberOfDays){if(0==numberOfDays){return }
;var dayOfYear=numberOfDays;var isLeapYear=date_isLeapYear(dateObj.year);var daysInYear=(isLeapYear)?366:365;var daysInFebruary=(isLeapYear)?29:28;var dayCounts=[0,31,daysInFebruary,31,30,31,30,31,31,30,31,30,31];for(var i=1;i<dateObj.month+1;i++)
{if(i==dateObj.month){dayOfYear+=dateObj.date;break;}

dayOfYear+=dayCounts[i];}

while(dayOfYear>daysInYear)
{dayOfYear=dayOfYear-daysInYear;dateObj.year=dateObj.year+1;isLeapYear=date_isLeapYear(dateObj.year);daysInYear=(isLeapYear)?366:365;}

while(dayOfYear<=0)
{isLeapYear=date_isLeapYear(dateObj.year-1);daysInYear=(isLeapYear)?366:365;dayOfYear=daysInYear+dayOfYear;dateObj.year=dateObj.year-1;}

daysInFebruary=(isLeapYear)?29:28;dayCounts=[0,31,daysInFebruary,31,30,31,30,31,31,30,31,30,31];for(var i=1;i<dayCounts.length;i++)
{var dayCount=dayCounts[i];if(dayCount>=dayOfYear){dateObj.month=i;dateObj.date=dayOfYear;break;}

dayOfYear-=dayCount;}

}
;function date_getPreviousDay(dateObj){var date=dateObj.date-1;var month=dateObj.month;var year=dateObj.year;if(date<1){var previousMonth=date_adjustMonth(dateObj,-1);date=date_getMonthDayCount(previousMonth);month=previousMonth.month;year=previousMonth.year;}

return (new date_ValDate(date,month,year));}
;function date_getMonthDayCount(dateObj){var month=dateObj.month;var dayCounts=new Array(0,31,-1,31,30,31,30,31,31,30,31,30,31);var dayCount=dayCounts[month];if(2==month){dayCount=date_isLeapYear(dateObj.year)?29:28;}

return dayCount;}
;function date_adjustMonth(dateObj,addOrSubtract){var month=dateObj.month+addOrSubtract;var year=dateObj.year;var date=dateObj.date;if(1>month){month+=12;year--;}

else if(12<month){month-=12;year++;}

var newMonthDayCount=date_getMonthDayCount(new date_ValDate(1,month,year));date=Math.min(date,newMonthDayCount);return (new date_ValDate(date,month,year));}
;function date_toJsDateObj(dateObj){return new Date(dateObj.year,dateObj.month-1,dateObj.date);}

function date_getDayString(dateObj,format){if(dateObj==null){return ;}

var aDate=new Date(dateObj.year,dateObj.month-1,dateObj.date);var day=(format==null||format=="full")?date_days[aDate.getDay()]:date_days_short[aDate.getDay()];return day;}

function date_DateInYears(dateObj){if(dateObj==null){return ;}

var currentYear=new Date().getYear();return currentYear-dateObj.year;}
;
function date_filterKeyPress(){var allowKey=(!valutility_isAlphabetic());if(!allowKey){valutility_cancelKeyPress();}

return null;}


function date_isDate(object){var dateString=object.value;if(null==dateString||""==dateString||date_formatGuide==dateString){return ;}

var dateObj=date_toStdFormat(dateString);if(null!=dateObj){object.value=date_formatDate(dateObj.date,dateObj.month,dateObj.year);}

else 
{var errorMessage=date_dateMsgStr1+object.displayName+date_dateMsgStr2;return (new validation_Error(object,errorMessage));}

}

function date_formatEmptyDate(inputEl){if(inputEl.value==""){inputEl.value=date_formatGuide;inputEl.style.color="#999999";}

}

function formatDateForEntry(inputEl){if(inputEl.value==date_formatGuide){inputEl.value="";inputEl.style.color="";}

}

function date_formatDate(date,month,year){var dateString="";dateString+=date_selectDatePart(1,date,month,year)+date_separator;dateString+=date_selectDatePart(2,date,month,year)+date_separator;dateString+=date_selectDatePart(3,date,month,year);return dateString;}

function date_toDbFormat(year,month,date){return year+"-"+date_formatDatePart(month)+"-"+date_formatDatePart(date);}

function date_selectDatePart(partNumber,date,month,year){if(partNumber==date_datePos){return date_formatDatePart(date);}

else if(partNumber==date_monthPos){return date_formatDatePart(month);}

else if(partNumber==date_yearPos){return year;}

}


function date_formatDatePart(number){if(number<10){return "0"+number;}

return number;}

function date_parseDatePart(str){return parseInt(date_stripPrecedingZeros(str));}

function date_stripPrecedingZeros(str){var i=0;while(str.charAt(i)=='0')
{i++;}

return str.substring(i,str.length);}

function date_parseYearPart(str){var year=parseInt(date_stripPrecedingZeros(str));if(year<30){year+=2000;}

else if(year>30&&year<100){year+=1900;}

return year;}

function date_isDateValid(date,month,year){if(isNaN(date)||isNaN(month)||isNaN(year)){return false;}

if(month<1||month>12){return false;}

var daysInMonth=date_getDaysInMonth(month,year);if(date>daysInMonth){return false;}

if(year<1000){return false;}

return true;}

function date_getDaysInMonth(month,year){var dayCounts=new Array(31,-1,31,30,31,30,31,31,30,31,30,31);var dayCount;if(month==2){dayCount=date_isLeapYear(year)?29:28;}

else 
{dayCount=dayCounts[month-1];}

return dayCount;}


function date_getIntervalBetweenDates(dateObj1,dateObj2){var interval=0;var dateObj1JSFormat=date_jsFormat(dateObj1);var dateObj2JSFormat=date_jsFormat(dateObj2);var earlierDateObj=null;var laterDateObj=null;if(dateObj1JSFormat<dateObj2JSFormat){earlierDateObj=dateObj1;laterDateObj=dateObj2;}

else if(dateObj1JSFormat>dateObj2JSFormat){earlierDateObj=dateObj2;laterDateObj=dateObj1;}

else 
{return 0;}

while(!date_isSameThanOtherDate(earlierDateObj,laterDateObj))
{interval++;earlierDateObj=date_getNextDay(earlierDateObj);}

return interval;}
;
function date_getString(dateObj){return date_generateStr(dateObj,arguments,1);}

function date_getFormatedStr(dateObj,format){return date_generateStr(dateObj,format,0);}

function date_generateStr(dateObj,args,index){if(null==dateObj){return "";}
;if(args.length<=1){return date_toString(dateObj);}

var monthStr="";var monthPos=-1;var dateStr="";var datePos=-1;var fullStr="";for(var i=index;i<args.length;i++)
{switch(args[i]){
case"monthAbbreviation":
monthStr=date_months_short[dateObj.month-1];fullStr+="!monthStr!";monthPos=i;break;case"dateAbbreviation":
var suffix=(date_suffix[dateObj.date])?date_suffix[dateObj.date]:"th";dateStr=dateObj.date+suffix;fullStr+="!dateStr!";datePos=i;break;case"dayAbbreviation":
fullStr+=date_days_short[date_getDayIndex(dateObj)];break;case"dayString":
fullStr+=date_days[date_getDayIndex(dateObj)];break;case"monthString":
monthStr=date_months[dateObj.month-1];fullStr+="!monthStr!";monthPos=i;break;case"month":
fullStr+="!monthStr!";monthStr=dateObj.month;monthPos=i;break;case"date":
fullStr+="!dateStr!";dateStr=dateObj.date;datePos=i;break;case"year":
fullStr+=dateObj.year;break;default:
fullStr+=args[i];}

}

var usDateFormat="!monthStr!/!dateStr!/"+dateObj.year;if(fullStr.indexOf(usDateFormat)>-1){fullStr=fullStr.replace(usDateFormat,date_toString(dateObj));}

else 
{var isDefaultMonthFirst=(date_monthPos<date_datePos);var isMonthFirst=(monthPos<datePos);if(isDefaultMonthFirst!=isMonthFirst){if(fullStr.indexOf("!dateStr")>0&&fullStr.indexOf("!monthStr")>0){fullStr=fullStr.replaceAll("!dateStr!",monthStr);fullStr=fullStr.replaceAll("!monthStr!",dateStr);}

else 
{fullStr=fullStr.replaceAll("!monthStr!",monthStr);fullStr=fullStr.replaceAll("!dateStr!",dateStr);}

}

else 
{fullStr=fullStr.replaceAll("!dateStr!",dateStr);fullStr=fullStr.replaceAll("!monthStr!",monthStr);}

}

return fullStr;}

var date_suffix={1:"st",2:"nd",3:"rd",21:"st",22:"nd",23:"rd",31:"st"}
;var date_months_short=new Array();date_months_short[0]="Jan";date_months_short[1]="Feb";date_months_short[2]="Mar";date_months_short[3]="Apr";date_months_short[4]="May";date_months_short[5]="Jun";date_months_short[6]="Jul";date_months_short[7]="Aug";date_months_short[8]="Sep";date_months_short[9]="Oct";date_months_short[10]="Nov";date_months_short[11]="Dec";var date_days_short=new Array();date_days_short[0]="Sun";date_days_short[1]="Mon";date_days_short[2]="Tue";date_days_short[3]="Wed";date_days_short[4]="Thu";date_days_short[5]="Fri";date_days_short[6]="Sat";var date_months=new Array();date_months[0]="January";date_months[1]="February";date_months[2]="March";date_months[3]="April";date_months[4]="May";date_months[5]="June";date_months[6]="July";date_months[7]="August";date_months[8]="September";date_months[9]="October";date_months[10]="November";date_months[11]="December";var date_days=new Array();date_days[0]="Sunday";date_days[1]="Monday";date_days[2]="Tuesday";date_days[3]="Wednesday";date_days[4]="Thursday";date_days[5]="Friday";date_days[6]="Saturday";
function date_isLeapYear(year){if(((year%4)==0)&&((year%100)!=0)||((year%400)==0)){return true;}

else 
{return false;}

}

function date_createDate(date,month,year){if(date_isDateValid(date,month,year)){return (new date_ValDate(date,month,year));}

else 
{return null;}

}

function date_toElegantString(dateObj){if(dateObj==null){return ;}

var aDate=new Date(dateObj.year,dateObj.month-1,dateObj.date);var month=date_months[aDate.getMonth()];var day=date_days[aDate.getDay()];return day+", "+month+" "+dateObj.date+", "+dateObj.year;}

function date_toElegantStringNoDay(dateObj){if(dateObj==null){return ;}

var aDate=new Date(dateObj.year,dateObj.month-1,dateObj.date);var month=date_months[aDate.getMonth()];var day=date_days[aDate.getDay()];return month+" "+dateObj.date+", "+dateObj.year;}

{var time_time=new validation_ValidationType("time",time_isTime);var time_timeBefore=new validation_ValidationType("timebefore",time_isBefore);var time_timeAfter=new validation_ValidationType("timeafter",time_isAfter);}

function time_ValTime(minuteOffset){this.secondOffset=(""==minuteOffset)?0:minuteOffset*60;this.minuteOffset=minuteOffset;}

function time_createTimeWMinute(minuteOffset){return new time_ValTime(minuteOffset*60);}

function time_cloneObj(timeObj){return new time_ValTime(timeObj.secondOffset);}

function time_addMinutes(timeObj,minutesToAdd){timeObj.secondOffset+=minutesToAdd*60;timeObj.minuteOffset+=minutesToAdd;}

function time_filterKeyPress(){var keyCode=crossbrowser_getKeyCode(valutility_currentEvent);var allowKey=(!valutility_isAlphabetic());if(!allowKey&&!time_isValidTimeKey(keyCode)){valutility_cancelKeyPress();}

return null;}

function time_toDbString(thisObj){return time_ensureTwoDigits(time_getHour(thisObj))+":"+
time_ensureTwoDigits(time_getMinute(thisObj))+":00";}

function time_createTime(hour,minute,second){if(null==second){second=0;}

if((hour<0)||(hour>=24)||(minute<0)||(minute>=60)||(second<0)||(second>=60)){return null;}

return new time_ValTime(((hour*3600)+(minute*60)+second));}

function time_stringToTime(timeString){var offset=time_stringToOffset(timeString);return new time_ValTime(offset);}

function time_timeToString(thisObj){if(thisObj.secondOffset==0){return time_offsetTo12Hr(thisObj.secondOffset/60);}

if(thisObj.secondOffset==""){return "";}

return time_offsetTo12Hr(thisObj.secondOffset/60);}

function time_getHourCeiling(timeObj){if(0==timeObj.minuteOffset){return time_getHour(thisObj);}

else 
{return time_getHour(thisObj)+1;}

}

function time_getCurrentTime(){var currentTime=new Date();return time_createTime(currentTime.getHours(),currentTime.getMinutes(),currentTime.getSeconds());}

function time_getHour(thisObj){return Math.floor(thisObj.secondOffset/3600);}

function time_getMinute(thisObj){var hoursRemoved=thisObj.secondOffset%3600;return Math.floor(hoursRemoved/60);}

function time_stringToOffset(timeString){var re=new RegExp("(\\d\\d*)(:?)(\\d*)\\s*([ap]?)","g");var result=re.exec(timeString.toLowerCase());if(null==result){return -1;}

var hour;var minute;var isPM;if(""==result[2]){if(result[1].length==3){hour=parseInt(result[1].charAt(0));minute=parseInt(result[1].charAt(1)+result[1].charAt(2));}

else if(result[1].length==4){hour=parseInt(result[1].charAt(0)+result[1].charAt(1));minute=parseInt(result[1].charAt(2)+result[1].charAt(3));}

else 
{return -1;}

}

else 
{hour=parseInt(result[1]);minute=parseInt(result[3]);}

if(minute<0||minute>59||isNaN(minute)||isNaN(hour)){return -1;}

var timeOffset;if(time_use24HourFormat){if(hour<0||hour>23){return -1;}

timeOffset=time_24HrToOffset(hour,minute);}

else 
{if(hour<1||hour>12){return -1;}

isPM=("p"==result[4])?true:false;timeOffset=time_12HrToOffset(hour,minute,isPM);}

return timeOffset;}

function time_isTime(object){var time=object.value;if(null==time||""==time){return ;}

var timeOffset=time_stringToOffset(time)
if(timeOffset==-1){var errorMessage=time_timeMsgStr1+object.displayName+time_timeMsgStr2;return (new validation_Error(object,errorMessage));}

object.value=(time_use24HourFormat)?time_offsetTo24Hr(timeOffset):time_offsetTo12Hr(timeOffset);}

function time_isAfter(object){var otherField=document.getElementById(object.timeAfter);if(null==otherField){return ;}

var fieldValue=time_stringToOffset(object.value);var otherValue=time_stringToOffset(otherField.value);if((-1==fieldValue)||(-1==otherValue)){return ;}

if(fieldValue<=otherValue){var errorMessage=time_afterTimeMsgStr1+object.displayName+time_afterTimeMsgStr2+
otherField.displayName+time_afterTimeMsgStr3;return (new validation_Error(object,errorMessage));}

}

function time_isBefore(object){var otherField=document.getElementById(object.timeBefore);if(null==otherField){return ;}

var fieldValue=time_stringToOffset(object.value);var otherValue=time_stringToOffset(otherField.value);if((-1==fieldValue)||(-1==otherValue)){return ;}

if(fieldValue>=otherValue){var errorMessage=time_beforeTimeMsgStr1+object.displayName+time_beforeTimeMsgStr2+
otherField.displayName+time_beforeTimeMsgStr3;return (new validation_Error(object,errorMessage));}

}

function time_isBeforeOther(timeObj,otherTimeObj){return (timeObj.minuteOffset<otherTimeObj.minuteOffset);}


function time_offsetTo12Hr(offset){if(offset>=0&&offset<60){return "12:"+time_ensureTwoDigits(offset)+"AM";}

else if(offset>=60&&offset<720){var hour=Math.floor(offset/60);var minute=offset%60;return hour+":"+time_ensureTwoDigits(minute)+"AM";}

else if(offset>=720&&offset<780){var minute=offset%60;return "12:"+time_ensureTwoDigits(minute)+"PM";}

else if(offset>=780&&offset<1440){offset-=12*60;var hour=Math.floor(offset/60);var minute=offset%60;return hour+":"+time_ensureTwoDigits(minute)+"PM";}

}

function time_offsetTo24Hr(offset){var hour=Math.floor(offset/60);var minute=offset%60;return time_ensureTwoDigits(hour)+":"+time_ensureTwoDigits(minute);}

function time_ensureTwoDigits(number){var numberStr=number.toString()
var dot=numberStr.indexOf(".");if(dot!=-1){number=parseInt(numberStr.substring(0,dot));}

if(number<10){return "0"+number;}

return number;}

function time_12HrToOffset(hour,minute,isPM){var minuteOffset=hour*60+minute;if(isPM){minuteOffset+=60*12;}

if(hour==12){minuteOffset-=60*12;}

return minuteOffset;}

function time_24HrToOffset(hour,minute){return hour*60+minute;}

function userstamp_UserStamp(name,displayName,displayOrder,userName,doUpdate,userId){this.doUpdate=doUpdate
this.userName=userName;this.userId=userId;this.TYPE="USERSTAMP";this.TYPE_DISPLAY_NAME="User Stamp";this.ownerRecord;this.ownerCache;this.parentField;this.name=name;this.displayName=displayName;this.displayOrder=displayOrder
this.isVisible=true;this.isEditable=false;this.children=null;this.fieldContainer=null;this.init=function(){}

this.buildChildFields=function(){userstamp_buildChildFields(this);}

this.buildHTML=function(){return userstamp_buildHTML(this);}

this.buildSettingsHTML=function(){return userstamp_buildSettingsHTML(this);}

this.toXml=function(){return userstamp_toXml(this);}

this.clone=function(){return userstamp_clone(this);}

this.buildSearchTerm=function(searchType){return userstamp_buildSearchterm(searchType)}
;}

function userstamp_objectToField(object,name){var field=new userstamp_UserStamp(name,"",0,"",false,0);return field;}

if(window.registerConverter){registerConverter("USERSTAMP",userstamp_objectToField);}

function userstamp_buildChildFields(thisObj){thisObj.children=new Array();thisObj.children['do_update']=new field_Boolean("do_update","Update?",2.0,thisObj.doUpdate,true);thisObj.children["user_name"]=new field_String("user_name","User Name",2.0,thisObj.userName,false);thisObj.children["user_id"]=new field_Integer("user_id","User Id",2.0,thisObj.userId,false);}

function userstamp_buildHTML(thisObj){if(thisObj.fieldContainer==null){thisObj.fieldContainer=document.createElement("span");}

var dataSpan=document.createElement("span");dataSpan.innerHTML=thisObj.userName;thisObj.fieldContainer.appendChild(dataSpan);return thisObj.fieldContainer;}

function userstamp_buildSettingsHTML(thisObj){var container=document.createElement("div")
var table=document.createElement("table");container.appendChild(table);var tbody=document.createElement("tbody");table.appendChild(tbody);var tr=document.createElement("tr");tbody.appendChild(tr);var td=document.createElement("td");td.vAlign="top";tr.appendChild(td);var doUpdate=document.createElement("input");doUpdate.type="checkbox";doUpdate.defaultChecked=(thisObj.doUpdate)?true:false;doUpdate.onclick=function(){thisObj.doUpdate=(this.checked)?true:false}
;td.appendChild(doUpdate);var td=document.createElement("td");td.className="architectReadOnly";tr.appendChild(td);var div=document.createElement("div");div.innerHTML="Update On Save?"
td.appendChild(div);return container;}

function userstamp_toXml(thisObj){userstamp_buildChildFields(thisObj);var xml=util_openFieldXmlTag(thisObj);for(var i in thisObj.children)
{xml+=thisObj.children[i].toXml();}

xml+=util_closeFieldXmlTag();return xml;}

function userstamp_clone(thisObj){return new userstamp_UserStamp(thisObj.name,thisObj.displayName,thisObj.displayOrder,thisObj.userName,thisObj.doUpdate,thisObj.userId);}

function field_DateTime(name,displayName,displayOrder,year,month,date,time){this.dateObj=date_createDate(date,month,year);this.timeObj=new time_ValTime(time);this.getDateFullString=function(){return dt_getFullDateTimeString(this)}
;this.getDateSimpleString=function(){return dt_getDateValueString(this)+" "+dt_getTimeValueString(this)}
;this.time=(time=="")?-1:parseInt(time);this.getDate=function(){return this.dateObj.date}

this.getDay=function(format){return date_getDayString(this.dateObj,format)}
;this.getMonth=function(format){return this.dateObj.getMonthStr(this.dateObj.month-1,format)}
;this.getYear=function(){return this.dateObj.year}

this.getTime=function(){return dt_getTimeValueString(this)}
;this.getDateStr=function(){var str="------";if(this.dateObj){str=date_toElegantStringNoDay(this.dateObj);}

return str;}
;this.buildDateComponent=function(){return df_buildDateComponent(this)}
;this.buildTimeComponent=function(){return dt_buildTimeComponent(this)}
;this.buildCalendarComponent=function(parentElement){df_buildCalendarComponent(this,parentElement)}
;this.setDateObj=function(date,month,year){this.dateObj=date_createDate(date,month,year)}
;this.setTimeObj=function(timeInMinutes){this.timeObj.secondOffset=timeInMinutes*60;this.timeObj.minuteOffset=timeInMinutes;}

this.input=null;this.isDateBefore=function(anotherObj){return dt_isDateBefore(this,anotherObj)}
;this.getTimeInMinutes=function(){return (!this.timeObj)?0:this.timeObj.minuteOffset}
;this.TYPE="DATETIME";this.TYPE_DISPLAY_NAME="Date/Time";this.ownerRecord;this.ownerCache;this.parentField;this.name=name;this.displayName=displayName;this.displayOrder=displayOrder
this.isVisible=true;this.isEditable=false;this.children=new Array();this.fieldContainer=null;this.init=function(){dt_init(this);}

this.buildChildFields=function(){dt_buildChildFields(this);}

this.buildHTML=function(){return dt_buildHTML(this);}

this.buildSettingsHTML=function(){return dt_buildSettingsHTML(this);}

this.toXml=function(){return dt_toXml(this);}

this.clone=function(){return dt_clone(this);}

this.buildSearchTerm=function(searchType){return dt_buildSearchterm(searchType)}
;}

function dtf_objectToField(object,name){if(!object){object=[];object.date=null;object.time=null;}

var field=new field_DateTime(name,"",0,-1,-1,-1,-1);field.dateObj=object.date;field.timeObj=object.time;return field;}

if(window.registerConverter){registerConverter("DATETIME",dtf_objectToField);}

function dt_isDateBefore(thisObj,anotherObj){var isBefore=true;var thisTimeOffset=thisObj.timeObj.secondOffset;var anotherTimeOffset=anotherObj.timeObj.secondOffset;var isDateBefore=date_isBeforeOtherDate(thisObj.dateObj,anotherObj.dateObj)
if(!isDateBefore){isBefore=false;}

return isBefore;}

function dt_buildTimeComponent(thisObj){var input=document.createElement("input");input.type="text";input.value=dt_getTimeValueString(thisObj);input.style.width=150;input.maxLength=7;input.displayName=thisObj.displayName;input.field=thisObj;input.onchange=function(){var errorList=validation_validateField(this);if(errorList.length==0){thisObj.timeObj=time_stringToTime(this.value);}

}

validation_attachValidationToElement(input);return input;}

function dt_getFullDateTimeString(thisObj){var dateStr=thisObj.dateObj.getElegantString();dateStr+=" "+dt_getTimeValueString(thisObj)
return dateStr;}

function dt_buildSearchterm(searchType){if(searchType=="interval"){alert("build interval search  type");}

else 
{alert("build search  by date conditional");}

return "";}

function dt_getDateValueString(thisObj){return (thisObj.dateObj!=null&&thisObj.dateObj!=undefined)?date_formatDate(thisObj.dateObj.date,thisObj.dateObj.month,thisObj.dateObj.year):"";}

function dt_getTimeValueString(thisObj){return (thisObj.timeObj!=null&&thisObj.timeObj!=undefined)?time_timeToString(thisObj.timeObj):"";}

function dt_init(thisObj){}

function dt_buildChildFields(thisObj){thisObj.children.isGMT=new field_Boolean("isGMT","",0,false,false);}

function dt_buildHTML(thisObj){if(thisObj.fieldContainer==null){thisObj.fieldContainer=document.createElement("span");}

if(thisObj.isEditable){dt_buildEditableHTML(thisObj);}

else 
{dt_buildReadOnlyHTML(thisObj);}

return thisObj.fieldContainer;}

function dt_buildEditableHTML(thisObj){var table=document.createElement("table");thisObj.fieldContainer.appendChild(table);var tbody=document.createElement("tbody");table.appendChild(tbody);var tr=document.createElement("tr");tbody.appendChild(tr);var td=document.createElement("td");tr.appendChild(td);var input=document.createElement("input");input.type="text";input.value=dt_getDateValueString(thisObj);input.style.width=150;input.maxLength=10;input.validationType="date";input.displayName=thisObj.displayName;input.field=thisObj;input.onchange=function(){var errorList=validation_validateField(this);if(errorList.length==0){thisObj.dateObj=date_toStdFormat(this.value);}

}

validation_attachValidationToElement(input);td.appendChild(input);var td=document.createElement("td");tr.appendChild(td);var input=document.createElement("input");input.type="text";input.value=dt_getTimeValueString(thisObj);input.style.width=150;input.maxLength=10;input.validationType="time";input.displayName=thisObj.displayName;input.field=thisObj;input.onchange=function(){var errorList=validation_validateField(this);if(errorList.length==0){thisObj.timeObj=time_stringToTime(this.value);}

}

validation_attachValidationToElement(input);td.appendChild(input);}

function dt_buildReadOnlyHTML(thisObj){var dataSpan=document.createElement("span");var value=dt_getDateValueString(thisObj)+" "+dt_getTimeValueString(thisObj);dataSpan.innerHTML=(value!="")?value:"&nbsp";dataSpan.className=thisObj.readOnlyClass;thisObj.fieldContainer.appendChild(dataSpan);}

function dt_buildSettingsHTML(thisObj){var container=document.createElement("div")
container.style.margin=10;var span=document.createElement("span");span.innerHTML="Date: ";span.className="architectReadOnly";container.appendChild(span);var input=document.createElement("input");input.type="text";input.value=dt_getDateValueString(thisObj);input.className="architectInput";input.style.width=100;input.validationType="date";input.field=thisObj;input.onchange=function(){var errorList=validation_validateField(this);if(errorList.length==0){thisObj.dateObj=date_toStdFormat(this.value);}

}

validation_attachValidationToElement(input);container.appendChild(input);var span=document.createElement("span");span.innerHTML="Time:  ";span.className="architectReadOnly";container.appendChild(span);var input=document.createElement("input");input.type="text";input.value=dt_getTimeValueString(thisObj);input.className="architectInput";input.style.width=100;input.validationType="time";input.field=thisObj;input.onchange=function(){var errorList=validation_validateField(this);if(errorList.length==0){thisObj.timeObj=time_stringToTime(this.value);}

}

validation_attachValidationToElement(input);container.appendChild(input);return container;}

function dt_toXml(thisObj){thisObj.buildChildFields();var xml=constants_LESS_THAN_CHAR+"f ";xml+="name='"+thisObj.name;xml+="' dn='"+util_formatForXmlValue(thisObj.displayName);xml+="' type='"+thisObj.TYPE;xml+="' do='"+thisObj.displayOrder;if(thisObj.dateObj!=null&&thisObj.timeObj!=null){var dateTime=date_toDbFormat(thisObj.dateObj.year,thisObj.dateObj.month,thisObj.dateObj.date);dateTime+=" "+time_toDbString(thisObj.timeObj);xml+="' value='"+dateTime+"'>";}

else 
{xml+="'  value=''>";}

xml+=thisObj.children.isGMT.toXml();xml+=util_closeFieldXmlTag();return xml;}

function dt_clone(thisObj){var field;if(null==thisObj.dateObj||thisObj.timeObj==null){field=new field_DateTime(thisObj.name,thisObj.displayName,thisObj.displayOrder,"","","","");}

else 
{field=new field_DateTime(thisObj.name,thisObj.displayName,thisObj.displayOrder,thisObj.dateObj.year,thisObj.dateObj.month,thisObj.dateObj.date,thisObj.timeObj.minuteOffset);}

return field
}

function field_Integer(name,displayName,displayOrder,value,isStatic){this.TYPE="INTEGER";this.TYPE_DISPLAY_NAME="Integer";this.ownerRecord;this.ownerCache;this.parentField;this.name=name;this.displayName=displayName;this.displayOrder=displayOrder
this.value=(value==null)?"":value;this.isStatic=isStatic;this.init=function(){}
;this.buildHTML=function(){return intp_buildHTML(this)}
;this.buildSettingsHTML=function(){return document.createElement("span");}
;this.toXml=function(){return intp_toXml(this)}
;this.clone=function(){return new field_Integer(this.name,this.displayName,this.displayOrder,this.value,this.isStatic)}
;this.getValue=function(){return this.value;}
;this.setValue=function(value){this.value=value;}

}

function integer_objectToField(object,name){var field=new field_Integer(name,"",0,object,false);return field;}

if(window.registerConverter){registerConverter("INTEGER",integer_objectToField);}

function intp_buildHTML(thisObj){if(thisObj.fieldContainer==null){thisObj.fieldContainer=document.createElement("span");}

var span=document.createElement("span");span.innerHTML=thisObj.value;span.className="architectReadOnly";thisObj.fieldContainer.appendChild(span);return thisObj.fieldContainer;}

function intp_toXml(thisObj){var xml=constants_LESS_THAN_CHAR+"f ";xml+="name='"+thisObj.name;xml+="' dn='"+util_formatForXmlValue(thisObj.displayName);xml+="' type='"+thisObj.TYPE;xml+="' do='"+thisObj.displayOrder;xml+="' value='"+thisObj.value;xml+="' is_static='"+thisObj.isStatic+"'/>";return xml;}

;;;function field_RecordType(name,displayName,displayOrder,selectedType,selectedId,createRecord,deleteRecord,isTypeStatic){this.selectRecord=function(){rt_startRecordSearch(this)}
;this.selectedType=selectedType;this.selectedId=selectedId;this.createRecord=createRecord;this.deleteRecord=deleteRecord;this.isTypeStatic=isTypeStatic;this.embeddedRecord=null;this.TYPE="RECORD_TYPE";this.TYPE_DISPLAY_NAME="Record Type";this.ownerRecord;this.ownerCache;this.parentField;this.name=name;this.displayName=displayName;this.displayOrder=displayOrder
this.isEditable=false;this.isVisible=true;this.children=new Array();this.fieldContainer=null;this.buildChildFields=function(){rt_buildChildFields(this)}
;this.buildSettingsHTML=function(){return rt_buildSettingsHTML(this)}
;this.buildHTML=function(){return rt_buildHTML(this)}
;this.toXml=function(){return rt_toXml(this)}
;this.init=function(){rt_init(this)}
;this.clone=function(){return rt_clone(this)}
;}

function rt_objectToField(object,name){var field=new field_RecordType(name,"","",object.type,object.id,object.createRecord,object.deleteRecord,object.isStatic);return field;}

if(window.registerConverter){registerConverter("RECORD_TYPE",rt_objectToField);}

function rt_buildHTML(thisObj){return document.createElement("span");
}


function rt_buildSettingsHTML(thisObj){var container=document.createElement("div")
container.style.margin=10;var table=document.createElement("table");table.cellSpacing=4;table.cellpadding=4;container.appendChild(table)
var tbody=document.createElement("tbody");table.appendChild(tbody);var tr=document.createElement("tr");tbody.appendChild(tr);if(thisObj.selectedType==""){var td=document.createElement("td");tr.appendChild(td);var span=document.createElement("span");span.innerHTML="Select a Type :  ";span.className="architectReadOnly";td.appendChild(span);var td=document.createElement("td");tr.appendChild(td);var dropdown=rt_buildTypeDD(thisObj);td.appendChild(dropdown);}

else 
{var td=document.createElement("td");tr.appendChild(td);var span=document.createElement("span");span.innerHTML="Selected Type :  ";span.className="architectReadOnly";td.appendChild(span);var td=document.createElement("td");tr.appendChild(td);var span=document.createElement("span");span.innerHTML=g_cache.typeList[thisObj.selectedType].displayName;span.style.fontWeight="bold";span.className="architectReadOnly";td.appendChild(span);}

var td=document.createElement("td");tr.appendChild(td);var input=document.createElement("input");input.type="checkbox";input.value=thisObj.createRecord;input.defaultChecked=(thisObj.createRecord)?true:false;input.onclick=function(event){thisObj.createRecord=(this.checked)?true:false;crossbrowser_cancelBubble(event);}
;td.appendChild(input);var td=document.createElement("td");tr.appendChild(td);var span=document.createElement("span");span.innerHTML=" Create Record?";span.className="architectReadOnly";td.appendChild(span);var td=document.createElement("td");tr.appendChild(td);var input=document.createElement("input");input.type="checkbox";input.value=thisObj.deleteRecord;input.defaultChecked=(thisObj.deleteRecord)?true:false;input.onclick=function(event){thisObj.deleteRecord=(this.checked)?true:false;crossbrowser_cancelBubble(event);}
;td.appendChild(input);var td=document.createElement("td");tr.appendChild(td);var span=document.createElement("span");span.innerHTML=" Delete Record?";span.className="architectReadOnly";td.appendChild(span);var td=document.createElement("td");tr.appendChild(td);var input=document.createElement("input");input.type="checkbox";input.value=thisObj.isTypeStatic;input.defaultChecked=(thisObj.isTypeStatic)?true:false;input.onclick=function(event){thisObj.isTypeStatic=this.checked;crossbrowser_cancelBubble(event);}
;td.appendChild(input);var td=document.createElement("td");tr.appendChild(td);var span=document.createElement("span");span.innerHTML=" Is Type Static?";span.className="architectReadOnly";td.appendChild(span);return container;}

function rt_buildChildFields(thisObj){thisObj.children['type']=new field_String('type','Type',2.0,thisObj.selectedType,thisObj.isTypeStatic);thisObj.children['id']=new field_Integer('id','id',2.0,thisObj.selectedId,false);thisObj.children['createRecord']=new field_Boolean("createRecord","Create Record?",4.0,thisObj.createRecord,true);thisObj.children['deleteRecord']=new field_Boolean("deleteRecord","Delete Record?",4.0,thisObj.deleteRecord,true);}

function rt_clone(thisObj){var field=new field_RecordType(thisObj.name,thisObj.displayName,thisObj.displayOrder,thisObj.selectedType,thisObj.selectedId,thisObj.createRecord,thisObj.deleteRecord)
if(field.createRecord){field.embeddedRecord=g_cache.getTemplate(field.selectedType).clone();field.selectedId=field.embeddedRecord.id;field.embeddedRecord.toSave=true;g_cache.recordsById[field.embeddedRecord.type+field.embeddedRecord.id]=field.embeddedRecord;g_cache.addRecord(field.embeddedRecord);}

return field;}

function rt_init(thisObj){for(var i in thisObj.children)
{thisObj.children[i].ownerCache=thisObj.ownerCache;thisObj.children[i].ownerRecord=thisObj.ownerRecord;thisObj.children[i].parentField=thisObj;thisObj.children[i].init();}

}

function rt_toXml(thisObj){if(thisObj.embeddedRecord!=null&&thisObj.ownerRecord.toSave){thisObj.embeddedRecord.toSave=true;thisObj.embeddedRecord.toLoad=true;}

thisObj.buildChildFields();var xml=util_openFieldXmlTag(thisObj);for(var i in thisObj.children)
{if(thisObj.children[i]!=null){xml+=thisObj.children[i].toXml();}

}

return xml+=util_closeFieldXmlTag();}


function changepassword_ChangePassword(){this.buildUsernameInput=function(){return this.children.userName.buildInputElement();}
;this.buildPasswordInput=function(){this.children.password.isEditable=true;this.children.password.buildHTML();return this.children.password.input;}
;this.buildButton=function(){return changepassword_buildButton(this)}
;this.getValue=function(){return this.children.password.value}
;this.setPassword=function(userName,password){changepassword_setPassword(this,userName,password)}
;this.TYPE="CHANGE_PASSWORD";this.TYPE_DISPLAY_NAME="Change  Password";this.ownerRecord;this.ownerCache;this.parentField;this.value=null;this.isEditable=false;this.isVisible=true;this.children=new Array();this.children.userName=new field_String("userName","userName",0,"",false);this.children.password=new field_Pw("password","",0.0);this.children.password.doSave=true;this.fieldContainer=null;this.init=function(){changepassword_init(this);}

this.buildHTML=function(){return changepassword_buildHTML(this);}

this.buildSettingsHTML=function(){return null;}

this.toXml=function(){return changepassword_toXml(this);}

this.clone=function(){return null}
;}

function changepassword_setPassword(thisObj,userName,password){thisObj.children.password.value=password;thisObj.children.userName.value=userName;}

function changepassword_buildButton(thisObj){var button=document.createElement("button");button.innerHTML="Change   Password";button.onclick=function(){thisObj.ownerCache.submitCache("go")}
;return button;}

function changepassword_init(thisObj){for(var i in thisObj.children)
{thisObj.children[i].ownerCache=thisObj.ownerCache;thisObj.children[i].ownerRecord=thisObj.ownerRecord;thisObj.children[i].parentField=thisObj;thisObj.children[i].init();}

}

function changepassword_toXml(thisObj){var xml=util_openFieldXmlTag(thisObj);for(var name in thisObj.children)
{xml+=thisObj.children[name].toXml();}

xml+=util_closeFieldXmlTag();return xml;}

function validateusername_Validate(requestHandler,userName){var path="ValidateUserName.ajax";var xmlRequest=ajax_getXMLHttpRequest();var url=path+"?userName="+userName;xmlRequest.open("POST",url,false);xmlRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded;  charset=utf-8");xmlRequest.send(null);do
{if(xmlRequest.readyState==4){if(xmlRequest.status==200){requestHandler(eval(xmlRequest.responseText));}

else 
{alert("HTTP error: "+xmlRequest.status);}

}

}

while(xmlRequest.readyState!=4)}

CONTENT_MARKER_BEGIN='vml.4ssjjtuihgx2UtnmqCu0';


;;;;;;;;;;;;;;;;;;;;;;;;function buildLoginBox(parentEl){buildLoginArea(parentEl);}

function buildLoginArea(parentEl){var tbody=createTable(parentEl,365);var table=tbody.parentNode;table.style.border="1px solid "+rgbToHex(202,202,187);if(g_failedLogin){eraseCookie("remember_me");var tr=cE("tr",tbody);var td=cE("td",tr);td.colSpan=2;td.align="center";buildFailedLoginAlert(td);}

var tr=cE("tr",tbody);var td=cE("td",tr);td.className="text";td.style.paddingBottom="5px";td.style.color=rgbToHex(102,102,102);td.width="90px";td.style.height="45px";td.align="right";td.vAlign="bottom";td.style.verticalAlign="bottom";td.innerHTML="Username:";var td=cE("td",tr);td.vAlign="bottom";td.style.textAlign="left";td.style.padding="9px 20px 0px 9px";td.style.verticalAlign="bottom";g_loginUtil.idHolder=td;var tr=cE("tr",tbody);var td=cE("td",tr);td.style.color=rgbToHex(102,102,102);td.style.paddingTop="12px";td.style.verticalAlign="top";td.style.height="20px";td.align="right";td.style.textAlign="right";td.innerHTML="Password:";var td=cE("td",tr);td.style.color=rgbToHex(102,102,102);td.style.padding="12px 20px 0px  9px";g_loginUtil.passwordHolder=td;var tr=cE("tr",tbody);var td=cE("td",tr);td.innerHTML="&nbsp";var td=cE("td",tr);td.style.padding="15px 0px 0px 9px";td.style.textAlign="left";var loginB=cb(td,"LOGIN");loginB.style.fontSize="11px";loginB.style.fontWeight="bold";loginB.style.color="#006699";loginB.style.height="30px";loginB.style.width="80px";g_loginUtil.loginEl=loginB;
var tr=cE("tr",tbody);var td=cE("td",tr);td.innerHTML="&nbsp";var td=cE("td",tr);td.style.paddingLeft="9px";td.style.paddingTop="10px";td.style.paddingBottom="10px";td.style.textAlign="left";g_loginUtil.passwordRecoveryHolder=td;}

function buildFailedLoginAlert(parentEl){var div=cE("div",parentEl);div.style.backgroundColor="#ffebe8";div.style.border="1px solid  red";div.style.padding="5px";div.align="left";var p=cE("p",div);p.style.fontSize="11px";p.style.fontWeight="bold";p.style.margin="0px";p.style.padding="0px";p.innerHTML="Incorrect Username/Password  combination";var p=cE("p",div);p.style.fontSize="11px";p.style.margin="0px";p.style.padding="0px";p.innerHTML="Passwords are  case-senstive. Please check your Caps  Lock  key.";}

function rgbToHex(red,green,blue){return "#"+decToHex(red)+decToHex(green)+decToHex(blue);}

function decToHex(decimal){var hexChars="0123456789ABCDEF";var a=decimal%16;var b=(decimal-a)/16;var hex=""+hexChars.charAt(b)+hexChars.charAt(a);return hex;}

CONTENT_MARKER_END='vml.4ssjjtuihgx2UtnmqCu0';

CONTENT_MARKER_BEGIN='vml.4ssjjtuihgx2UtnmqTiwqqv';

;;;;;;var g_failedLogin=false;var g_loginUtil=null;function buildScreen(){g_loginUtil=new login_LoginUtil();var rememberMe=readCookie("remember_me");if(rememberMe){g_loginUtil.logUser();}

else 
{var container=document.getElementById("loginBox");container.align="center";buildLoginBox(container);g_loginUtil.buildHTML();}
;}

CONTENT_MARKER_END='vml.4ssjjtuihgx2UtnmqTiwqqv';
