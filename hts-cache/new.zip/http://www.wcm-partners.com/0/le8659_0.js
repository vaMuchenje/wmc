

function setFolderCreator(fieldName,miniCache,name,parentPageId){var fCreator=createGEToRunFirst(fieldName,miniCache,"FolderCreator");var params=fCreator.getChildField("exec_params");params.addChildField("name","TEXT",name);params.addChildField("parent_page_id","INTEGER",parentPageId);return fCreator;}
;{var sl_onAfterFx=sl_onAfterLoadFx['/0/le8659_0.js'];if(sl_onAfterFx){sl_onAfterFx();}}